cmake_minimum_required(VERSION 3.21)
project(tis_compiler VERSION 4.1 LANGUAGES CXX) # 4.1.0 module模块支持自构建 

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# 标准化架构名称
if (CMAKE_SYSTEM_PROCESSOR STREQUAL "AMD64" OR CMAKE_SYSTEM_PROCESSOR STREQUAL "x86_64")
    set(TARGET_ARCH "x64")
elseif (CMAKE_SYSTEM_PROCESSOR STREQUAL "aarch64")
    set(TARGET_ARCH "arm64")
else()
    message(FATAL_ERROR "Unsupported architecture: ${CMAKE_SYSTEM_PROCESSOR}")
endif()
# 检查当前平台
if (CMAKE_SYSTEM_NAME STREQUAL "Windows")
    set(TARGET_OS "windows")
    add_compile_options(/utf-8)
elseif (CMAKE_SYSTEM_NAME STREQUAL "Linux")
    set(TARGET_OS "linux")
elseif (CMAKE_SYSTEM_NAME STREQUAL "Darwin") 
    set(TARGET_OS "macos")
else()
    message(FATAL_ERROR "Unsupported platform: ${CMAKE_SYSTEM_NAME}")
endif()
# 动态设置输出目录
string(TOLOWER "${CMAKE_BUILD_TYPE}" BUILD_TYPE_LOWER)

# 设置运行目录
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_SOURCE_DIR}/${TARGET_ARCH}-${TARGET_OS}-${BUILD_TYPE_LOWER}")
message("=================== Platform Begin ===================")
message("Build Type: ${BUILD_TYPE_LOWER}")
if(CMAKE_BUILD_TYPE STREQUAL "Release")
    message("Release flags: ${CMAKE_CXX_FLAGS_RELEASE}")
endif()
message("Target Platform: ${TARGET_ARCH}-${TARGET_OS}")
message("current compiler: ${CMAKE_CXX_COMPILER_ID}")
message("Output Directory: ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}")
message("=================== Platform End   ===================")
file(GLOB_RECURSE SRC_MAIN CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/src/*.h ${CMAKE_CURRENT_SOURCE_DIR}/src/*.cpp)
set(APP_MAIN ${CMAKE_CURRENT_SOURCE_DIR}/src/main.cpp)
list(REMOVE_ITEM SRC_MAIN ${APP_MAIN})

add_library(tis_compiler_lib
${SRC_MAIN}
)

add_executable(${PROJECT_NAME}
${APP_MAIN}
)

target_link_libraries(${PROJECT_NAME} PRIVATE tis_compiler_lib)
target_include_directories(tis_compiler_lib PUBLIC ${CMAKE_SOURCE_DIR}/src)
target_include_directories(${PROJECT_NAME} PUBLIC ${CMAKE_SOURCE_DIR}/src)
set_target_properties(${PROJECT_NAME} PROPERTIES
    WIN32_EXECUTABLE FALSE
)

enable_testing()

add_executable(tis_compiler_regression_tests
    ${CMAKE_CURRENT_SOURCE_DIR}/tests/ReflectionGeneratorTests.cpp
)
target_link_libraries(tis_compiler_regression_tests PRIVATE tis_compiler_lib)
target_compile_definitions(tis_compiler_regression_tests PRIVATE TIS_COMPILER_SOURCE_DIR="${CMAKE_SOURCE_DIR}")
add_test(NAME tis_compiler_regression_tests COMMAND tis_compiler_regression_tests)



