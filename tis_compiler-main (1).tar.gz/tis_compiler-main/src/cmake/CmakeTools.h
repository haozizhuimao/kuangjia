#pragma once

#include <string>
#include <unordered_set>
#include <vector>

class CmakeTools
{
  public:
    static std::string readCmake(const std::string &filePath);
    static std::vector<std::string> commandLines(const std::string &content, const std::string &commandName);
    static std::vector<std::string> extractListValues(const std::string &content, const std::string &varName);
    static std::unordered_set<std::string> extractTargetKitNames(const std::string &content, const std::string &targetName);
};
