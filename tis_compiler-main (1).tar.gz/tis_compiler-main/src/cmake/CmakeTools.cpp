#include "cmake/CmakeTools.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <regex>
#include <sstream>
#include <unordered_set>

namespace
{
    struct CommandMatch
    {
        std::string name;
        std::string body;
    };

    bool isIdentifierChar(char ch)
    {
        const auto uch = static_cast<unsigned char>(ch);
        return std::isalnum(uch) || ch == '_';
    }

    std::string toLowerCopy(const std::string &value)
    {
        std::string lower = value;
        std::transform(lower.begin(), lower.end(), lower.begin(), [](char ch) {
            return static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        });
        return lower;
    }

    size_t skipWhitespace(const std::string &content, size_t pos)
    {
        while (pos < content.size() && std::isspace(static_cast<unsigned char>(content[pos])))
        {
            ++pos;
        }
        return pos;
    }

    size_t findCommandEnd(const std::string &content, size_t openParenPos)
    {
        bool inDoubleQuote = false;
        bool inSingleQuote = false;
        bool escaped = false;
        int depth = 0;

        for (size_t pos = openParenPos; pos < content.size(); ++pos)
        {
            const char ch = content[pos];

            if (escaped)
            {
                escaped = false;
                continue;
            }

            if ((inDoubleQuote || inSingleQuote) && ch == '\\')
            {
                escaped = true;
                continue;
            }

            if (ch == '"' && !inSingleQuote)
            {
                inDoubleQuote = !inDoubleQuote;
                continue;
            }

            if (ch == '\'' && !inDoubleQuote)
            {
                inSingleQuote = !inSingleQuote;
                continue;
            }

            if (inDoubleQuote || inSingleQuote)
            {
                continue;
            }

            if (ch == '(')
            {
                ++depth;
            }
            else if (ch == ')')
            {
                --depth;
                if (depth == 0)
                {
                    return pos;
                }
            }
        }

        return std::string::npos;
    }

    size_t findLineCommentStart(const std::string &content, size_t lineStart, size_t lineEnd)
    {
        bool inDoubleQuote = false;
        bool inSingleQuote = false;
        bool escaped = false;

        for (size_t pos = lineStart; pos < lineEnd; ++pos)
        {
            const char ch = content[pos];

            if (escaped)
            {
                escaped = false;
                continue;
            }

            if ((inDoubleQuote || inSingleQuote) && ch == '\\')
            {
                escaped = true;
                continue;
            }

            if (ch == '"' && !inSingleQuote)
            {
                inDoubleQuote = !inDoubleQuote;
                continue;
            }

            if (ch == '\'' && !inDoubleQuote)
            {
                inSingleQuote = !inSingleQuote;
                continue;
            }

            if (!inDoubleQuote && !inSingleQuote && ch == '#')
            {
                return pos;
            }
        }

        return lineEnd;
    }

    std::vector<CommandMatch> findCommands(const std::string &content, const std::string &commandName)
    {
        std::vector<CommandMatch> matches;
        const auto normalizedCommandName = toLowerCopy(commandName);
        if (normalizedCommandName.empty())
        {
            return matches;
        }

        const auto contentLower = toLowerCopy(content);
        size_t searchPos = 0;
        while (searchPos < contentLower.size())
        {
            const auto pos = contentLower.find(normalizedCommandName, searchPos);
            if (pos == std::string::npos)
            {
                break;
            }

            if (pos > 0 && isIdentifierChar(contentLower[pos - 1]))
            {
                searchPos = pos + normalizedCommandName.size();
                continue;
            }

            const auto parenPos = skipWhitespace(contentLower, pos + normalizedCommandName.size());
            if (parenPos >= contentLower.size() || contentLower[parenPos] != '(')
            {
                searchPos = pos + normalizedCommandName.size();
                continue;
            }

            const auto endPos = findCommandEnd(content, parenPos);
            if (endPos == std::string::npos)
            {
                searchPos = pos + normalizedCommandName.size();
                continue;
            }

            matches.push_back({normalizedCommandName, content.substr(parenPos + 1, endPos - parenPos - 1)});
            searchPos = endPos + 1;
        }

        return matches;
    }

    std::vector<std::string> tokenizeArguments(const std::string &content)
    {
        std::vector<std::string> tokens;
        std::string current;
        bool inDoubleQuote = false;
        bool inSingleQuote = false;
        bool escaped = false;

        auto flush = [&]() {
            if (!current.empty())
            {
                tokens.push_back(current);
                current.clear();
            }
        };

        for (char ch : content)
        {
            if (escaped)
            {
                current.push_back(ch);
                escaped = false;
                continue;
            }

            if ((inDoubleQuote || inSingleQuote) && ch == '\\')
            {
                escaped = true;
                continue;
            }

            if (ch == '"' && !inSingleQuote)
            {
                inDoubleQuote = !inDoubleQuote;
                continue;
            }

            if (ch == '\'' && !inDoubleQuote)
            {
                inSingleQuote = !inSingleQuote;
                continue;
            }

            if (!inDoubleQuote && !inSingleQuote && std::isspace(static_cast<unsigned char>(ch)))
            {
                flush();
                continue;
            }

            current.push_back(ch);
        }

        flush();
        return tokens;
    }

    void insertKitMatches(const std::string &argument, std::unordered_set<std::string> &kitNames)
    {
        static const std::regex kitRegex(R"(^(kit_[A-Za-z0-9_]+))");
        std::smatch match;
        if (std::regex_search(argument, match, kitRegex))
        {
            kitNames.emplace(match[1].str());
        }
    }
} // namespace

std::string CmakeTools::readCmake(const std::string &filePath)
{
    std::ifstream file(filePath);
    if (!file.is_open())
    {
        return "";
    }

    std::string content;
    std::string line;
    while (std::getline(file, line))
    {
        content += line.substr(0, findLineCommentStart(line, 0, line.size()));
        if (!file.eof())
        {
            content.push_back('\n');
        }
    }
    return content;
}

std::vector<std::string> CmakeTools::commandLines(const std::string &content, const std::string &commandName)
{
    std::vector<std::string> lines;
    for (const auto &match : findCommands(content, commandName))
    {
        lines.push_back(match.body);
    }
    return lines;
}

std::vector<std::string> CmakeTools::extractListValues(const std::string &content, const std::string &varName)
{
    std::vector<std::string> values;

    const auto listMatches = findCommands(content, "list");
    for (const auto &match : listMatches)
    {
        auto tokens = tokenizeArguments(match.body);
        if (tokens.size() < 3 || tokens[1] != varName)
        {
            continue;
        }

        const auto operation = toLowerCopy(tokens[0]);
        if (operation == "append")
        {
            values.insert(values.end(), tokens.begin() + 2, tokens.end());
        }
        else if (operation == "prepend")
        {
            std::vector<std::string> prefix(tokens.begin() + 2, tokens.end());
            prefix.insert(prefix.end(), values.begin(), values.end());
            values = std::move(prefix);
        }
    }

    return values;
}

std::unordered_set<std::string> CmakeTools::extractTargetKitNames(const std::string &content, const std::string &targetName)
{
    std::unordered_set<std::string> kitNames;

    for (const auto &command : commandLines(content, "target_link_libraries"))
    {
        auto tokens = tokenizeArguments(command);
        if (tokens.empty() || tokens.front() != targetName)
        {
            continue;
        }

        for (size_t index = 1; index < tokens.size(); ++index)
        {
            insertKitMatches(tokens[index], kitNames);
        }
    }

    return kitNames;
}
