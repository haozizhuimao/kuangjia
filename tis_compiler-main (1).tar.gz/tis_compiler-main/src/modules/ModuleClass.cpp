#include "ModuleClass.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>

namespace
{
    size_t skipWhitespace(const std::string &content, size_t pos)
    {
        while (pos < content.size() && std::isspace(static_cast<unsigned char>(content[pos])))
        {
            ++pos;
        }
        return pos;
    }

    size_t findSenderInsertPos(const std::string &content)
    {
        static const std::string namespaceEndMarker = "} // namespace _Modules";
        size_t pos = content.rfind(namespaceEndMarker);
        if (pos == std::string::npos)
        {
            return content.size();
        }

        size_t lineEnd = content.find('\n', pos);
        if (lineEnd == std::string::npos)
        {
            return content.size();
        }

        return lineEnd + 1;
    }

    std::string extractTrailingIdentifier(const std::string &text)
    {
        size_t end = text.find_last_not_of(" \t\r\n");
        if (end == std::string::npos)
        {
            return {};
        }

        const unsigned char last = static_cast<unsigned char>(text[end]);
        if (!std::isalnum(last) && text[end] != '_')
        {
            return {};
        }

        size_t start = end;
        while (start > 0)
        {
            const unsigned char ch = static_cast<unsigned char>(text[start - 1]);
            if (!std::isalnum(ch) && text[start - 1] != '_')
            {
                break;
            }
            --start;
        }

        return text.substr(start, end - start + 1);
    }

    size_t findBodyBraceAfterDeclarator(const std::string &content, size_t pos)
    {
        size_t cursor = skipWhitespace(content, pos);
        while (cursor < content.size())
        {
            if (content[cursor] == ';')
            {
                return std::string::npos;
            }

            size_t bracePos = content.find('{', cursor);
            if (bracePos == std::string::npos)
            {
                return std::string::npos;
            }

            size_t semicolonPos = content.find(';', cursor);
            if (semicolonPos != std::string::npos && semicolonPos < bracePos)
            {
                return std::string::npos;
            }

            int braceCount = 1;
            size_t matchBrace = bracePos + 1;
            while (matchBrace < content.size() && braceCount > 0)
            {
                if (content[matchBrace] == '{')
                    ++braceCount;
                else if (content[matchBrace] == '}')
                    --braceCount;
                ++matchBrace;
            }

            if (braceCount != 0)
            {
                return std::string::npos;
            }

            size_t nextPos = skipWhitespace(content, matchBrace);
            if (nextPos < content.size() && (content[nextPos] == ',' || content[nextPos] == '{'))
            {
                cursor = nextPos;
                continue;
            }

            return bracePos;
        }

        return std::string::npos;
    }
} // namespace

void ModuleClass::parse(const std::string &moduleRootPath, const std::unordered_set<std::string> &moduleNames)
{
    namespace fs = std::filesystem;
    if (!fs::exists(moduleRootPath))
    {
        std::cerr << "Warning: Module path does not exist: " << moduleRootPath << std::endl;
        return;
    }

    for (const auto &entry : fs::recursive_directory_iterator(moduleRootPath))
    {
        const std::string extension = entry.path().extension().string();
        if (entry.is_regular_file() && extension == ".h")
        {
            std::ifstream headerFile(entry.path());
            std::string content((std::istreambuf_iterator<char>(headerFile)), std::istreambuf_iterator<char>());
            auto targetClassInfo = parseTargetClass(content);
            if (targetClassInfo.className.empty() || moduleNames.find(targetClassInfo.className) == moduleNames.end())
            {
                continue;
            }
            m_classInfos.push_back(targetClassInfo);
            std::string relativePath = fs::relative(entry.path().parent_path(), moduleRootPath).generic_string();
            m_moduleSubPaths.emplace(relativePath);
            generateCpp(entry.path().string(), targetClassInfo);
        }
    }
}

std::vector<ClassInfo> ModuleClass::getClasseInfos() const
{
    return m_classInfos;
}

std::unordered_set<std::string> ModuleClass::getModuleSubPaths() const
{
    return m_moduleSubPaths;
}

ClassInfo ModuleClass::parseTargetClass(const std::string &content)
{
    static const std::regex moduleClassRegex(R"(class\s+(\w+)\s*:\s*public\s+[\w:]*ModuleBase\b)");
    static const std::regex funcDeclRegex(R"(\b(tis_sender|tis_receiver)\b)");

    std::smatch match;
    ClassInfo classInfo;
    if (!std::regex_search(content, match, moduleClassRegex))
    {
        return classInfo;
    }

    classInfo.className = match.str(1);

    size_t classDefStart = match.position(0);
    size_t classDefEnd = classDefStart + match.length(0);

    size_t bodyStart = content.find('{', classDefEnd);
    if (bodyStart == std::string::npos)
        return classInfo;

    int braceCount = 1;
    size_t pos = bodyStart + 1;
    while (pos < content.size() && braceCount > 0)
    {
        if (content[pos] == '{')
            ++braceCount;
        else if (content[pos] == '}')
            --braceCount;
        ++pos;
    }

    if (braceCount != 0)
        return classInfo;

    size_t bodyEnd = pos - 1;
    std::string classBody = content.substr(bodyStart + 1, bodyEnd - bodyStart - 1);

    std::smatch funcMatch;
    std::string::const_iterator bodyIter = classBody.cbegin();

    while (std::regex_search(bodyIter, classBody.cend(), funcMatch, funcDeclRegex))
    {
        FunctionInfo info;
        info.macroType = funcMatch[1].str();

        size_t matchPos = funcMatch.position(0) + (bodyIter - classBody.cbegin());
        size_t declStart = matchPos + funcMatch.length(0);
        size_t openParen = classBody.find('(', declStart);
        if (openParen == std::string::npos)
        {
            bodyIter = funcMatch.suffix().first;
            continue;
        }

        info.name = extractTrailingIdentifier(classBody.substr(declStart, openParen - declStart));
        if (info.name.empty())
        {
            bodyIter = classBody.cbegin() + openParen + 1;
            continue;
        }

        size_t argsStart = openParen + 1;
        std::string args;
        size_t argsEnd = 0;
        if (!extractArgs(classBody, argsStart, args, argsEnd))
        {
            bodyIter = funcMatch.suffix().first;
            continue;
        }
        info.args = args;

        size_t semicolon = classBody.find(';', argsEnd);
        if (semicolon == std::string::npos)
        {
            bodyIter = funcMatch.suffix().first;
            continue;
        }

        if (info.macroType == "tis_sender")
            classInfo.senders.push_back(info);
        else
            classInfo.receivers.push_back(info);

        bodyIter = classBody.cbegin() + semicolon + 1;
    }

    return classInfo;
}

bool ModuleClass::extractArgs(const std::string &text, size_t startPos, std::string &args, size_t &endPos)
{
    int depth = 1;
    size_t pos = startPos;

    while (pos < text.size() && depth > 0)
    {
        if (text[pos] == '(')
            ++depth;
        else if (text[pos] == ')')
            --depth;
        ++pos;
    }

    if (depth != 0)
        return false;

    args = text.substr(startPos, pos - startPos - 1);
    endPos = pos;
    return true;
}

void ModuleClass::generateCpp(const std::string &headerPath, const ClassInfo &classInfo)
{
    std::filesystem::path headerPathObj(headerPath);
    std::filesystem::path filePath = headerPathObj.replace_extension(".cpp");

    std::ifstream inFile(filePath);
    if (!inFile.is_open())
    {
        return;
    }

    std::stringstream buffer;
    buffer << inFile.rdbuf();
    std::string content = buffer.str();
    inFile.close();

    content = clearConstructorBody(content, classInfo.className);
    content = removeCompilerBlocks(content);
    content = insertMacros(content, classInfo);
    content = insertSenders(content, classInfo);

    std::ofstream outFile(filePath, std::ios::trunc);
    if (outFile.is_open())
    {
        outFile << content;
        outFile.close();
    }
}

std::string ModuleClass::clearConstructorBody(const std::string &content, const std::string &className)
{
    std::string result = content;
    auto [bracePos, bodyEnd] = findConstructor(result, className);
    if (bracePos != std::string::npos && bodyEnd != std::string::npos)
    {
        result.erase(bracePos + 1, bodyEnd - bracePos - 1);
    }
    return result;
}

std::string ModuleClass::removeCompilerBlocks(const std::string &content)
{
    std::string result = content;
    const std::string beginMarker = "// tis_compiler sender begin";
    const std::string endMarker = "// tis_compiler sender end";

    size_t beginPos = 0;
    while ((beginPos = result.find(beginMarker, beginPos)) != std::string::npos)
    {
        size_t lineStart = beginPos;
        while (lineStart > 0 && result[lineStart - 1] != '\n')
            --lineStart;

        size_t endPos = result.find(endMarker, beginPos);
        if (endPos == std::string::npos)
            break;

        size_t lineEnd = endPos;
        while (lineEnd < result.size() && result[lineEnd] != '\n')
            ++lineEnd;
        if (lineEnd < result.size())
            ++lineEnd;

        result.erase(lineStart, lineEnd - lineStart);
        beginPos = lineStart;
    }

    return result;
}

std::string ModuleClass::insertMacros(const std::string &content, const ClassInfo &classInfo)
{
    std::string result = content;
    auto [bracePos, bodyEnd] = findConstructor(result, classInfo.className);
    if (bracePos == std::string::npos || bodyEnd == std::string::npos)
    {
        return result;
    }

    std::string macros;
    const std::string indentStr(4, ' ');
    for (const auto &sender : classInfo.senders)
    {
        macros += indentStr + "__DECLARE_MODULE_REGISTER_FUNCTION(" + sender.name + ");\n";
    }
    for (const auto &receiver : classInfo.receivers)
    {
        macros += indentStr + "__DECLARE_MODULE_REGISTER_FUNCTION(" + receiver.name + ");\n";
    }

    result.replace(bracePos + 1, bodyEnd - bracePos - 1, "\n" + macros);
    return result;
}

std::string ModuleClass::insertSenders(const std::string &content, const ClassInfo &classInfo)
{
    std::string result = content;
    const std::string beginMarker = "// tis_compiler sender begin";
    const std::string endMarker = "// tis_compiler sender end";

    std::string newFunctions;
    for (const auto &sender : classInfo.senders)
    {
        std::string signature;
        std::string placeholders;
        if (sender.args.empty())
        {
            newFunctions += "\nvoid _Modules::" + classInfo.className + "::" + sender.name + "()\n{\n";
            newFunctions += "    __DECLARE_MODULE_FUNCTION_INNER(" + sender.name + ", std::function<void(void)>);\n";
            newFunctions += "}\n";
        }
        else
        {
            signatureFunction(sender.args, signature, placeholders);
            newFunctions += "\nvoid _Modules::" + classInfo.className + "::" + sender.name + signature + "\n{\n";
            newFunctions += "    __DECLARE_MODULE_FUNCTION_INNER(" + sender.name + ", std::function<void(" + sender.args + ")>, " +
                            placeholders + ");\n";
            newFunctions += "}\n";
        }
    }

    if (newFunctions.empty())
    {
        return result;
    }

    std::string senderBlock = beginMarker;
    senderBlock += newFunctions;
    senderBlock += endMarker;

    size_t insertPos = findSenderInsertPos(result);
    std::string blockWithSpacing = "\n" + senderBlock;
    result.insert(insertPos, blockWithSpacing);

    return result;
}

void ModuleClass::signatureFunction(const std::string &typeList, std::string &outSignature, std::string &outPlaceholders)
{
    auto args = parseArgs(typeList);

    std::vector<std::string> sigParts;
    std::vector<std::string> placeholders;

    for (size_t i = 0; i < args.size(); ++i)
    {
        std::string varName = "_" + std::to_string(i);
        sigParts.push_back(args[i] + " " + varName);
        placeholders.push_back("__INNER_FWD(" + varName + ")");
    }

    outSignature = "(" + join(sigParts, ", ") + ")";
    outPlaceholders = join(placeholders, ", ");
}

std::vector<std::string> ModuleClass::parseArgs(const std::string &tempSignature)
{
    std::vector<std::string> args;
    std::string currentArg;
    int angleBrackets = 0;
    int parens = 0;
    int brace = 0;
    std::string signature = tempSignature;
    if (signature.size() >= 2 && signature.front() == '(' && signature.back() == ')')
    {
        signature = signature.substr(1, signature.size() - 2);
    }

    for (size_t i = 0; i < signature.size(); ++i)
    {
        char ch = signature[i];

        if (ch == '<')
            ++angleBrackets;
        else if (ch == '>')
            --angleBrackets;
        else if (ch == '(')
            ++parens;
        else if (ch == ')')
            --parens;
        else if (ch == '{')
            ++brace;
        else if (ch == '}')
            --brace;

        if (ch == ',' && angleBrackets == 0 && parens == 0 && brace == 0)
        {
            if (!currentArg.empty())
            {
                currentArg.erase(0, currentArg.find_first_not_of(" \t"));
                currentArg.erase(currentArg.find_last_not_of(" \t") + 1);
                args.push_back(currentArg);
                currentArg.clear();
            }
        }
        else
        {
            currentArg += ch;
        }
    }

    if (!currentArg.empty())
    {
        currentArg.erase(0, currentArg.find_first_not_of(" \t"));
        currentArg.erase(currentArg.find_last_not_of(" \t") + 1);
        args.push_back(currentArg);
    }

    return args;
}

std::string ModuleClass::join(const std::vector<std::string> &v, const std::string &sep)
{
    std::string result;
    for (size_t i = 0; i < v.size(); ++i)
    {
        result += v[i];
        if (i + 1 < v.size())
            result += sep;
    }
    return result;
}

std::pair<size_t, size_t> ModuleClass::findConstructor(const std::string &content, const std::string &className)
{
    size_t pos = 0;
    while ((pos = content.find(className, pos)) != std::string::npos)
    {
        if ((pos > 0 && std::isalnum(static_cast<unsigned char>(content[pos - 1]))) ||
            (pos + className.size() < content.size() && std::isalnum(static_cast<unsigned char>(content[pos + className.size()]))))
        {
            pos += className.size();
            continue;
        }

        size_t parenPos = pos + className.size();
        while (parenPos < content.size() && std::isspace(static_cast<unsigned char>(content[parenPos])))
            ++parenPos;
        if (parenPos >= content.size() || content[parenPos] != '(')
        {
            pos += className.size();
            continue;
        }

        int parenCount = 1;
        size_t matchParen = parenPos + 1;
        while (matchParen < content.size() && parenCount > 0)
        {
            if (content[matchParen] == '(')
                ++parenCount;
            else if (content[matchParen] == ')')
                --parenCount;
            ++matchParen;
        }
        if (parenCount != 0)
        {
            pos = matchParen;
            continue;
        }
        size_t paramEnd = matchParen - 1;

        size_t bracePos = findBodyBraceAfterDeclarator(content, paramEnd + 1);
        if (bracePos == std::string::npos)
        {
            pos = paramEnd + 1;
            continue;
        }

        int braceCount = 1;
        size_t matchBrace = bracePos + 1;
        while (matchBrace < content.size() && braceCount > 0)
        {
            if (content[matchBrace] == '{')
                ++braceCount;
            else if (content[matchBrace] == '}')
                --braceCount;
            ++matchBrace;
        }
        if (braceCount != 0)
        {
            pos = matchBrace;
            continue;
        }

        size_t bodyEnd = matchBrace - 1;
        return {bracePos, bodyEnd};
    }

    return {std::string::npos, std::string::npos};
}
