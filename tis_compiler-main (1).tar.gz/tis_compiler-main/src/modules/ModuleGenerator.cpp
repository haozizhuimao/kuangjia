#include "ModuleGenerator.h"

#include "cmake/CmakeTools.h"

void ModuleGenerator::generate(const std::string &rootPath, const std::unordered_set<std::string> &moduleNames)
{
    std::string moduleRootPath = rootPath + "/src/modules/";
    m_moduleClass.parse(moduleRootPath, moduleNames);
    auto subPaths = m_moduleClass.getModuleSubPaths();
    m_moduleBuild.build(moduleRootPath, subPaths);
    parseSubCmake(moduleRootPath, subPaths);
}

std::vector<ClassInfo> ModuleGenerator::getClassInfos() const
{
    return m_moduleClass.getClasseInfos();
}

std::unordered_set<std::string> ModuleGenerator::getKitNames() const
{
    return m_kitNames;
}

void ModuleGenerator::parseSubCmake(const std::string &moduleRoot, const std::unordered_set<std::string> &subPaths)
{
    for (const auto &subPath : subPaths)
    {
        std::string subCmakePath = moduleRoot + subPath + "/CMakeLists.txt";
        auto tempContent = CmakeTools::readCmake(subCmakePath);
        auto kitNames = CmakeTools::extractTargetKitNames(tempContent, "${MODULE_NAME}");
        m_kitNames.merge(kitNames);
    }
}
