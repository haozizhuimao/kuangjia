#pragma once
#include "ModuleBuild.h"
#include "ModuleClass.h"
#include <string>
#include <unordered_set>
#include <vector>

class ModuleGenerator
{
  public:
    void generate(const std::string &rootPath, const std::unordered_set<std::string> &moduleNames);
    std::vector<ClassInfo> getClassInfos() const;
    std::unordered_set<std::string> getKitNames() const;

  private:
    void parseSubCmake(const std::string &moduleRoot, const std::unordered_set<std::string> &subPaths);
    ModuleClass m_moduleClass;
    ModuleBuild m_moduleBuild;
    std::unordered_set<std::string> m_kitNames;
};
