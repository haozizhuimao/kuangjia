#pragma once
#include <string>
#include <unordered_set>

class ModuleBuild
{
  public:
    void build(const std::string &moduleRootPath, const std::unordered_set<std::string> &moduleSubPath);
};