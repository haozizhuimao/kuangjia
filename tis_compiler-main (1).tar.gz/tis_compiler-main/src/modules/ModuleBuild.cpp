#include "ModuleBuild.h"
#include <fstream>
#include <iostream>
void ModuleBuild::build(const std::string &moduleRootPath, const std::unordered_set<std::string> &moduleSubPath)
{
    std::string outputPath = moduleRootPath + "/CMakeLists.txt";
    std::ofstream file(outputPath);
    if (!file.is_open())
    {
        std::cerr << "can not write file: " << outputPath << std::endl;
        return;
    }
    file << "# [tis_compiler] auto-generate, 不要自己手动改!\n"
         << "set(LIB_MODULES \"lib_modules\")\n"
         << "add_library(${LIB_MODULES} OBJECT)\n"
         << "\n"
         << "message(\"===================== MODS BEGIN =====================\")\n";
    for (const auto &subPath : moduleSubPath)
    {
        file << "add_subdirectory(" << subPath << ")\n";
    }
    file << "message(\"===================== MODS END   =====================\")\n";
}
