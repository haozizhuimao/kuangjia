#pragma once
#include <string>
#include "struct/GlobalStruct.h"
#include <unordered_set>
#include <vector>

class ModuleClass
{

  public:
    void parse(const std::string &moduleRootPath, const std::unordered_set<std::string> &moduleNames);
    std::unordered_set<std::string> getModuleSubPaths() const;
    std::vector<ClassInfo> getClasseInfos() const;

  private:
    ClassInfo parseTargetClass(const std::string &content);
    bool extractArgs(const std::string &text, size_t startPos, std::string &args, size_t &endPos);
    void generateCpp(const std::string &headerPath, const ClassInfo &classInfo);

    std::pair<size_t, size_t> findConstructor(const std::string &content, const std::string &className);
    std::string clearConstructorBody(const std::string &content, const std::string &className);
    std::string removeCompilerBlocks(const std::string &content);
    std::string insertMacros(const std::string &content, const ClassInfo &classInfo);
    std::string insertSenders(const std::string &content, const ClassInfo &classInfo);
    void signatureFunction(const std::string &typeList, std::string &outSignature, std::string &outPlaceholders);
    std::vector<std::string> parseArgs(const std::string &signature);
    std::string join(const std::vector<std::string> &v, const std::string &sep);
    std::unordered_set<std::string> m_moduleSubPaths;
    std::vector<ClassInfo> m_classInfos;
};