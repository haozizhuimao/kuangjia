#include "ReflectStruct.h"

#include <cctype>

void ReflectStruct::generate(const std::string &rootPath)
{
    generateReflections(rootPath);
}

std::string ReflectStruct::marker() const
{
    return "REFLECTION_STRUCT";
}

std::string ReflectStruct::outputRelativePath() const
{
    return "/src/kits/utility/serialization/reflection_struct_extension.h";
}

std::string ReflectStruct::reflectionInclude() const
{
    return "reflection_struct.h";
}

std::string ReflectStruct::projectInclude() const
{
    return "tis_global/Struct.h";
}

std::string ReflectStruct::reflectionMacro() const
{
    return "__REFLECTION_STRUCT_INNER";
}

size_t ReflectStruct::findDeclarationStart(const std::string &code, size_t markerPos) const
{
    return code.find("struct", markerPos);
}

size_t ReflectStruct::findNameStart(const std::string &code, size_t declarationPos) const
{
    return skipWhitespace(code, declarationPos + std::string_view("struct").size());
}

ReflectStruct::ReflectionItems ReflectStruct::extractItems(const std::string &body) const
{
    ReflectionItems members;
    std::string currentDecl;
    bool inString = false;
    bool inChar = false;
    bool escaped = false;
    int parenDepth = 0;
    int braceDepth = 0;

    auto flushDecl = [&](std::string decl) {
        decl = trim(decl);
        if (decl.empty() || decl.find('(') != std::string::npos)
        {
            return;
        }
        if (decl.rfind("static", 0) == 0 || decl.rfind("using", 0) == 0 || decl.rfind("typedef", 0) == 0 ||
            decl.rfind("friend", 0) == 0)
        {
            return;
        }

        const size_t equalPos = decl.find('=');
        if (equalPos != std::string::npos)
        {
            decl = trim(decl.substr(0, equalPos));
        }

        size_t end = decl.size();
        while (end > 0 && std::isspace(static_cast<unsigned char>(decl[end - 1])))
        {
            --end;
        }

        while (end > 0 && decl[end - 1] == ']')
        {
            int bracketDepth = 1;
            --end;
            while (end > 0 && bracketDepth > 0)
            {
                --end;
                if (decl[end] == ']')
                {
                    ++bracketDepth;
                }
                else if (decl[end] == '[')
                {
                    --bracketDepth;
                }
            }
            while (end > 0 && std::isspace(static_cast<unsigned char>(decl[end - 1])))
            {
                --end;
            }
        }

        size_t start = end;
        while (start > 0 &&
               (std::isalnum(static_cast<unsigned char>(decl[start - 1])) || decl[start - 1] == '_'))
        {
            --start;
        }

        const std::string name = decl.substr(start, end - start);
        if (!name.empty() && (std::isalpha(static_cast<unsigned char>(name.front())) || name.front() == '_'))
        {
            members.push_back(name);
        }
    };

    for (const char current : body)
    {
        if (escaped)
        {
            escaped = false;
            currentDecl += current;
            continue;
        }

        if ((inString || inChar) && current == '\\')
        {
            escaped = true;
            currentDecl += current;
            continue;
        }

        if (inString)
        {
            if (current == '"')
            {
                inString = false;
            }
            currentDecl += current;
            continue;
        }

        if (inChar)
        {
            if (current == '\'')
            {
                inChar = false;
            }
            currentDecl += current;
            continue;
        }

        if (current == '"')
        {
            inString = true;
            currentDecl += current;
            continue;
        }

        if (current == '\'')
        {
            inChar = true;
            currentDecl += current;
            continue;
        }

        if (current == '{')
        {
            ++braceDepth;
        }
        else if (current == '}')
        {
            --braceDepth;
        }
        else if (current == '(')
        {
            ++parenDepth;
        }
        else if (current == ')')
        {
            --parenDepth;
        }

        if (current == ';' && braceDepth == 0 && parenDepth == 0)
        {
            flushDecl(currentDecl);
            currentDecl.clear();
            continue;
        }

        currentDecl += current;
    }

    return members;
}
