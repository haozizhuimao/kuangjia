#include "ReflectEnum.h"

#include <cctype>

void ReflectEnum::generate(const std::string &rootPath)
{
    generateReflections(rootPath);
}

std::string ReflectEnum::marker() const
{
    return "REFLECTION_ENUM";
}

std::string ReflectEnum::outputRelativePath() const
{
    return "/src/kits/utility/serialization/reflection_enum_extension.h";
}

std::string ReflectEnum::reflectionInclude() const
{
    return "reflection_enum.h";
}

std::string ReflectEnum::projectInclude() const
{
    return "tis_global/EnumPublic.h";
}

std::string ReflectEnum::reflectionMacro() const
{
    return "__REFLECTION_ENUM_INNER";
}

size_t ReflectEnum::findDeclarationStart(const std::string &code, size_t markerPos) const
{
    return code.find("enum", markerPos);
}

size_t ReflectEnum::findNameStart(const std::string &code, size_t declarationPos) const
{
    size_t namePos = skipWhitespace(code, declarationPos + std::string_view("enum").size());
    if (matchesKeyword(code, namePos, "class"))
    {
        namePos = skipWhitespace(code, namePos + std::string_view("class").size());
    }
    else if (matchesKeyword(code, namePos, "struct"))
    {
        namePos = skipWhitespace(code, namePos + std::string_view("struct").size());
    }
    return namePos;
}

ReflectEnum::ReflectionItems ReflectEnum::extractItems(const std::string &body) const
{
    ReflectionItems enumerators;
    std::string currentItem;
    bool inString = false;
    bool inChar = false;
    bool escaped = false;
    int parenDepth = 0;
    int bracketDepth = 0;
    int braceDepth = 0;

    auto flushItem = [&](std::string item) {
        item = trim(item);
        if (item.empty())
        {
            return;
        }

        const size_t equalPos = item.find('=');
        if (equalPos != std::string::npos)
        {
            item = trim(item.substr(0, equalPos));
        }
        if (item.empty())
        {
            return;
        }

        size_t end = 0;
        while (end < item.size() && (std::isalnum(static_cast<unsigned char>(item[end])) || item[end] == '_'))
        {
            ++end;
        }
        if (end > 0)
        {
            enumerators.push_back(item.substr(0, end));
        }
    };

    for (const char current : body)
    {
        if (escaped)
        {
            escaped = false;
            currentItem += current;
            continue;
        }

        if ((inString || inChar) && current == '\\')
        {
            escaped = true;
            currentItem += current;
            continue;
        }

        if (inString)
        {
            if (current == '"')
            {
                inString = false;
            }
            currentItem += current;
            continue;
        }

        if (inChar)
        {
            if (current == '\'')
            {
                inChar = false;
            }
            currentItem += current;
            continue;
        }

        if (current == '"')
        {
            inString = true;
            currentItem += current;
            continue;
        }

        if (current == '\'')
        {
            inChar = true;
            currentItem += current;
            continue;
        }

        if (current == '(')
        {
            ++parenDepth;
        }
        else if (current == ')')
        {
            --parenDepth;
        }
        else if (current == '[')
        {
            ++bracketDepth;
        }
        else if (current == ']')
        {
            --bracketDepth;
        }
        else if (current == '{')
        {
            ++braceDepth;
        }
        else if (current == '}')
        {
            --braceDepth;
        }

        if (current == ',' && parenDepth == 0 && bracketDepth == 0 && braceDepth == 0)
        {
            flushItem(currentItem);
            currentItem.clear();
            continue;
        }

        currentItem += current;
    }

    flushItem(currentItem);
    return enumerators;
}
