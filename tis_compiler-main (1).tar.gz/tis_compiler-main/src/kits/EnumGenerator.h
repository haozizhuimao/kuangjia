#pragma once
#include <filesystem>
#include <vector>
#include <string>
class EnumGenerator
{
  public:
    void generate(const std::string &rootPath);

  private:
    struct QmlEnumInfo
    {
        std::string EnumName;
        std::vector<std::string> enumItems;
    };
    void generateEnumClassHeader(const std::string &dirPath, const std::string &qmlKitsFilePath);
    std::vector<QmlEnumInfo> parseQmlCommunicationClass(const std::filesystem::path &filePath);
    bool shouldSkipLine(const std::string &line, bool &inMultiLineComment);
    std::string extractSubstring(const std::string &input);
    std::string findQmlCommunication(const std::string &path);
};