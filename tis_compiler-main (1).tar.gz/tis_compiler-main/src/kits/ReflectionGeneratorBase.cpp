#include "ReflectionGeneratorBase.h"

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <iostream>

namespace fs = std::filesystem;

void ReflectionGeneratorBase::generateReflections(const std::string &rootPath)
{
    reflectionMap_.clear();
    parsePath(rootPath + "/src/tis_global");
    writeOutput(rootPath + outputRelativePath());
}

std::string ReflectionGeneratorBase::trim(const std::string &value)
{
    const size_t start = value.find_first_not_of(" \t\r\n");
    if (start == std::string::npos)
    {
        return "";
    }

    const size_t end = value.find_last_not_of(" \t\r\n");
    return value.substr(start, end - start + 1);
}

size_t ReflectionGeneratorBase::skipWhitespace(const std::string &code, size_t pos)
{
    while (pos < code.size() && std::isspace(static_cast<unsigned char>(code[pos])))
    {
        ++pos;
    }
    return pos;
}

bool ReflectionGeneratorBase::matchesKeyword(const std::string &code, size_t pos, std::string_view keyword)
{
    if (pos == std::string::npos || pos + keyword.size() > code.size())
    {
        return false;
    }

    if (code.compare(pos, keyword.size(), keyword) != 0)
    {
        return false;
    }

    return pos + keyword.size() == code.size() || !isIdentifierChar(code[pos + keyword.size()]);
}

void ReflectionGeneratorBase::parsePath(const std::string &path)
{
    for (const auto &entry : fs::recursive_directory_iterator(path))
    {
        if (!entry.is_regular_file())
        {
            continue;
        }

        const auto ext = entry.path().extension().string();
        if (ext == ".h" || ext == ".hpp")
        {
            parseFile(entry.path().string());
        }
    }
}

void ReflectionGeneratorBase::parseFile(const std::string &filePath)
{
    std::ifstream file(filePath);
    if (!file.is_open())
    {
        return;
    }

    const std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    const std::string code = removeComments(content);
    const std::string markerToken = marker();

    size_t pos = 0;
    while ((pos = code.find(markerToken, pos)) != std::string::npos)
    {
        const size_t declarationPos = findDeclarationStart(code, pos);
        if (declarationPos == std::string::npos)
        {
            pos += markerToken.size();
            continue;
        }

        const size_t nameStart = findNameStart(code, declarationPos);
        if (nameStart == std::string::npos)
        {
            pos += markerToken.size();
            continue;
        }

        size_t nameEnd = nameStart;
        while (nameEnd < code.size() && isIdentifierChar(code[nameEnd]))
        {
            ++nameEnd;
        }
        if (nameEnd == nameStart)
        {
            pos += markerToken.size();
            continue;
        }

        const size_t openBrace = code.find('{', nameEnd);
        if (openBrace == std::string::npos)
        {
            pos += markerToken.size();
            continue;
        }

        const size_t closeBrace = findMatchingBrace(code, openBrace);
        if (closeBrace == std::string::npos)
        {
            pos += markerToken.size();
            continue;
        }

        reflectionMap_[code.substr(nameStart, nameEnd - nameStart)] = extractItems(code.substr(openBrace + 1, closeBrace - openBrace - 1));
        pos = closeBrace + 1;
    }
}

void ReflectionGeneratorBase::writeOutput(const std::string &outputPath) const
{
    std::ofstream out(outputPath);
    if (!out)
    {
        std::cerr << "Cannot open " << outputPath << std::endl;
        std::cerr << "错误码: " << errno << std::endl;
        std::cerr << "原因: " << std::strerror(errno) << std::endl;
        return;
    }

    out << "// [tis_compiler] auto-generate, do not edit manually.\n";
    out << "#pragma once\n";
    out << "#include \"" << reflectionInclude() << "\"\n";
    out << "#include \"" << projectInclude() << "\"\n\n";

    std::vector<std::string> names;
    names.reserve(reflectionMap_.size());
    for (const auto &[name, _] : reflectionMap_)
    {
        names.push_back(name);
    }
    std::sort(names.begin(), names.end());

    for (const auto &name : names)
    {
        out << reflectionMacro() << "(TIS_Info::" << name;
        for (const auto &item : reflectionMap_.at(name))
        {
            out << ", " << item;
        }
        out << ")\n";
    }
}

std::string ReflectionGeneratorBase::removeComments(const std::string &code)
{
    std::string result;
    bool inBlock = false;
    bool inLine = false;
    bool inString = false;
    bool inChar = false;
    bool escaped = false;

    for (size_t index = 0; index < code.size(); ++index)
    {
        const char current = code[index];
        const char next = (index + 1 < code.size()) ? code[index + 1] : '\0';

        if (escaped)
        {
            escaped = false;
            result += current;
            continue;
        }

        if ((inString || inChar) && current == '\\')
        {
            escaped = true;
            result += current;
            continue;
        }

        if (inString)
        {
            if (current == '"')
            {
                inString = false;
            }
            result += current;
            continue;
        }

        if (inChar)
        {
            if (current == '\'')
            {
                inChar = false;
            }
            result += current;
            continue;
        }

        if (inBlock)
        {
            if (current == '*' && next == '/')
            {
                inBlock = false;
                ++index;
            }
            continue;
        }

        if (inLine)
        {
            if (current == '\n')
            {
                inLine = false;
                result += current;
            }
            continue;
        }

        if (current == '/' && next == '*')
        {
            inBlock = true;
            ++index;
            continue;
        }

        if (current == '/' && next == '/')
        {
            inLine = true;
            ++index;
            continue;
        }

        if (current == '"')
        {
            inString = true;
        }
        else if (current == '\'')
        {
            inChar = true;
        }

        result += current;
    }

    return result;
}

bool ReflectionGeneratorBase::isIdentifierChar(char ch)
{
    return std::isalnum(static_cast<unsigned char>(ch)) || ch == '_';
}

size_t ReflectionGeneratorBase::findMatchingBrace(const std::string &code, size_t openBrace)
{
    int depth = 1;
    bool inString = false;
    bool inChar = false;
    bool escaped = false;

    for (size_t pos = openBrace + 1; pos < code.size(); ++pos)
    {
        const char current = code[pos];
        if (escaped)
        {
            escaped = false;
            continue;
        }
        if ((inString || inChar) && current == '\\')
        {
            escaped = true;
            continue;
        }
        if (inString)
        {
            if (current == '"')
            {
                inString = false;
            }
            continue;
        }
        if (inChar)
        {
            if (current == '\'')
            {
                inChar = false;
            }
            continue;
        }
        if (current == '"')
        {
            inString = true;
        }
        else if (current == '\'')
        {
            inChar = true;
        }
        else if (current == '{')
        {
            ++depth;
        }
        else if (current == '}')
        {
            --depth;
            if (depth == 0)
            {
                return pos;
            }
        }
    }

    return std::string::npos;
}
