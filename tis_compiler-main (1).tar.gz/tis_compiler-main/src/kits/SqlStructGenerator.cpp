#include "SqlStructGenerator.h"
#include <fstream>
#include <iostream>
#include <regex>
#include <sstream>
void SqlStructGenerator::generate(const std::string &rootPath)
{
    auto sqlFile = rootPath + "/config/database_manager/pg_init/createtable.sql";
    auto outputFile = rootPath + "/src/tis_global/struct_details/sql_struct.h";
    auto tables = parseSqlFile(sqlFile);
    generateStructs(outputFile, tables);
}
std::string SqlStructGenerator::removeComments(const std::string &sql)
{
    std::string result = std::regex_replace(sql, std::regex(R"(--.*)"), "");
    return std::regex_replace(result, std::regex(R"(/\*[\s\S]*?\*/)"), "");
}

std::string SqlStructGenerator::getCppType(const std::string &sqlType)
{
    std::string lowerType = toLower(sqlType.substr(0, sqlType.find('(')));

    return sqlToCppTypeMap.find(lowerType) == sqlToCppTypeMap.end() ? "std::string" : sqlToCppTypeMap.at(lowerType);
}

std::vector<SqlStructGenerator::TableInfo> SqlStructGenerator::parseSqlFile(const std::string &filePath)
{
    std::ifstream file(filePath);
    if (!file)
    {
        std::cerr << "Failed to open file: " << filePath << std::endl;
        return {};
    }

    std::ostringstream sqlContent;
    sqlContent << file.rdbuf();
    std::istringstream cleanedStream(removeComments(sqlContent.str()));

    std::vector<TableInfo> tables;
    std::string line;
    TableInfo currentTable;
    bool inTableDefinition = false;

    std::regex tableRegex(R"(CREATE\s+TABLE\s+(\w+)\s*\()", std::regex::icase);
    std::regex fieldRegex(R"(^\s*(\w+)\s+([\w()]+)(.*),?)");
    std::regex tableEndRegex(R"(\);)");

    while (std::getline(cleanedStream, line))
    {
        std::smatch match;

        if (!inTableDefinition && std::regex_search(line, match, tableRegex))
        {
            currentTable = TableInfo{match[1], {}};
            inTableDefinition = true;
            continue;
        }

        if (inTableDefinition && std::regex_search(line, tableEndRegex))
        {
            tables.push_back(currentTable);
            inTableDefinition = false;
            continue;
        }

        if (inTableDefinition && std::regex_search(line, match, fieldRegex))
        {
            std::string sqlType = match[2];
            std::string sqlOthers = match[3];
            currentTable.fields.push_back({match[1],
                                           getCppType(sqlType),
                                           sqlType,
                                           sqlOthers.find("PRIMARY KEY") != std::string::npos,
                                           sqlOthers.find("NOT NULL") != std::string::npos});
        }
    }

    return tables;
}

void SqlStructGenerator::generateStructs(const std::string &output, const std::vector<TableInfo> &tables)
{
    std::ofstream result(output);
    result << "// [tis_compiler] auto-generate, 不要自己手动改!\n"
           << "#pragma once\n"
           << "#include <chrono>\n"
           << "#include <cstdint>\n"
           << "#include <string>\n"
           << "#include \"kits/utility/serialization/reflection_struct.h\"\n";
    result << "namespace TIS_Info{\n";

    for (const auto &table : tables)
    {
        result << "REFLECTION_STRUCT struct " << table.name << "\n{\n";
        for (const auto &field : table.fields)
        {
            std::string defaultValue = "{}";
            if (field.cppType == "int")
            {
                defaultValue = "-1";
            }
            result << "    " << field.cppType << " " << field.name << " = " << defaultValue << ";\n";
        }
        result << "};\n\n";
    }
    result << "\n}";
}

std::string SqlStructGenerator::toLower(const std::string &str)
{
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), [](unsigned char c) { return std::tolower(c); });
    return result;
}

std::string SqlStructGenerator::toUpper(const std::string &str)
{
    std::string result = str;
    std::transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}
