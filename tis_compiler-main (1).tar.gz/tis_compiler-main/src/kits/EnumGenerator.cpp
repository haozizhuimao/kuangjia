#include "EnumGenerator.h"
#include <iostream>
#include <fstream>
void EnumGenerator::generate(const std::string &rootPath)
{
    auto enumFile = rootPath + "/src/tis_global/enum_public/uc_enum.h";
    auto qmlKitsFile = rootPath + "/src/kits/ui_components/qml_engine/QmlCommunication.h";
    generateEnumClassHeader(enumFile, qmlKitsFile);
}
void EnumGenerator::generateEnumClassHeader(const std::string &dirPath, const std::string &qmlKitsFilePath)
{
    auto enumInfo = parseQmlCommunicationClass(dirPath);
    if (enumInfo.empty())
    {
        return;
    }

    std::ofstream file(qmlKitsFilePath);
    if (!file.is_open())
    {
        std::cerr << "can not write file: " << qmlKitsFilePath << std::endl;
        return;
    }
    file << "// [tis_compiler] auto-generate, 不要自己手动改!\n"
         << "#pragma once\n"
         << "#include <QObject>\n"
         << "#include <QVariant>\n"
         << "namespace _Kits {\n"
         << "class QmlCommunication : public QObject\n"
         << "{\n"
         << "    Q_OBJECT\n"
         << "  public:\n";
    for (const auto &enumClass : enumInfo)
    {
        for (const auto &line : enumClass.enumItems)
        {
            file << "    " << line << "\n";
        }
        file << "    " << "Q_ENUM(" << enumClass.EnumName << ")\n";
    }
    file << "    explicit QmlCommunication(QObject *parent = nullptr);\n"
         << "    virtual ~QmlCommunication();\n"
         << "  signals:\n"
         << "    void behaviorFromQml(ActionsUI2CPP action, const QVariant &data);\n";
    for (const auto &enumClass : enumInfo)
    {
        if (enumClass.EnumName == "ActionsCPP2UI")
        {
            for (size_t index = 2; index < enumClass.enumItems.size() - 1; index++)
            {
                auto str = extractSubstring(enumClass.enumItems[index]);
                if (!str.empty())
                    file << "    void " << str << "FromCpp(const QVariant &value);\n";
            }
        }
    }

    file << "};\n"
         << "} // namespace _Kits\n";
}

std::string EnumGenerator::findQmlCommunication(const std::string &path)
{
    if (!std::filesystem::exists(path))
    {
        return "";
    }

    for (const auto &entry : std::filesystem::recursive_directory_iterator(path))
    {
        if (entry.is_regular_file())
        {
            std::string filename = entry.path().filename().string();

            if (filename.find("QmlCommunication") != std::string::npos)
            {
                std::string file_path = entry.path().parent_path().string() + "/QmlCommunication.h";
                return file_path;
            }
        }
    }

    return "";
}

std::string EnumGenerator::extractSubstring(const std::string &input)
{
    // 查找第一个非空字符的位置
    size_t start = input.find_first_not_of(" \t\n\r");
    if (start == std::string::npos)
    {
        return ""; // 如果全是空白字符，返回空字符串
    }

    // 查找 '=' 的位置
    size_t equal_pos = input.find('=', start);
    if (equal_pos == std::string::npos)
    {
        return ""; // 如果没有 '='，返回空字符串
    }

    // 从 '=' 向前查找最后一个非空字符的位置
    size_t end = input.find_last_not_of(" \t\n\r", equal_pos - 1);
    if (end == std::string::npos || end < start)
    {
        return ""; // 如果 '=' 前没有非空字符，返回空字符串
    }

    return input.substr(start, end - start + 1);
}

std::vector<EnumGenerator::QmlEnumInfo> EnumGenerator::parseQmlCommunicationClass(const std::filesystem::path &filePath)
{
    std::ifstream file(filePath);
    if (!file.is_open())
    {
        std::cerr << "can not open file: " << filePath << std::endl;
        return {};
    }
    std::vector<QmlEnumInfo> vEnumClass;
    QmlEnumInfo classInfo;
    std::string line;
    bool inMultiLineComment = false;
    bool inEnum = false;

    while (std::getline(file, line))
    {
        // 跳过注释和空行
        if (shouldSkipLine(line, inMultiLineComment))
            continue;

        if (line.find("enum class ActionsUI2CPP") != std::string::npos)
        {
            classInfo.EnumName = "ActionsUI2CPP";
            classInfo.enumItems.clear();
            inEnum = true;
        }
        else if (line.find("enum class ActionsCPP2UI") != std::string::npos)
        {
            classInfo.EnumName = "ActionsCPP2UI";
            classInfo.enumItems.clear();
            inEnum = true;
        }

        if (inEnum)
        {
            classInfo.enumItems.push_back(line);
            // 如果遇到 `}`，结束当前枚举解析
            if (line.find('}') != std::string::npos)
            {
                vEnumClass.push_back(classInfo);
                inEnum = false;
            }
        }
    }

    return vEnumClass;
}

bool EnumGenerator::shouldSkipLine(const std::string &line, bool &inMultiLineComment)
{
    // 跳过空行
    if (std::all_of(line.begin(), line.end(), isspace))
        return true;

    // 处理多行注释
    if (line.find("/*") != std::string::npos)
        inMultiLineComment = true;
    if (line.find("*/") != std::string::npos)
    {
        inMultiLineComment = false;
        return true;
    }
    if (inMultiLineComment)
        return true;

    // 处理单行注释
    size_t nonSpacePos = line.find_first_not_of(" \t");
    if (nonSpacePos != std::string::npos && line.substr(nonSpacePos, 2) == "//")
        return true;

    return false;
}