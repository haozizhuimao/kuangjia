#pragma once

#include "ReflectionGeneratorBase.h"

class ReflectEnum : private ReflectionGeneratorBase
{
  public:
    void generate(const std::string &rootPath);

  private:
    std::string marker() const override;
    std::string outputRelativePath() const override;
    std::string reflectionInclude() const override;
    std::string projectInclude() const override;
    std::string reflectionMacro() const override;
    size_t findDeclarationStart(const std::string &code, size_t markerPos) const override;
    size_t findNameStart(const std::string &code, size_t declarationPos) const override;
    ReflectionItems extractItems(const std::string &body) const override;
};
