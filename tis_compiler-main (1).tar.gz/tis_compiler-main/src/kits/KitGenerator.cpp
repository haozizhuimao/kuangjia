#include "KitGenerator.h"
#include "cmake/CmakeTools.h"

#include <algorithm>
#include <filesystem>
#include <format>
#include <fstream>
#include <regex>
#include <stdexcept>

void KitGenerator::generate(const std::string &rootPath, const std::unordered_set<std::string> &kitNames)
{
    const auto kitRootPath = rootPath + "/src/kits/";
    const auto fullKits = collectFullKits(kitRootPath);
    const auto kitList = resortKitList(fullKits, kitNames);
    buildMakefile(kitRootPath, kitList, fullKits);

    const bool needsSqlStructs = std::find(kitList.begin(), kitList.end(), "kit_database") != kitList.end();
    const bool needsQmlEnums = std::find(kitList.begin(), kitList.end(), "kit_ui_components") != kitList.end();

    if (needsSqlStructs)
    {
        sqlStructGenerator.generate(rootPath);
    }

    reflectStruct.generate(rootPath);
    reflectEnum.generate(rootPath);

    if (needsQmlEnums)
    {
        enumGenerator.generate(rootPath);
    }
}

std::vector<std::string> KitGenerator::sortKitNames(const std::unordered_set<std::string> &kitNames)
{
    if (kitNames.empty())
    {
        return {};
    }

    std::vector<std::string> orderedNames(kitNames.begin(), kitNames.end());
    std::sort(orderedNames.begin(), orderedNames.end());
    return orderedNames;
}

std::string KitGenerator::formatCycleMessage(const std::vector<std::string> &activePath, const std::string &repeatedKit)
{
    const auto cycleStart = std::find(activePath.begin(), activePath.end(), repeatedKit);
    std::string message = "Circular kit dependency detected: ";
    bool first = true;

    for (auto it = cycleStart; it != activePath.end(); ++it)
    {
        if (!first)
        {
            message += " -> ";
        }
        message += *it;
        first = false;
    }

    if (!first)
    {
        message += " -> ";
    }
    message += repeatedKit;
    return message;
}

std::vector<std::string> KitGenerator::resortKitList(const std::unordered_map<std::string, KitInfo> &fullKits,
                                                     const std::unordered_set<std::string> &kitNames)
{
    std::vector<std::string> orderedKits;
    std::unordered_map<std::string, VisitState> visitStates;

    for (const auto &item : sortKitNames(kitNames))
    {
        std::vector<std::string> activePath;
        appendKitDependencies(item, fullKits, visitStates, activePath, orderedKits);
    }

    return orderedKits;
}

void KitGenerator::appendKitDependencies(const std::string &kitName,
                                         const std::unordered_map<std::string, KitInfo> &fullKits,
                                         std::unordered_map<std::string, VisitState> &visitStates,
                                         std::vector<std::string> &activePath,
                                         std::vector<std::string> &orderedKits)
{
    const auto stateIt = visitStates.find(kitName);
    if (stateIt != visitStates.end())
    {
        if (stateIt->second == VisitState::Visiting)
        {
            throw std::runtime_error(formatCycleMessage(activePath, kitName));
        }
        return;
    }

    const auto kitIt = fullKits.find(kitName);
    if (kitIt == fullKits.end())
    {
        throw std::runtime_error(std::format("Kit {} not found!", kitName));
    }

    visitStates[kitName] = VisitState::Visiting;
    activePath.push_back(kitName);
    for (const auto &dependency : kitIt->second.dependencies)
    {
        appendKitDependencies(dependency, fullKits, visitStates, activePath, orderedKits);
    }
    activePath.pop_back();
    visitStates[kitName] = VisitState::Visited;
    orderedKits.push_back(kitName);
}

std::unordered_map<std::string, KitGenerator::KitInfo> KitGenerator::collectFullKits(const std::string &kitRoot)
{
    std::unordered_map<std::string, KitInfo> fulls;
    namespace fs = std::filesystem;

    const std::regex kitNameRegex(R"(set\s*\(\s*KIT_NAME\s+\"([^\"]+)\"\s*\))");

    for (const auto &entry : fs::recursive_directory_iterator(kitRoot))
    {
        if (!entry.is_regular_file() || entry.path().filename() != "CMakeLists.txt")
        {
            continue;
        }

        std::ifstream file(entry.path());
        const std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());

        std::smatch match;
        if (!std::regex_search(content, match, kitNameRegex) || match.size() <= 1)
        {
            continue;
        }

        KitInfo info;
        const std::string kitName = match[1].str();
        info.relativePath = fs::relative(entry.path().parent_path(), kitRoot).generic_string();
        info.dependencies = sortKitNames(CmakeTools::extractTargetKitNames(content, "${KIT_NAME}"));
        fulls[kitName] = std::move(info);
    }

    return fulls;
}

void KitGenerator::buildMakefile(const std::string &kitRootPath,
                                 const std::vector<std::string> &kitList,
                                 const std::unordered_map<std::string, KitInfo> &fulls)
{
    std::ofstream of(kitRootPath + "/CMakeLists.txt");
    of << "# [tis_compiler] generate !\n";
    of << "# 不要自己手动改.\n";
    of << "message(\"===================== KITS SWITCH =====================\")\n";
    for (const auto &it : kitList)
    {
        of << "add_subdirectory(\"" << fulls.at(it).relativePath << "\")\n";
    }
    of << "message(\"===================== KITS SWITCH =====================\")\n";
}
