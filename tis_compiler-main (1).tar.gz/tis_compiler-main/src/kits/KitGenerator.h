#pragma once

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "EnumGenerator.h"
#include "ReflectEnum.h"
#include "ReflectStruct.h"
#include "SqlStructGenerator.h"

class KitGenerator
{
  public:
    void generate(const std::string &rootPath, const std::unordered_set<std::string> &kitNames);

  private:
    struct KitInfo
    {
        std::string relativePath;
        std::vector<std::string> dependencies;
    };

    enum class VisitState
    {
        Visiting,
        Visited
    };

    std::vector<std::string> resortKitList(const std::unordered_map<std::string, KitInfo> &fulls,
                                           const std::unordered_set<std::string> &kitNames);
    void appendKitDependencies(const std::string &kitName,
                               const std::unordered_map<std::string, KitInfo> &fulls,
                               std::unordered_map<std::string, VisitState> &visitStates,
                               std::vector<std::string> &activePath,
                               std::vector<std::string> &orderedKits);
    void buildMakefile(const std::string &kitRootPath,
                       const std::vector<std::string> &kitList,
                       const std::unordered_map<std::string, KitInfo> &fulls);
    std::unordered_map<std::string, KitInfo> collectFullKits(const std::string &kitRoot);
    static std::vector<std::string> sortKitNames(const std::unordered_set<std::string> &kitNames);
    static std::string formatCycleMessage(const std::vector<std::string> &activePath, const std::string &repeatedKit);

    SqlStructGenerator sqlStructGenerator;
    EnumGenerator enumGenerator;
    ReflectEnum reflectEnum;
    ReflectStruct reflectStruct;
};
