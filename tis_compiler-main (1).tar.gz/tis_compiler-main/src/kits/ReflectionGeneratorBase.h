#pragma once

#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

class ReflectionGeneratorBase
{
  protected:
    using ReflectionItems = std::vector<std::string>;

    void generateReflections(const std::string &rootPath);
    static std::string trim(const std::string &value);
    static size_t skipWhitespace(const std::string &code, size_t pos);
    static bool matchesKeyword(const std::string &code, size_t pos, std::string_view keyword);

  private:
    using ReflectionMap = std::unordered_map<std::string, ReflectionItems>;

    void parsePath(const std::string &path);
    void parseFile(const std::string &filePath);
    void writeOutput(const std::string &outputPath) const;

    static std::string removeComments(const std::string &code);
    static bool isIdentifierChar(char ch);
    static size_t findMatchingBrace(const std::string &code, size_t openBrace);

    virtual std::string marker() const = 0;
    virtual std::string outputRelativePath() const = 0;
    virtual std::string reflectionInclude() const = 0;
    virtual std::string projectInclude() const = 0;
    virtual std::string reflectionMacro() const = 0;
    virtual size_t findDeclarationStart(const std::string &code, size_t markerPos) const = 0;
    virtual size_t findNameStart(const std::string &code, size_t declarationPos) const = 0;
    virtual ReflectionItems extractItems(const std::string &body) const = 0;

  protected:
    ReflectionMap reflectionMap_;
};
