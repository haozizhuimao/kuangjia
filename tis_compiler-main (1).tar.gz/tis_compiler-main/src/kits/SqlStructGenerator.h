#pragma once
#include <string>
#include <unordered_map>
#include <vector>

class SqlStructGenerator
{
  public:
    void generate(const std::string &rootPath);

  private:
    struct FieldInfo
    {
        std::string name;
        std::string cppType;
        std::string sqlType;
        bool isPrimaryKey = false;
        bool isNotNull = false;
    };

    struct TableInfo
    {
        std::string name;
        std::vector<FieldInfo> fields;
    };

  private:
    std::vector<TableInfo> parseSqlFile(const std::string &filePath);
    void generateStructs(const std::string &output, const std::vector<TableInfo> &tables);
    std::string toLower(const std::string &str);
    std::string toUpper(const std::string &str);
    std::string removeComments(const std::string &sql);
    std::string getCppType(const std::string &sqlType);
    std::string getConversionMethod(const std::string &cppType);

    const std::unordered_map<std::string, std::string> sqlToCppTypeMap = {{"boolean", "bool"},
                                                                          {"bool", "bool"},
                                                                          {"int", "int"},
                                                                          {"integer", "int"},
                                                                          {"bigint", "int64_t"},
                                                                          {"real", "double"},
                                                                          {"double", "double"},
                                                                          {"float", "float"},
                                                                          {"text", "std::string"},
                                                                          {"varchar", "std::string"},
                                                                          {"char", "std::string"},
                                                                          {"timestamp", "std::chrono::system_clock::time_point"}};
};
