
#pragma once
#include <string>
#include <vector>
struct FunctionInfo
{
    std::string name;
    std::string macroType; // "tis_sender" 或 "tis_receiver"
    std::string args;
};

struct ClassInfo
{
    std::string className;
    std::vector<FunctionInfo> senders;
    std::vector<FunctionInfo> receivers;
};