#include "CompilerApp.h"

#include "version/VersionInfo.h"
#include "controllers/CtrlGenerator.h"
#include "kits/KitGenerator.h"
#include "modules/ModuleGenerator.h"
#include "service/ServiceGenerator.h"

#include <exception>
#include <iostream>
#include <unordered_set>

int CompilerApp::run(const std::string &inputPath)
{
    try
    {
        auto versionPath = inputPath + "/.version";
        VersionInfo vInfo(inputPath);
        if (vInfo.version().empty())
        {
            std::cerr << "Error: Could not read version file: " << inputPath << std::endl;
            return 1;
        }

        std::unordered_set<std::string> candidateKitNames;

        CtrlGenerator ctrlGen;
        ctrlGen.generate(vInfo);
        auto moduleNames = ctrlGen.getModuleNames();
        auto controllerKitNames = ctrlGen.getKitNames();
        if (moduleNames.empty() && controllerKitNames.empty())
        {
            std::cerr << "Warning: No modules or kits found in controllers.\n";
            return 0;
        }
        candidateKitNames.merge(controllerKitNames);

        ModuleGenerator moduleGen;
        moduleGen.generate(inputPath, moduleNames);
        candidateKitNames.merge(moduleGen.getKitNames());

        ServiceGenerator serviceGen;
        serviceGen.generate(inputPath, moduleGen.getClassInfos());
        candidateKitNames.merge(serviceGen.getKitNames());

        KitGenerator kitGen;
        kitGen.generate(inputPath, candidateKitNames);
        return 0;
    }
    catch (const std::exception &ex)
    {
        std::cerr << ex.what() << std::endl;
        return 1;
    }
}
