#pragma once

#include <string>
class CompilerApp
{
  public:
    int run(const std::string &inputPath);
};
