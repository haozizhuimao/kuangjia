#pragma once
#include <string>
#include <unordered_map>

class VersionInfo
{
  public:
    VersionInfo(const std::string &rootPath);
    std::string rootPath() const;
    std::string version() const;

    std::string compilerId() const;

  private:
    std::string detectCompilerId() const;
    std::string trim(std::string value);
    std::unordered_map<std::string, std::string> readFile(const std::string &filePath);
    std::string extractOptionalValue(const std::string &key) const;

  private:
    std::string rootPath_;
    std::string versionName_;
    std::unordered_map<std::string, std::string> values_;
};
