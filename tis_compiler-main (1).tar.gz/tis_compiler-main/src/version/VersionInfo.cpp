#include "VersionInfo.h"
#include <fstream>
#include <iostream>

VersionInfo::VersionInfo(const std::string &rootPath)
{
    rootPath_ = rootPath;
    auto verPath = rootPath + "/.version";
    values_ = readFile(verPath);
    versionName_ = extractOptionalValue("CURRENT_VERSION");
}

std::string VersionInfo::rootPath() const
{
    return rootPath_;
}
std::string VersionInfo::version() const
{
    return versionName_;
}

std::string VersionInfo::compilerId() const
{
    return detectCompilerId();
}

std::string VersionInfo::detectCompilerId() const
{
#if defined(__apple_build_version__)
    return "AppleClang";
#elif defined(__clang__)
    return "Clang";
#elif defined(__INTEL_LLVM_COMPILER)
    return "IntelLLVM";
#elif defined(__INTEL_COMPILER)
    return "Intel";
#elif defined(_MSC_VER)
    return "MSVC";
#elif defined(__GNUC__)
    return "GNU";
#else
    return "Unknown";
#endif
}

std::string VersionInfo::extractOptionalValue(const std::string &key) const
{
    auto it = values_.find(key);
    return it == values_.end() ? std::string{} : it->second;
}

std::string VersionInfo::trim(std::string value)
{
    const size_t start = value.find_first_not_of(" \t\r\n");
    if (start == std::string::npos)
    {
        return "";
    }

    const size_t end = value.find_last_not_of(" \t\r\n");
    return value.substr(start, end - start + 1);
}

std::unordered_map<std::string, std::string> VersionInfo::readFile(const std::string &filePath)
{
    std::unordered_map<std::string, std::string> values;
    std::ifstream file(filePath);
    if (!file.is_open())
    {
        std::cerr << "Error: Could not open version file: " << filePath << "\n";
        return values;
    }

    std::string line;
    while (std::getline(file, line))
    {
        const auto trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == '#')
        {
            continue;
        }

        const auto separator = trimmed.find('=');
        if (separator == std::string::npos)
        {
            continue;
        }

        auto key = trim(trimmed.substr(0, separator));
        auto value = trim(trimmed.substr(separator + 1));
        if (!value.empty() && value.front() == '"' && value.back() == '"' && value.size() >= 2)
        {
            value = value.substr(1, value.size() - 2);
        }

        values[std::move(key)] = std::move(value);
    }

    return values;
}
