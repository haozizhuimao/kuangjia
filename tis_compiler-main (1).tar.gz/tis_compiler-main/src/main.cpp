#include "compiler/CompilerApp.h"
#include <iostream>
int main(int argc, char *argv[])
{
    std::string inputPath;
#if defined(_DEBUG)
    inputPath = "D:/workspace/code/togee_infinity_station/";
#else
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " <input_dir>" << std::endl;
        return 1;
    }
    inputPath = argv[1];
#endif
    CompilerApp app;
    return app.run(inputPath);
}
