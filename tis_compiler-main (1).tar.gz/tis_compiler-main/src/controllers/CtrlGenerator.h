#pragma once

#include "CtrlClass.h"
#include "CtrlVersion.h"
#include <unordered_set>
#include "version/VersionInfo.h"
#include <string>

class CtrlGenerator
{
  public:
    void generate(const VersionInfo &vInfo);
    std::unordered_set<std::string> getModuleNames() const;
    std::unordered_set<std::string> getKitNames() const;

  private:
    CtrlVersion m_ctlVersion;
    CtrlClass m_ctlClass;
    std::unordered_set<std::string> m_moduleNames;
    std::unordered_set<std::string> m_kitNames;
};
