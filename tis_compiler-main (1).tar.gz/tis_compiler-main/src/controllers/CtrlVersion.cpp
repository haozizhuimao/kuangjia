#include "CtrlVersion.h"

#include "cmake/CmakeTools.h"

void CtrlVersion::parse(const VersionInfo &vInfo)
{
    std::string filePath = vInfo.rootPath() + "/tis_cmake/version_build/" + vInfo.version() + ".cmake";
    auto content = CmakeTools::readCmake(filePath);
    m_ctlNames = CmakeTools::extractListValues(content, "CTLS_CONFIGS");

    for (const auto &ctlItem : m_ctlNames)
    {
        if (ctlItem.empty())
        {
            continue;
        }

        std::string ctlCmake = vInfo.rootPath() + "/src/controllers/" + ctlItem + "/CMakeLists.txt";
        auto tempContent = CmakeTools::readCmake(ctlCmake);
        auto kitNames = CmakeTools::extractTargetKitNames(tempContent, "${CTL_NAME}");
        m_kitNames.merge(kitNames);
    }
}

std::vector<std::string> CtrlVersion::getCtlNames() const
{
    return m_ctlNames;
}

std::unordered_set<std::string> CtrlVersion::getKitNames() const
{
    return m_kitNames;
}
