#include "CtrlClass.h"
#include <regex>
#include <filesystem>
#include <fstream>
#include <iostream>

void CtrlClass::parse(const std::string &rootPath, const std::vector<std::string> &ctlNames)
{
    for (const auto &ctl_item : ctlNames)
    {
        if (ctl_item.empty())
        {
            continue;
        }
        else if (ctl_item == "qml")
        {
            m_moduleNames.insert("UIEngine");
            continue;
        }
        else if (ctl_item == "remote_access")
        {
            m_moduleNames.insert("RemoteAccess");
            continue;
        }
        std::string ctlPath = rootPath + "/src/controllers/" + ctl_item;
        auto moduleNames = findModuleNames(ctlPath);
        m_moduleNames.merge(moduleNames);
    }
}

std::unordered_set<std::string> CtrlClass::getModuleNames() const
{
    return m_moduleNames;
}

bool CtrlClass::isTargetClass(const std::string &content)
{
    static const std::regex classRegex(R"(class\s+(\w+)\s+.*?:\s*public\s+[\w:]*ControllerBase\s*<\s*\1\s*>)");
    return std::regex_search(content, classRegex);
}
std::unordered_set<std::string> CtrlClass::findModuleNames(const std::string &controllerPath)
{
    namespace fs = std::filesystem;
    std::unordered_set<std::string> moduleNames;
    for (const auto &entry : fs::recursive_directory_iterator(controllerPath))
    {
        const std::string extension = entry.path().extension().string();
        if (entry.is_regular_file() && extension == ".h")
        {
            std::ifstream headerFile(entry.path());
            std::string content((std::istreambuf_iterator<char>(headerFile)), std::istreambuf_iterator<char>());
            if (!isTargetClass(content))
            {
                // std::cerr << entry.path() << std::endl;
                // std::cerr << "原因: 格式匹配失败。" << std::endl;
                continue;
            }
            std::unordered_set<std::string> namesInHeader = findInContent(content);
            moduleNames.merge(namesInHeader);
            auto cppPath = entry.path();
            std::ifstream cppFile(cppPath.replace_extension(".cpp"));
            std::string cppContent((std::istreambuf_iterator<char>(cppFile)), std::istreambuf_iterator<char>());
            std::unordered_set<std::string> namesInCpp = findInContent(cppContent);
            moduleNames.merge(namesInCpp);
        }
    }
    return moduleNames;
}

std::unordered_set<std::string> CtrlClass::findInContent(const std::string &content)
{
    static const std::regex serviceCallRegex(R"(_Service::([A-Za-z_]\w*)::([A-Za-z_]\w*)(?!\s*\)\s*;))");
    std::unordered_set<std::string> moduleNames;
    std::smatch match;
    std::string::const_iterator searchStart(content.cbegin());
    while (std::regex_search(searchStart, content.cend(), match, serviceCallRegex))
    {
        if (match.size() > 2)
        {
            moduleNames.insert(match[1].str());
        }
        searchStart = match.suffix().first;
    }
    return moduleNames;
}