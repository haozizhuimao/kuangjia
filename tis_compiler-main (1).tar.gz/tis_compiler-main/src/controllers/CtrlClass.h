#pragma once
#include <unordered_set>
#include <vector>
#include <string>

class CtrlClass
{
  public:
    void parse(const std::string &rootPath, const std::vector<std::string> &ctlNames);
    std::unordered_set<std::string> getModuleNames() const;

  private:
    std::unordered_set<std::string> findModuleNames(const std::string &controllerPath);
    std::unordered_set<std::string> findInContent(const std::string &content);
    bool isTargetClass(const std::string &content);
    std::unordered_set<std::string> m_moduleNames;
};