#include "CtrlGenerator.h"

void CtrlGenerator::generate(const VersionInfo &vInfo)
{
    m_ctlVersion.parse(vInfo);
    m_kitNames = m_ctlVersion.getKitNames();
    m_ctlClass.parse(vInfo.rootPath(), m_ctlVersion.getCtlNames());
    m_moduleNames = m_ctlClass.getModuleNames();
}

std::unordered_set<std::string> CtrlGenerator::getModuleNames() const
{
    return m_moduleNames;
}

std::unordered_set<std::string> CtrlGenerator::getKitNames() const
{
    return m_kitNames;
}
