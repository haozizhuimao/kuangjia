#pragma once
#include <unordered_set>
#include <vector>
#include <string>
#include "version/VersionInfo.h"

class CtrlVersion
{
  public:
    void parse(const VersionInfo &versionTool);
    std::unordered_set<std::string> getKitNames() const;
    std::vector<std::string> getCtlNames() const;
    std::unordered_set<std::string> m_kitNames;
    std::vector<std::string> m_ctlNames;
};
