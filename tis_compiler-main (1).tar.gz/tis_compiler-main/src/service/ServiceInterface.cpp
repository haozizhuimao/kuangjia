
#include "ServiceInterface.h"
#include <iostream>
#include <fstream>

void ServiceInterface::make(const std::vector<ClassInfo> &classInfos, const std::string &sevRootPath)
{
    std::string typesPath = sevRootPath + "/AppInnerTypes.h";
    std::string moduleHelpPath = sevRootPath + "/AppModuleHelper.h";
    std::string apiPath = sevRootPath + "/AppInterface.h";
    makeAppInnerTypes(classInfos, typesPath);
    makeModuleHelper(classInfos, moduleHelpPath);
    makeAppInterface(classInfos, apiPath);
}

void ServiceInterface::makeAppInnerTypes(const std::vector<ClassInfo> &classInfos, const std::string &filePath)
{
    std::ofstream file(filePath);
    if (!file.is_open())
    {
        std::cerr << "can not write file: " << filePath << std::endl;
        return;
    }
    file << "// [tis_compiler] auto-generate, 不要自己手动改!\n"
         << "#pragma once\n"
         << "#include \"AppDeclare.h\"\n"
         << "namespace _Service \n{\n"
         << "    namespace _Details\n"
         << "    {\n";
    for (const auto &classInfo : classInfos)
    {
        for (const auto &sig : classInfo.senders)
        {
            file << "        __DECLARE_SERVICE_TYPES(" << classInfo.className << ", " << sig.name << ")\n";
        }
        for (const auto &slot : classInfo.receivers)
        {
            file << "        __DECLARE_SERVICE_TYPES(" << classInfo.className << ", " << slot.name << ")\n";
        }
    }
    file << "    } // namespace _Details\n"
         << "} // namespace _Service\n";
}

void ServiceInterface::makeAppInterface(const std::vector<ClassInfo> &classInfos, const std::string &filePath)
{
    std::ofstream file(filePath);
    if (!file.is_open())
    {
        std::cerr << "can not write file: " << filePath << std::endl;
        return;
    }
    file << "// [tis_compiler] auto-generate, 不要自己手动改!\n"
         << "#pragma once\n"
         << "#include \"AppInnerTypes.h\"\n"
         << "namespace _Service \n{\n";
    for (const auto &classInfo : classInfos)
    {
        file << "    namespace " << classInfo.className << "{\n";
        for (const auto &sig : classInfo.senders)
        {
            file << "        __DECLARE_SERVICE_API(" << classInfo.className << ", " << sig.name << ")\n";
        }
        for (const auto &slot : classInfo.receivers)
        {
            file << "        __DECLARE_SERVICE_API(" << classInfo.className << ", " << slot.name << ")\n";
        }
        file << "    }\n";
    }
    file << "} // namespace _Service";
}
void ServiceInterface::makeModuleHelper(const std::vector<ClassInfo> &classInfos, const std::string &filePath)
{
    std::ofstream file(filePath);
    if (!file.is_open())
    {
        std::cerr << "can not write file: " << filePath << std::endl;
        return;
    }
    file << "// [tis_compiler] auto-generate, 不要自己手动改!\n"
         << "#pragma once\n"
         << "#include \"AppInnerTypes.h\"\n"
         << "namespace _Service \n{\n"
         << "    namespace _Details\n"
         << "    {\n"
         << "        inline void moduleHelper(_Kits::ModuleBase *mod)\n"
         << "        {\n";

    for (const auto &classInfo : classInfos)
    {
        for (const auto &sig : classInfo.senders)
        {
            file << "            ___DECLARE_SERVICE_HELPER_INNER_(" << classInfo.className << ", " << sig.name << ")\n";
        }
        for (const auto &slot : classInfo.receivers)
        {
            file << "            ___DECLARE_SERVICE_HELPER_INNER_(" << classInfo.className << ", " << slot.name << ")\n";
        }
    }
    file << "        }\n"
         << "    } // namespace _Details\n"
         << "} // namespace _Service\n";
}