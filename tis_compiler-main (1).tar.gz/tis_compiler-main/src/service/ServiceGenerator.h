#pragma once
#include <unordered_set>
#include <string>
#include "ServiceInterface.h"

class ServiceGenerator
{
  public:
    void generate(const std::string &rootPath, const std::vector<ClassInfo> &classInfos);
    std::unordered_set<std::string> getKitNames() const;

  private:
    std::unordered_set<std::string> m_kitNames;
    ServiceInterface m_serviceInterface;
};
