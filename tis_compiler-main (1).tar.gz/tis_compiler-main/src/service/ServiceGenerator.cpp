
#include "ServiceGenerator.h"
#include "cmake/CmakeTools.h"

void ServiceGenerator::generate(const std::string &rootPath, const std::vector<ClassInfo> &classInfos)
{
    auto sevRootPath = rootPath + "/src/service/";

    auto tempContext = CmakeTools::readCmake(sevRootPath + "CMakeLists.txt");
    m_kitNames = CmakeTools::extractTargetKitNames(tempContext, "lib_service");
    m_serviceInterface.make(classInfos, sevRootPath);
}
std::unordered_set<std::string> ServiceGenerator::getKitNames() const
{
    return m_kitNames;
}