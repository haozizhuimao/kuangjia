#pragma once
#include <string>
#include "struct/GlobalStruct.h"
class ServiceInterface
{
  public:
    void make(const std::vector<ClassInfo> &classInfos, const std::string &sevRootPath);

  private:
    void makeAppInnerTypes(const std::vector<ClassInfo> &classInfos, const std::string &filePath);
    void makeModuleHelper(const std::vector<ClassInfo> &classInfos, const std::string &filePath);
    void makeAppInterface(const std::vector<ClassInfo> &classInfos, const std::string &filePath);
};