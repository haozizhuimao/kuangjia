#include "kits/KitGenerator.h"
#include "kits/ReflectEnum.h"
#include "kits/ReflectStruct.h"
#include "kits/ReflectionGeneratorBase.h"
#include "kits/SqlStructGenerator.h"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <unordered_set>

namespace fs = std::filesystem;

namespace
{
    class ProbeReflectionGenerator : private ReflectionGeneratorBase
    {
      public:
        void generate(const std::string &rootPath)
        {
            generateReflections(rootPath);
        }

        int extractCallCount() const
        {
            return extractCallCount_;
        }

      private:
        std::string marker() const override
        {
            return "REFLECTION_PROBE";
        }

        std::string outputRelativePath() const override
        {
            return "/src/kits/utility/serialization/reflection_probe_extension.h";
        }

        std::string reflectionInclude() const override
        {
            return "reflection_probe.h";
        }

        std::string projectInclude() const override
        {
            return "tis_global/Struct.h";
        }

        std::string reflectionMacro() const override
        {
            return "__REFLECTION_PROBE";
        }

        size_t findDeclarationStart(const std::string &code, size_t markerPos) const override
        {
            return code.find("struct", markerPos);
        }

        size_t findNameStart(const std::string &code, size_t declarationPos) const override
        {
            return skipWhitespace(code, declarationPos + std::string_view("struct").size());
        }

        ReflectionItems extractItems(const std::string &) const override
        {
            ++extractCallCount_;
            return {"value"};
        }

        mutable int extractCallCount_ = 0;
    };

    fs::path fixtureRoot(std::string_view name)
    {
        return fs::path(TIS_COMPILER_SOURCE_DIR) / ".cache" / "reflection-tests" / name;
    }

    void resetFixture(const fs::path &root)
    {
        std::error_code ec;
        fs::remove_all(root, ec);
        fs::create_directories(root);
    }

    void writeText(const fs::path &path, std::string_view content)
    {
        fs::create_directories(path.parent_path());
        std::ofstream out(path, std::ios::binary);
        if (!out.is_open())
        {
            throw std::runtime_error("Cannot write file: " + path.string());
        }
        out << content;
    }

    std::string readText(const fs::path &path)
    {
        std::ifstream in(path, std::ios::binary);
        if (!in.is_open())
        {
            throw std::runtime_error("Cannot read file: " + path.string());
        }
        return std::string((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    }

    void requireContains(const std::string &text, std::string_view expected, std::string_view label)
    {
        if (text.find(expected) == std::string::npos)
        {
            throw std::runtime_error("Missing expected content for " + std::string(label) + ": " + std::string(expected));
        }
    }

    size_t countOccurrences(const std::string &text, std::string_view needle)
    {
        if (needle.empty())
        {
            return 0;
        }

        size_t count = 0;
        size_t pos = 0;
        while ((pos = text.find(needle, pos)) != std::string::npos)
        {
            ++count;
            pos += needle.size();
        }
        return count;
    }

    void testStructGeneratorWritesReflectionStructExtension()
    {
        const auto root = fixtureRoot("struct");
        resetFixture(root);

        writeText(root / "src/tis_global/Struct.h", "#pragma once\n");
        writeText(root / "src/tis_global/TestStructs.h", R"(#pragma once
namespace TIS_Info {
REFLECTION_STRUCT struct Sample
{
    int id = 1;
    std::string name;
    static int ignored;
    using Alias = int;
    typedef long LongType;
    friend class Friend;
    void skip();
    int values[4];
    const char *raw = nullptr;
};
} // namespace TIS_Info
)");
        fs::create_directories(root / "src/kits/utility/serialization");

        ReflectStruct generator;
        generator.generate(root.string());

        const auto outputPath = root / "src/kits/utility/serialization/reflection_struct_extension.h";
        const auto output = readText(outputPath);
        requireContains(output, "#include \"reflection_struct.h\"", "struct include");
        requireContains(output, "#include \"tis_global/Struct.h\"", "struct header include");
        requireContains(output, "__REFLECTION_STRUCT_INNER(TIS_Info::Sample, id, name, values, raw)", "struct reflection body");

        if (fs::exists(root / "src/kits/utility/serialization/reflection_extension.h"))
        {
            throw std::runtime_error("Old reflection_extension.h should not be generated anymore.");
        }
    }

    void testEnumGeneratorWritesReflectionEnumExtension()
    {
        const auto root = fixtureRoot("enum");
        resetFixture(root);

        writeText(root / "src/tis_global/EnumPublic.h", "#pragma once\n");
        writeText(root / "src/tis_global/TestEnums.h", R"(#pragma once
namespace TIS_Info {
REFLECTION_ENUM enum class Mode : int
{
    Idle = 0,
    Running = 1 << 1,
    Error,
};

REFLECTION_ENUM enum Legacy
{
    Unknown,
    Ready = 10,
};
} // namespace TIS_Info
)");
        fs::create_directories(root / "src/kits/utility/serialization");

        ReflectEnum generator;
        generator.generate(root.string());

        const auto output = readText(root / "src/kits/utility/serialization/reflection_enum_extension.h");
        requireContains(output, "#include \"reflection_enum.h\"", "enum include");
        requireContains(output, "#include \"tis_global/EnumPublic.h\"", "enum header include");
        requireContains(output, "__REFLECTION_ENUM_INNER(TIS_Info::Mode, Idle, Running, Error)", "enum class reflection body");
        requireContains(output, "__REFLECTION_ENUM_INNER(TIS_Info::Legacy, Unknown, Ready)", "enum reflection body");
    }

    void testKitGeneratorReflectsSqlStructsInSameRun()
    {
        const auto root = fixtureRoot("kit");
        resetFixture(root);

        writeText(root / "src/tis_global/Struct.h", "#pragma once\n");
        writeText(root / "src/tis_global/EnumPublic.h", "#pragma once\n");
        writeText(root / "config/database_manager/pg_init/createtable.sql", R"(CREATE TABLE demo_table (
    id int PRIMARY KEY,
    name varchar(64) NOT NULL
);
)");
        writeText(root / "src/kits/database/CMakeLists.txt", "set(KIT_NAME \"kit_database\")\n");
        fs::create_directories(root / "src/tis_global/struct_details");
        fs::create_directories(root / "src/kits/utility/serialization");

        KitGenerator generator;
        generator.generate(root.string(), {"kit_database"});

        const auto sqlStruct = readText(root / "src/tis_global/struct_details/sql_struct.h");
        requireContains(sqlStruct, "#include \"kits/utility/serialization/reflection_struct.h\"", "sql reflection include");

        const auto reflectionStruct = readText(root / "src/kits/utility/serialization/reflection_struct_extension.h");
        requireContains(reflectionStruct, "__REFLECTION_STRUCT_INNER(TIS_Info::demo_table, id, name)", "sql struct reflection");
    }

    void testReflectionGeneratorBaseScansNestedHeadersOnlyOnce()
    {
        const auto root = fixtureRoot("scan-once");
        resetFixture(root);

        writeText(root / "src/tis_global/Struct.h", "#pragma once\n");
        writeText(root / "src/tis_global/RootProbe.h", R"(REFLECTION_PROBE struct RootProbe
{
    int value;
};
)");
        writeText(root / "src/tis_global/nested/NestedProbe.h", R"(REFLECTION_PROBE struct NestedProbe
{
    int value;
};
)");
        fs::create_directories(root / "src/kits/utility/serialization");

        ProbeReflectionGenerator generator;
        generator.generate(root.string());

        if (generator.extractCallCount() != 2)
        {
            throw std::runtime_error("Nested headers should be scanned exactly once.");
        }
    }

    void testSqlStructGeneratorDoesNotAccumulateTablesAcrossRuns()
    {
        const auto root = fixtureRoot("sql-repeat");
        resetFixture(root);

        writeText(root / "config/database_manager/pg_init/createtable.sql", R"(CREATE TABLE demo_table (
    id int PRIMARY KEY,
    name varchar(64) NOT NULL
);
)");
        fs::create_directories(root / "src/tis_global/struct_details");

        SqlStructGenerator generator;
        generator.generate(root.string());
        generator.generate(root.string());

        const auto output = readText(root / "src/tis_global/struct_details/sql_struct.h");
        if (countOccurrences(output, "REFLECTION_STRUCT struct demo_table") != 1)
        {
            throw std::runtime_error("SqlStructGenerator should not duplicate tables across repeated generate() calls.");
        }
    }
} // namespace

int main()
{
    try
    {
        testStructGeneratorWritesReflectionStructExtension();
        testEnumGeneratorWritesReflectionEnumExtension();
        testKitGeneratorReflectsSqlStructsInSameRun();
        testReflectionGeneratorBaseScansNestedHeadersOnlyOnce();
        testSqlStructGeneratorDoesNotAccumulateTablesAcrossRuns();
        std::cout << "Reflection generator regression tests passed.\n";
        return 0;
    }
    catch (const std::exception &ex)
    {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
