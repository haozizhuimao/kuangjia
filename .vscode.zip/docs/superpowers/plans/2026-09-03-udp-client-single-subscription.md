# UDP 客户端单订阅实施计划

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 使每个 `UdpClient` 只接受一个可同步确认的订阅，并在 UDP strand 上有序执行回调与非阻塞停止清理。

**Architecture:** 以互斥锁保护唯一订阅槽位和订阅入口状态，避免同步 `bool subscribe()` 依赖异步 strand 投递。读循环仍由 `strand_` 串行驱动，接收分发直接调用复制出的唯一回调。停止操作先关闭订阅入口，再异步进入 strand 清理，并用可选完成回调报告收敛完成。

**Tech Stack:** C++20、Standalone Asio 1.36、CMake/Ninja、CTest 自定义断言测试程序。

---

## Chunk 1: 测试支撑与订阅契约

### Task 1: 建立 UDP 行为测试

**Files:**
- Create: `src/kits/communication/asio/udp_client/UdpClientTests.cpp`
- Modify: `src/kits/communication/asio/udp_client/CMakeLists.txt`
- Modify: `CMakeLists.txt`

- [ ] **Step 1: 建立最小测试骨架与目标**

先创建只含成功返回 `main()` 的 `UdpClientTests.cpp` 骨架；将该文件从现有 `file(GLOB .../*.cpp)` 收集结果中排除，确保测试 `main()` 不会进入 `kit_asio_udp` 对象库和产品可执行文件；随后仅在 `BUILD_TESTING` 下创建独立 `udp_client_tests` 目标并注册 CTest。测试目标复用 UDP 实现和既有依赖，但不引入新的第三方测试框架。先构建并运行该空测试，确认测试基础设施可用。

- [ ] **Step 2: 写出失败测试**

新增 CTest 可执行程序，使用真实 `asio::io_context` 和 loopback UDP 端点验证：首个非空订阅返回真；第二个订阅返回假；发送两个载荷后，首个回调只收到且按发送顺序保存两个载荷。

- [ ] **Step 3: 运行测试确认失败**

运行：`cmake --build build --target udp_client_tests && ctest --test-dir build --output-on-failure -R udp_client_tests`

预期：由于 `subscribe()` 仍为 `void` 且现有实现允许多个订阅，测试编译失败或断言失败；此即所需的红灯。

## Chunk 2: 单订阅与串行回调

### Task 2: 实现唯一订阅槽位

**Files:**
- Modify: `src/kits/communication/asio/udp_client/UdpClient.h`
- Modify: `src/kits/communication/asio/udp_client/UdpClient.cpp`
- Test: `src/kits/communication/asio/udp_client/UdpClientTests.cpp`

- [ ] **Step 1: 扩展失败测试**

补充空回调失败、第二次订阅不覆盖首个回调、所有回调在同一个顺序上下文内完成的断言。

- [ ] **Step 2: 运行测试确认失败**

运行：`cmake --build build --target udp_client_tests && ctest --test-dir build --output-on-failure -R udp_client_tests`

预期：空回调和重复订阅契约失败，或分发仍经全局线程池。

- [ ] **Step 3: 实现最小生产改动**

将 `subscribers_` 替换为受 `subscriptionMutex_` 保护的唯一 `subscriber_` 和 `acceptingSubscription_` 状态。`subscribe()` 同步返回 `bool`；空回调、重复订阅、停止中的订阅均记录含模块名、客户端标题和原因的中文错误日志。`dispatchIncoming()` 在锁内复制回调、解锁后直接调用 `invokeReceiveCallback()`，删除对全局 `thread_pool` 的依赖。

- [ ] **Step 4: 运行测试确认通过**

运行同一命令，预期所有单订阅和顺序测试通过。

## Chunk 3: 非阻塞停止与回归验证

### Task 3: 添加停止完成回调并收敛订阅状态

**Files:**
- Modify: `src/kits/communication/asio/udp_client/UdpClient.h`
- Modify: `src/kits/communication/asio/udp_client/UdpClient.cpp`
- Test: `src/kits/communication/asio/udp_client/UdpClientTests.cpp`

- [ ] **Step 1: 写出失败测试**

在单线程 `io_context` handler 中调用 `stop(完成回调)`，断言调用立即返回；完成回调到达后重启客户端并发送 loopback 数据，断言旧回调不再执行、新订阅可成功注册且接收新包。

- [ ] **Step 2: 运行测试确认失败**

运行：`cmake --build build --target udp_client_tests && ctest --test-dir build --output-on-failure -R udp_client_tests`

预期：现有阻塞 `future.get()` 或未清空订阅导致失败。

- [ ] **Step 3: 实现最小生产改动**

将 `stop()` 改为接受可选完成回调的非阻塞接口：发起停止时在订阅锁内关闭订阅入口并设置运行标记；在 strand 中关闭 socket、清空发送队列和订阅槽位，最后调用完成回调。成功 `start()` 后重新开启订阅入口；不支持未等待停止完成回调的并发重启。

- [ ] **Step 4: 运行全部 UDP 测试并构建目标程序**

运行：`cmake --build build --target udp_client_tests togee_infinity_station && ctest --test-dir build --output-on-failure -R udp_client_tests`

预期：构建成功，全部 UDP 测试通过。

- [ ] **Step 5: 检查改动并提交**

运行：`git diff --check`，确认无空白错误；以 `refactor: 收敛UDP单订阅回调` 与 `fix: 消除UDP停止等待死锁` 分两次提交实现和测试。
