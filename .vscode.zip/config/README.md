# config 目录说明

`config/` 存放运行期主配置、通用模块配置，以及按场景拆分的产品配置目录。

## 当前结构

这里至少同时存在两种配置形态：

### 根配置

- `config/config.yaml`

当前代码可确认会直接读取这个文件作为主配置入口。

### 场景配置目录

例如：

- `chongqing27/`
- `jc22-12_shanghai4c/`
- `jc24-18hefeiS1/`
- `jc24_09guiyangs1/`
- `jc2501xuegui/`
- `ningbo8_continuous_video/`
- `ningbo8_low/`
- `shenzhen8_video/`
- `taiyuans1/`
- `tiejianuzbekistan/`
- `wulumuqi2/`

这些目录通常包含自己的 `config.yaml` 以及按模块拆分的子目录。

## 通用模块配置目录

根 `config/` 下也有很多通用模块配置，例如：

- `camera_config/`
- `controller_manager/`
- `database_manager/`
- `hik_manager/`
- `location_service/`
- `task_service/`
- `tcp_client_center/`
- `tcp_server_center/`
- `udp_center/`
- `ui_config/`

## 维护注意

- 当前不能默认认为 `.version` 会自动切到 `config/<scene>/config.yaml`
- 根配置和场景配置目录是并存关系，不是简单的替代关系
- 节点命名存在新旧混用，例如 `UIEngine` / `QmlPrivateEngine`、`Device6017Manager` / `Dispatch6017`

## 推荐阅读

- [专题配置说明](../doc/config-conventions.md)
- [版本矩阵](../doc/version-matrix.md)
