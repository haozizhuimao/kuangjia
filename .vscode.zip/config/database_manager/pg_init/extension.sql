-- 自动设置 updated_time = NOW()
CREATE OR REPLACE FUNCTION update_updated_time_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_time := NOW()::timestamp(6);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION update_updated_time_column() IS
'通用触发器函数：在 INSERT/UPDATE 时自动将 updated_time 字段设为当前时间。';

CREATE OR REPLACE FUNCTION auto_create_time_partition(
    parent_table TEXT,
    partition_key TEXT,
    time_value TIMESTAMP,
    part_type TEXT DEFAULT 'MONTH'  -- 'YEAR', 'MONTH', 'WEEK', 'DAY'
)
RETURNS VOID AS $$
DECLARE
    partition_name TEXT;
    start_ts TIMESTAMP;
    end_ts TIMESTAMP;
    fmt TEXT;
BEGIN
    -- 标准化 part_type 为大写，便于比较
    part_type := UPPER(part_type);

    -- 校验 part_type
    IF part_type NOT IN ('YEAR', 'MONTH', 'WEEK', 'DAY') THEN
        RAISE EXCEPTION 'part_type must be one of: YEAR, MONTH, WEEK, DAY';
    END IF;

    -- 计算分区起止时间与名称
    CASE part_type
        WHEN 'YEAR' THEN
            start_ts := date_trunc('year', time_value);
            end_ts   := start_ts + INTERVAL '1 year';
            partition_name := parent_table || '_' || to_char(start_ts, 'YYYY');

        WHEN 'MONTH' THEN
            start_ts := date_trunc('month', time_value);
            end_ts   := start_ts + INTERVAL '1 month';
            partition_name := parent_table || '_' || to_char(start_ts, 'YYYYMM');

        WHEN 'WEEK' THEN
            -- PostgreSQL 的 week 从周一开始，ISO 标准
            start_ts := date_trunc('week', time_value);  -- 周一 00:00:00
            end_ts   := start_ts + INTERVAL '1 week';
            -- 使用 ISO 周格式：YYYY"w"WW，例如 2026w05
            partition_name := parent_table || '_' || to_char(start_ts, 'YYYY"w"IW');

        WHEN 'DAY' THEN
            start_ts := date_trunc('day', time_value);
            end_ts   := start_ts + INTERVAL '1 day';
            partition_name := parent_table || '_' || to_char(start_ts, 'YYYYMMDD');

        ELSE
            RAISE EXCEPTION 'Unsupported part_type: %', part_type;
    END CASE;

    -- 检查分区是否已存在（在当前 schema，通常是 public）
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables
        WHERE schemaname = current_schema() AND tablename = partition_name
    ) THEN
        BEGIN
            EXECUTE format(
                'CREATE TABLE %I PARTITION OF %I FOR VALUES FROM (%L) TO (%L)',
                partition_name,
                parent_table,
                start_ts,
                end_ts
            );
            RAISE NOTICE 'Auto-created partition: %.%', current_schema(), partition_name;
        EXCEPTION
            WHEN duplicate_table THEN
                -- 并发插入时可能已被其他会话创建，安全忽略
                NULL;
        END;
    END IF;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION auto_create_time_history_partition 
    (table_name TEXT,
     part_type TEXT DEFAULT 'MONTH')
RETURNS VOID AS $$
DECLARE
    v_history_partition_name text := format('%I_history', table_name);
    v_start_date timestamp;
    v_end_date timestamp;
BEGIN
    part_type := UPPER(part_type);
    IF part_type NOT IN ('YEAR', 'MONTH', 'WEEK', 'DAY') THEN
        RAISE EXCEPTION 'part_type must be one of: YEAR, MONTH, WEEK, DAY';
    END IF;

    -- 计算分区起止时间与名称
    CASE part_type
        WHEN 'YEAR' THEN
            v_end_date := (date_trunc(part_type, NOW()) - INTERVAL '1 day')::timestamp;
        WHEN 'MONTH' THEN
            v_end_date := (date_trunc(part_type, NOW()) - INTERVAL '1 day')::timestamp;
        WHEN 'YEAR' THEN
            v_end_date := (date_trunc(part_type, NOW()) - INTERVAL '1 day')::timestamp;
        WHEN 'WEEK' THEN
            v_end_date := (date_trunc(part_type, NOW()) - INTERVAL '1 day')::timestamp;
        WHEN 'DAY' THEN
            v_end_date := (date_trunc(part_type, NOW()) - INTERVAL '1 day')::timestamp;
        ELSE
            RAISE EXCEPTION 'Unsupported part_type: %', part_type;
    END CASE;

    v_start_date := '1970-01-01'::timestamp;

    EXECUTE format('
        CREATE TABLE %I (
            LIKE %I INCLUDING DEFAULTS INCLUDING CONSTRAINTS
        )', v_history_partition_name, table_name);

    EXECUTE format('
        ALTER TABLE %I 
        ADD CONSTRAINT %I_check 
        CHECK (created_time >= %L AND created_time < %L)',
        v_history_partition_name, 
        v_history_partition_name || '_check', 
        v_start_date, 
        v_end_date);

    EXECUTE format('
        ALTER TABLE %I 
        ATTACH PARTITION %I 
        FOR VALUES FROM (%L) TO (%L)',
        table_name, v_history_partition_name, v_start_date, v_end_date);
END;
$$ LANGUAGE plpgsql;