CREATE OR REPLACE FUNCTION ensure_partitions_for_table(
    parent_table TEXT,
    period_count INT DEFAULT 4
)
RETURNS VOID AS $$
DECLARE
    part_type TEXT;
    base_time TIMESTAMP;
    interval_unit INTERVAL;
    i INT;
    inferred_type TEXT;
    today_partition_name TEXT;
    today_start TIMESTAMP;
BEGIN
    -- 查询表的分区粒度
    inferred_type := NULL;
    BEGIN
        EXECUTE format('
            WITH partitions AS (
                SELECT
                    pg_get_expr(c.relpartbound, c.oid) AS partbound_expr,
                    c.relname AS partition_name
                FROM pg_class p
                JOIN pg_inherits i ON i.inhparent = p.oid
                JOIN pg_class c ON c.oid = i.inhrelid
                WHERE p.relname = %L AND p.relkind = ''p''
            ),
            bounds AS (
                SELECT
                    partition_name,
                    (regexp_match(partbound_expr, ''FROM \(''''(.*?)''''\) TO \(''''(.*?)''''\)'')) AS m
                FROM partitions
                WHERE partbound_expr IS NOT NULL
            ),
            sorted AS (
                SELECT
                    m[1]::timestamp AS start_time,
                    m[2]::timestamp AS end_time,
                    partition_name,
                    row_number() OVER (ORDER BY m[1]::timestamp) AS rn
                FROM bounds
                WHERE m[1] IS NOT NULL
            )
            SELECT
                CASE
                    WHEN (s2.start_time - s1.start_time) = interval ''1 day'' THEN ''DAY''
                    WHEN (s2.start_time - s1.start_time) = interval ''7 days'' THEN ''WEEK''
                    WHEN (s2.start_time - s1.start_time) = interval ''1 month'' THEN ''MONTH''
                    WHEN (s2.start_time - s1.start_time) = interval ''1 year'' THEN ''YEAR''
                END AS part_type
            INTO inferred_type
            FROM sorted s1, sorted s2
            WHERE s1.rn = 1 AND s2.rn = 2;
        ', parent_table);
    EXCEPTION
        WHEN OTHERS THEN
            inferred_type := NULL;
    END;

    IF inferred_type IS NULL THEN
        RAISE WARNING '无法推断表 % 的分区粒度，将默认使用 DAY 粒度', parent_table;
        part_type := 'DAY';
    ELSE
        part_type := inferred_type;
    END IF;

    CASE part_type
        WHEN 'YEAR'  THEN base_time := date_trunc('year', CURRENT_DATE);
        WHEN 'MONTH' THEN base_time := date_trunc('month', CURRENT_DATE);
        WHEN 'WEEK'  THEN base_time := date_trunc('week', CURRENT_DATE);
        WHEN 'DAY'   THEN base_time := date_trunc('day', CURRENT_DATE);
        ELSE RAISE EXCEPTION '不支持的分区粒度: %', part_type;
    END CASE;

    -- 分区检查
    DECLARE
        expected_partition_name TEXT;
    BEGIN
        CASE part_type
            WHEN 'YEAR'  THEN expected_partition_name := parent_table || '_' || to_char(base_time, 'YYYY');
            WHEN 'MONTH' THEN expected_partition_name := parent_table || '_' || to_char(base_time, 'YYYYMM');
            WHEN 'WEEK'  THEN expected_partition_name := parent_table || '_' || to_char(base_time, 'YYYY"w"IW');
            WHEN 'DAY'   THEN expected_partition_name := parent_table || '_' || to_char(base_time, 'YYYYMMDD');
        END CASE;

        IF EXISTS (
            SELECT 1 FROM pg_tables
            WHERE schemaname = current_schema() AND tablename = expected_partition_name
        ) THEN
            RAISE NOTICE '表 % 的当前周期分区 % 已存在，不创建任何新分区。',
                parent_table, expected_partition_name;
            RETURN;
        END IF;
    END;

    -- 当前周期分区不存在，创建后续分区
    CASE part_type
        WHEN 'YEAR'  THEN interval_unit := '1 year'::INTERVAL;
        WHEN 'MONTH' THEN interval_unit := '1 month'::INTERVAL;
        WHEN 'WEEK'  THEN interval_unit := '1 week'::INTERVAL;
        WHEN 'DAY'   THEN interval_unit := '1 day'::INTERVAL;
    END CASE;

    FOR i IN 0 .. (period_count - 1) LOOP
        PERFORM auto_create_time_partition(
            parent_table,
            'created_time',
            base_time + i * interval_unit,
            part_type
        );
    END LOOP;

    RAISE NOTICE '表 %（粒度 %）当前周期分区缺失，已创建从 % 开始连续 % 个周期的分区',
        parent_table, part_type, base_time, period_count;
END;
$$ LANGUAGE plpgsql;


-- 为数据库中所有分区表自动创建未来N个周期的分区,默认为4个
CREATE OR REPLACE FUNCTION ensure_partitions_for_all_tables(
    period_count INT DEFAULT 4
)
RETURNS VOID AS $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN
        SELECT relname AS table_name
        FROM pg_class
        WHERE relkind = 'p' AND relnamespace = 'public'::regnamespace
    LOOP
        BEGIN
            PERFORM ensure_partitions_for_table(rec.table_name, period_count);
        EXCEPTION
            WHEN OTHERS THEN
                RAISE WARNING '处理表 % 时出错: %', rec.table_name, SQLERRM;
        END;
    END LOOP;
END;
$$ LANGUAGE plpgsql;