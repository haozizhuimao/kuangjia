
-- ========== device_status ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'device_status' AND schemaname = 'public'
    ) THEN
        CREATE TABLE device_status (
            id INT GENERATED ALWAYS AS IDENTITY,
            tag VARCHAR(20) NOT NULL,
            details_json TEXT,
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        );

        CREATE INDEX ON device_status USING BRIN (created_time); 

        CREATE TRIGGER trg_device_status_updated_time
        BEFORE INSERT OR UPDATE ON device_status
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();


        COMMENT ON COLUMN device_status.tag IS '设备标签（唯一标识符，如传感器ID）';
        COMMENT ON COLUMN device_status.details_json IS '设备状态详情（JSON格式）';

        COMMENT ON TABLE device_status IS '设备状态数据表(无分区)';
        RAISE NOTICE '创建表成功: device_status';
    ELSE
        RAISE NOTICE 'device_status 已存在，跳过创建。';
    END IF;
END $$;



-- ========== location_confluent ==========

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'location_confluent' AND schemaname = 'public'
    ) THEN
        CREATE TABLE location_confluent (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id          INT,
            location_type    INT,         -- 0(错误), 1(速度传感器), 2(跨距), 3(站区), 4(RFID), 5(图像), 6(锚段)
            speed            FLOAT,       -- km/h 实时速度
            line_name        VARCHAR(20),
            station_name     VARCHAR(20),
            maoduan_name     VARCHAR(20),
            pole_name        VARCHAR(20),
            mileage_normal   FLOAT,       -- km 无校准累积里程
            mileage_adjust   FLOAT,       -- km 校准累计里程
            milimeter        BIGINT,      -- mm 脉冲距离
            zig_0 FLOAT,     
            zig_1 FLOAT,     
            zig_2 FLOAT,     
            zig_3 FLOAT,     
            hei_0 FLOAT,
            hei_1 FLOAT,
            hei_2 FLOAT,
            hei_3 FLOAT,
            jihe_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            created_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON location_confluent USING BRIN (created_time); 

        CREATE TRIGGER trg_location_confluent_updated_time
        BEFORE INSERT OR UPDATE ON location_confluent
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();
        COMMENT ON COLUMN location_confluent.task_id IS '关联任务ID';
        COMMENT ON COLUMN location_confluent.location_type IS '定位类型：0=错误,1=速度传感器,2=跨距,3=站区,4=RFID,5=图像,6=锚段';
        COMMENT ON COLUMN location_confluent.speed IS '实时速度（单位：km/h）';
        COMMENT ON COLUMN location_confluent.line_name IS '线路名称';
        COMMENT ON COLUMN location_confluent.station_name IS '站区名称';
        COMMENT ON COLUMN location_confluent.maoduan_name IS '锚段名称';
        COMMENT ON COLUMN location_confluent.pole_name IS '杆号名称';
        COMMENT ON COLUMN location_confluent.mileage_normal IS '无校准累积里程（单位：km）';
        COMMENT ON COLUMN location_confluent.mileage_adjust IS '校准后累积里程（单位：km）';
        COMMENT ON TABLE location_confluent IS '定位融合数据表(按周分区)';
        RAISE NOTICE '创建表成功: location_confluent';

        PERFORM auto_create_time_history_partition('location_confluent','WEEK');
    ELSE
        RAISE NOTICE 'location_confluent 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('location_confluent', 'created_time', NOW()::timestamp, 'WEEK');
END $$;


DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'location_realtime' AND schemaname = 'public'
    ) THEN
        CREATE TABLE location_realtime (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id          INT,
            location_type    INT,         -- 0(错误), 1(速度传感器), 2(跨距), 3(站区), 4(RFID), 5(图像), 6(锚段)
            speed            FLOAT,       -- km/h 实时速度
            line_name        VARCHAR(20),
            station_name     VARCHAR(20),
            maoduan_name     VARCHAR(20),
            pole_name        VARCHAR(20),
            mileage_normal   FLOAT,       -- km 无校准累积里程
            mileage_adjust   FLOAT,       -- km 校准累计里程
            milimeter        BIGINT,      -- mm 脉冲距离
            zig_0 FLOAT,     
            zig_1 FLOAT,     
            zig_2 FLOAT,     
            zig_3 FLOAT,     
            hei_0 FLOAT,
            hei_1 FLOAT,
            hei_2 FLOAT,
            hei_3 FLOAT,  
            created_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON location_realtime USING BRIN (created_time); 

        CREATE TRIGGER trg_location_realtime_updated_time
        BEFORE INSERT OR UPDATE ON location_realtime
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();
        COMMENT ON TABLE location_realtime IS '定位实时数据表(按周分区)';
        RAISE NOTICE '创建表成功: location_realtime';

        PERFORM auto_create_time_history_partition('location_realtime','WEEK');
    ELSE
        RAISE NOTICE 'location_realtime 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('location_realtime', 'created_time', NOW()::timestamp, 'WEEK');
END $$;


DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'location_structure' AND schemaname = 'public'
    ) THEN
        CREATE TABLE location_structure (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id          INT,
            pole_name        VARCHAR(20),
            milimeter        BIGINT,      -- mm 脉冲距离
            zig_0 FLOAT,     
            zig_1 FLOAT,     
            zig_2 FLOAT,     
            zig_3 FLOAT,     
            hei_0 FLOAT,
            hei_1 FLOAT,
            hei_2 FLOAT,
            hei_3 FLOAT,  
            created_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time  TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON location_structure USING BRIN (created_time); 

        CREATE TRIGGER trg_location_structure_updated_time
        BEFORE INSERT OR UPDATE ON location_structure
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();
        COMMENT ON TABLE location_structure IS '图像定位分段数据表(按年分区)';
        RAISE NOTICE '创建表成功: location_structure';

        PERFORM auto_create_time_history_partition('location_structure','YEAR');
    ELSE
        RAISE NOTICE 'location_structure 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('location_structure', 'created_time', NOW()::timestamp, 'YEAR');
END $$;


-- ========== jihe_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'jihe_data' AND schemaname = 'public'
    ) THEN
        -- 创建主表
        CREATE TABLE jihe_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT, 
            frame_number INT,
            line_number INT,
            pos_type INT,
            zig0 FLOAT,
            zig1 FLOAT,
            zig2 FLOAT,
            zig3 FLOAT,
            hei0 FLOAT,
            hei1 FLOAT,
            hei2 FLOAT,
            hei3 FLOAT,
            zig_bc0 FLOAT,
            zig_bc1 FLOAT,
            zig_bc2 FLOAT,
            zig_bc3 FLOAT,
            hei_bc0 FLOAT,
            hei_bc1 FLOAT,
            hei_bc2 FLOAT,
            hei_bc3 FLOAT,
            left_bc_x FLOAT,
            left_bc_y FLOAT,
            right_bc_x FLOAT,
            right_bc_y FLOAT,
            mohao_width0 FLOAT,
            mohao_width1 FLOAT,
            mohao_width2 FLOAT,
            mohao_width3 FLOAT,
            mohao_height0 FLOAT,
            mohao_height1 FLOAT,
            mohao_height2 FLOAT,
            mohao_height3 FLOAT,
            diameter0 FLOAT,
            diameter1 FLOAT,
            diameter2 FLOAT,
            diameter3 FLOAT,
            gradeLenght FLOAT,
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON jihe_data USING BRIN (created_time); 

        CREATE TRIGGER trg_jihe_data_updated_time
        BEFORE INSERT OR UPDATE ON jihe_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();
        
        -- 添加字段注释
        COMMENT ON COLUMN jihe_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN jihe_data.frame_number IS '帧号ID';
        COMMENT ON COLUMN jihe_data.line_number IS '线号ID';
        COMMENT ON COLUMN jihe_data.pos_type IS '位置类型';
        COMMENT ON COLUMN jihe_data.zig0 IS '几何数据Zig0（原始值）';
        COMMENT ON COLUMN jihe_data.zig1 IS '几何数据Zig1（原始值）';
        COMMENT ON COLUMN jihe_data.zig2 IS '几何数据Zig2（原始值）';
        COMMENT ON COLUMN jihe_data.zig3 IS '几何数据Zig3（原始值）';
        COMMENT ON COLUMN jihe_data.hei0 IS '几何数据Hei0（原始值）';
        COMMENT ON COLUMN jihe_data.hei1 IS '几何数据Hei1（原始值）';
        COMMENT ON COLUMN jihe_data.hei2 IS '几何数据Hei2（原始值）';
        COMMENT ON COLUMN jihe_data.hei3 IS '几何数据Hei3（原始值）';
        COMMENT ON COLUMN jihe_data.zig_bc0 IS 'Zig0基线校正值';
        COMMENT ON COLUMN jihe_data.zig_bc1 IS 'Zig1基线校正值';
        COMMENT ON COLUMN jihe_data.zig_bc2 IS 'Zig2基线校正值';
        COMMENT ON COLUMN jihe_data.zig_bc3 IS 'Zig3基线校正值';
        COMMENT ON COLUMN jihe_data.hei_bc0 IS 'Hei0基线校正值';
        COMMENT ON COLUMN jihe_data.hei_bc1 IS 'Hei1基线校正值';
        COMMENT ON COLUMN jihe_data.hei_bc2 IS 'Hei2基线校正值';
        COMMENT ON COLUMN jihe_data.hei_bc3 IS 'Hei3基线校正值';
        COMMENT ON COLUMN jihe_data.left_bc_x IS '左侧边界校正X坐标';
        COMMENT ON COLUMN jihe_data.left_bc_y IS '左侧边界校正Y坐标';
        COMMENT ON COLUMN jihe_data.right_bc_x IS '右侧边界校正X坐标';
        COMMENT ON COLUMN jihe_data.right_bc_y IS '右侧边界校正Y坐标';
        COMMENT ON COLUMN jihe_data.mohao_width0 IS '磨耗宽度0';
        COMMENT ON COLUMN jihe_data.mohao_width1 IS '磨耗宽度1';
        COMMENT ON COLUMN jihe_data.mohao_width2 IS '磨耗宽度2';
        COMMENT ON COLUMN jihe_data.mohao_width3 IS '磨耗宽度3';
        COMMENT ON COLUMN jihe_data.mohao_height0 IS '磨耗高度0';
        COMMENT ON COLUMN jihe_data.mohao_height1 IS '磨耗高度1';
        COMMENT ON COLUMN jihe_data.mohao_height2 IS '磨耗高度2';
        COMMENT ON COLUMN jihe_data.mohao_height3 IS '磨耗高度3';
        COMMENT ON COLUMN jihe_data.diameter0 IS '直径0';
        COMMENT ON COLUMN jihe_data.diameter1 IS '直径1';
        COMMENT ON COLUMN jihe_data.diameter2 IS '直径2';
        COMMENT ON COLUMN jihe_data.diameter3 IS '直径3';
        COMMENT ON COLUMN jihe_data.gradeLenght IS '定位器坡度';
        COMMENT ON TABLE jihe_data IS '几何数据表(历史分区+按天分区)';

        PERFORM auto_create_time_history_partition('jihe_data', 'DAY');
    ELSE
        RAISE NOTICE 'jihe_data 已存在，跳过创建。';
    END IF;

    -- 兼容已存在表结构，补齐新增字段
    ALTER TABLE public.jihe_data
        ADD COLUMN IF NOT EXISTS gradeLenght INT;
    COMMENT ON COLUMN public.jihe_data.gradeLenght IS '定位器坡度';

    PERFORM auto_create_time_partition('jihe_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;

-- ========== press_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'press_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE press_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            press0 FLOAT,
            press1 FLOAT,
            press2 FLOAT,
            press3 FLOAT,
            press4 FLOAT,
            press5 FLOAT,
            press6 FLOAT,
            press7 FLOAT,
            acc0_x FLOAT,
            acc0_y FLOAT,
            acc0_z FLOAT,
            acc1_x  FLOAT,
            acc1_y  FLOAT,
            acc1_z  FLOAT,
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON press_data USING BRIN (created_time); 

        CREATE TRIGGER trg_press_data_updated_time
        BEFORE INSERT OR UPDATE ON press_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN press_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN press_data.press0 IS '压力传感器0读数';
        COMMENT ON COLUMN press_data.press1 IS '压力传感器1读数';
        COMMENT ON COLUMN press_data.press2 IS '压力传感器2读数';
        COMMENT ON COLUMN press_data.press3 IS '压力传感器3读数';
        COMMENT ON COLUMN press_data.press4 IS '压力传感器4读数';
        COMMENT ON COLUMN press_data.press5 IS '压力传感器5读数';
        COMMENT ON COLUMN press_data.press6 IS '压力传感器6读数';
        COMMENT ON COLUMN press_data.press7 IS '压力传感器7读数';
        COMMENT ON COLUMN press_data.acc0_x IS '加速度计0 X轴';
        COMMENT ON COLUMN press_data.acc0_y IS '加速度计0 Y轴';
        COMMENT ON COLUMN press_data.acc0_z IS '加速度计0 Z轴';
        COMMENT ON COLUMN press_data.acc1_x IS '加速度计1 X轴';
        COMMENT ON COLUMN press_data.acc1_y IS '加速度计1 Y轴';
        COMMENT ON COLUMN press_data.acc1_z IS '加速度计1 Z轴';
        COMMENT ON TABLE press_data IS '压力硬点表(按天分区)';
        RAISE NOTICE '创建表成功: press_data';

        PERFORM auto_create_time_history_partition('press_data', 'DAY');
    ELSE
        RAISE NOTICE 'press_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('press_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;



-- ========== collect_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'collect_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE collect_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            vol FLOAT,--网压
            cur FLOAT,--电流
            tem FLOAT,--温度
            hum FLOAT,--湿度
            cba FLOAT,--车体振动加速度
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON collect_data USING BRIN (created_time); 

        CREATE TRIGGER trg_collect_data_updated_time
        BEFORE INSERT OR UPDATE ON collect_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN collect_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN collect_data.vol IS '网压（单位：V 或 kV）';
        COMMENT ON COLUMN collect_data.cur IS '电流（单位：A）';
        COMMENT ON COLUMN collect_data.tem IS '温度（单位：℃）';
        COMMENT ON COLUMN collect_data.hum IS '湿度（单位：%RH）';
        COMMENT ON COLUMN collect_data.cba IS '车体振动加速度（单位：m/s^2）';
        COMMENT ON TABLE collect_data IS '采集设备表(按天分区)';
        RAISE NOTICE '创建表成功: collect_data';

        PERFORM auto_create_time_history_partition('collect_data', 'DAY');
    ELSE
        RAISE NOTICE 'collect_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('collect_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;

-- ========== radar_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'radar_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE radar_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            location_time TIMESTAMP(6),
            points JSON, -- 存储多个 (x, y)
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON radar_data USING BRIN (created_time); 

        CREATE TRIGGER trg_radar_data_updated_time
        BEFORE INSERT OR UPDATE ON radar_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN radar_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN radar_data.location_time IS '雷达定位时间（微秒精度）';
        COMMENT ON COLUMN radar_data.points IS '点云数据（JSON数组，格式：[{"x":1.2,"y":3.4},...]）';
        COMMENT ON TABLE radar_data IS '雷达数据表(按天分区)';
        RAISE NOTICE '创建表成功: radar_data';
        
        PERFORM auto_create_time_history_partition('radar_data', 'DAY');
    ELSE
        RAISE NOTICE 'radar_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('radar_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;




-- ========== radar_over_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'radar_over_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE radar_over_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            location_time_start timestamp,
            location_time_end timestamp,
            points JSON, -- 存储多个 (x, y)
            direction varchar(8), -- 超限方向   上下左右
            overrun_time INT,
            point_count INT, -- 超限点数
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON radar_over_data USING BRIN (created_time); 

        CREATE TRIGGER trg_radar_over_data_updated_time
        BEFORE INSERT OR UPDATE ON radar_over_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN radar_over_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN radar_over_data.location_time_start IS '超限起始定位时间';
        COMMENT ON COLUMN radar_over_data.location_time_end IS '超限结束定位时间';
        COMMENT ON COLUMN radar_over_data.points IS '超限点云数据（JSON数组）';
        COMMENT ON COLUMN radar_over_data.direction IS '超限方向：上、下、左、右';
        COMMENT ON COLUMN radar_over_data.overrun_time IS '超限持续时间（单位：ms）';
        COMMENT ON COLUMN radar_over_data.point_count IS '超限点数量';
        COMMENT ON TABLE radar_over_data IS '雷达超限表(按天分区)';
        RAISE NOTICE '创建表成功: radar_over_data';

        PERFORM auto_create_time_history_partition('radar_over_data', 'DAY');
    ELSE
        RAISE NOTICE 'radar_over_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('radar_over_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;




-- ========== pantograph_defect_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'pantograph_defect_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE pantograph_defect_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            yangjiao_front_left INT,              -- 羊角前左
            yangjiao_front_right INT,             -- 羊角前右 
            yangjiao_back_left INT,               -- 羊角后左 
            yangjiao_back_right INT,              -- 羊角后右  
            pantograph_bow INT,                   -- 弓头
            carbon_strip INT,                     -- 碳滑板
            pantowear INT,                        
            electricconnector INT,                -- 电连接线
            alarm_value INT,                      -- 报警值
            defect_json TEXT,                     -- 缺陷JSON数据
            csv_file_path varchar(255) NOT NULL,    -- csv文件路径
            defect_image_path varchar(255) NOT NULL, -- 缺陷图片路径
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON pantograph_defect_data USING BRIN (created_time); 

        CREATE TRIGGER trg_pantograph_defect_data_updated_time
        BEFORE INSERT OR UPDATE ON pantograph_defect_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN pantograph_defect_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN pantograph_defect_data.yangjiao_front_left IS '羊角前左缺陷状态（0正常，1缺失）';
        COMMENT ON COLUMN pantograph_defect_data.yangjiao_front_right IS '羊角前右缺陷状态（0正常，1缺失）';
        COMMENT ON COLUMN pantograph_defect_data.yangjiao_back_left IS '羊角后左缺陷状态（0正常，1缺失）';
        COMMENT ON COLUMN pantograph_defect_data.yangjiao_back_right IS '羊角后右缺陷状态（0正常，1缺失）';
        COMMENT ON COLUMN pantograph_defect_data.pantograph_bow IS '弓头缺陷状态';
        COMMENT ON COLUMN pantograph_defect_data.carbon_strip IS '碳滑板缺陷状态';
        COMMENT ON COLUMN pantograph_defect_data.pantowear IS '弓网磨耗状态';
        COMMENT ON COLUMN pantograph_defect_data.electricconnector IS '电连接线缺陷状态';
        comment ON COLUMN pantograph_defect_data.defect_json IS '缺陷详细信息（JSON格式）';
        COMMENT ON COLUMN pantograph_defect_data.alarm_value IS '报警阈值';
        COMMENT ON COLUMN pantograph_defect_data.csv_file_path IS '原始CSV文件存储路径';
        COMMENT ON COLUMN pantograph_defect_data.defect_image_path IS '缺陷图片存储路径';
        COMMENT ON TABLE pantograph_defect_data IS '羊角缺失表(按月分区)';
        RAISE NOTICE '创建表成功: pantograph_defect_data';

        PERFORM auto_create_time_history_partition('pantograph_defect_data', 'MONTH');
    ELSE
        RAISE NOTICE 'pantograph_defect_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('pantograph_defect_data', 'created_time', NOW()::timestamp, 'MONTH');
END $$;




-- ========== task_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'task_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE task_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_name varchar(255) NOT NULL, -- 任务名
            task_type INT NOT NULL, -- 任务类型 -1: 无效值 0：手动任务，1：站区id任务，2：rfid任务
            task_state INT NOT NULL, -- 任务状态 TASK_NONE = 0,TASK_START = 1,TASK_RUNNING = 2,TASK_STOPPED = 3,TASK_PAUSED = 4
            train_number varchar(255) NOT NULL,  -- 列车编号
            line_name varchar(64) NOT NULL, -- 线路名
            line_direction INT NOT NULL, -- 线路方向 0:上行 1:下行
            drive_direction INT NOT NULL, -- 0:正向 1:反向
            start_station varchar(64) NOT NULL, -- 起始站
            start_kilometer BIGINT, -- 起始公里标
            end_station varchar(64) NOT NULL, -- 终止站
            start_pole varchar(64) NOT NULL, -- 起始杆号
            end_time    TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6), -- 任务结束时间
            rfid varchar(255),         -- rfid标签任务
            station_id INT,              --  站区任务创建id
            save_path TEXT NOT NULL, -- 任务保存路径
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        );

        CREATE INDEX ON task_data USING BRIN (created_time); 

        CREATE TRIGGER trg_task_data_updated_time
        BEFORE INSERT OR UPDATE ON task_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN task_data.task_type IS '任务类型：-1=无效,0=手动,1=站区ID,2=RFID';
        COMMENT ON COLUMN task_data.task_state IS '任务状态：0=未开始,1=已启动,2=运行中,3=已停止,4=已暂停';
        COMMENT ON COLUMN task_data.task_name IS '任务名称';
        COMMENT ON COLUMN task_data.line_name IS '线路名称';
        COMMENT ON COLUMN task_data.line_direction IS '线路方向：0=上行,1=下行';
        COMMENT ON COLUMN task_data.drive_direction IS '行驶方向：0=正向,1=反向';
        COMMENT ON COLUMN task_data.start_station IS '起始站名称';
        COMMENT ON COLUMN task_data.start_kilometer IS '起始公里标';
        COMMENT ON COLUMN task_data.end_station IS '终止站名称';
        COMMENT ON COLUMN task_data.start_pole IS '起始杆号';
        COMMENT ON COLUMN task_data.rfid IS 'rfid标签任务';
        COMMENT ON COLUMN task_data.station_id IS '站区任务创建id';
                
        COMMENT ON TABLE task_data IS '任务信息表(无分区)';
        RAISE NOTICE '创建表成功: task_data';
    ELSE
        RAISE NOTICE 'task_data 已存在，跳过创建。';
    END IF;
END $$;




-- ========== line_data ==========
DO $$
BEGIN
DROP TABLE IF EXISTS line_data CASCADE;
CREATE TABLE line_data (
  id INT GENERATED ALWAYS AS IDENTITY, -- 自增id
  line_type INT NOT NULL, -- 线路类型，0：刚性 1：柔性 -1：未识别
  line_direction INT NOT NULL, -- 线路方向 0:上行 1:下行
  line_name varchar(20) NOT NULL, -- 线路名
  station_name varchar(20) NOT NULL, -- 站区名
  maoduan_name varchar(20), -- 锚段名  可空
  pole_name varchar(20) NOT NULL, -- 杆号
  kilometer FLOAT NOT NULL, -- 公里标
  station_id INT, -- 站区id
  rfid_id varchar(128), -- RFID标签id
  span FLOAT, -- 跨距
  structure varchar(64), -- 结构
  zig_manual FLOAT,     --手测拉出值
  hei_manual FLOAT,     --手测导高
  offset_value FLOAT, --rfid或站区,锚段 偏移值
  created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
  updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
);

CREATE INDEX ON line_data USING BRIN (created_time); 
CREATE TRIGGER trg_line_data_updated_time
BEFORE INSERT OR UPDATE ON line_data
FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

COMMENT ON COLUMN line_data.line_type IS '线路类型：0=刚性,1=柔性,-1=未识别';
COMMENT ON COLUMN line_data.line_direction IS '线路方向：0=上行,1=下行';
COMMENT ON COLUMN line_data.line_name IS '线路名称';
COMMENT ON COLUMN line_data.station_name IS '站区名称';
COMMENT ON COLUMN line_data.maoduan_name IS '锚段名称（可为空）';
COMMENT ON COLUMN line_data.pole_name IS '杆号';
COMMENT ON COLUMN line_data.kilometer IS '公里标（单位：km）';
COMMENT ON COLUMN line_data.station_id IS '站区唯一ID';
COMMENT ON COLUMN line_data.rfid_id IS 'RFID标签ID';
COMMENT ON COLUMN line_data.span IS '跨距（单位：m）';
COMMENT ON COLUMN line_data.structure IS '结构类型描述';
COMMENT ON COLUMN line_data.offset_value IS 'RFID/站区/锚段偏移值（单位：m）';

COMMENT ON TABLE line_data IS '线路信息表(无分区)';
RAISE NOTICE '创建表成功: line_data';

END $$;





-- ========== arc_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'arc_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE arc_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            arc_count INT NOT NULL, -- 燃弧次数
            arc_time INT NOT NULL, -- 燃弧持续时间
            arc_pulse INT NOT NULL, -- 燃弧脉冲数
            arc_timestamp BIGINT NOT NULL, -- 用于与老程序交互的时间戳
            arcvideo_path varchar(255) NOT NULL, -- 燃弧视频路径
            arc_device_index varchar(20) NOT NULL, -- 燃弧设备索引
            camera_name varchar(20) NOT NULL, -- 摄像头名称
            arc_intensity float NOT NULL, -- 燃弧强度
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON arc_data USING BRIN (created_time); 

        CREATE TRIGGER trg_arc_data_updated_time
        BEFORE INSERT OR UPDATE ON arc_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN arc_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN arc_data.arc_count IS '燃弧次数';
        COMMENT ON COLUMN arc_data.arc_time IS '单次燃弧持续时间（单位：ms）';
        COMMENT ON COLUMN arc_data.arc_pulse IS '燃弧脉冲数量';
        COMMENT ON COLUMN arc_data.arc_timestamp IS '燃弧发生时间戳（毫秒，用于兼容旧系统）';
        COMMENT ON COLUMN arc_data.arcvideo_path IS '燃弧视频文件路径';
        COMMENT ON COLUMN arc_data.arc_device_index IS '燃弧检测设备索引';
        COMMENT ON COLUMN arc_data.camera_name IS '关联摄像头名称';
        COMMENT ON COLUMN arc_data.arc_intensity IS '燃弧强度';
        
        COMMENT ON TABLE arc_data IS '燃弧数据表(按周分区)';
        RAISE NOTICE '创建表成功: arc_data';

        PERFORM auto_create_time_history_partition('arc_data','WEEK');
    ELSE
        RAISE NOTICE 'arc_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('arc_data', 'created_time', NOW()::timestamp, 'WEEK');
END $$;




-- ========== config_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'config_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE config_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            config_type varchar(20) NOT NULL, -- 
            config_value varchar(100) NOT NULL,
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        );

        CREATE INDEX ON config_data USING BRIN (created_time); 

        CREATE TRIGGER trg_config_data_updated_time
        BEFORE INSERT OR UPDATE ON config_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();
        
        COMMENT ON TABLE config_data IS '分析阶段需要的各模块参数(无分区)';
        RAISE NOTICE '创建表成功: config_data';
    ELSE
        RAISE NOTICE 'config_data 已存在，跳过创建。';
    END IF;
END $$;



-- ========== temperature_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'temperature_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE temperature_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT NOT NULL, -- 任务id
            camera_no INT NOT NULL, --相机编号
            rules_no INT NOT NULL, -- 规则编号
            max FLOAT NOT NULL, -- 最大温度
            min FLOAT NOT NULL, -- 最小温度
            avg FLOAT NOT NULL, -- 平均温度
            alarm_temp FLOAT NOT NULL, -- 报警温度
            alarm_level INT NOT NULL,  -- 报警等级
            pic_path varchar(255), -- 温度图片路径
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        )PARTITION BY RANGE (created_time);

        CREATE INDEX ON temperature_data USING BRIN (created_time); 

        CREATE TRIGGER trg_temperature_data_updated_time
        BEFORE INSERT OR UPDATE ON temperature_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN temperature_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN temperature_data.max IS '最大温度（℃）';
        COMMENT ON COLUMN temperature_data.min IS '最小温度（℃）';
        COMMENT ON COLUMN temperature_data.avg IS '平均温度（℃）';
        COMMENT ON COLUMN temperature_data.alarm_temp IS '触发报警的温度阈值（℃）';
        COMMENT ON COLUMN temperature_data.alarm_level IS '报警等级（1~5，数值越大越严重）';
        COMMENT ON COLUMN temperature_data.pic_path IS '温度热力图存储路径';
        COMMENT ON TABLE temperature_data IS '定位融合数据表(按天分区)';
        RAISE NOTICE '创建表成功: temperature_data';

        PERFORM auto_create_time_history_partition('temperature_data','DAY');
    ELSE
        RAISE NOTICE 'temperature_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('temperature_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;


-- ========== mvb_info ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'mvb_info' AND schemaname = 'public'
    ) THEN
        CREATE TABLE mvb_info (
            id INT GENERATED ALWAYS AS IDENTITY,
            cur_station_id INT, -- 当前站ID
            next_station_id INT,  --  下一站ID
            start_station_id INT, -- 起始站ID
            end_station_id INT, -- 终点站ID
            line_id INT,  -- 线路编号
            train_id INT, -- 车号
            iyear INT,  -- 年
            imonth INT, -- 月
            iday INT, -- 日
            ihour INT,  -- 时
            iminute INT,  -- 分
            isecond INT, -- 秒
            speed FLOAT,  -- 速度
            voltage FLOAT,  -- 电压
            elec FLOAT, -- 电流
            battery_status INT NOT NULL,  -- 车辆电池状态,TRUE表示列车进入断电状态
            door_state INT NOT NULL, -- 开门状态 FALSE表示开门状态,TRUE表示关门状态
            panto_up INT NOT NULL, -- 受电弓状态 FALSE表示降弓,TRUE表示升弓
            atb_mode INT NOT NULL,  -- ATB模式
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        )PARTITION BY RANGE (created_time);

        CREATE INDEX ON mvb_info USING BRIN (created_time); 

        CREATE TRIGGER trg_mvb_info_updated_time
        BEFORE INSERT OR UPDATE ON mvb_info
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN mvb_info.cur_station_id IS '当前站ID';
        COMMENT ON COLUMN mvb_info.next_station_id IS '下一站ID';
        COMMENT ON COLUMN mvb_info.start_station_id IS '起始站ID';
        COMMENT ON COLUMN mvb_info.end_station_id IS '终点站ID';
        COMMENT ON COLUMN mvb_info.line_id IS '线路编号';
        COMMENT ON COLUMN mvb_info.train_id IS '车号';
        COMMENT ON COLUMN mvb_info.battery_status IS '车辆电池状态,TRUE表示列车进入断电状态';
        COMMENT ON COLUMN mvb_info.door_state IS '开门状态 FALSE表示开门状态,TRUE表示关门状态';
        COMMENT ON COLUMN mvb_info.panto_up IS '受电弓状态 FALSE表示降弓,TRUE表示升弓';
        COMMENT ON COLUMN mvb_info.atb_mode IS 'ATB模式';
        COMMENT ON TABLE mvb_info IS 'mvb_info(按天分区)';

        RAISE NOTICE '创建表成功: mvb_info';

        PERFORM auto_create_time_history_partition('mvb_info', 'DAY');
    ELSE
        RAISE NOTICE 'mvb_info 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('mvb_info', 'created_time', NOW()::timestamp, 'DAY');
END $$;

-- ========== detection_info ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'detection_info' AND schemaname = 'public'
    ) THEN
        CREATE TABLE detection_info (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT NOT NULL,
            detect_image_path varchar(100) NOT NULL,
            files  varchar(100),
            line_name varchar(20),
            station_name varchar(20),
            maoduan_name varchar(20),
            pole_name varchar(20),
            milimeter BIGINT,
            detect_count INT,
            detect_info TEXT,
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON detection_info USING BRIN (created_time); 
        CREATE TRIGGER trg_detection_info_updated_time
        BEFORE INSERT OR UPDATE ON detection_info
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN detection_info.task_id IS '当前任务ID';
        COMMENT ON COLUMN detection_info.detect_image_path IS '当前帧图片保存路径(多合一)';     
        COMMENT ON COLUMN detection_info.files IS '文件名称列表';
        COMMENT ON COLUMN detection_info.line_name IS '线路名';
        COMMENT ON COLUMN detection_info.station_name IS '站点';
        COMMENT ON COLUMN detection_info.maoduan_name IS '锚段';
        COMMENT ON COLUMN detection_info.pole_name IS '杆号';
        COMMENT ON COLUMN detection_info.milimeter IS '公里标';
        COMMENT ON COLUMN detection_info.detect_count IS '当前帧各图像缺陷总数';
        COMMENT ON COLUMN detection_info.detect_info IS '图片缺陷信息(json字符串)';
        COMMENT ON TABLE detection_info IS 'detection_info(按天分区)';
        RAISE NOTICE '创建表成功: detection_info';

        PERFORM auto_create_time_history_partition('detection_info', 'DAY');
    ELSE
        RAISE NOTICE 'detection_info 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('detection_info', 'created_time', NOW()::timestamp, 'DAY');
END $$;


-- ========== gauge_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'gauge_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE gauge_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            superelevation FLOAT,  -- 超高
            gauge FLOAT,           -- 轨距
            inclination FLOAT,     -- 倾角
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON gauge_data USING BRIN (created_time);

        CREATE TRIGGER trg_gauge_data_updated_time
        BEFORE INSERT OR UPDATE ON gauge_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN gauge_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN gauge_data.superelevation IS '超高（单位：mm）';
        COMMENT ON COLUMN gauge_data.gauge IS '轨距（单位：mm）';
        COMMENT ON COLUMN gauge_data.inclination IS '倾角（单位：°）';
        COMMENT ON TABLE gauge_data IS '超高/轨距/倾角数据表(按天分区)';
        RAISE NOTICE '创建表成功: gauge_data';

        PERFORM auto_create_time_history_partition('gauge_data', 'DAY');
    ELSE
        RAISE NOTICE 'gauge_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('gauge_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;


-- ========== clearance_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'clearance_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE clearance_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            left_clearance FLOAT,   -- 左侧面限界
            right_clearance FLOAT,  -- 右侧面限界
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON clearance_data USING BRIN (created_time);

        CREATE TRIGGER trg_clearance_data_updated_time
        BEFORE INSERT OR UPDATE ON clearance_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN clearance_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN clearance_data.left_clearance IS '支柱左侧面限界（单位：mm）';
        COMMENT ON COLUMN clearance_data.right_clearance IS '支柱右侧面限界（单位：mm）';
        COMMENT ON TABLE clearance_data IS '支柱左右侧面限界数据表(按天分区)';
        RAISE NOTICE '创建表成功: clearance_data';

        PERFORM auto_create_time_history_partition('clearance_data', 'DAY');
    ELSE
        RAISE NOTICE 'clearance_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('clearance_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;


-- ========== sling_data ==========
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_tables WHERE tablename = 'sling_data' AND schemaname = 'public'
    ) THEN
        CREATE TABLE sling_data (
            id INT GENERATED ALWAYS AS IDENTITY,
            task_id INT,
            zig_sling0 FLOAT,  -- 承力索拉出值0
            zig_sling1 FLOAT,  -- 承力索拉出值1
            zig_sling2 FLOAT,  -- 承力索拉出值2
            zig_sling3 FLOAT,  -- 承力索拉出值3
            hei_sling0 FLOAT,  -- 承力索导高0
            hei_sling1 FLOAT,  -- 承力索导高1
            hei_sling2 FLOAT,  -- 承力索导高2
            hei_sling3 FLOAT,  -- 承力索导高3
            created_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6),
            updated_time TIMESTAMP(6) NOT NULL DEFAULT NOW()::timestamp(6)
        ) PARTITION BY RANGE (created_time);

        CREATE INDEX ON sling_data USING BRIN (created_time);

        CREATE TRIGGER trg_sling_data_updated_time
        BEFORE INSERT OR UPDATE ON sling_data
        FOR EACH ROW EXECUTE FUNCTION update_updated_time_column();

        COMMENT ON COLUMN sling_data.task_id IS '关联任务ID';
        COMMENT ON COLUMN sling_data.zig_sling0 IS '承力索拉出值0（单位：mm）';
        COMMENT ON COLUMN sling_data.zig_sling1 IS '承力索拉出值1（单位：mm）';
        COMMENT ON COLUMN sling_data.zig_sling2 IS '承力索拉出值2（单位：mm）';
        COMMENT ON COLUMN sling_data.zig_sling3 IS '承力索拉出值3（单位：mm）';
        COMMENT ON COLUMN sling_data.hei_sling0 IS '承力索导高0（单位：mm）';
        COMMENT ON COLUMN sling_data.hei_sling1 IS '承力索导高1（单位：mm）';
        COMMENT ON COLUMN sling_data.hei_sling2 IS '承力索导高2（单位：mm）';
        COMMENT ON COLUMN sling_data.hei_sling3 IS '承力索导高3（单位：mm）';
        COMMENT ON TABLE sling_data IS '承力索几何数据表(按天分区)';
        RAISE NOTICE '创建表成功: sling_data';

        PERFORM auto_create_time_history_partition('sling_data', 'DAY');
    ELSE
        RAISE NOTICE 'sling_data 已存在，跳过创建。';
    END IF;
    PERFORM auto_create_time_partition('sling_data', 'created_time', NOW()::timestamp, 'DAY');
END $$;
