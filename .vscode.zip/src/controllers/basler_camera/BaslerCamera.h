#pragma once
#include "kits/database/postgresql_interface/PgPressureData.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include "kits/common/camera/basler/base/BaslerBase.h"
#include <memory>
#include <mutex>
namespace _Kits::database {
class PressureSql;
}
namespace _Kits {
class UdpClient;
}
namespace _Controllers {

class BaslerCamera : public ControllerBase<BaslerCamera>
{
  public:
    void onStart();
    void onStop();
    void onRecvTaskInfo(const TIS_Info::task_data &);
    void recvGetLocation(const TIS_Info::LocationData &);
    void initNetCamera(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>,
                       std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>>);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, BaslerCamera::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, BaslerCamera::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, BaslerCamera::onRecvTaskInfo);
    ASYNC_TASK_ADD(_Service::LocationService::LocationRadio, BaslerCamera::recvGetLocation);
    ASYNC_TASK_ADD(_Service::BaslerManager::initPatrolCtrls, BaslerCamera::initNetCamera);
    TASK_LIST_END

  private:
    void savePictureInFileNetcam(std::shared_ptr<TIS_Info::ImageBuffer>);

  private:

    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>> m_udm_cam =
        std::make_shared<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>();
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> m_udm_camInfo =
        std::make_shared<std::unordered_map<std::string, TIS_Info::CameraInfo>>();  
    std::atomic<int> m_taskID = -1;
    TIS_Info::LocationData m_locationData;
    std::atomic_bool m_bInTask {false};
};
} // namespace _Controllers
