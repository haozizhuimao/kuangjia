﻿#include "BaslerCamera.h"
#include <vector>


namespace _Controllers {
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
void BaslerCamera::onStart()
{
}
void BaslerCamera::onStop() {}
void BaslerCamera::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    if (static_cast<int>(TIS_Info::TaskState::TASK_NONE) != taskInfo.task_state ||
        static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) != taskInfo.task_state)
    {
        m_taskID.store(taskInfo.id);
        m_bInTask.store(true, std::memory_order_release);
    }
    else if (static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) == taskInfo.task_state)
    {
        m_taskID.store(-1);
        m_bInTask.store(false, std::memory_order_release);
    }
}
void BaslerCamera::recvGetLocation(const TIS_Info::LocationData &data)
{
    m_locationData = data;
}

void BaslerCamera::initNetCamera(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>> cameraMap,
                                        std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> cameraInfo)
{
    {
        m_udm_cam = cameraMap;
        m_udm_camInfo = cameraInfo;

        for (const auto &[name, cam] : (*m_udm_cam))
        {

            cam->setSendImageCapturedCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) {
                if (!img)
                    return;
                _Kits::LogInfo("Receive image:{}", img->name);
                savePictureInFileNetcam(img);
            });
            cam->start(m_udm_camInfo->find(name)->second);
            // cam->acquireImage();
        }
    }
}

void BaslerCamera::savePictureInFileNetcam(std::shared_ptr<TIS_Info::ImageBuffer> data)
{

    // 存图逻辑
    // if (mytaskdir == "")
    //     mytaskdir = basedir + "无任务图片";
    // QByteArray picture_0 = QByteArray(reinterpret_cast<const char *>(data->data.data()), static_cast<int>(data->data.size()));
    // QByteArray picture = truncateTrailingZeros(picture_0);
    // // QImage picture = ConvertToQImage(data->data.data(), data->width, data->height, 1);
    // QString cameraname = m_initinfo.value(QString::fromStdString(data->name)).value<QString>();
    // qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
    // QDir dir;
    // QString filename = QString("jpgPicture%1_%2.jpg").arg(usecs).arg(cameraname);
    // const size_t currentSize = pathVector.size();
    // QString path;
    // if (currentSize == 0)
    // {
    //     path = QString("A-10%1").arg(testcount_netcam++);
    // }
    // else
    // {
    //     size_t index = findNearestIndex(usecs, currentSize);
    //     path = pathVector[index].first;
    // }

    // QString filedir = mytaskdir + "/" + path;
    // dir.mkpath(filedir);
    // int ret = deleteFilesContaining(cameraname, filedir); // 删除同名文件
    // QString filepath = filedir + "/" + filename;

    // QFile outFile(filepath);
    // // if (picture.save(filepath, "JPG", 80))
    // if (outFile.open(QIODevice::WriteOnly))
    // {
    //     outFile.write(picture);
    //     outFile.close();
    //     _Kits::LogInfo("Image saved to:{},outqueue", filepath.toStdString());
    // }
    // else
    // {
    //     _Kits::LogInfo("Failed to save image to:{}", filepath.toStdString());
    // }
    // std::lock_guard<std::mutex> lock(tasklocker);
    // if (countmap.contains(cameraname))
    // {
    //     int ct = countmap.value(cameraname);
    //     countmap.insert(cameraname, ct + 1);
    // }
    // else
    // {
    //     countmap.insert(cameraname, 1);
    // }
    // 将图片转换为字节数组
    // QImage sendimg;
    // sendimg.load(filepath);
    // QByteArray imageData;
    // QBuffer buffer(&imageData);
    // buffer.open(QIODevice::WriteOnly);
    // sendimg.save(&buffer, "JPG", 100);
    // buffer.close();
    // QString picdata = filepath;
    // QString id = cameraname;
    // int count = countmap.value(cameraname);
    //senderBaslerManagersendImageToQml(picdata, id, count);
    return;
    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
    // TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page,
    // QVariant::fromValue(sendData));
}



} // namespace _Controllers
