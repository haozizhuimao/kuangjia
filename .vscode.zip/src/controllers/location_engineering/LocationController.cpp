#include "LocationController.h"
#include "kits/common/location_general/LocationGeneral.h"
#include "kits/common/location_general/LocationMVB.h"
#include "kits/database/DbClient.h"
#include "kits/database/postgresql_interface/PgLocationConfluent.h"
#include "kits/database/postgresql_interface/PgLocationRealtime.h"
#include "kits/database/postgresql_interface/PgLocationStructure.h"
#include "kits/common/remote_message_parser/RemoteParser.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppInterface.h"
#include "tis_global/enum_public/location_enum.h"
#include <atomic>
#include <cstdint>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void LocationController::initConfigInfo(const TIS_Info::LocationConfigs &config, const std::shared_ptr<_Kits::LocationBase> &ptrTools)
{
    (void)config;
    m_kitLocation = ptrTools;
}

void LocationController::onStart()
{
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationGeneral *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }

    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (!pgClientPtr)
    {
        LogError("pg client unavailable");
        return;
    }

    auto realtime = std::make_shared<database::PgLocationRealtime>(pgClientPtr);
    auto structure = std::make_shared<database::PgLocationStructure>(pgClientPtr);
    auto confluent = std::make_shared<database::PgLocationConfluent>(pgClientPtr);
    locationPtr->setDatabaseOperators(realtime, structure, confluent);
}

void LocationController::onStop() {}

void LocationController::recvTaskData(const TIS_Info::task_data &task)
{
    auto locationTools = m_kitLocation.lock();
    if (!locationTools)
    {
        LogError("location tool unavailable");
        return;
    }

    m_curTaskInfo = task;
    auto nTaskstate = static_cast<TIS_Info::TaskState>(task.task_state);
    if (nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        bInTask_.store(true, std::memory_order_release);
        auto data = locationTools->startTask(task);
        if (!data.pole_name.empty())
        {
            _Service::LocationService::LocationRadio(data);
            LogInfo("[location start] task_state:{} task_id:{}", task.task_state, task.id);
        }
        return;
    }

    if (nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        bInTask_.store(false, std::memory_order_release);
        auto data = locationTools->stopTask();
        if (!data.pole_name.empty())
        {
            _Service::LocationService::LocationRadio(data);
        }
        _Service::LocationService::locationFinished(task);
        LogInfo("[location stop] task_state:{} task_id:{}", task.task_state, task.id);
    }
}

void LocationController::recvSpeedValue(double speed, int64_t timestamp)
{
    (void)timestamp;
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationGeneral *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }

    if (bInTask_.load(std::memory_order_acquire))
    {
        locationPtr->updateSpeed(speed);
    }
}

void LocationController::recvSpeedData(const TIS_Info::SpeedData &data)
{
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationGeneral *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }

    auto locationData = locationPtr->updateMillimeter(data.millimeter, data.timestamp);
    if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
    {
        lastSendMM = locationData.milimeter;
        _Service::LocationService::LocationRadio(locationData);
        return;
    }

    if (locationData.milimeter - lastSendMM >= 1000)
    {
        _Service::LocationService::LocationRadio(locationData);
        lastSendMM = locationData.milimeter;
    }
}

void LocationController::recvRfidDataFromModule(const std::string &data, int64_t timet)
{
    (void)timet;
    auto locationTools = m_kitLocation.lock();
    if (!locationTools)
    {
        LogError("location tool unavailable");
        return;
    }
    if (data.empty())
    {
        LogError("invalid rfid data");
        return;
    }
    TIS_Info::CalibrationInfo adjustInfo;
    adjustInfo.calibration_type = TIS_Info::CalibrationType::CALIBRATION_ELECTTAG;
    adjustInfo.calibration_rfid = data;
    externalCal(adjustInfo);
}

void LocationController::recvHandData(const Json::Value &data)
{
    if (data.isNull() || !data.isMember("pole_name"))
    {
        LogError("Invalid data!");
        return;
    }
    std::string str = data["pole_name"].asString();
    TIS_Info::CalibrationInfo adjustInfo;
    adjustInfo.calibration_type = TIS_Info::CalibrationType::CALIBRATION_MANUAL;
    adjustInfo.calibration_pole_name = str;
    externalCal(adjustInfo);
}

void LocationController::recvStationSignal()
{
    TIS_Info::CalibrationInfo adjustInfo;
    adjustInfo.calibration_type = TIS_Info::CalibrationType::CALIBRATION_STOPSTAION;
    externalCal(adjustInfo);
}

void LocationController::recvJiheData(const std::shared_ptr<TIS_Info::JiHeData> &data)
{
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationGeneral *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }
    if (data == nullptr)
    {
        LogError("几何空指针");
        return;
    }

    auto locationData = locationPtr->updateJiheData(data);
    if (locationData.timestamp > 0 && locationData.milimeter - lastSendImgMM_ > 1000)
    {
        lastSendImgMM_ = locationData.milimeter;
        _Service::LocationService::LocationRadio(locationData);
    }
}
void LocationController::recvAlgoJiheData(const std::shared_ptr<TIS_Info::JiHeData> &data)
{
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationGeneral *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }

    auto locationData = locationPtr->updateJiheData(data);
    if (locationData.timestamp > 0 && locationData.milimeter - lastSendImgMM_ > 1000)
    {
        lastSendImgMM_ = locationData.milimeter;
        _Service::LocationService::LocationRadio(locationData);
    }
}

void LocationController::recvMvbSpeed(const TIS_Info::RemoteMessage &msg)
{
    auto locationTools = m_kitLocation.lock();
    auto locationPtr = dynamic_cast<LocationMVB *>(locationTools.get());
    if (!locationPtr)
    {
        LogError("location tool unavailable");
        return;
    }
    TIS_Info::MVBLocationInfo mvbInfo;
    if (!_Kits::RemoteParser::parseMVBLocationInfo(msg, mvbInfo))
    {
        _Kits::LogError("接收MVB信息解析失败");
        return;
    }
    auto locationData = locationPtr->speedMVBUpdate(datetime::current_timestamp(datetime::TimestampUnit::Milliseconds), mvbInfo.dSpeed);
    if (mvbInfo.stationAdjust)
    {
        recvStationSignal();
    }
    if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
    {
        lastSendMM = locationData.milimeter;
        _Service::LocationService::LocationRadio(locationData);
        return;
    }

    if (locationData.milimeter - lastSendMM >= 1000)
    {
        _Service::LocationService::LocationRadio(locationData);
        lastSendMM = locationData.milimeter;
    }
}

void LocationController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    auto locationTools = m_kitLocation.lock();
    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化");
        return;
    }

    if (static_cast<TIS_Info::TaskState>(m_curTaskInfo.task_state) == TIS_Info::TaskState::TASK_START)
    {

        auto locationPtr = static_cast<LocationMVB *>(locationTools.get());
        _Kits::LogInfo("[LocationController] 时间戳: {}", datetime::current_timestamp(datetime::TimestampUnit::Milliseconds));
        auto locationData = locationPtr->speedMVBUpdate(datetime::current_timestamp(datetime::TimestampUnit::Milliseconds), data.dSpeed);
        if (locationData.mileage_normal == 0)
        {
            LogInfo("[LocationController2] 里程间隔过大，丢弃数据: milimeter={}, location_type={}",
                    locationData.milimeter,
                    static_cast<int>(locationData.location_type));
            return;
        }
        if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
        {
            _Service::LocationService::LocationRadio(locationData);
            LogInfo("[LocationController1] 发送定位数据: milimeter={}, location_type={}",
                    locationData.milimeter,
                    static_cast<int>(locationData.location_type));
        }
        else
        {

            static auto last_mm = locationData.mileage_normal;
            auto interval = locationData.mileage_normal - last_mm;
            constexpr double MAX_DISTANCE = 500; // 默认 500mm
            if (interval > MAX_DISTANCE)
            {
                _Service::LocationService::LocationRadio(locationData);
                last_mm = locationData.mileage_normal;
            }
        }
    }
}

void LocationController::externalCal(TIS_Info::CalibrationInfo adjustInfo)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(locationTools.get());
    auto locationData = locationPtr->externalCalibration(adjustInfo);
    if (locationData.timestamp > 0)
    {
        lastSendImgMM_ = locationData.milimeter;
        _Service::LocationService::LocationRadio(locationData);
    }
}

} // namespace _Controllers
