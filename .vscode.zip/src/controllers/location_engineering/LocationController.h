#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <atomic>
#include <cstdint>
#include <memory>
#include "kits/common/location_general/LocationBase.h"
#include "tis_global/struct_details/jihe_struct.h"
#include "tis_global/struct_details/location_struct.h"
#include "tis_global/struct_details/sql_struct.h"
namespace _Controllers {
class LocationController : public ControllerBase<LocationController>
{
  public:
    void initConfigInfo(const TIS_Info::LocationConfigs &, const std::shared_ptr<_Kits::LocationBase> &);

    void onStart();
    void onStop();

    void recvTaskData(const TIS_Info::task_data &);
    void recvJiheData(const std::shared_ptr<TIS_Info::JiHeData> &);
    void recvAlgoJiheData(const std::shared_ptr<TIS_Info::JiHeData> &);
    void recvRfidDataFromModule(const std::string &, int64_t);
    void recvHandData(const Json::Value &);
    void recvStationSignal();
    void recvSpeedData(const TIS_Info::SpeedData &);
    void recvSpeedValue(double, int64_t);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);
    void recvMvbSpeed(const TIS_Info::RemoteMessage &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, LocationController::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, LocationController::onStop);
    SYNC_TASK_ADD(_Service::LocationService::initConfigInfo, LocationController::initConfigInfo);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, LocationController::recvTaskData);
    ASYNC_TASK_ADD(_Service::Sensor6051Manager::sendSpeedData, LocationController::recvSpeedData);
    ASYNC_TASK_ADD(_Service::Sensor6051Manager::sendSpeedValue, LocationController::recvSpeedValue);
    ASYNC_TASK_ADD(_Service::Sensor7404DataOut::sendSpeedDataOut, LocationController::recvSpeedData);
    ASYNC_TASK_ADD(_Service::Sensor7404DataOut::sendSpeedValue, LocationController::recvSpeedValue);
    REMOTE_TASK_ADD(TIS_Info::MVBCommunication::sendMVBLocationInfo, LocationController::recvMvbSpeed);
    ASYNC_TASK_ADD(_Service::RfidService::rfidSend, LocationController::recvRfidDataFromModule);
    ASYNC_TASK_ADD(_Service::JiHeService::full, LocationController::recvJiheData);
    ASYNC_TASK_ADD(_Service::JiHeService::broadcast, LocationController::recvAlgoJiheData);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::ULPoleCalibration, LocationController::recvHandData);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::PoleCalibration, LocationController::recvHandData);
    TASK_LIST_END
  private:
    void externalCal(TIS_Info::CalibrationInfo adjustInfo);

  private:
    std::weak_ptr<_Kits::LocationBase> m_kitLocation;
    TIS_Info::task_data m_curTaskInfo;
    std::atomic_bool bInTask_{false};
    std::atomic_uint64_t lastSendMM = 0;
    std::atomic_int64_t lastSendImgMM_ = 0;
    std::mutex m_mutex;
};

} // namespace _Controllers
