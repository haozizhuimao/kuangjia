#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/utility/excel_writer/ExcelWriter.h"
#include <json/value.h>
#include <string>
#include <vector>

namespace _Kits::database {
class PgLineData;
}
namespace _Controllers {
class DatabaseController : public ControllerBase<DatabaseController>
{
  public:
    void onStart();
    void onStop();
    void dataFromUI(const Json::Value &);
    void dataFromConfig(const Json::Value &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, DatabaseController::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, DatabaseController::onStop);
    ASYNC_TASK_ADD(_Service::DatabaseManager::dataFromUI, DatabaseController::dataFromUI);
    SYNC_TASK_ADD(_Service::DatabaseManager::dataFromConfig, DatabaseController::dataFromConfig);

    TASK_LIST_END
  private:
    struct CsvImportPaths;

    bool initLineData(const std::string &filepath);
    bool validateCsvFilesJson(const Json::Value &json) const;
    bool buildCsvImportPaths(CsvImportPaths &paths) const;
    bool collectCsvFiles(const Json::Value &json,
                         const CsvImportPaths &paths,
                         std::vector<std::string> &copiedFiles,
                         std::vector<std::string> &yamlLineData) const;
    bool updateLineDataYaml(const CsvImportPaths &paths, const std::vector<std::string> &yamlLineData) const;
    bool reloadLineData(const std::vector<std::string> &copiedFiles);
    Json::Value m_lineDataJson;
    std::string getConfigFilePath() const;
    std::shared_ptr<_Kits::database::PgLineData> m_tableLineData;
    _Kits::ExcelWriter excelwriter_;
};
} // namespace _Controllers
