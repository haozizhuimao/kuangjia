#include "DatabaseController.h"
#include "kits/database/postgresql_interface/PgLineData.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/system_config/SystemConfig.h"
#include <filesystem>
#include <fstream>
#include <system_error>
#include <yaml-cpp/yaml.h>

namespace _Controllers {
using namespace _Kits;

namespace {
namespace fs = std::filesystem;

std::string pathToUtf8String(const fs::path &path)
{
    return path.generic_string();
}
} // namespace

struct DatabaseController::CsvImportPaths
{
    fs::path configRoot;
    fs::path databaseManagerDir;
    fs::path targetCsvDir;
    fs::path yamlPath;
};

void DatabaseController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        m_tableLineData = std::make_shared<database::PgLineData>(pgClientPtr);

        if (m_lineDataJson.isMember("csv_files") && m_lineDataJson["csv_files"].isArray())
        {
            for (const auto &file : m_lineDataJson["csv_files"])
            {
                initLineData(file.asString());
            }

            // 预留从数据库重载线路数据接口，现场数据拿回来分析要用
            // m_tableLineData->reloadLineDataFromSql();
        }
        else
        {
            LogError("数据库控制器默认线路CSV导入失败，配置中缺少 csv_files 数组");
        }
    }
}

void DatabaseController::onStop()
{
    if (m_tableLineData)
    {
        m_tableLineData.reset();
    }
}

void DatabaseController::dataFromUI(const Json::Value &json)
{
    LogDebug("[DatabaseController]数据库控制器收到界面数据，内容: {}", json.toStyledString());

    if (!validateCsvFilesJson(json))
    {
        return;
    }

    CsvImportPaths paths;
    if (!buildCsvImportPaths(paths))
    {
        return;
    }

    std::vector<std::string> copiedFiles;
    std::vector<std::string> yamlLineData;
    if (!collectCsvFiles(json, paths, copiedFiles, yamlLineData))
    {
        return;
    }

    if (!updateLineDataYaml(paths, yamlLineData))
    {
        return;
    }

    if (!reloadLineData(copiedFiles))
    {
        return;
    }

    LogInfo("[DatabaseController]数据库控制器线路CSV导入成功，处理文件数量: {}", copiedFiles.size());
}

bool DatabaseController::validateCsvFilesJson(const Json::Value &json) const
{
    if (!json.isMember("csv_files") || !json["csv_files"].isArray() || json["csv_files"].empty())
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，json 中缺少有效的 csv_files 数组");
        return false;
    }

    return true;
}

bool DatabaseController::buildCsvImportPaths(CsvImportPaths &paths) const
{
    const std::string configRootPath = getConfigFilePath();
    if (configRootPath.empty())
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，配置根目录为空");
        return false;
    }

    paths.configRoot = fs::path(configRootPath);
    paths.databaseManagerDir = paths.configRoot / "database_manager";
    paths.targetCsvDir = paths.databaseManagerDir / "csv_info";
    paths.yamlPath = paths.databaseManagerDir / "database_manager.yaml";

    if (!fs::exists(paths.yamlPath) || !fs::is_regular_file(paths.yamlPath))
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，未找到配置文件，路径: {}", pathToUtf8String(paths.yamlPath));
        return false;
    }

    std::error_code ec;
    fs::create_directories(paths.targetCsvDir, ec);
    if (ec)
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，创建目录失败，目录: {}，错误: {}",
                 pathToUtf8String(paths.targetCsvDir),
                 ec.message());
        return false;
    }

    return true;
}

bool DatabaseController::collectCsvFiles(const Json::Value &json,
                                         const CsvImportPaths &paths,
                                         std::vector<std::string> &copiedFiles,
                                         std::vector<std::string> &yamlLineData) const
{
    copiedFiles.reserve(static_cast<size_t>(json["csv_files"].size()));
    yamlLineData.reserve(static_cast<size_t>(json["csv_files"].size()));

    std::error_code ec;
    for (const auto &file : json["csv_files"])
    {
        if (!file.isString())
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，csv_files 中存在非字符串项");
            return false;
        }

        const fs::path sourceFile(file.asString());
        if (!fs::exists(sourceFile) || !fs::is_regular_file(sourceFile))
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，源文件不存在，路径: {}", pathToUtf8String(sourceFile));
            return false;
        }

        const fs::path targetFilePath = paths.targetCsvDir / sourceFile.filename();
        ec.clear();
        const fs::path sourceAbsPath = fs::absolute(sourceFile, ec);
        if (ec)
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，解析源文件绝对路径失败，路径: {}，错误: {}",
                     pathToUtf8String(sourceFile),
                     ec.message());
            return false;
        }

        ec.clear();
        const fs::path targetAbsPath = fs::absolute(targetFilePath, ec);
        if (ec)
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，解析目标文件绝对路径失败，路径: {}，错误: {}",
                     pathToUtf8String(targetFilePath),
                     ec.message());
            return false;
        }

        if (sourceAbsPath != targetAbsPath)
        {
            if (fs::exists(targetFilePath))
            {
                ec.clear();
                if (!fs::remove(targetFilePath, ec))
                {
                    LogError("[DatabaseController]数据库控制器线路CSV导入失败，删除旧文件失败，路径: {}，错误: {}",
                             pathToUtf8String(targetFilePath),
                             ec ? ec.message() : "目标文件删除返回 false");
                    return false;
                }
            }

            ec.clear();
            fs::copy_file(sourceFile, targetFilePath, fs::copy_options::overwrite_existing, ec);
            if (ec)
            {
                LogError("[DatabaseController]数据库控制器线路CSV导入失败，拷贝文件失败，源文件: {}，目标文件: {}，错误: {}",
                         pathToUtf8String(sourceFile),
                         pathToUtf8String(targetFilePath),
                         ec.message());
                return false;
            }
        }

        copiedFiles.emplace_back(pathToUtf8String(targetFilePath));
        yamlLineData.emplace_back("/csv_info/" + sourceFile.filename().generic_string());
    }

    return true;
}

bool DatabaseController::updateLineDataYaml(const CsvImportPaths &paths, const std::vector<std::string> &yamlLineData) const
{
    try
    {
        YAML::Node rootNode = YAML::LoadFile(pathToUtf8String(paths.yamlPath));

        YAML::Node lineDataNode(YAML::NodeType::Sequence);
        lineDataNode.SetStyle(YAML::EmitterStyle::Block);

        for (const auto &item : yamlLineData)
        {
            lineDataNode.push_back(item);
        }

        rootNode["pg_init"]["csv_info"]["line_data"] = lineDataNode;

        YAML::Emitter emitter;
        emitter << rootNode;

        std::ofstream fout(paths.yamlPath, std::ios::out | std::ios::trunc);
        if (!fout.is_open())
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，写入配置文件失败，路径: {}", pathToUtf8String(paths.yamlPath));
            return false;
        }

        fout << emitter.c_str();
        fout.close();
    }
    catch (const std::exception &e)
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，更新YAML异常，配置文件: {}，异常: {}",
                 pathToUtf8String(paths.yamlPath),
                 e.what());
        return false;
    }

    return true;
}

bool DatabaseController::reloadLineData(const std::vector<std::string> &copiedFiles)
{
    if (!m_tableLineData)
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，线路表对象未初始化");
        return false;
    }

    if (!m_tableLineData->clearLineData())
    {
        LogError("[DatabaseController]数据库控制器线路CSV导入失败，清空线路表数据失败");
        return false;
    }

    for (const auto &filePath : copiedFiles)
    {
        if (!initLineData(filePath))
        {
            LogError("[DatabaseController]数据库控制器线路CSV导入失败，初始化线路数据失败，文件: {}", filePath);
            return false;
        }
    }

    return true;
}

void DatabaseController::dataFromConfig(const Json::Value &json)
{
    LogDebug("[DatabaseController]数据库控制器收到配置数据，内容: {}", json.toStyledString());
    m_lineDataJson = json;
}

std::string DatabaseController::getConfigFilePath() const
{
    auto systemAppPath = _Kits::SystemConfig::configPath();
    if (systemAppPath.empty())
    {
        return {};
    }
    return systemAppPath;
}

bool DatabaseController::initLineData(const std::string &filepath)
{
    const auto &csvLines = excelwriter_.read_csv(filepath);
    std::vector<TIS_Info::line_data> vObjs;
    vObjs.reserve(csvLines.size());
    const auto &timestring = _Kits::datetime::current_timepoint();
    const auto &find_value = [](const std::unordered_map<std::string, std::string> &line, const std::string &key) -> std::string {
        auto finder = line.begin();
        for (; finder != line.end(); ++finder)
        {
            if (finder->first.find(key) != std::string::npos)
            {
                return finder->second;
            }
        }
        return {};
    };

    for (const auto &line : csvLines)
    {
        if (find_value(line, "线路").empty() || find_value(line, "行别").empty() || find_value(line, "线路类型").empty())
        {
            continue;
        }

        TIS_Info::line_data data;
        auto str_line_type = find_value(line, "线路类型");
        if (!str_line_type.empty())
        {
            data.line_type = str_line_type.find("刚性") != std::string::npos ? 0 : 1;
        }

        auto str_line_direction = find_value(line, "行别");
        if (!str_line_direction.empty())
        {
            data.line_direction = str_line_direction.find("上行") != std::string::npos ? 0 : 1;
        }

        data.line_name = !find_value(line, "线路").empty() ? find_value(line, "线路") : "";
        data.station_name = !find_value(line, "站区").empty() ? find_value(line, "站区") : "";
        data.maoduan_name = !find_value(line, "锚段").empty() ? find_value(line, "锚段") : "";
        data.pole_name = !find_value(line, "杆号").empty() ? find_value(line, "杆号") : "";
        data.kilometer = !find_value(line, "公里标").empty() ? std::stof(find_value(line, "公里标")) : 0.0f;
        data.station_id = !find_value(line, "站区id").empty() ? std::stoi(find_value(line, "站区id")) : -1;
        data.rfid_id = !find_value(line, "RFID").empty() ? find_value(line, "RFID") : "";
        data.span = !find_value(line, "跨距").empty() ? std::stof(find_value(line, "跨距")) : 0.0f;
        data.structure = !find_value(line, "结构").empty() ? find_value(line, "结构") : "";
        data.zig_manual = !find_value(line, "拉出值").empty() ? std::stof(find_value(line, "拉出值")) : 0.0f;
        data.hei_manual = !find_value(line, "导高").empty() ? std::stof(find_value(line, "导高")) : 0.0f;
        data.created_time = timestring;
        vObjs.emplace_back(std::move(data));
    }

    if (!vObjs.empty() && m_tableLineData)
    {
        m_tableLineData->insertDatas(std::move(vObjs));
    }
    return true;
}
} // namespace _Controllers
