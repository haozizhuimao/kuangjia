
set(CTL_NAME "ctrl_infrared_temperature")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})

target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_database>
$<TARGET_OBJECTS:kit_infrared_general>
)        

find_package(OpenCV REQUIRED)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
) 


target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies
kit_database
kit_log
kit_infrared_general
)

target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})
