#include "TemperatureDataDeal.h"
#include "kits/utility/log/CRossLogger.h"
#include <iostream>
#include <filesystem>
#include <cmath>
#include <algorithm>
#include <opencv2/opencv.hpp>
#include "kits/database/postgresql_interface/InfraredSql.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

TemperatureDataDeal::TemperatureDataDeal(const int camerano)
:m_camerano(camerano)
{}

void TemperatureDataDeal::setSqlptr(const std::shared_ptr<_Kits::database::InfraredSql> &infraredSql)
{
    if(nullptr == infraredSql)
    {
        LogError("infraredSql is nullptr");
    }
    m_infraredSql = infraredSql;
}
void TemperatureDataDeal::recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
{
    m_IRImageQueue.pushItemNoBlocking(std::move(IRimagebuffer));
}
void TemperatureDataDeal::setRuleRect(const std::vector<_Kits::IRRuleRect> &rect,const int width,const int height)
{
    m_rawRect = rect;
    m_normalwidth = width;
    m_normalheight = height;
}
void TemperatureDataDeal::init(const TIS_Info::TemperatureConfig &tempctrl)
{
    m_IRImageObjectPool = std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>(30);
    if (nullptr == m_infraredGeneral)
    {
        m_infraredGeneral = std::make_unique<_Kits::InfraredGeneral>();
    }
    m_infraredGeneral->updataAlarmTemp(tempctrl.fAlarmTemp1, tempctrl.fAlarmTemp2, tempctrl.fAlarmTemp3);
    m_ctlConfig = tempctrl;
    m_startFalg.store(true);
    m_IRImageThread = std::thread(&TemperatureDataDeal::handleIRImageThread, this);
}

void TemperatureDataDeal::updateTaskInfo(const TIS_Info::task_data &taskInfo)
{
    
    if(static_cast<int>(TIS_Info::TaskState::TASK_NONE) !=  taskInfo.task_state || static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) != taskInfo.task_state)
    {
        m_taskID.store(taskInfo.id);
        if(!taskInfo.save_path.empty())
        {
            createSaveDiretory(taskInfo.save_path);
        }
        m_iSaveImgCount = 0;
    }
    else if(static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) == taskInfo.task_state)
    {
        m_taskID.store(-1);
        m_taskFlag.store(false);
    }
}
void TemperatureDataDeal::stop()
{
    exitthread();
}
void TemperatureDataDeal::handleIRImageThread()
{
    while (m_startFalg.load())
    {
        auto IRimagebuffer = m_IRImageQueue.popItem();
        if (std::nullopt == IRimagebuffer)
        {
            break;
        }
         
         int no = 1;
        std::vector<float> maxtempvec;
        maxtempvec.clear();
        for(auto &it: m_rawRect)
        {
            cv::Point tempPoint;
            float maxtemp = 0.0;
            float mintemp = 0.0;
            if (0 != updateTempValue(*IRimagebuffer, tempPoint,mintemp,maxtemp,it))
            {
                continue;
            }
            dealIRImageData(*IRimagebuffer, tempPoint,no,mintemp,maxtemp);
            no++;
            maxtempvec.emplace_back(maxtemp);
        }

        dealSendToQmlData(*IRimagebuffer, m_rawRect,maxtempvec);

    }
}
int TemperatureDataDeal::updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, cv::Point &maxTempPoint,float& mintemp, float& maxtemp, _Kits::IRRuleRect& rect)
{
    if (nullptr == IRimagebuffer)
    {
        return 1;
    }

    if (1 == m_ctlConfig.getTemperatrueType)
    {
        IRRuleRect normalRect;
        InfraredGeneral::normalizeRuleRect(
        rect, IRimagebuffer->width, IRimagebuffer->height, m_normalwidth, m_normalheight, normalRect);
        float maxTemp = 0.0;
        float minTemp = 0.0;
        IRPoint maxTempIRPoint;
        InfraredGeneral::analysisHotPicData(
            IRimagebuffer->tempdata.data(), normalRect, IRimagebuffer->width, minTemp, maxTemp, maxTempIRPoint);
        mintemp = minTemp;
        maxtemp= maxTemp;
        maxTempPoint.x = maxTempIRPoint.x;
        maxTempPoint.y = maxTempIRPoint.y;
    
        
    }
    else
    {
        maxtemp =  IRimagebuffer->maxtemp;
        mintemp =  IRimagebuffer->mintemp;
        maxTempPoint.x = IRimagebuffer->maxpointx * IRimagebuffer->width;
        maxTempPoint.y = IRimagebuffer->maxpointy * IRimagebuffer->height;
    }

    float tmpmaxTemp = m_ctlConfig.favgTemperature_coefficient * maxtemp + m_ctlConfig.fmaxTemperature_calibration;
    maxtemp= tmpmaxTemp;
   // m_maxtemp.store(tmpmaxTemp);

    return 0;
}
void TemperatureDataDeal::dealSendToQmlData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, std::vector<_Kits::IRRuleRect> &rawRect,const std::vector<float>& maxtempvec)
{
    if (nullptr == IRimagebuffer)
    {
        LogError("IRImageBuffer is null");
        return;
    }

    cv::Mat imageMat;  // 用于存储最终图像（RGB或BGR顺序）
    if (1 == m_ctlConfig.getTemperatrueType) {
        std::vector<uchar> buf(IRimagebuffer->data.data(),
                            IRimagebuffer->data.data() + IRimagebuffer->iamgesize);
        imageMat = cv::imdecode(buf, cv::IMREAD_COLOR);  // 解码为 BGR 图像
        if (imageMat.empty()) {
            return;
        }
    } else {

        cv::Mat yuv_mat(IRimagebuffer->height * 3 / 2, IRimagebuffer->width,
                        CV_8UC1, IRimagebuffer->data.data());
        cv::Mat rgb_mat(IRimagebuffer->height, IRimagebuffer->width, CV_8UC3);
        cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);  // 输出为 RGB 顺序
        cv::Mat bgr_mat;
        cv::cvtColor(rgb_mat, bgr_mat, cv::COLOR_RGB2BGR);
        imageMat = bgr_mat;
    }


    if (0 < m_normalheight && 0 < m_normalwidth)
    {
        std::cout << "size:" << rawRect.size() << std::endl;
        for(int i = 0; i < rawRect.size(); i++)
        {
            
            paintRectangle(IRimagebuffer,imageMat,rawRect.at(i),maxtempvec.at(i));
        }
    }
    auto imageBuffer = m_IRImageObjectPool->getObject(imageMat.cols, imageMat.rows,
                                                    imageMat.channels());
    imageBuffer->name = IRimagebuffer->name;
    std::copy(imageMat.data, imageMat.data + imageMat.total() * imageMat.elemSize(), imageBuffer->data.begin());

    try {
        _Service::TemperatureService::sendIRImageToQml(imageBuffer);
    } catch (std::exception &e) {
        // 错误处理
    }

}

void TemperatureDataDeal::paintRectangle(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer,const cv::Mat &imageMat,_Kits::IRRuleRect &rawRect,float maxTemp)
{
    int offsetx = rawRect.startx * IRimagebuffer->width / m_normalwidth;
    int offsety = rawRect.starty * IRimagebuffer->height / m_normalheight;
    int endoffsetx = rawRect.endx * IRimagebuffer->width / m_normalwidth;
    int endoffsety = rawRect.endy * IRimagebuffer->height / m_normalheight;

    // 2. 计算矩形区域（注意原代码中使用了 IRimagebuffer->height 做翻转）
    //    我们保持与原 QPainter 完全一致的坐标逻辑
    int x1 = offsetx;
    int y1 = IRimagebuffer->height - endoffsety;   
    int x2 = endoffsetx;
    int y2 = IRimagebuffer->height - offsety;      

    cv::Rect rect(x1, y1, x2 - x1, y2 - y1);       

    // 3. 在 imageMat 上绘制绿色矩形和文字（使用 OpenCV 绘图函数）
    cv::Scalar green(0, 255, 0);  // BGR 顺序下的绿色
    cv::rectangle(imageMat, rect, green, 1);  // 线宽为 2 像素

    // 获取最大温度值（假设 m_maxtemp 是原子类型或可直接读取）
    //float maxTemp = m_maxtemp.load();
    std::string tempText = std::format("{:.2f}", maxTemp);  // 格式化为两位小数

    int fontFace = cv::FONT_HERSHEY_TRIPLEX;
    // 根据图像宽度自动调整字号，保证不同分辨率下文字清晰
    double fontScale = static_cast<double>(imageMat.cols) / 800.0 * 0.6;
    if (fontScale < 0.5) fontScale = 0.5;
    if (fontScale > 2.0) fontScale = 2.0;
    int thickness = std::max(1, static_cast<int>(std::round(fontScale)));
    int baseline = 0;
    cv::Size textSize = cv::getTextSize(tempText, fontFace, fontScale, thickness, &baseline);

    // 计算文字位置：矩形上方 10 像素处居中
    cv::Point textOrg(rect.x + (rect.width - textSize.width) / 2, rect.y - 10);

    // 如果矩形太靠上，避免文字出界，放到矩形下方
    if (textOrg.y < textSize.height) {
        textOrg.y = rect.y + rect.height + textSize.height + 10;
    }

    // 使用抗锯齿并带合适粗细，提高在缩放时的可读性
    cv::putText(imageMat, tempText, textOrg, fontFace, fontScale, green, thickness, cv::LINE_AA);
}
void TemperatureDataDeal::dealIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const cv::Point &maxTempPoint,int rulesno,const float mintemp, const float maxtemp)
{
    if (!m_taskFlag.load())
    {
        return;
    }
    bool bLimitByTime = true;
    auto now = std::chrono::high_resolution_clock::now();
    if(m_saveImageTime.size() < rulesno)
    {
        m_saveImageTime.emplace_back( std::chrono::steady_clock::time_point(std::chrono::seconds(0)));
    }
    auto durationtime = std::chrono::duration_cast<std::chrono::seconds>(now - m_saveImageTime.at(rulesno -1));

    if ( m_saveImageTime.at(rulesno -1) != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_ctlConfig.iAlarmTimeInterval)
    {
        bLimitByTime = false;
    }

    int alarmLevel = m_infraredGeneral->isAlarm(maxtemp);
    std::string picname = " ";
    if (alarmLevel > 0)
    {
        if (bLimitByTime)
        {
             m_saveImageTime.at(rulesno -1) = now;
            if (alarmLevel <= m_ctlConfig.savepicflag)
            {
                picname = generatePictureName();
                saveIRImage(IRimagebuffer, picname, maxTempPoint,maxtemp);
            }
        }
    }
    if (!bLimitByTime)
    {
        alarmLevel = 0;
    }

    float avgtemp = (mintemp + maxtemp) / 2;
    std::filesystem::path picnamepath = std::filesystem::path(picname);
    auto  utf8picpath = picnamepath.u8string();
    std::string picnamepathstr(utf8picpath.begin(), utf8picpath.end());
    dealIRAlarmData(alarmLevel, mintemp, maxtemp, avgtemp, picnamepathstr,rulesno);
}

void TemperatureDataDeal::saveIRImage(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer,
                                        const std::string &picname,
                                        const cv::Point &maxTempPoint,
                                        const float maxtemp)
{
    if (nullptr == IRimagebuffer)
    {
        return;
    }

    std::vector<uchar> buf(IRimagebuffer->data.data(), IRimagebuffer->data.data() + IRimagebuffer->iamgesize);
    cv::Mat img = cv::imdecode(buf, cv::IMREAD_COLOR); // 或 cv::IMREAD_UNCHANGED? QImage::fromData默认读取为RGB？ QImage加载JPG会得到RGB格式。OpenCV默认是BGR。
    if (img.empty()) {
        LogError("cv::imdecode failed");
        return; // 或者相应处理
    }

    // 在原图上绘制矩形
    cv::Point topLeft(maxTempPoint.x - 20, maxTempPoint.y - 20);
    cv::Point bottomRight(maxTempPoint.x + 20, maxTempPoint.y + 20);
    cv::rectangle(img, topLeft, bottomRight, cv::Scalar(0, 0, 0), 1, cv::LINE_8); // 榛戣壊锛岀嚎瀹?

    // 绘制文本（格式化并根据图像宽度调整字号）
    std::string tempText = std::format("{:.2f}", maxtemp);
    double saveFontScale = static_cast<double>(img.cols) / 800.0 * 0.6;
    if (saveFontScale < 0.5) saveFontScale = 0.5;
    if (saveFontScale > 2.0) saveFontScale = 2.0;
    int saveThickness = std::max(1, static_cast<int>(std::round(saveFontScale)));
    int yOffset = static_cast<int>(15 * saveFontScale);
    cv::putText(img, tempText, cv::Point(maxTempPoint.x, maxTempPoint.y + yOffset),
                cv::FONT_HERSHEY_SIMPLEX, saveFontScale, cv::Scalar(0, 0, 0), saveThickness, cv::LINE_AA);

    // 保存图像
    bool ret = cv::imwrite(picname, img);
    if (!ret) {
        LogError("saveIRImage failed:{}", picname);
    }
}
void TemperatureDataDeal::createSaveDiretory(const std::string &taskName)
{
    LogInfo("TemperatureDataDeal::startTask:{}", taskName);
    std::filesystem::path path = std::filesystem::u8path(taskName);
    
    path += u8"/红外超限/IRCamera";
    path += std::to_string(m_camerano);  

    m_taskSvaePath = path.string(); 
    //m_taskSvaePath += std::to_string(m_camerano);

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            m_iSaveImgCount = 0;
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    LogInfo("start success:{}", m_taskSvaePath);

    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    m_taskFlag.store(true);
}
std::string TemperatureDataDeal::generatePictureName()
{

    std::string strPicName = std::format("{}_{}_0_0.jpg", m_iSaveImgCount++, _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds));

    std::string picname = m_taskSvaePath + "/" + strPicName;
    return picname;
}
void TemperatureDataDeal::dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname,int rulesno)
{
    TIS_Info::temperature_data tempData;
    tempData.rules_no = rulesno;
    tempData.camera_no = m_camerano;
    tempData.alarm_level = level;
    tempData.max = maxtemp;
    tempData.min = mintemp;
    tempData.avg = avgtemp;
    if (level > 0)
    {
        tempData.alarm_temp = maxtemp;
    }
    else
    {
        tempData.alarm_temp = 0;
    }
    tempData.task_id = m_taskID;
    tempData.pic_path = picname;
    tempData.created_time = _Kits::datetime::current_timepoint();


    if (m_infraredSql)
    {
        m_infraredSql->insert(std::move(tempData));
    }

    
}
void TemperatureDataDeal::exitthread()
{
    m_startFalg.store(false);
    recvIRImageData(nullptr);
    if (m_IRImageThread.joinable())
    {
        m_IRImageThread.join();
    }
}
} // namespace _Controllers


