#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
//#include "tis_global/Function.h"
#include "kits/utility/container/BlockingQueue.h"
#include "kits/common/infrared_general/InfraredGeneral.h"
#include "kits/common/camera/hik/temperature/HikTemperatureCamera.h"
#include "kits/utility/object_pool/ObjectPool.h"
#include <thread>
#include <atomic>
#include <memory>
#include <string>
#include <opencv2/opencv.hpp>
#include <vector>

namespace _Kits::database {
class InfraredSql;
}

namespace _Controllers {
class TemperatureDataDeal
{
  public:
    TemperatureDataDeal(const int camerano);
    ~TemperatureDataDeal() {};
    // void start();
    void stop();
    void init(const TIS_Info::TemperatureConfig &tempctrl);
    void updateTaskInfo(const TIS_Info::task_data &);
    void recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer>);
    void setRuleRect(const std::vector<_Kits::IRRuleRect> &rect,const int width,const int height);
    void setSqlptr(const std::shared_ptr<_Kits::database::InfraredSql> &infraredSql);

  private:
    _Kits::BlockingQueue<std::shared_ptr<TIS_Info::IRImageBuffer>> m_IRImageQueue{10};
    std::thread m_IRImageThread;
    std::atomic_bool m_startFalg = false;
    std::vector<_Kits::IRRuleRect> m_rawRect;
    int m_normalwidth = 0;
    int m_normalheight = 0;
    int m_iSaveImgCount = 0;
    // std::atomic<float> m_mintemp = 0.0;
    //std::atomic<float> m_maxtemp = 0.0;
    std::atomic_bool m_taskFlag = false;
    std::string m_taskSvaePath = "";
    std::string m_strSavePicRoot = "";
    std::vector<std::chrono::steady_clock::time_point> m_saveImageTime;
    //std::chrono::steady_clock::time_point m_saveImageTime = std::chrono::steady_clock::time_point(std::chrono::seconds(0));
    std::unique_ptr<_Kits::InfraredGeneral> m_infraredGeneral = nullptr;
    std::atomic<int> m_taskID = -1;
    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> m_IRImageObjectPool = nullptr;
    std::shared_ptr<_Kits::database::InfraredSql> m_infraredSql;
    TIS_Info::TemperatureConfig m_ctlConfig;
    int m_camerano = 0;

  private:
   
    void handleIRImageThread();
    void dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname,int rulesno);
    void createSaveDiretory(const std::string &taskName);
    void exitthread();
    void dealIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const cv::Point &maxTempPoint,int rulesno,const float mintemp, const float maxtemp);
    void dealSendToQmlData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, std::vector<_Kits::IRRuleRect> &rawRect,const std::vector<float>& maxtempvec);
    void saveIRImage(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const std::string &picname, const cv::Point &maxTempPoint,const float maxtemp);
    int updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, cv::Point &maxTempPoint,float& mintemp,  float& maxtemp, _Kits::IRRuleRect& rect);
    void paintRectangle(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer,const cv::Mat &imageMat,_Kits::IRRuleRect &rawRect,float maxTemp);
    std::string generatePictureName();
};
} // namespace _Controllers
