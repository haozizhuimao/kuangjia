#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
//#include "tis_global/Function.h"
#include "kits/utility/container/BlockingQueue.h"
#include "kits/common/infrared_general/InfraredGeneral.h"
#include "kits/common/camera/hik/temperature/HikTemperatureCamera.h"
#include "kits/utility/object_pool/ObjectPool.h"
#include <thread>
#include "TemperatureDataDeal.h"
#include <atomic>
#include <memory>
#include <string>
#include <opencv2/opencv.hpp>
#include <unordered_map>
namespace _Kits::database {
class InfraredSql;
}

namespace _Controllers {
class TemperatureController : public ControllerBase<TemperatureController>
{
  public:
    void init(const std::unordered_map<std::string, TIS_Info::TemperatureConfig> &);
    void stop();
    void onStart();
    void onRecvTaskInfo(const TIS_Info::task_data &);
    void initTemperatureObject(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikTemperatureCamera>> &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(_Service::TemperatureService::dispatchHiKTemperatureObject, TemperatureController::initTemperatureObject);
    ASYNC_TASK_ADD(_Service::TemperatureService::initSignal, TemperatureController::init);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, TemperatureController::stop);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, TemperatureController::onStart);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, TemperatureController::onRecvTaskInfo);
    TASK_LIST_END

  private:
    std::unordered_map<std::string, std::shared_ptr<TemperatureDataDeal>> m_temperatureDealObject;
    std::unordered_map<std::string, TIS_Info::TemperatureConfig> m_temperatureConfigMap;
};

} // namespace _Controllers
