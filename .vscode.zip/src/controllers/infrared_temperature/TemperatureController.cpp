#include "TemperatureController.h"
#include "kits/utility/log/CRossLogger.h"
#include <iostream>
#include <filesystem>
#include <cmath>
#include <algorithm>
#include <opencv2/opencv.hpp>
#include "kits/database/postgresql_interface/InfraredSql.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TemperatureController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        auto infraredSql = std::make_shared<database::InfraredSql>(pgClientPtr);
        for(const auto &it:m_temperatureDealObject)
        {
            if(nullptr != it.second)
            {
                it.second->setSqlptr(infraredSql);
            }
        }
    }
}
void TemperatureController::initTemperatureObject(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikTemperatureCamera>>  &temperatureObjectMap)
{
    int cameraNO = 0;
    for(const auto &it:temperatureObjectMap)
    {
        auto dataDealObject = std::make_shared<TemperatureDataDeal>(cameraNO);
        auto cameraName = it.first;

        it.second->setIRImageReadyCallback([this,dataDealObject,cameraName](std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
        {
            IRimagebuffer->name = cameraName;
            dataDealObject->recvIRImageData(IRimagebuffer);
        });
        std::vector<_Kits::IRRuleRect> rawRect;
        int normalwidth = 0;
        int normalheight = 0;
        it.second->getIRTempRect(rawRect, normalwidth, normalheight);
        dataDealObject->setRuleRect(rawRect,normalwidth,normalheight);  
        dataDealObject->init(m_temperatureConfigMap[cameraName]);
        m_temperatureDealObject[cameraName] = dataDealObject;
        cameraNO++;
    }
}
void TemperatureController::init(const std::unordered_map<std::string, TIS_Info::TemperatureConfig> & configMap)
{

    m_temperatureConfigMap = configMap;
}

void TemperatureController::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    for(auto &it:m_temperatureDealObject)
    {
        if(nullptr != it.second)
        {
            it.second->updateTaskInfo(taskInfo);
        }
    }
}
void TemperatureController::stop()
{
   // exitthread();
   for(auto &it:m_temperatureDealObject)
   {
       if(nullptr != it.second)
       {
           it.second->stop();
       }
   }
}

} // namespace _Controllers


