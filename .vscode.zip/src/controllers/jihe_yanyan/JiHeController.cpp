﻿#include "JiHeController.h"
#include "JiheTools.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/database/DbClient.h"
#include "kits/database/postgresql_interface/PgJiheData.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/struct_details/sql_struct.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

static void Rota(double &dx, double &dy, double dAngle)
{
    double dLen = std::sqrt(dx * dx + dy * dy);
    if (dLen == 0)
        return;

    double dAngleQ = asin(dx / dLen);
    double dAngleNew = dAngleQ + dAngle;
    dx = sin(dAngleNew) * dLen;
    dy = cos(dAngleNew) * dLen;
    return;
}

static void ExcucteBc(float &fzig, float &fhei, float fleft_zig, float fleft_hei, float fright_zig, float fright_hei)
{
    const double fdist = 1500;

    double fdy = (fright_hei - fleft_hei) * 1.0;
    double dCAngle = asin(fdy / fdist);
    double dx = fzig;
    double dy = fhei;
    Rota(dx, dy, -dCAngle);

    double dXDiff = dx - fzig;
    fzig = (float)dx + (fleft_zig + fright_zig) / 2;
    fhei = (float)dy + (fleft_hei + fright_hei) / 2;

    fhei += (float)std::abs(dXDiff) * 0;
    return;
}

void JiHeController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        m_pgJiheData = std::make_shared<database::PgJiheData>(pgClientPtr);
    }

    const std::string &udpbc_name = "udp_buchang";
    auto udp_client = _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(udpbc_name);
    if (udp_client)
    {
        m_bBCStatus = true;
        udp_client->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) {
            if (!datas)
            {
                return;
            }
            recvUdpBuchangData(std::vector<uint8_t>(datas->begin(), datas->end()));
        });
    }
}

void JiHeController::onStop() {}

void JiHeController::recvUdpBuchangData(std::vector<uint8_t> &&datas)
{
    if (datas.size() < sizeof(TIS_Info::BCData))
    {
        LogError("[JiHeController::recvUdpBuchangData] invalid data size: {}", datas.size());
        return;
    }

    TIS_Info::BCData bcData;
    std::memcpy(&bcData, datas.data(), sizeof(TIS_Info::BCData));

    if (buchangCollector_)
    {
        buchangCollector_->insert({std::move(datas), datetime::current_timestamp(datetime::TimestampUnit::Milliseconds)});
    }

    std::lock_guard<std::mutex> lock(m_mtxBuchang);
    m_bcData = bcData;
}

void JiHeController::recvTaskData(const TIS_Info::task_data &task)
{
    auto nTaskstate = static_cast<TIS_Info::TaskState>(task.task_state);

    if (TIS_Info::TaskState::TASK_STOPPED == nTaskstate || TIS_Info::TaskState::TASK_NONE == nTaskstate)
    {
        m_taskID.store(-1, std::memory_order_release);
        if (jiheCollector_)
        {
            jiheCollector_.reset();
        }
        if (buchangCollector_)
        {
            buchangCollector_.reset();
        }
        return;
    }

    if (TIS_Info::TaskState::TASK_START != nTaskstate)
    {
        return;
    }

    std::unique_lock ul(m_mtxSqlite);

    std::string yanyan_name =
        std::format("yanyan_{}_{}.db", task.id, _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds));
    auto yanyan_client = _Service::DatabaseManager::getSqlite3Client<database::DbClientPtr>(yanyan_name, true);
    jiheCollector_ = std::make_shared<_Kits::database::SqliteCollect>(yanyan_client);
    m_taskID.store(task.id, std::memory_order_release);

    if (m_bBCStatus)
    {
        std::string buchang_name =
            std::format("udpbuchang_{}_{}.db", task.id, _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds));
        auto buchang_client = _Service::DatabaseManager::getSqlite3Client<database::DbClientPtr>(buchang_name, true);
        buchangCollector_ = std::make_shared<_Kits::database::SqliteCollect>(buchang_client);
    }
}

void JiHeController::broadcastJiHeData(const std::shared_ptr<TIS_Info::JiHeData> &jiheData)
{
    _Service::JiHeService::full(jiheData);
    auto currentTime = datetime::current_timestamp(datetime::TimestampUnit::Milliseconds);
    constexpr int interval = 50;
    auto lastTime = m_lastBroadcast.load(std::memory_order_acquire);
    if (currentTime - lastTime >= interval)
    {
        _Service::JiHeService::broadcast(jiheData);
        m_lastBroadcast.store(currentTime, std::memory_order_release);
    }
}

void JiHeController::recvJiheData(const std::shared_ptr<TIS_Info::RawData> &rawData)
{
    if (m_taskID == -1 || !rawData)
    {
        return;
    }

    std::shared_ptr<JCWD> jcwjh = std::make_shared<JCWD>();
    std::memcpy(jcwjh.get(), rawData->data.data(), sizeof(JCWD));

    if (m_bBCStatus)
    {
        float flx, frx, fly, fry;
        {
            std::lock_guard<std::mutex> lock(m_mtxBuchang);
            jcwjh->pntCompLeft.y = m_bcData.left_fvert;
            jcwjh->pntCompLeft.x = m_bcData.left_fhori;
            jcwjh->pntCompRight.y = m_bcData.right_fvert;
            jcwjh->pntCompRight.x = m_bcData.right_fhori;
            flx = m_bcData.left_fhori * 1.0;
            frx = m_bcData.right_fhori * 1.0;
            fly = m_bcData.left_fvert * 1.0;
            fry = m_bcData.right_fvert * 1.0;
        }
        for (int i = 0; i < jcwjh->uiLineNum; i++)
        {
            float DX = 1.0 * jcwjh->jcx[i].pntLinePos.x + 0 * jcwjh->jcx[i].pntLinePos.y + 0;
            float DY = 0 * jcwjh->jcx[i].pntLinePos.x + 1.0 * jcwjh->jcx[i].pntLinePos.y + 0;
            if (std::abs(flx) < 200 && std::abs(fly) < 200 && std::abs(frx) < 200 && std::abs(fry) < 200)
            {

                ExcucteBc(DX, DY, flx, fly, frx, fry);
                lastflx = flx;
                lastfly = fly;
                lastfrx = frx;
                lastfry = fry;
            }
            else
            {
                ExcucteBc(DX, DY, lastflx, lastfly, lastfrx, lastfry);
            }
            jcwjh->jcx[i].pntCompPos.x = DX;
            jcwjh->jcx[i].pntCompPos.y = DY;
        }
    }

    auto jiheData = JiheTools::convertToJiheData(jcwjh);
    jiheData->timestamp = rawData->timestamp / 1000;
    jiheData->task_id = m_taskID.load(std::memory_order_acquire);

    pgJieData(jiheData);
    broadcastJiHeData(jiheData);

    if (jiheCollector_)
    {
        jiheCollector_->insert({std::move(rawData->data), rawData->timestamp});
    }
}

void JiHeController::recvJiheJCWJHData(const std::shared_ptr<TIS_Info::RawData> &rawData)
{
    if (m_taskID == -1 || !rawData)
    {
        return;
    }
    std::shared_ptr<JCWJH> jcwjh = std::make_shared<JCWJH>();
    std::memcpy(jcwjh.get(), rawData->data.data(), sizeof(JCWJH));

    auto jcwjhData = JiheTools::convertToFullJiheJCWJHData(jcwjh);
    jcwjhData->timestamp = rawData->timestamp / 1000;
    jcwjhData->task_id = m_taskID.load(std::memory_order_acquire);
    // LogError("frame_number: {} line_number: {}", jcwjhData->frame_number, jcwjhData->line_number);

    pgJieData(jcwjhData);
    broadcastJiHeData(jcwjhData);
}

void JiHeController::recvBcData(const std::shared_ptr<TIS_Info::RawData> &rawData)
{
    recvUdpBuchangData(std::move(rawData->data));
}

void JiHeController::getUdpClient(const std::string &title)
{
    auto client = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(title);
    if (!client)
    {
        LogError("[JiHeController::getUdpClient] 未找到UDP客户端: {}", title);
        return;
    }

    _Service::YanYanDataCollect::udpClientGet(client);
    LogInfo("[JiHeController::getUdpClient] 获取UDP客户端成功: {}", title);
}

void JiHeController::pgJieData(const std::shared_ptr<TIS_Info::JiHeData> &org)
{
    if (!m_pgJiheData || !org)
    {
        return;
    }

    TIS_Info::jihe_data jihe;
    auto &data = *org;
    jihe.created_time = _Kits::datetime::timestamp_to_timepoint(data.timestamp, _Kits::datetime::TimestampUnit::Milliseconds);
    jihe.task_id = data.task_id;
    jihe.frame_number = data.frame_number;
    jihe.line_number = data.line_number;
    jihe.pos_type = data.position_type;
    jihe.zig0 = data.fZig[0];
    jihe.zig1 = data.fZig[1];
    jihe.zig2 = data.fZig[2];
    jihe.zig3 = data.fZig[3];
    jihe.hei0 = data.fHei[0];
    jihe.hei1 = data.fHei[1];
    jihe.hei2 = data.fHei[2];
    jihe.hei3 = data.fHei[3];
    jihe.zig_bc0 = data.fZigBc[0];
    jihe.zig_bc1 = data.fZigBc[1];
    jihe.zig_bc2 = data.fZigBc[2];
    jihe.zig_bc3 = data.fZigBc[3];
    jihe.hei_bc0 = data.fHeiBc[0];
    jihe.hei_bc1 = data.fHeiBc[1];
    jihe.hei_bc2 = data.fHeiBc[2];
    jihe.hei_bc3 = data.fHeiBc[3];
    jihe.left_bc_x = data.fLeftBCX;
    jihe.left_bc_y = data.fLeftBCY;
    jihe.right_bc_x = data.fRightBCX;
    jihe.right_bc_y = data.fRightBCY;
    jihe.mohao_width0 = data.fMoHaoWidth[0];
    jihe.mohao_width1 = data.fMoHaoWidth[1];
    jihe.mohao_width2 = data.fMoHaoWidth[2];
    jihe.mohao_width3 = data.fMoHaoWidth[3];
    jihe.mohao_height0 = data.fMoHaoHeight[0];
    jihe.mohao_height1 = data.fMoHaoHeight[1];
    jihe.mohao_height2 = data.fMoHaoHeight[2];
    jihe.mohao_height3 = data.fMoHaoHeight[3];
    jihe.diameter0 = data.Diameter[0];
    jihe.diameter1 = data.Diameter[1];
    jihe.diameter2 = data.Diameter[2];
    jihe.diameter3 = data.Diameter[3];
    jihe.gradeLenght = m_lastGrade.load(std::memory_order_acquire);

    m_pgJiheData->insert(std::move(jihe));
}

} // namespace _Controllers
