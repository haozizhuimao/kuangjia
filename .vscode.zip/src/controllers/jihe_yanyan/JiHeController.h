#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/database/sqlite3_interface/SqliteCollect.h"
#include "tis_global/struct_details/jihe_struct.h"
#include "tis_global/struct_details/sql_struct.h"
#include <atomic>
#include <memory>
#include <shared_mutex>

namespace _Kits::database {
class PgJiheData;
}

namespace _Controllers {
class JiHeController : public ControllerBase<JiHeController>
{

  public:
    void onStart();
    void onStop();
    void recvTaskData(const TIS_Info::task_data &);
    void recvJiheData(const std::shared_ptr<TIS_Info::RawData> &);
    void recvBcData(const std::shared_ptr<TIS_Info::RawData> &);
    void recvJiheJCWJHData(const std::shared_ptr<TIS_Info::RawData> &);
    void getUdpClient(const std::string &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, JiHeController::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, JiHeController::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(_Service::YanYanDataCollect::rawDataReady, JiHeController::recvJiheData);
    ASYNC_TASK_ADD(_Service::YanYanDataCollect::rawDataReadyJcwjh, JiHeController::recvJiheJCWJHData);
    ASYNC_TASK_ADD(_Service::SimulationService::distributeJiheData, JiHeController::recvJiheData);
    ASYNC_TASK_ADD(_Service::SimulationService::distributeBcData, JiHeController::recvBcData);
    ASYNC_TASK_ADD(_Service::YanYanDataCollect::getUdpClient, JiHeController::getUdpClient);
    TASK_LIST_END

  private:
    void recvUdpBuchangData(std::vector<uint8_t> &&datas);
    void broadcastJiHeData(const std::shared_ptr<TIS_Info::JiHeData> &JiHeData);
    void pgJieData(const std::shared_ptr<TIS_Info::JiHeData> &data);

    float lastflx = 0;
    float lastfly = 0;
    float lastfrx = 0;
    float lastfry = 0;
    bool m_bBCStatus = false;
    std::mutex m_mtxBuchang;
    TIS_Info::BCData m_bcData;
    std::atomic_int m_taskID = -1;
    std::shared_mutex m_mtxSqlite;
    std::shared_ptr<_Kits::database::SqliteCollect> jiheCollector_{nullptr};
    std::shared_ptr<_Kits::database::SqliteCollect> buchangCollector_{nullptr};
    std::shared_ptr<_Kits::database::PgJiheData> m_pgJiheData;
    std::atomic_int64_t m_lastBroadcast{0};
    std::atomic<float> m_lastGrade{0}; // 上一次得定位器坡度
};
} // namespace _Controllers
