#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <memory>
#include "kits/common/hardware_resources/HardwareInterface.h"
namespace _Controllers {
class HWindowsInfo : public ControllerBase<HWindowsInfo>
{
  public:
    void onStart();
    void onStop();
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, HWindowsInfo::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, HWindowsInfo::onStop);
    TASK_LIST_END
  private:
    std::weak_ptr<_Kits::HardwareInterface> client_;
};
} // namespace _Controllers