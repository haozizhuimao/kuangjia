#include "HWindowsInfo.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <memory>

namespace _Controllers {
void HWindowsInfo::onStart()
{
    client_ = _Service::HardwareManager::getClient<std::shared_ptr<_Kits::HardwareInterface>>();
    auto clientPtr = client_.lock();
    if (clientPtr)
    {
        // 启动时先发送一次硬件信息
        _Kits::thread_pool::runEvery("HardwareManager::resourceInfo", 1000, [this] {
            auto client = client_.lock();
            if (client)
                _Service::HardwareManager::resourceInfo(client->resourcesInfo());
        });
        _Kits::thread_pool::runEvery("HardwareManager::logicalDriveInfo", 30 * 60 * 1000, [this] {
            auto client = client_.lock();
            if (client)
                _Service::HardwareManager::logicalDriveInfo(client->logicalDriveInfo());
        });
    }
}
void HWindowsInfo::onStop() {}
} // namespace _Controllers