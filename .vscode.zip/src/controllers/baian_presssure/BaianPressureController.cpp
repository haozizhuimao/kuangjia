﻿#include "BaianPressureController.h"
#include <vector>
#include <cstdint>
#include <bit>
#include <array>
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/database/postgresql_interface/PgPressureData.h"
#include "BaianDataParse.h"
namespace _Controllers {
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
void BaianPressureController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        m_pressureSql = std::make_shared<database::PgPressureData>(pgClientPtr);
    }
    const std::string &client_title = "baian_pressure";
    const std::string &send_client_title = "baian_pressure_send";
    auto udp_client = _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(client_title);
    if (udp_client)
    {
        udp_client->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) {
            if (!datas)
            {
                return;
            }
            if (!m_bInTask.load(std::memory_order_acquire))
            {
                return;
            }
            recvUdpBaianData(std::vector<uint8_t>(datas->begin(), datas->end()));
        });
    }
    else
    {
        _Kits::LogError(" [拜安压力硬点] UdpClient not found for name: {}", client_title);
    }

    auto udpArcClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(send_client_title);
    if (udpArcClient)
    {
        m_sendudpClient = udpArcClient;
    }
    else
    {
        _Kits::LogError("[拜安压力硬点] UdpClient not found for name: {}", send_client_title);
    }
}
void BaianPressureController::onStop() {}
void BaianPressureController::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    if (static_cast<int>(TIS_Info::TaskState::TASK_NONE) != taskInfo.task_state ||
        static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) != taskInfo.task_state)
    {
        m_taskID.store(taskInfo.id);
        m_bInTask.store(true, std::memory_order_release);
    }
    else if (static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) == taskInfo.task_state)
    {
        m_taskID.store(-1);
        m_bInTask.store(false, std::memory_order_release);
    }
}

void BaianPressureController::recvUdpBaianData(std::vector<uint8_t> &&data)
{
    if (m_taskID.load(std::memory_order_acquire) < 0)
    {
        return;
    }

    int i = 0;
    auto iPackLength = data.size();
    while (iPackLength >= c_data_len)
    {
        if (0xaa == data.at(i) && 0x55 == data.at(i + 1))
        {

            TIS_Info::PressureData pressData;
            if (i + c_data_len > iPackLength)
            {
                break;
            }
            int offset = i + 107;
            BaianDataParse::parsePressData(data, offset, pressData, m_dAccXishu, m_dPressXishu);
            savePressDataToDb(pressData);
            _Service::BaianPressureService::sendPressSpotOut(pressData);
            i += c_data_len;
            iPackLength -= c_data_len;
        }
        else
        {
            ++i;
            --iPackLength;
        }
    }
    return;
}

void BaianPressureController::init(const bool saveRawDataFlag, const double &coefficient)
{
    m_saveRawDataFlag = saveRawDataFlag;
    m_dAccXishu = coefficient;
}
void BaianPressureController::savePressDataToDb(const TIS_Info::PressureData &pressureData)
{
    TIS_Info::press_data pressData;

    pressData.acc0_x = pressureData.fHorizontalAcc.at(0);
    pressData.acc0_y = pressureData.ForwardAcc.at(0);
    pressData.press0 = pressureData.fPress.at(0);
    pressData.press1 = pressureData.fPress.at(1);
    pressData.press2 = pressureData.fPress.at(2);
    pressData.press3 = pressureData.fPress.at(3);
    pressData.task_id = m_taskID.load(std::memory_order_acquire);

    pressData.press4 = pressureData.fPress.at(4);
    pressData.press5 = pressureData.fPress.at(5);
    pressData.press6 = pressureData.fPress.at(6);
    pressData.press7 = pressureData.fPress.at(7);

    pressData.acc0_z = pressureData.VeticalAcc.at(0);
    pressData.acc1_x = pressureData.fHorizontalAcc.at(1);
    pressData.acc1_y = pressureData.ForwardAcc.at(1);
    pressData.acc1_z = pressureData.VeticalAcc.at(1);

    pressData.created_time = std::chrono::system_clock::now();
    pressData.updated_time = std::chrono::system_clock::now();

    std::lock_guard<std::mutex> lock(m_mutexPressData);
    if (m_pressureSql)
    {
        m_pressureSql->insert(std::move(pressData));
    }
}
void BaianPressureController::recvGetLocation(const TIS_Info::LocationData &data)
{
    m_locationData = data;
}
void BaianPressureController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    m_mvbInfo = data;
    _Kits::thread_pool::runTask([this] { sendDataToBaian(); });
}
void BaianPressureController::sendDataToBaian()
{
    std::vector<uint8_t> data;
    data.resize(64);

    BaianDataParse::packageSendData(data, m_locationData, m_mvbInfo, m_liveCount++);

    if (auto udpClient = m_sendudpClient.lock())
    {
        const std::string &send_client_title = "baian_pressure_send";
        udpClient->post(send_client_title, std::move(data));
    }
}

} // namespace _Controllers
