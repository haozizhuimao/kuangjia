#include "BaianDataParse.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/datetime/datetime.h"

namespace _Kits
{
constexpr double PRECISION =  10000 ;
void BaianDataParse::parsePressData(const std::vector<uint8_t> &data, const int offsetbyte, TIS_Info::PressureData &pressureData,const double acccoeff, const double presscoeff)
{
    int offset = offsetbyte;
    for (int j = 0; j < 8; ++j)
    {
        auto result = _Kits::ByteArrayTools::readFromVectorBE<uint32_t>(data, offset);
        auto value = result * 1.0 / PRECISION ;
        pressureData.fPress.at(j) = (value > 8000 ||value <= -8000) ? 8000 : value;
        offset += 4;
    }

    for (int j = 0; j < 2; ++j)
    {
        auto result = _Kits::ByteArrayTools::readFromVectorBE<uint32_t>(data, offset);
        auto value = result * 1.0 / PRECISION * acccoeff ;
        pressureData.fHorizontalAcc.at(j) = (value > 8000 ||value <= -8000) ? 8000 : value;;

        offset += 4;
        result = _Kits::ByteArrayTools::readFromVectorBE<uint32_t>(data, offset);
        value = result * 1.0 / PRECISION * acccoeff;
        pressureData.ForwardAcc.at(j) = (value > 8000 ||value <= -8000) ? 8000 : value; 

        offset += 4;
        result = _Kits::ByteArrayTools::readFromVectorBE<uint32_t>(data, offset);
        value = result * 1.0 / PRECISION * acccoeff;
        pressureData.VeticalAcc.at(j) = (value > 8000 ||value <= -8000) ? 8000 : value; 
        offset += 4;
    }
}

void BaianDataParse::packageSendData(std::vector<uint8_t> &data, const TIS_Info::LocationData &locationData, const TIS_Info::MVBCommunicationInfo &mvbInfo,const int liveCount)
{
    packageHeader(data,liveCount);

   //行驶方向
    data.at(14) = mvbInfo.nLineDirection;
    //升降弓状态
    data.at(15) = mvbInfo.mp1PanStatus;

    //开关门状态
    data.at(32) = mvbInfo.doorStatus;
    
    //速度
    std::vector<uint8_t> speedbytes(sizeof(uint64_t));
    int64_t ispeep = mvbInfo.dSpeed * 100;
    std::memcpy(speedbytes.data(), &ispeep, sizeof(uint64_t));
    if constexpr (std::endian::native == std::endian::little)
    {
        std::reverse(speedbytes.begin(), speedbytes.end());
    }
    std::copy(speedbytes.begin(), speedbytes.end(), data.begin() + 16);
    //公里标
    std::vector<uint8_t> milagebytes(sizeof(uint64_t));
    std::memcpy(milagebytes.data(), &locationData.mileage_normal, sizeof(uint64_t));
    if constexpr (std::endian::native == std::endian::little)
    {
        std::reverse(milagebytes.begin(), milagebytes.end());
    }
    std::copy(milagebytes.begin(), milagebytes.end(), data.begin() + 24);

    auto result = crc16_ccitt(data, 62);

    ByteArrayTools::writeToVectorBE<uint16_t>(data, 62, result);
}
void BaianDataParse::packageHeader(std::vector<uint8_t> &data,const int liveCount)
{
    data.at(0) = 0xFF;
    data.at(1) = 0x66;
    ByteArrayTools::writeToVectorBE<uint16_t>(data,liveCount,2);
    auto timestamp_ms = datetime::current_timestamp(datetime::TimestampUnit::Milliseconds);
    uint32_t timestamp = timestamp_ms / 1000;
    uint16_t milliseconds = timestamp_ms % 1000;
    ByteArrayTools::writeToVectorBE<uint32_t>(data, timestamp,4);
    ByteArrayTools::writeToVectorBE<uint16_t>(data, milliseconds,8);
    ByteArrayTools::writeToVectorBE<uint16_t>(data, 48, 10);
}


uint16_t BaianDataParse::crc16_ccitt(const std::vector<uint8_t> &data, int blockLength)
{
    uint16_t crc = 0xffff;
    for (int i = 0; i < blockLength; ++i)
    {
        uint16_t tmp = (crc >> 8) ^ (uint16_t)data[i];
        crc = ((uint16_t)(crc << 8U)) ^ crc16_ccitt_table[tmp];
    }
    return crc;
}

}