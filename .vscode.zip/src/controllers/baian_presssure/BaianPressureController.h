#pragma once
#include "kits/database/postgresql_interface/PgPressureData.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include "tis_global/struct_details/press_acc_collect_struct.h"
#include "kits/database/postgresql_interface/PgPressureData.h"
#include <memory>
#include <mutex>
namespace _Kits::database {
class PressureSql;
}
namespace _Kits {
class UdpClient;
}
namespace _Controllers {

class BaianPressureController : public ControllerBase<BaianPressureController>
{
  public:
    void onStart();
    void onStop();
    void onRecvTaskInfo(const TIS_Info::task_data &);
    void init(const bool, const double &);
    void recvGetLocation(const TIS_Info::LocationData &);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, BaianPressureController::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, BaianPressureController::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, BaianPressureController::onRecvTaskInfo);
    SYNC_TASK_ADD(_Service::BaianPressureService::initBaianPressure, BaianPressureController::init);
    ASYNC_TASK_ADD(_Service::LocationService::LocationRadio, BaianPressureController::recvGetLocation);
    ASYNC_TASK_ADD(_Service::MVBCommunication::sendMVBComInfo, BaianPressureController::recvMVBInfo);
    TASK_LIST_END

  private:
    void recvUdpBaianData(std::vector<uint8_t> &&datas);
    void savePressDataToDb(const TIS_Info::PressureData &pressureData);
    void sendDataToBaian();

  private:
    std::weak_ptr<_Kits::UdpClient> m_sendudpClient;
    std::atomic<int> m_taskID = -1;
    static constexpr int c_data_len = 909;
    double m_dPressXishu{1.0};
    double m_dAccXishu{1.0};
    bool m_saveRawDataFlag = false;
    std::mutex m_mutexPressData;
    TIS_Info::LocationData m_locationData;
    TIS_Info::MVBCommunicationInfo m_mvbInfo;
    uint16_t m_liveCount = 0;
    std::shared_ptr<_Kits::database::PgPressureData> m_pressureSql;
    std::atomic_bool m_bInTask {false};
};
} // namespace _Controllers
