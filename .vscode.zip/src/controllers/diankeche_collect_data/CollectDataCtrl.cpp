#include "CollectDataCtrl.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/database/DbClient.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppInterface.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <format>
#include <utility>
#include "kits/primary/thread_pool/thread_pool.h"

namespace _Controllers {

void CollectDataCtrl::onStart()
{
       auto pgcollectClient =
        _Service::DatabaseManager::getPgClient<_Kits::database::DbClientPtr>(_Kits::database::PgClientNames::pg_client_default);
    m_devCollectDataInsert = std::make_unique<CollectDataInsert>(pgcollectClient);
}

void CollectDataCtrl::onStop()
{
    bInTask_.store(false, std::memory_order_release);
    std::unique_lock ul(mtxCollect_);
    m_devCollectDataInsert->stopProcess();
}

void CollectDataCtrl::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    auto nTaskstate = static_cast<TIS_Info::TaskState>(taskInfo.task_state);
    m_taskInfo_ = taskInfo;
    if (nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        bInTask_.store(true, std::memory_order_release);
        std::unique_lock ul(mtxCollect_);
        if (m_devCollectDataInsert)
        {
            m_devCollectDataInsert->collectionEnable(true);
        }
    }
    else if (nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        if (m_devCollectDataInsert)
        {
            m_devCollectDataInsert->collectionEnable(false);
        }
        bInTask_.store(false, std::memory_order_release);

    }
}

void CollectDataCtrl::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    if(!bInTask_.load(std::memory_order_acquire))
    {
        return;
    }
    std::unordered_map<std::string, float> dataMap = {{"voltage", data.voltage}, {"electric", data.electric}};
    if(nullptr != m_devCollectDataInsert)
    {
        m_devCollectDataInsert->process(dataMap, m_taskInfo_.id);
    }
}
void CollectDataCtrl::onRecvTemperatureHumidityData(const TIS_Info::TemperatureHumidity &th)
{

    if(!bInTask_.load(std::memory_order_acquire))
    {
        return;
    }
    _Kits::LogDebug("Received temperature humidity data: {}, {}", th.temperature, th.humidity);
    std::unordered_map<std::string, float> dataMap = {{"temperature", th.temperature}, {"humidity", th.humidity}};
    if(nullptr != m_devCollectDataInsert)
    {
        m_devCollectDataInsert->process(dataMap, m_taskInfo_.id);
    }
}

} // namespace _Controllers
