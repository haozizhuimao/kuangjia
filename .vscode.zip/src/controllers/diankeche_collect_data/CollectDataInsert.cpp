#include "CollectDataInsert.h"
#include <chrono>
#include <string>
#include <unordered_map>
#include <utility>
#include "kits/utility/datetime/datetime.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <thread>

namespace _Controllers {

CollectDataInsert::CollectDataInsert(const _Kits::database::DbClientPtr &pgcollectClient)
{
    m_collectData = std::make_shared<_Kits::database::PgCollectData>(pgcollectClient);
    
    mv_collectData.vol = 8000.0;
    mv_collectData.cur = 8000.0;
    mv_collectData.cba = 8000.0;
    mv_collectData.tem = 8000.0;
    mv_collectData.hum = 8000.0;

    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    asio::co_spawn(io_timer, [this]() -> _Kits::AwaitTask<void> { co_await processData(); }, asio::detached);
}
CollectDataInsert::~CollectDataInsert()
{
    m_stopRequested_.store(true);
}
void CollectDataInsert::get_value(const std::unordered_map<std::string, float> &data, const std::string &key, float &val)
{
    auto it = data.find(key);
    if (it != data.end())
    {
        double d_val = static_cast<double>(it->second);
        // 只有当值不是无效值 8000.0 时才更新
        if (d_val != 8000.0)
        {
            val = d_val;
        }
    }
}

void CollectDataInsert::collectionEnable(bool isEnabled)
{
    m_started.store(isEnabled);
}

void CollectDataInsert::process(const std::unordered_map<std::string, float> &data, int task_id)
{
    auto now = std::chrono::system_clock::now();

    {
        std::lock_guard<std::mutex> lg(mtxCollect_);

        get_value(data, "voltage", mv_collectData.vol);
        get_value(data, "electric", mv_collectData.cur);
        get_value(data, "cba", mv_collectData.cba);

        get_value(data, "temperature", mv_collectData.tem);
        get_value(data, "humidity", mv_collectData.hum);

        mv_collectData.task_id = task_id;
        mv_collectData.updated_time = now;
        mv_collectData.created_time = now;
    }
}

void CollectDataInsert::stopProcess()
{
    m_stopRequested_.store(true);
}

void CollectDataInsert::insert(TIS_Info::collect_data &&data)
{
    m_collectData->insert(std::move(data));
}

_Kits::AwaitTask<void> CollectDataInsert::processData()
{
    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);

    while (!m_stopRequested_.load())
    {
        if (m_started.load())
        {
            TIS_Info::collect_data collect;

            {
                std::lock_guard<std::mutex> lk(mtxCollect_);
                // 拷贝当前最新的缓存快照
                collect = mv_collectData;
            }
            insert(std::move(collect));
        }

        asio::steady_timer timer(io_timer, std::chrono::milliseconds(SLEEP_TIME_MS));
        co_await timer.async_wait(asio::use_awaitable);
    }
}

} // namespace _Controllers
