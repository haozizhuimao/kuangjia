#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/database/sqlite3_interface/SqliteCollect.h"
#include "tis_global/struct_details/sql_struct.h"
#include "CollectDataInsert.h"
#include <atomic>
#include <memory>
#include <shared_mutex>

namespace _Controllers {
class CollectDataCtrl : public ControllerBase<CollectDataCtrl>
{
  public:
    void onStart();
    void onStop();
    void onRecvTaskInfo(const TIS_Info::task_data &taskInfo);
    void onRecvTemperatureHumidityData(const TIS_Info::TemperatureHumidity &);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, CollectDataCtrl::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, CollectDataCtrl::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, CollectDataCtrl::onRecvTaskInfo);
    ASYNC_TASK_ADD(_Service::TemperatureHumidityService::sendTemperatureHumidity, CollectDataCtrl::onRecvTemperatureHumidityData);
    ASYNC_TASK_ADD(_Service::MVBCommunication::sendMVBComInfo, CollectDataCtrl::recvMVBInfo);
    TASK_LIST_END
  private:

    std::atomic_bool bInTask_;
    TIS_Info::task_data m_taskInfo_;
    mutable std::shared_mutex mtxCollect_;
    //std::shared_ptr<_Kits::database::SqliteCollect> sqliteCollector_;
    std::unique_ptr<CollectDataInsert> m_devCollectDataInsert;
};
} // namespace _Controllers