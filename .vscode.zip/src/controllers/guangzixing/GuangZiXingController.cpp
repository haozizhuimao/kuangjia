﻿#include "GuangZiXingController.h"
#include <vector>
#include <cstdint>
#include <bit>
#include <array>
#include "kits/database/postgresql_interface/PgPressureData.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"

namespace _Controllers {
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
void GuangZiXingController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        m_pressureSql = std::make_shared<database::PgPressureData>(pgClientPtr);
    }
    const std::string &client_title = "guangzixing";
    auto clientPtr = _Service::TcpClientCenter::getClient<std::shared_ptr<_Kits::TcpSession>>(client_title);
    m_bRecvData.store(true, std::memory_order_release);
    if (clientPtr == nullptr)
    {
        _Kits::LogError("[光子行] 客户端={}, 获取会话失败",client_title);
        // return;
    }
    else
    {
        clientPtr->start();
        _Kits::LogInfo("[光子行] 客户端={}, 获取会话成功", client_title);
        if (!m_bTcpSubscribed.exchange(true, std::memory_order_acq_rel))
        {
            clientPtr->subscribe([this](TcpSession::SharedDataBuffer payload) {
                if (!payload || !m_bRecvData.load(std::memory_order_acquire) || !m_bInTask.load(std::memory_order_acquire))
                {
                    return;
                }
                auto rawData =
                    std::make_shared<TIS_Info::RawData>(std::vector<uint8_t>(payload->begin(), payload->end()),
                                                        _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds));
                std::lock_guard lg(mtxRaw_);
                m_pressrawQueue.push_back(std::move(rawData));
            });
        }
    }
    m_tcpClient = clientPtr;
    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    asio::co_spawn(io_timer, [this]() -> AwaitTask<void> { co_await processData(); }, asio::detached);

}
void GuangZiXingController::onStop() {}
void GuangZiXingController::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    if (static_cast<int>(TIS_Info::TaskState::TASK_NONE) != taskInfo.task_state ||
        static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) != taskInfo.task_state)
    {
        m_taskID.store(taskInfo.id);
        m_bInTask.store(true, std::memory_order_release);
    }
    else if (static_cast<int>(TIS_Info::TaskState::TASK_STOPPED) == taskInfo.task_state)
    {
        m_taskID.store(-1);
        m_bInTask.store(false, std::memory_order_release);
    }
}

void GuangZiXingController::dealData(const std::vector<uint8_t> &data, int64_t timestamp)
{
    if (m_taskID.load(std::memory_order_acquire) < 0)
    {
        return;
    }
    m_buffer.insert(m_buffer.end(), data.begin(), data.end());
    static const size_t PACKET_SIZE = 12;
    

    auto iPackLength = m_buffer.size();
    while(iPackLength >= PACKET_SIZE)
    {
        TIS_Info::PressureData pressData;
        parsePressData(data,  pressData);
        savePressDataToDb(pressData);
        _Service::BaianPressureService::sendPressSpotOut(pressData);
        iPackLength -= PACKET_SIZE;
        m_buffer.erase(m_buffer.begin(), m_buffer.begin() + PACKET_SIZE);
    }
    return;
}

void GuangZiXingController::parsePressData(const std::vector<uint8_t> &data,TIS_Info::PressureData &pressureData)
{

    auto hearttime = _Kits::ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    auto result = _Kits::ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    int16_t HorizontalAcc = static_cast<int16_t>(result);

    auto value = HorizontalAcc * 1.0 / 100 ;
    pressureData.fHorizontalAcc.at(0) =  (value > 8000 ||value <= -8000) ? 8000 : value;

    result = _Kits::ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    int16_t ForwardAcc = static_cast<int16_t>(result);
    value = ForwardAcc * 1.0 / 100;
    pressureData.ForwardAcc.at(0) = (value > 8000 ||value <= -8000) ? 8000 : value ;

    result = _Kits::ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    value = result * 1.0 / 100;
    pressureData.fPress.at(0) = (value > 8000 ||value <= -8000) ? 8000 : value ;
    
    result = _Kits::ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
    value =  result * 1.0 / 100;
    pressureData.fPress.at(1) = (value > 8000 ||value <= -8000) ? 8000 : value;

}

void GuangZiXingController::packageSendData(std::vector<uint8_t> &data, const TIS_Info::LocationData &locationData, const TIS_Info::MVBCommunicationInfo &mvbInfo,const int liveCount)
{
    packageHeader(data,liveCount);

    //行驶方向
    data.at(14) = mvbInfo.nLineDirection;
    //升降弓状态
    data.at(15) = mvbInfo.mp1PanStatus;

    //开关门状态
    data.at(32) = mvbInfo.doorStatus;
    
    //速度
    std::vector<uint8_t> speedbytes(sizeof(uint64_t));
    int64_t ispeep = mvbInfo.dSpeed * 100;
    std::memcpy(speedbytes.data(), &ispeep, sizeof(uint64_t));
    if constexpr (std::endian::native == std::endian::little)
    {
        std::reverse(speedbytes.begin(), speedbytes.end());
    }
    std::copy(speedbytes.begin(), speedbytes.end(), data.begin() + 16);
    //公里标
    std::vector<uint8_t> milagebytes(sizeof(uint64_t));
    std::memcpy(milagebytes.data(), &locationData.mileage_normal, sizeof(uint64_t));
    if constexpr (std::endian::native == std::endian::little)
    {
        std::reverse(milagebytes.begin(), milagebytes.end());
    }
    std::copy(milagebytes.begin(), milagebytes.end(), data.begin() + 24);

    auto result = crc16_ccitt(data, 62);
    //uint16_t result = 0;
    ByteArrayTools::writeToVectorBE<uint16_t>(data, result,62);

}
void GuangZiXingController::savePressDataToDb(const TIS_Info::PressureData &pressureData)
{
    TIS_Info::press_data pressData;

    pressData.acc0_x = pressureData.fHorizontalAcc.at(0);
    pressData.acc0_y = pressureData.ForwardAcc.at(0);
    pressData.press0 = pressureData.fPress.at(0);
    pressData.press1 = pressureData.fPress.at(1);
    pressData.press2 = pressureData.fPress.at(2);
    pressData.press3 = pressureData.fPress.at(3);
    pressData.task_id = m_taskID.load(std::memory_order_acquire);

    pressData.press4 = pressureData.fPress.at(4);
    pressData.press5 = pressureData.fPress.at(5);
    pressData.press6 = pressureData.fPress.at(6);
    pressData.press7 = pressureData.fPress.at(7);

    pressData.acc0_z = pressureData.VeticalAcc.at(0);
    pressData.acc1_x = pressureData.fHorizontalAcc.at(1);
    pressData.acc1_y = pressureData.ForwardAcc.at(1);
    pressData.acc1_z = pressureData.VeticalAcc.at(1);

    pressData.created_time = std::chrono::system_clock::now();
    pressData.updated_time = std::chrono::system_clock::now();

    std::lock_guard<std::mutex> lock(m_mutexPressData);
    if (m_pressureSql)
    {
        m_pressureSql->insert(std::move(pressData));
    }
}
void GuangZiXingController::recvGetLocation(const TIS_Info::LocationData &data)
{
    m_locationData = data;
}
void GuangZiXingController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    m_mvbInfo = data;
    
    std::vector<uint8_t> senddata;
    senddata.resize(64);
    packageSendData(senddata, m_locationData, m_mvbInfo, m_liveCount++);
    sendData(senddata);
}
void GuangZiXingController::sendData(std::vector<uint8_t>& data)
{
    auto client = m_tcpClient.lock();
    if (m_bInTask.load(std::memory_order_acquire))
    {
        if (client)
        {
             client->post(data);
        }
    }
}

std::shared_ptr<TIS_Info::RawData> GuangZiXingController::popRawData()
{
    std::lock_guard lg(mtxRaw_);
    if (!m_pressrawQueue.empty())
    {
        auto ret = m_pressrawQueue.front();
        m_pressrawQueue.pop_front();
        return ret;
    }

    return std::shared_ptr<TIS_Info::RawData>{};
}
AwaitTask<void> GuangZiXingController::processData()
{
    asio::steady_timer timer(co_await asio::this_coro::executor);
    int64_t last_collect_time = 0;

    while (m_bRecvData.load(std::memory_order_acquire))
    {
        //timer.expires_after(std::chrono::milliseconds(m_logInfo.time_interval));
        timer.expires_after(std::chrono::milliseconds(20));
        co_await timer.async_wait(asio::use_awaitable);
        auto client = m_tcpClient.lock();

        if (m_bRecvData.load(std::memory_order_acquire) && m_bInTask.load(std::memory_order_acquire))
        {
            if (client)
            {
                auto rawData = popRawData();
                if (rawData)
                {
                    dealData(rawData->data, rawData->timestamp);
                }
            }
        }
    }
}

void GuangZiXingController::packageHeader(std::vector<uint8_t> &data,const int liveCount)
{
    data.at(0) = 0xFF;
    data.at(1) = 0x66;
    ByteArrayTools::writeToVectorBE<uint16_t>(data,liveCount,2);
    auto timestamp_ms = datetime::current_timestamp(datetime::TimestampUnit::Milliseconds);
    uint32_t timestamp = timestamp_ms / 1000;
    uint16_t milliseconds = timestamp_ms % 1000;
    ByteArrayTools::writeToVectorBE<uint32_t>(data, timestamp,4);
    ByteArrayTools::writeToVectorBE<uint16_t>(data, milliseconds,8);
    ByteArrayTools::writeToVectorBE<uint16_t>(data, 48, 10);

}

uint16_t GuangZiXingController::crc16_ccitt(const std::vector<uint8_t> &data, int blockLength)
{
    uint16_t crc = 0xffff;
    for (int i = 0; i < blockLength; ++i)
    {
        uint16_t tmp = (crc >> 8) ^ (uint16_t)data[i];
        crc = ((uint16_t)(crc << 8U)) ^ crc16_ccitt_table[tmp];
    }
    return crc;
}

} // namespace _Controllers
