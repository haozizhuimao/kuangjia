#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <cstdint>
#include <optional>
#include <json/json.h>

namespace _Controllers
{

 

    class MvbProtocolTool
    {
    public:
        static std::unordered_map<std::string, Json::Value> loadProtocolDef(const std::string& csvPath) ;
        static uint8_t readUint8(const std::vector<uint8_t>& data, size_t offset);
        static uint16_t readUint16BE(const std::vector<uint8_t>& data, size_t offset);
        static uint32_t readUint32BE(const std::vector<uint8_t>& data, size_t offset);
        static std::string getNameValue(const std::string& name,const Json::Value& json);
    private:
        static std::unordered_map<std::string, Json::Value> readFile(const std::string& csvPath);
        static std::optional<size_t> parseOffset(const std::string& s);
        static std::optional<uint8_t> parseBitIndex(const std::string& s);
    };
    
    

}