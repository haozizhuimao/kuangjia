#include "MvbProtocolTool.h"
#include "kits/utility/log/CRossLogger.h"
//#include "kits/utility/excel_writer/ExcelWriter.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <charconv>
#include <string>
#include <json/json.h>

namespace _Controllers
{ 
    std::optional<size_t> MvbProtocolTool::parseOffset(const std::string& s) 
    {
        if (s.empty()) return std::nullopt;
        size_t val;
        auto [ptr, ec] = std::from_chars(s.data(), s.data() + s.size(), val);
        if (ec == std::errc()) return val;
        return std::nullopt;
    }

    std::optional<uint8_t> MvbProtocolTool::parseBitIndex(const std::string& s)
    {
        if (s.empty()) return std::nullopt;
        unsigned val;
        auto [ptr, ec] = std::from_chars(s.data(), s.data() + s.size(), val);
        if (ec == std::errc() && val <= 7) return static_cast<uint8_t>(val);
        return std::nullopt;
    }
    std::unordered_map<std::string, Json::Value>  MvbProtocolTool::loadProtocolDef(const std::string& csvPath) 
    {
        return readFile(csvPath);
    }
    std::unordered_map<std::string, Json::Value>MvbProtocolTool::readFile(const std::string& csvPath)
    {
        
        std::unordered_map<std::string, Json::Value> groupMap;  
        if(csvPath.empty())
        {
            return groupMap;
        }
        std::ifstream file(csvPath);
        if (!file.is_open())
        {
            return groupMap;
        }
        std::string line;
        bool firstLine = true;
        while (std::getline(file, line)) {
            if (firstLine) { firstLine = false; continue; } // 跳过表头

            // 按逗号分割（注意：CSV 中字段不含逗号）
            std::stringstream ss(line);
            std::string proto, name, type, offsetStr, bitIndexStr, rawValue, remark;
            std::getline(ss, proto, ',');
            std::getline(ss, name, ',');
            std::getline(ss, type, ',');
            std::getline(ss, offsetStr, ',');
            std::getline(ss, bitIndexStr, ',');
            std::getline(ss, rawValue, ',');
            std::getline(ss, remark, ',');

            // 解析 offset
            size_t offset = std::stoul(offsetStr);

           // 构建一个字段的 JSON 对象
            Json::Value field;
            field["FieldName"] = name;
            field["Type"] = type;
            field["Offset"] = static_cast<Json::UInt64>(offset);
 
            // BitIndex
            if (type == "bit") {
                if (bitIndexStr.empty()) {
                    continue;   // 无效，跳过
                }
                int bitIdx = std::stoi(bitIndexStr);
                field["BitIndex"] = bitIdx;
            } else {
                field["BitIndex"] = Json::nullValue;
            }

            // Default：根据内容智能转换
            field["Default"] = rawValue;

            // Remark：空字符串输出空字符串（示例中为 ""），非空原样输出
            field["Remark"] = remark.empty() ? Json::Value("") : Json::Value(remark);
            // 将当前字段添加到对应协议组
            auto it = groupMap.find(proto);
            if (it == groupMap.end()) {
                groupMap[proto] = Json::arrayValue;   // 新建数组
            } else if (!it->second.isArray()) {
                it->second = Json::arrayValue;        // 覆盖为非数组的情况（防御）
            }
            groupMap[proto].append(field);
        }
        file.close();
        return groupMap;
    }
    uint8_t MvbProtocolTool::readUint8(const std::vector<uint8_t>& data, size_t offset) {
        if (offset >= data.size()) {
            throw std::out_of_range("readUint8: offset out of range");
        }
        return data[offset];
    }

    uint16_t MvbProtocolTool::readUint16BE(const std::vector<uint8_t>& data, size_t offset) {
        if (offset + 1 >= data.size()) {
            throw std::out_of_range("readUint16BE: offset out of range");
        }
        return (static_cast<uint16_t>(data[offset]) << 8) |
                static_cast<uint16_t>(data[offset + 1]);
    }
    uint32_t MvbProtocolTool::readUint32BE(const std::vector<uint8_t>& data, size_t offset)
    {
        if (offset + 3 >= data.size()) {
            throw std::out_of_range("readUint32BE: offset out of range");
        }
        return  (static_cast<uint32_t>(data[offset])     << 24) |
                (static_cast<uint32_t>(data[offset + 1]) << 16) |
                (static_cast<uint32_t>(data[offset + 2]) << 8)  |
                static_cast<uint32_t>(data[offset + 3]);
    }

    std::string MvbProtocolTool::getNameValue(const std::string& name,const Json::Value& json)
    {
        std::string value = "";
        for (const auto& item : json) {
            if (!item.isObject()) continue;
            // 检查 FieldName 字段是否存在且等于 "comId"
            if (item.isMember("FieldName") && item["FieldName"].asString() == name) {
                // 读取 Default 字段，可能有多种类型，但 comId 的是数字
                if (item.isMember("Default")) {
                    value = item["Default"].asString();
                }
                break; // 找到即可退出
            }
        }
        return value;
    }

}