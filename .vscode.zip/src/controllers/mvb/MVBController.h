#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>
#include "tis_global/struct_details/sql_struct.h"
#include "tis_global/struct_details/mvb_struct.h"
#include "kits/database/postgresql_interface/PgMvbInfoSql.h"
#include <vector>
#include <thread>
#include <condition_variable>
#include <json/value.h>
#include "MvbProtocolTool.h"

// #include <QVariantMap>
namespace _Kits {
class UdpClient;
}

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;

    void onStart();
    void setConfigSwitch(const TIS_Info::MVBConfig &, const std::string &protocolPath);
    void onRecvSimuteMvbData(const Json::Value &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, MVBController::onStart);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::MVBSimluteHeartData, MVBController::onRecvSimuteMvbData);
    TASK_LIST_END

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&);
    void sendTcmsData(const Json::Value &);
    void onUdpAlarmReceived(const std::vector<uint8_t> &&);

  private:
    void heartFunc();
    void sendAliveData();
    // 解析公共数据
    void displayRecvPortData(Json::Value &);
    ;
    // 解析告警数据
    void parseAmifData(const Json::Value &);
    // 解析故障数据
    void parseAsatData(const Json::Value &);
    void setAmifAlarm(const int, const int, const int, const int, const int);
    void setAsatStatus(const int, const int, const int);

    void updateCommonInfo(Json::Value &);
    void updateCCUDataInfo(Json::Value &);

    void parseTCMSData(const std::vector<uint8_t> &data, Json::Value &outputData);
    void packageData(const Json::Value &inputData, std::vector<uint8_t> &outputData, uint32_t rawval);
    void writeheaderFcs(const int offset,const int type);


    void getHeaderFscInfo(Json::Value &jsondata,int &offset,int &type,int &fcsindex);
    void writeHeaderData(Json::Value &jsondata, Json::Value &outputData);

  private:
    std::atomic_bool m_bHolder = true;
    const std::string m_heartUdpName = "mvb_heart_B";
    const std::string m_udpName = "mvb";
    const std::string m_mvbAmifName = "mvb_amif";
    std::shared_ptr<_Kits::UdpClient> m_heartUdpClient;
    std::vector<uint8_t> m_recvData;
    std::vector<uint8_t> m_heartData;

    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    int m_headLength = 0;   // trdp协议头长度

    int m_startStation = -1;
    int m_endStation = -1;
    int m_lineDir = -1;
    float m_speed = 0;

    std::vector<TIS_Info::mvb_info> m_mvbInfoSqlvec;
    TIS_Info::mvb_info m_CurrentMvbInfo;
    std::atomic_int16_t m_CurrentMvbInfoStatus{0};
    std::mutex m_mutex;
    std::atomic_bool m_writeDBFlag = false;

    TIS_Info::MVBConfig m_mvbConfig;

    std::shared_ptr<_Kits::database::PgMvbInfoSql> m_pgMvbInfoSql;
    std::unordered_map<std::string, Json::Value> m_mapProtocol;
    std::string m_protocolPath{""};
};
} // namespace _Controllers
