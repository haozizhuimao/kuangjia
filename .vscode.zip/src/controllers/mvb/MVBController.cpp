﻿#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "tis_global/enum_public/uc_enum.h"
#include "kits/utility/datetime/datetime.h"
#include <regex>
#include <charconv>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_heartData.resize(m_headLength + 40, 0);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}

MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
}

void MVBController::onStart()
{
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    if (pgClientPtr)
    {
        m_pgMvbInfoSql = std::make_shared<database::PgMvbInfoSql>(pgClientPtr);
    }
    // MVB tcms数据接收
    auto udpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_udpName);

    if (udpClient == nullptr)
    {
        _Kits::LogError("[MVBController] 客户端={}, 获取UDP会话失败", m_udpName);
        return;
    }

    udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) {
        if (!data)
        {
            return;
        }
        onUdpDataReceived(std::vector<uint8_t>(data->begin(), data->end()));
    });

    // MVB告警数据接收
    auto alarmUdpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_mvbAmifName);
    if (alarmUdpClient == nullptr)
    {
        _Kits::LogError("[MVBController] 客户端={}, 获取UDP会话失败", m_mvbAmifName);
        return;
    }
    alarmUdpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) {
        if (!data)
        {
            return;
        }
        onUdpAlarmReceived(std::vector<uint8_t>(data->begin(), data->end()));
    });

    // 心跳数据发送
    auto heartUdpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_heartUdpName);
    m_heartUdpClient = heartUdpClient;

    m_mapProtocol = MvbProtocolTool::loadProtocolDef(m_protocolPath);
}

void MVBController::displayRecvPortData(Json::Value &portData)
{
    // 给页面传递数据展示
    // auto timeFmt =  _Kits::datetime::current_string("%Y-%m-%d %H:%M:%S.%3f");
    // portData["recvTime"] = timeFmt;

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

void MVBController::onUdpAlarmReceived(const std::vector<uint8_t> &&data)
{
    auto alarmData = std::move(data);
    std::string jsonStr(reinterpret_cast<const char *>(alarmData.data()), alarmData.size());
    Json::Value jsonValue = stringToJson(jsonStr);
    if (jsonValue["msgType"].asString() == "amif")
    {
        parseAmifData(jsonValue["data"]);
    }
    LogInfo("[MVBController] 接收告警Json数据={}", jsonStr);
}

void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConf, const std::string &protocolPath)
{
    m_mvbConfig = std::move(mvbConf);
    m_protocolPath = protocolPath;
    // m_version = getConfVersion(m_mvbConfig.mvbPublicCfg.version);
}

void MVBController::parseAsatData(const Json::Value &jsonObj)
{
    TIS_Info::AsatModuleType_GuiYang moduleType = static_cast<TIS_Info::AsatModuleType_GuiYang>(jsonObj["moduleType"].asInt());
    int moduleStatus = jsonObj["moduleState"].asInt();

    switch (moduleType)
    {
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_PantoMod: {
        // 设备状态
        setAsatStatus(m_headLength + 5, 1, m_mvbConfig.asatCfg.pantoMode);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAsatStatus(const int offset, const int targetBit, const int moduleState)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    // 设置目标位模块状态
    std::bitset<8> asatBit = m_heartData.at(offset);
    asatBit.set(targetBit, moduleState);
    m_heartData.at(offset) = static_cast<uint8_t>(asatBit.to_ulong());
}

void MVBController::parseAmifData(const Json::Value &jsonObj)
{
    TIS_Info::AmifAlarmType amifType = static_cast<TIS_Info::AmifAlarmType>(jsonObj["alarmType"].asInt());
    TIS_Info::AmifAlarmLevel amifLevel = static_cast<TIS_Info::AmifAlarmLevel>(jsonObj["alarmLevel"].asInt());
    int alarmValue = jsonObj["alarmValue"].asInt();
    // int targetOffset = amifLevel - 1; // 目标位偏移

    switch (amifType)
    {
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanAttitude: {
        // 受电弓严重故障
        setAmifAlarm(m_headLength + 5, 2, 2, 2, alarmValue);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    std::bitset<8> amifBit = m_heartData.at(offset);
    // 该类型超限所有的状态复位
    for (int i = startBit; i <= endBit; i++)
    {
        amifBit.set(i, 0);
    }
    // 设置目标位超限值
    amifBit.set(targetBit, alarmValue);
    m_heartData.at(offset) = static_cast<uint8_t>(amifBit.to_ulong());
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        LogError("[MVBController] UDP接收长度错误，长度={}", data.size());
        return;
    }
    Json::Value protocoltrdpheader = m_mapProtocol["trdpheader"];
    parseTCMSData(data, protocoltrdpheader);

    auto valueret = MvbProtocolTool::getNameValue("comId", protocoltrdpheader);
    uint32_t comId = std::stoi(valueret);
    std::vector<uint8_t> processData(data.begin(), data.end());
    if (comId == m_mvbConfig.netPortCfg.commonPortNetB)
    {
        Json::Value jsonValue = m_mapProtocol["commondata"];
        parseTCMSData(data, jsonValue);
        sendTcmsData(jsonValue);
        updateCommonInfo(jsonValue);
        Json::Value commontData;
        commontData["dataSource"] = jsonValue;
        displayRecvPortData(commontData);
    }
    else if (comId == m_mvbConfig.netPortCfg.tcmsPortNetB)
    {
        Json::Value jsonValue = m_mapProtocol["ccudata"];
        parseTCMSData(data, jsonValue);
        updateCCUDataInfo(jsonValue);
        Json::Value ccutData;
        ccutData["dataSource"] = jsonValue;
        ccutData["ccu_data"] = 1;
        displayRecvPortData(ccutData);
    }
    else
    {
        LogError("comId error, comId ={} commoncomid = {} tcmscommonId = {}",
                 comId,
                 m_mvbConfig.netPortCfg.commonPortNetB,
                 m_mvbConfig.netPortCfg.tcmsPortNetB);
    }
}

void MVBController::sendTcmsData(const Json::Value &recvData)
{
    int curStartStation = std::stoi(MvbProtocolTool::getNameValue("startStation", recvData)); // recvData["startStation"].asInt();
    int curEndStation = std::stoi(MvbProtocolTool::getNameValue("endStation", recvData));     // recvData["endStation"].asInt();
    // 行别切换

    TIS_Info::MVBCommunicationInfo mvbCommInfo;
    mvbCommInfo.startStation = curStartStation;
    mvbCommInfo.endStation = curEndStation;
    mvbCommInfo.currentStationId =
        std::stoi(MvbProtocolTool::getNameValue("currentStation", recvData)); // recvData["currentStation"].asInt();
    mvbCommInfo.strLineName = m_mvbConfig.mvbPublicCfg.lineName;
    mvbCommInfo.dSpeed =
        std::stod(MvbProtocolTool::getNameValue("trainSpeed", recvData)) / 100.0; // recvData["trainSpeed"].asDouble() / 100;

    // LogInfo("行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
    //         m_lineDir,
    //         m_startStation,
    //         m_endStation,
    //         mvbCommInfo.currentStationId,
    //         mvbCommInfo.dSpeed);
    if (m_startStation != curStartStation && m_endStation != curEndStation && curStartStation != 0 && curEndStation != 0)
    {
        m_lineDir = curStartStation < curEndStation ? 0 : 1;
        m_startStation = curStartStation;
        m_endStation = curEndStation;
        LogInfo("[MVBController] 行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
                m_lineDir,
                m_startStation,
                m_endStation,
                mvbCommInfo.currentStationId,
                mvbCommInfo.dSpeed);
    }
    mvbCommInfo.nLineDirection = m_lineDir;
    mvbCommInfo.nDirection = 0;
    mvbCommInfo.strTrainNum = MvbProtocolTool::getNameValue("trainNum", recvData);
    _Service::MVBCommunication::sendMVBComInfo(mvbCommInfo);
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(1000);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::sendAliveData()
{
    if (nullptr != m_heartUdpClient)
    {
        ++m_aliveId; // 心跳id自增

        int headerFcsoffset = 0;
        int fcstype = 0;
        int headerFcsindex = -1;
        auto jsonValue = m_mapProtocol["trdpheader"];
        getHeaderFscInfo(jsonValue, headerFcsoffset, fcstype, headerFcsindex);
        if (-1 != headerFcsindex)
        {
            Json::Value jsonheader;
            jsonValue.removeIndex(headerFcsindex, &jsonheader);
        }
        Json::Value outjsonValue;
        writeHeaderData(jsonValue, outjsonValue);

        auto headJsonvalue = m_mapProtocol["heartData"];
        writeHeaderData(headJsonvalue, outjsonValue);

        writeheaderFcs(headerFcsoffset, fcstype);

        auto headvector = m_heartData;
        m_heartUdpClient->post("mvb_heart", std::move(headvector));
        std::vector<uint8_t> processData(m_heartData.begin(), m_heartData.end());
        LogInfo("[MVBController] 发送心跳数据 ={}", ByteArrayTools::hexString(processData.data(), processData.size()));

        Json::Value heartData;
        heartData["dataSource"] = outjsonValue;
        heartData["heart"] = 1;
        displayRecvPortData(heartData);
    }
}

void MVBController::onRecvSimuteMvbData(const Json::Value &simulateHeart)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto &item : m_mapProtocol["heartData"])
    {
        std::string defalutval = item["Default"].asString();
        auto simulaterVal = MvbProtocolTool::getNameValue(item["FieldName"].asString(), simulateHeart);
        if (item["FieldName"].asString() == "sequenceCounter")
        {
            continue;
        }
        if (defalutval != simulaterVal)
        {
            item["Default"] = simulaterVal;
        }
    }
}
void MVBController::updateCommonInfo(Json::Value &data)
{
    m_CurrentMvbInfo.cur_station_id = std::stoi(MvbProtocolTool::getNameValue("currentStation", data)); // data["currentStation"].asInt();
    m_CurrentMvbInfo.next_station_id = std::stoi(MvbProtocolTool::getNameValue("nextStation", data));   // data["nextStation"].asInt();
    m_CurrentMvbInfo.start_station_id = std::stoi(MvbProtocolTool::getNameValue("startStation", data)); // data["startStation"].asInt();
    m_CurrentMvbInfo.end_station_id = std::stoi(MvbProtocolTool::getNameValue("endStation", data));     // data["endStation"].asInt();
    m_CurrentMvbInfo.line_id = -1;
    m_CurrentMvbInfo.train_id = std::stoi(MvbProtocolTool::getNameValue("trainNum", data)); // data["trainNum"].asInt();
    m_CurrentMvbInfo.iyear = std::stoi(MvbProtocolTool::getNameValue("year", data));        // data["year"].asInt();
    m_CurrentMvbInfo.imonth = std::stoi(MvbProtocolTool::getNameValue("month", data));      // data["month"].asInt();
    m_CurrentMvbInfo.iday = std::stoi(MvbProtocolTool::getNameValue("day", data));          // data["day"].asInt();
    m_CurrentMvbInfo.ihour = std::stoi(MvbProtocolTool::getNameValue("hour", data));        // data["hour"].asInt();
    m_CurrentMvbInfo.iminute = std::stoi(MvbProtocolTool::getNameValue("minute", data));    // data["minute"].asInt();
    m_CurrentMvbInfo.isecond = std::stoi(MvbProtocolTool::getNameValue("second", data));    // data["second"].asInt();
    m_CurrentMvbInfo.speed = std::stof(MvbProtocolTool::getNameValue("trainSpeed", data));  // data["trainSpeed"].asFloat();
    // m_CurrentMvbInfo.voltage = data["voltage").toFloat();
    // m_CurrentMvbInfo.elec = data["electricity").toFloat();
    // m_CurrentMvbInfo.atb_mode = data["ATBMode").toInt();
    if (0 == m_CurrentMvbInfoStatus)
    {
        m_CurrentMvbInfoStatus = 1;
    }
    else if (2 == m_CurrentMvbInfoStatus)
    {
        if (nullptr != m_pgMvbInfoSql)
        {
            m_pgMvbInfoSql->insert(m_CurrentMvbInfo);
        }
        m_CurrentMvbInfoStatus = 0;
    }
}
void MVBController::updateCCUDataInfo(Json::Value &data)
{
    m_CurrentMvbInfo.battery_status = -1;
    m_CurrentMvbInfo.door_state = std::stof(MvbProtocolTool::getNameValue("doorCls", data)); // data["doorCls"].asInt();
    m_CurrentMvbInfo.panto_up = std::stof(MvbProtocolTool::getNameValue("pan2Up", data));    // data["pan2Up"].asInt();
    if (0 == m_CurrentMvbInfoStatus)
    {
        m_CurrentMvbInfoStatus = 2;
    }
    else if (1 == m_CurrentMvbInfoStatus)
    {
        if (nullptr != m_pgMvbInfoSql)
        {
            m_pgMvbInfoSql->insert(m_CurrentMvbInfo);
        }
        m_CurrentMvbInfoStatus = 0;
    }
}
void MVBController::parseTCMSData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    if (data.size() == 0)
    {
        return;
    }

    for (auto &item : outputData)
    {

        std::string type = item["Type"].asString();
        size_t offset = item["Offset"].asUInt64();
        // LogInfo("MVBController::parseTCMSData FieldName:{} type: {}, offset: {}", item["FieldName"].asString(), type, offset);
        if (type == "uint8")
        {
            uint8_t value = MvbProtocolTool::readUint8(data, offset);
            item["Default"] = static_cast<int>(value); // Json::Value 存储数值
        }
        else if (type == "uint16")
        {
            uint16_t value = MvbProtocolTool::readUint16BE(data, offset);
            item["Default"] = static_cast<int>(value);
        }
        else if (type == "uint32")
        {
            uint32_t value = MvbProtocolTool::readUint32BE(data, offset);
            item["Default"] = static_cast<int>(value);
        }
        else if (type == "bit")
        {
            // 读取一个字节
            int bitIndex = item["BitIndex"].asInt();
            uint8_t byte = MvbProtocolTool::readUint8(data, offset);
            // 遍历每个位域，分别填充 outputData
            bool bitValue = (byte >> bitIndex) & 0x01;
            item["Default"] = bitValue ? "1" : "0";
        }
        else
        {
            // 未知类型，忽略或抛出异常
            // 可根据需要添加日志
        }
    }
}

void MVBController::packageData(const Json::Value &inputData, std::vector<uint8_t> &outputData, uint32_t rawval)
{
    if (inputData["Type"].asString() == "uint8")
    {
        uint8_t val = static_cast<uint8_t>(rawval);
        ByteArrayTools::writeToVectorBE<uint8_t>(outputData, val, inputData["Offset"].asInt());
    }
    else if (inputData["Type"].asString() == "uint16")
    {
        uint16_t val = static_cast<uint16_t>(rawval);
        ByteArrayTools::writeToVectorBE<uint16_t>(outputData, val, inputData["Offset"].asInt());
    }
    else if (inputData["Type"].asString() == "uint32")
    {
        uint32_t val = rawval;
        ByteArrayTools::writeToVectorBE<uint32_t>(outputData, val, inputData["Offset"].asInt());
    }
    else if (inputData["Type"].asString() == "bit")
    {
        bool val = rawval != 0 ? true : false;
        ByteArrayTools::setBitInVectorLSB(
            outputData, inputData["Offset"].asInt(), static_cast<uint8_t>(inputData["BitIndex"].asInt()), val);
    }
}

void MVBController::writeheaderFcs(const int offset, const int type)
{
    if (1 == type)
    {
        auto headerFcs = ByteArrayTools::getTrdpHeaderChecksumuint16(m_heartData, offset);
        LogInfo("headerFcs ={} tcstype = {}", headerFcs, type);

        ByteArrayTools::writeToVectorLE<uint16_t>(m_heartData, headerFcs, offset);
    }
    else
    {
        // 生成校验码
        auto headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, offset);
        LogInfo("headerFcs={} tcstype = {}", headerFcs, type);

        ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, headerFcs, offset);
    }
}

void MVBController::getHeaderFscInfo(Json::Value &jsondata, int &offset, int &type, int &fcsindex)
{
    static bool isfirst = true;
    static int headerFcsoffset = -1;
    static int fcstype = -1;
    static int headerFcsindex = -1;
    if (!isfirst)
    {
        offset = headerFcsoffset;
        type = fcstype;
        fcsindex = headerFcsindex;
        return;
    }
    int index = 0;
    for (auto &item : jsondata)
    {
        std::string defalutval = item["Default"].asString();
        if (item["FieldName"].asString() == "headerFcs")
        {
            headerFcsoffset = item["Offset"].asInt();
            if (!defalutval.empty())
            {
                fcstype = std::stoi(defalutval);
            }
            headerFcsindex = index;
            break;
        }
        index++;
    }
    offset = headerFcsoffset;
    type = fcstype;
    fcsindex = headerFcsindex;
    isfirst = false;
    return;
}

void MVBController::writeHeaderData(Json::Value &jsondata, Json::Value &outputData)
{
    for (auto &item : jsondata)
    {
        std::string defalutval = item["Default"].asString();
        uint32_t rawval = 0;
        if (!defalutval.empty())
        {
            auto valuetype = defalutval.size() >= 2 && defalutval[0] == '0' && (defalutval[1] == 'x' || defalutval[1] == 'X');
            rawval = std::stoul(defalutval, nullptr, valuetype ? 16 : 10);
        }

        if (item["FieldName"].asString() == "sequenceCounter")
        {
            rawval = m_aliveId;
            item["Default"] = rawval;
        }
        packageData(item, m_heartData, rawval);
        outputData.append(item);
    }
}

} // namespace _Controllers
