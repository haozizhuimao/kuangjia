#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/database/sqlite3_interface/SqliteCollect.h"
#include "tis_global/struct_details/sql_struct.h"
#include "tis_global/struct_details/device6017_struct.h"
#include "Dev6017Sql.h"
#include <atomic>
#include <memory>
#include <shared_mutex>

namespace _Controllers {
class Device6017Ctrl : public ControllerBase<Device6017Ctrl>
{
  public:
    void initConfig(const std::unordered_map<std::string, TIS_Info::ConfigInfo6017> &);
    void onStart();
    void onStop();
    void onRecvTaskInfo(const TIS_Info::task_data &taskInfo);
    void onRecvTemperatureHumidityData(const TIS_Info::TemperatureHumidity &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::Device6017Manager::init6017Info, Device6017Ctrl::initConfig);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, Device6017Ctrl::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, Device6017Ctrl::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, Device6017Ctrl::onRecvTaskInfo);
    ASYNC_TASK_ADD(_Service::TemperatureHumidityService::sendTemperatureHumidity, Device6017Ctrl::onRecvTemperatureHumidityData);
    TASK_LIST_END
  private:
    std::unordered_map<std::string, float> processData(const std::vector<uint8_t> &data, const TIS_Info::ConfigInfo6017 &configInfo);
    std::unordered_map<std::string, float> resolveChannelValues(const std::vector<std::pair<std::string, float>> &rawResults);

    std::unordered_map<std::string, TIS_Info::ConfigInfo6017> mapConfiginfo_;
    std::atomic_bool bInTask_;
    TIS_Info::task_data m_taskInfo_;
    mutable std::shared_mutex mtxCollect_;
    std::shared_ptr<_Kits::database::SqliteCollect> sqliteCollector_;
    std::unique_ptr<Dev6017Sql> m_dev6017Sql;
};
} // namespace _Controllers