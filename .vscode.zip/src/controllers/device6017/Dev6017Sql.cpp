#include "Dev6017Sql.h"
#include <chrono>
#include <string>
#include <unordered_map>
#include <utility>
#include "kits/utility/datetime/datetime.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <thread>

namespace _Controllers {

Dev6017Sql::Dev6017Sql(const _Kits::database::DbClientPtr &pgcollectClient, const _Kits::database::DbClientPtr &pgpressClient)
{
    m_collectData = std::make_shared<_Kits::database::PgCollectData>(pgcollectClient);
    m_pressureData = std::make_shared<_Kits::database::PgPressureData>(pgpressClient);

    // 初始化缓存成员为无效值 8000.0
    // 如果结构体字段较多，这里可以根据你的实际结构体进行初始化
    mv_pressureData.acc0_x = 8000.0;
    mv_pressureData.acc0_y = 8000.0;
    mv_pressureData.press0 = 8000.0;
    mv_pressureData.press1 = 8000.0;
    mv_pressureData.press2 = 8000.0;
    mv_pressureData.press3 = 8000.0;
    mv_pressureData.press4 = 8000.0;
    mv_pressureData.press5 = 8000.0;
    mv_pressureData.press6 = 8000.0;
    mv_pressureData.press7 = 8000.0;

    mv_collectData.vol = 8000.0;
    mv_collectData.cur = 8000.0;
    mv_collectData.cba = 8000.0;
    mv_collectData.tem = 8000.0;
    mv_collectData.hum = 8000.0;

    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    asio::co_spawn(io_timer, [this]() -> _Kits::AwaitTask<void> { co_await processData(); }, asio::detached);
}
Dev6017Sql::~Dev6017Sql()
{
    m_stopRequested_.store(true);
}
void Dev6017Sql::get_value(const std::unordered_map<std::string, float> &data, const std::string &key, float &val)
{
    auto it = data.find(key);
    if (it != data.end())
    {
        double d_val = static_cast<double>(it->second);
        // 只有当值不是无效值 8000.0 时才更新
        if (d_val != 8000.0)
        {
            val = d_val;
        }
    }
}

void Dev6017Sql::collectionEnable(bool isEnabled)
{
    m_started.store(isEnabled);
}

void Dev6017Sql::process(const std::unordered_map<std::string, float> &data, int task_id)
{
    auto now = std::chrono::system_clock::now();

    {
        std::lock_guard<std::mutex> lg(mtxCollect_);

        // 直接更新成员变量，只有有效值（非 8000.0）才会被覆盖
        get_value(data, "spot_0x", mv_pressureData.acc0_x);
        get_value(data, "spot_0y", mv_pressureData.acc0_y);

        get_value(data, "press0", mv_pressureData.press0);
        get_value(data, "press1", mv_pressureData.press1);
        get_value(data, "press2", mv_pressureData.press2);
        get_value(data, "press3", mv_pressureData.press3);
        get_value(data, "press4", mv_pressureData.press4);
        get_value(data, "press5", mv_pressureData.press5);
        get_value(data, "press6", mv_pressureData.press6);
        get_value(data, "press7", mv_pressureData.press7);

        get_value(data, "voltage", mv_collectData.vol);
        get_value(data, "electric", mv_collectData.cur);
        get_value(data, "cba", mv_collectData.cba);

        get_value(data, "temperature", mv_collectData.tem);
        get_value(data, "humidity", mv_collectData.hum);

        // 更新公共字段
        mv_pressureData.task_id = task_id;
        mv_pressureData.updated_time = now;
        mv_pressureData.created_time = now;

        mv_collectData.task_id = task_id;
        mv_collectData.updated_time = now;
        mv_collectData.created_time = now;
    }
}

void Dev6017Sql::stopProcess()
{
    m_stopRequested_.store(true);
}

void Dev6017Sql::insert(TIS_Info::collect_data &&data)
{
    m_collectData->insert(std::move(data));
}
void Dev6017Sql::insert(TIS_Info::press_data &&data)
{
    m_pressureData->insert(std::move(data));
}

_Kits::AwaitTask<void> Dev6017Sql::processData()
{
    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);

    while (!m_stopRequested_.load())
    {
        if (m_started.load())
        {
            TIS_Info::press_data press;
            TIS_Info::collect_data collect;

            {
                std::lock_guard<std::mutex> lk(mtxCollect_);
                // 拷贝当前最新的缓存快照
                press = mv_pressureData;
                collect = mv_collectData;
            }

            // 无条件定频写入
            insert(std::move(press));
            insert(std::move(collect));
        }

        asio::steady_timer timer(io_timer, std::chrono::milliseconds(SLEEP_TIME_MS));
        co_await timer.async_wait(asio::use_awaitable);
    }
}

} // namespace _Controllers
