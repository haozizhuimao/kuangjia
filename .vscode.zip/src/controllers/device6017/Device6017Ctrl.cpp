#include "Device6017Ctrl.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/database/DbClient.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppInterface.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <format>
#include <utility>
#include "kits/primary/thread_pool/thread_pool.h"

namespace _Controllers {

void Device6017Ctrl::initConfig(const std::unordered_map<std::string, TIS_Info::ConfigInfo6017> &config)
{
    mapConfiginfo_ = config;
}

void Device6017Ctrl::onStart()
{
    auto pgcollectClient =
        _Service::DatabaseManager::getPgClient<_Kits::database::DbClientPtr>(_Kits::database::PgClientNames::pg_client_default);
    auto pgpressClient =
        _Service::DatabaseManager::getPgClient<_Kits::database::DbClientPtr>(_Kits::database::PgClientNames::pg_client_default);
    m_dev6017Sql = std::make_unique<Dev6017Sql>(pgcollectClient, pgpressClient);

    for (const auto &[client_name, config_info] : mapConfiginfo_)
    {
        _Kits::thread_pool::runTask([this, client_name, config_info] {
            uint16_t retryCount = 0;
            std::shared_ptr<_Kits::UdpClient> client = nullptr;
            while ((client = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(client_name)) == nullptr)
            {
                _Kits::LogError("UdpClient: {} is not available", client_name);
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                ++retryCount;
                if (retryCount >= 5)
                {
                    break;
                }
            }

            if (retryCount >= 5)
            {
                return;
            }

            _Kits::LogInfo("6017 UdpClient: {} is available", client_name);
            client->subscribe([this, config_info](_Kits::UdpClient::SharedDataBuffer data) {
                if (!data || !bInTask_.load(std::memory_order_acquire))
                {
                    return;
                }

                std::vector<uint8_t> payload(data->begin(), data->end());
                {
                    std::shared_lock sl(mtxCollect_);
                    sqliteCollector_->insert({payload, _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds)});
                }

                auto mapRes = processData(payload, config_info);
                m_dev6017Sql->process(mapRes, m_taskInfo_.id);
                _Service::Device6017Manager::send6017Info(mapRes);
            });
        });
    }
}

void Device6017Ctrl::onStop()
{
    bInTask_.store(false, std::memory_order_release);
    std::unique_lock ul(mtxCollect_);
    sqliteCollector_.reset();
    m_dev6017Sql->stopProcess();
}

void Device6017Ctrl::onRecvTaskInfo(const TIS_Info::task_data &taskInfo)
{
    auto nTaskstate = static_cast<TIS_Info::TaskState>(taskInfo.task_state);
    m_taskInfo_ = taskInfo;
    if (nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        bInTask_.store(true, std::memory_order_release);
        std::unique_lock ul(mtxCollect_);
        std::string client_name =
            std::format("6017data_{}_{}.db", taskInfo.id, _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds));
        auto dbClientPtr = _Service::DatabaseManager::getSqlite3Client<_Kits::database::DbClientPtr>(client_name, true);
        sqliteCollector_ = std::make_shared<_Kits::database::SqliteCollect>(dbClientPtr);
        if (m_dev6017Sql)
        {
            m_dev6017Sql->collectionEnable(true);
        }
    }
    else if (nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        if (m_dev6017Sql)
        {
            m_dev6017Sql->collectionEnable(false);
        }
        bInTask_.store(false, std::memory_order_release);
        std::unique_lock ul(mtxCollect_);
        sqliteCollector_.reset();
    }
}

std::unordered_map<std::string, float> Device6017Ctrl::resolveChannelValues(const std::vector<std::pair<std::string, float>> &rawResults)
{
    std::unordered_map<std::string, float> finalMap;

    for (const auto &[name, value] : rawResults)
    {
        auto it = finalMap.find(name);
        if (it == finalMap.end())
        {
            finalMap[name] = value;
        }
        else
        {
            if (value >= 5.0f ||
                value <= -5.0f) // 一个6017的两个通道会接收同一个值（比如电压），要筛选哪个是正确的，此筛选值不确定，因为6017没有明确异常值
            {
                it->second = value;
            }
        }
    }

    return finalMap;
}

std::unordered_map<std::string, float> Device6017Ctrl::processData(const std::vector<uint8_t> &data,
                                                                   const TIS_Info::ConfigInfo6017 &configInfo)
{
    int expectRecvDataHead = 15 + configInfo.send_interval * 2 * 2 * 8;

    // 1. 内部使用 vector<pair> 暂存，允许存在相同的 key
    std::vector<std::pair<std::string, float>> rawResults;

    if (data.size() < expectRecvDataHead)
    {
        _Kits::LogError("Received data size {} is less than expected size {}, 需要修改配置中的interval", data.size(), expectRecvDataHead);
        return resolveChannelValues(rawResults);
    }

    int offset = 6 + 9;

    int samplesPerChannel = expectRecvDataHead - 15;
    samplesPerChannel /= (8 * 2);

    for (int i = 0; i < 8; ++i)
    {
        float finalValue = 8000.0f;
        int channelOffset = offset + i * samplesPerChannel * 2;
        int channelDataEnd = channelOffset + samplesPerChannel * 2;

        if (channelDataEnd > data.size())
        {
            _Kits::LogError("Channel {} data exceeds buffer size, skipping", i);
            rawResults.emplace_back(configInfo.channel_info[i].channel_name, finalValue);
            continue;
        }

        // 提取当前通道的原始数据
        std::vector<uint8_t> channelData(data.begin() + channelOffset, data.begin() + channelDataEnd);

        // 获取最后一个采样值（保留原有逻辑）
        int lastSampleOffset = channelOffset + (samplesPerChannel - 1) * 2;
        if (lastSampleOffset + 2 <= data.size())
        {
            uint16_t rawValue = static_cast<uint8_t>(data[lastSampleOffset]) << 8 | static_cast<uint8_t>(data[lastSampleOffset + 1]);
            int16_t signedValue = static_cast<int16_t>(rawValue);

            finalValue = static_cast<float>(signedValue);
            finalValue = (finalValue + configInfo.channel_info[i].constant) * configInfo.channel_info[i].coefficient;
        }
        rawResults.emplace_back(configInfo.channel_info[i].channel_name, finalValue); // 将计算结果存储到结果映射中
    }

    return resolveChannelValues(rawResults);
}

void Device6017Ctrl::onRecvTemperatureHumidityData(const TIS_Info::TemperatureHumidity &th)
{
    _Kits::LogDebug("Received temperature humidity data: {}, {}", th.temperature, th.humidity);
    std::unordered_map<std::string, float> dataMap = {{"temperature", th.temperature}, {"humidity", th.humidity}};
    m_dev6017Sql->process(dataMap, m_taskInfo_.id);
}

} // namespace _Controllers
