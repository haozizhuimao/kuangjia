#pragma once
#include "tis_global/Struct.h"
#include "kits/database/postgresql_interface/PgCollectData.h"
#include "kits/database/postgresql_interface/PgPressureData.h"
#include "tis_global/struct_details/sql_struct.h"
#include "kits/primary/coroutine/coroutine_awaiter.h"
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include <thread>
#include <condition_variable>
#include <deque>
#include <stop_token>
#include <atomic>
#include "kits/primary/io_manager/io_manager.h"

namespace _Controllers {
class Dev6017Sql
{
  public:
    Dev6017Sql(const _Kits::database::DbClientPtr &pgcollectClient, const _Kits::database::DbClientPtr &pgpressClient);
    ~Dev6017Sql();

    void collectionEnable(bool isEnabled);
    void process(const std::unordered_map<std::string, float> &data, int task_id);
    void stopProcess();

  private:
    void insert(TIS_Info::press_data &&data);
    void insert(TIS_Info::collect_data &&data);

    void get_value(const std::unordered_map<std::string, float> &data, const std::string &key, float &val);
    _Kits::AwaitTask<void> processData();

    std::shared_ptr<_Kits::database::PgCollectData> m_collectData;
    std::shared_ptr<_Kits::database::PgPressureData> m_pressureData;

    std::mutex mtxCollect_;
    std::atomic_bool m_started{false};
    std::atomic<bool> m_stopRequested_{false};
    std::atomic<bool> m_hasNewData_{false}; // 增加是否有新数据的标志位
    TIS_Info::press_data mv_pressureData;
    TIS_Info::collect_data mv_collectData;
    inline static int32_t SLEEP_TIME_MS = 10;
};
} // namespace _Controllers
