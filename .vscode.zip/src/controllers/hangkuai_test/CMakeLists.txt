set(CTL_NAME "ctl_hangkuai_test")

message("---------- Building ${CTL_NAME}  ----------")
file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)
add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})

target_sources(${LIB_CONTROLLERS} PUBLIC 
    $<TARGET_OBJECTS:${CTL_NAME}>  
    $<TARGET_OBJECTS:kit_asio_udp>
    
)  


target_link_libraries(${CTL_NAME} PUBLIC 
        shared_dependencies 
        qt_dependencies
        kit_log
        kit_asio_udp
             
)
target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

# 用于选择加载的资源和界面文件 begin
# set(RES_QML
#     res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
#     res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
#     res/qml/engineering_vehicle_qml/rfid_page/rfid_page.qml
#     res/qml/engineering_vehicle_qml/main.qml
#     res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
#     res/qml/engineering_vehicle_qml/mvb_page/mvb_page.qml
#     res/qml/engineering_vehicle_qml/egv_ir_page/egv_irvideo_page.qml
#     res/qml/engineering_vehicle_qml/arc_data_page/arc_data_page.qml
#     res/qml/public_controls/CustomTitleBar.qml
#     res/qml/public_controls/Table.qml
#     res/qml/public_controls/Modules.qml
#     res/qml/public_controls/VideoDisplay.qml
#     res/qml/public_controls/HighFrequencyChart.qml
   
    
# )

# file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end

