#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "kits/common/orm_user/MvbInfoSql.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <qobject.h>

#include <QVariantMap>



namespace _Controllers {
using namespace _Kits;
using namespace _Service;
static uint16_t getUdpProxyChecksum16(const uint8_t *buff, uint16_t len)
{
    static const uint8_t auchCRCLo[] = {
        0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4, 
0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09, 
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 
0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7, 
0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A, 
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 
0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26, 
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2, 
0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F, 
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB, 
0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5, 
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90, 0x91, 
0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C, 
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88, 
0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C, 
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80, 
0x40
    };

    static const uint8_t auchCRCHi[] = {
       0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 
0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 
0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 
0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 
0x40
    };

    uint8_t uchCRCHi = 0xFF;
    uint8_t uchCRCLo = 0xFF;

    for (uint16_t i = 0; i < len; ++i)
    {
        uint16_t uIndex = uchCRCLo ^ buff[i];
        uchCRCLo = uchCRCHi ^ auchCRCHi[uIndex];
        uchCRCHi = auchCRCLo[uIndex];
    }

    return static_cast<uint16_t>((uchCRCHi << 8) | uchCRCLo);
}
MVBController::MVBController()
{
    //m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_headLength = 24;//sizeof(TIS_Info::MVBuDPHeader);
    m_heartData.resize(m_headLength + 802, 0);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
    //m_mvbInfoWirteSqlThread = std::thread(&MVBController::writeMvbInfoToDBFun, this);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
    m_condition.notify_one();
    if (m_mvbInfoWirteSqlThread.joinable())
    {
        m_mvbInfoWirteSqlThread.join();
    }
}

// void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
// {
//     // // mvb tcms数据接收
//     // auto finder = clients.find(m_udpName);
//     // if (finder == clients.end())
//     // {
//     //     LogError("can not find udp client.name = {}", m_udpName);
//     //     return;
//     // }
//     // auto udpClient = finder->second;
//     // udpClient->start();
//     // udpClient->setReceiveCallback([this](std::vector<uint8_t> &&datas) { onUdpDataReceived(std::move(datas)); });
//     // // mvb 告警数据接收
//     // auto alarmUdp = clients.find(m_mvbAmifName);
//     // if (alarmUdp == clients.end())
//     // {
//     //     LogError("can not find udp client.name = {}", m_mvbAmifName);
//     //     return;
//     // }
//     // alarmUdp->second->start();
//     // alarmUdp->second->setReceiveCallback([this](std::vector<uint8_t> &&datas) { onUdpAlarmReceived(std::move(datas)); });
//     // // mvb 心跳数据发送
//     // auto heartUdp = clients.find(m_heartUdpName);
//     // if (heartUdp == clients.end())
//     // {
//     //     LogError("can not find udp client.name = {}", m_heartUdpName);
//     //     return;
//     // }
//     // auto heartUdpClient = heartUdp->second;
//     // heartUdpClient->start();
//     // m_heartUdpClient = heartUdpClient;
// }

void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        LogError("recv common payload too short, len = {}", data.size());
        return;
    }
    // 这里可能要加trdp 协议
    // 1心跳，vcu发送数据
    outputData["TCMSHeartbeat"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    m_tcmsaliveId.store(ByteArrayTools::readFromVectorBE<uint16_t>(data, 0));
    // 2 日期时间，byte2-7
    int year = 2000 + ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    int month = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    int day = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    int hour = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    int minute = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    int second = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);

    outputData["dateTime"] = QString("%1-%2-%3 %4:%5:%6")
        .arg(year).arg(month, 2, 10, QChar('0')).arg(day, 2, 10, QChar('0'))
        .arg(hour, 2, 10, QChar('0')).arg(minute, 2, 10, QChar('0')).arg(second, 2, 10, QChar('0'));

    // 3 列车编号

    outputData["trainset"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 8);
    //4 tc1端 司机室激活    
    uint8_t statusByte9 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
    //tc1端 司机室激活 
     outputData["Cab1Active"] = (statusByte9 >> 0) & 0x01;
    // 5 tc2端 司机室激活
     outputData["Cab2Active"] = (statusByte9 >> 1) & 0x01;

     // 6 ATO模式激活  1=ATO模式激活

     outputData["ATOActive"] = (statusByte9 >> 2) & 0x01;
     //7 FAM模式激活 1=FAM模式激活
     outputData["FAM"] = (statusByte9 >> 3) & 0x01;

     //8 列车休眠信号
     outputData["TrainSleep"] = (statusByte9 >> 4) & 0x01;

     // 9 起点站ID
     outputData["StartStationID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
     //10 当前站ID
     outputData["CurrentStationID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);

     // 11 下一站ID
     outputData["NextStationID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
     //12 终点站ID
     outputData["DestStationID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
     // 13   Byte18控制命令   报警/故障复位



    //  uint8_t statusByte18  = ByteArrayTools::readFromVectorBE<uint8_t>(data, 18);
    // outputData["AlarmFltReset"] = (statusByte18 >> 0) & 0x01; 
    // // 14 牵引指令
    // outputData["TractionCommand"] = (statusByte18 >> 2) & 0x01; 
    // // 15 制动指令
    //  outputData["BrakeCmd"] = (statusByte18 >> 3) & 0x01;
    // //16 快速制动指令
    // outputData["FastBrakeCommandRequest"] = (statusByte18 >> 4) & 0x01; 

    // //17 列车限速有效
    // outputData["SpeedLmtValid"] = (statusByte18 >> 7 )& 0x01;
    // // 18 列车限速值 1 = 1km/h
    // outputData["SpeedLmt"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 20);

    // 19 牵引制动力参考值  有效范围：0-10000，1=0.01%
// 0=惰行（无牵引或制动）
// 10000=100%牵引/制动请求值
// 10001-65535无效有效范围：0-10000，1=0.01%
// 0=惰行（无牵引或制动）
// 10000=100%牵引/制动请求值
// 10001-65535无效
    // uint16_t TractionandBrakeEffortDemand =  ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
    // outputData["TractionandBrakeEffortDemand"] =TractionandBrakeEffortDemand * 0.01;

    // //20 六编组1车1门对位隔离请求
    // uint8_t doorByte24 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 24);
    // outputData["DorInhib1_1"] = (doorByte24 >> 0) & 0x01;
    // // 21 六编组1车3门对位隔离请求
    // outputData["DorInhib1_3"] = (doorByte24 >> 1) & 0x01;
    // //22 六编组1车5门对位隔离请求
    // outputData["DorInhib1_5"] = (doorByte24 >> 2) & 0x01;
    // //23 六编组1车7门对位隔离请求
    // outputData["DorInhib1_7"] = (doorByte24 >> 3) & 0x01;
    // //24 六编组2车1门对位隔离请求
    // outputData["DorInhib2_1"] = (doorByte24 >> 4) & 0x01;

    // //25 六编组2车3门对位隔离请求
    // outputData["DorInhib2_3"] = (doorByte24 >> 5) & 0x01;
    // //26 六编组2车5门对位隔离请求
    // outputData["DorInhib2_5"] = (doorByte24 >> 6) & 0x01;
    // // 27 六编组2车7门对位隔离请求
    // outputData["DorInhib2_7"] = (doorByte24 >> 7) & 0x01;

    // //28 六编组3车1门对位隔离请求
    // uint8_t doorByte25 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 25);
    // outputData["DorInhib3_1"] = (doorByte25 >> 0) & 0x01;

    // //29 六编组3车3门对位隔离请求
    // outputData["DorInhib3_3"] = (doorByte25 >> 1) & 0x01;
    // // 30 六编组3车5门对位隔离请求
    // outputData["DorInhib3_5"] = (doorByte25 >> 2) & 0x01;


    // //31 六编组3车7门对位隔离请求
    // outputData["DorInhib3_7"] = (doorByte25 >> 3) & 0x01;

    // //32 六编组4车1门对位隔离请求
    // outputData["DorInhib4_1"] = (doorByte25 >> 4) & 0x01;
    // //33 六编组4车3门对位隔离请求
    // outputData["DorInhib4_3"] = (doorByte25 >> 5) & 0x01;
    // // 34 六编组4车5门对位隔离请求
    // outputData["DorInhib4_5"] = (doorByte25 >> 6) & 0x01;
    // // 35 六编组4车7门对位隔离请求
    // outputData["DorInhib4_7"] = (doorByte25 >> 7) & 0x01;

    // // 36 六编组5车1门对位隔离请求
    // uint8_t doorByte26 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 26);
    // outputData["DorInhib5_1"] = (doorByte26 >> 0) & 0x01;

    // //37 六编组5车3门对位隔离请求
    // outputData["DorInhib5_3"] = (doorByte26 >> 1) & 0x01;
    // // 38 六编组5车5门对位隔离请求
    // outputData["DorInhib5_5"] = (doorByte26 >> 2) & 0x01;
    // // 39 六编组5车7门对位隔离请求
    // outputData["DorInhib5_7"] = (doorByte26 >> 3) & 0x01;
    // // 40 六编组6车1门对位隔离请求
    // outputData["DorInhib6_1"] = (doorByte26 >> 4) & 0x01;
    // //41 六编组6车3门对位隔离请求
    // outputData["DorInhib6_3"] = (doorByte26 >> 5) & 0x01;
    // //42 六编组6车5门对位隔离请求
    // outputData["DorInhib6_5"] = (doorByte26 >> 6) & 0x01;
    // // 43 六编组6车7门对位隔离请求
    // outputData["DorInhib6_7"] = (doorByte26 >> 7) & 0x01;   

    // //44 六编组1车2门对位隔离请求
    // uint8_t doorByte28 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 28);
    // outputData["DorInhib1_2"] = (doorByte28 >> 0) & 0x01;
    // //45 六编组1车4门对位隔离请求
    // outputData["DorInhib1_4"] = (doorByte28 >> 1) & 0x01;
    // // 46 六编组1车6门对位隔离请求
    // outputData["DorInhib1_6"] = (doorByte28 >> 2) & 0x01;
    // // 47 六编组1车8门对位隔离请求
    // outputData["DorInhib1_8"] = (doorByte28 >> 3) & 0x01;
    // //48 六编组2车2门对位隔离请求
    // outputData["DorInhib2_2"] = (doorByte28 >> 4) & 0x01;
    // //49 六编组2车4门对位隔离请求
    // outputData["DorInhib2_4"] = (doorByte28 >> 5) & 0x01;
    // // 50 六编组2车6门对位隔离请求
    // outputData["DorInhib2_6"] = (doorByte28 >> 6) & 0x01;
    // // 51 六编组2车8门对位隔离请求
    // outputData["DorInhib2_8"] = (doorByte28 >> 7) & 0x01;
    // // 52 六编组3车2门对位隔离请求
    // uint8_t doorByte29 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 29);
    // outputData["DorInhib3_2"] = (doorByte29 >> 0) & 0x01;
    // //53 六编组3车4门对位隔离请求
    // outputData["DorInhib3_4"] = (doorByte29 >> 1) & 0x01;
    // // 54 六编组3车6门对位隔离请求
    // outputData["DorInhib3_6"] = (doorByte29 >> 2) & 0x01;
    // // 55 六编组3车8门对位隔离请求
    // outputData["DorInhib3_8"] = (doorByte29 >> 3) & 0x01;
    // // 56 六编组4车2门对位隔离请求
    // outputData["DorInhib4_2"] = (doorByte29 >> 4) & 0x01;
    // // 57 六编组4车4门对位隔离请求
    // outputData["DorInhib4_4"] = (doorByte29 >> 5) & 0x01;
    // // 58 六编组4车6门对位隔离请求
    // outputData["DorInhib4_6"] = (doorByte29 >> 6) & 0x01;
    // // 59 六编组4车8门对位隔离请求
    // outputData["DorInhib4_8"] = (doorByte29 >> 7) & 0x01;
    // // 60 六编组5车2门对位隔离请求
    // uint8_t doorByte30 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 30);
    // outputData["DorInhib5_2"] = (doorByte30 >> 0) & 0x01;
    // // 61 六编组5车4门对位隔离请求
    // outputData["DorInhib5_4"] = (doorByte30 >> 1) & 0x01;
    // // 62 六编组5车6门对位隔离请求
    // outputData["DorInhib5_6"] = (doorByte30 >> 2) & 0x01;
    // // 63 六编组5车8门对位隔离请求
    // outputData["DorInhib5_8"] = (doorByte30 >> 3) & 0x01;
    // // 64 六编组6车2门对位隔离请求
    // outputData["DorInhib6_2"] = (doorByte30 >> 4) & 0x01;
    // // 65 六编组6车4门对位隔离请求
    // outputData["DorInhib6_4"] = (doorByte30 >> 5) & 0x01;
    // // 66 六编组6车6门对位隔离请求
    // outputData["DorInhib6_6"] = (doorByte30 >> 6) & 0x01;
    // // 67 六编组6车8门对位隔离请求
    // outputData["DorInhib6_8"] = (doorByte30 >> 7) & 0x01;

    // Byte340综合状态 
    uint8_t statusByte340 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 150);
    //所有左侧门关好
    outputData["LDoorClosed"] = (statusByte340 >> 0) & 0x01;
    //所有右侧门关好
    outputData["RDoorClosed"] = (statusByte340 >> 1) & 0x01;
    //列车参考速度有效
    outputData["TrainSpeedValid"] = (statusByte340 >> 2) & 0x01;
    //列车向前状态
    outputData["TrainForward"] = (statusByte340 >> 3) & 0x01;
    //列车向后状态
    outputData["Trainbackward"] = (statusByte340 >> 4) & 0x01;
    //列车休眠信号（同byte9bit4）
    outputData["TrainSleep1"] = (statusByte340 >> 5) & 0x01;
    //充电机故障（≥2台充电机工作输出1，否则输出0）
    outputData["HalfBCGFlt"] = (statusByte340 >> 6) & 0x01;
    //1车轮径更新成功
    outputData["WDSetValid_1"] = (statusByte340 >> 7) & 0x01;

    // Byte341综合状态
    uint8_t statusByte341 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 151);
    // 2车轮径更新成功
    outputData["WDSetValid_2"] = (statusByte341 >> 0) & 0x01;
    // 3车轮径更新成功
    outputData["WDSetValid_3"] = (statusByte341 >> 1) & 0x01;
    // 4车轮径更新成功
    outputData["WDSetValid_4"] = (statusByte341 >> 2) & 0x01;
    // 5车轮径更新成功
    outputData["WDSetValid_5"] = (statusByte341 >> 3) & 0x01;
    // 6车轮径更新成功
    outputData["WDSetValid_6"] = (statusByte341 >> 4) & 0x01;

    uint8_t statusByte342 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 152);
    //隧道检测系统开启指令  1=唤醒，0=关闭

    outputData["TunnelON"] = (statusByte342 >> 3) & 0x01;
    //车在场段内
    outputData["trainOnline"] = (statusByte342 >> 4) & 0x01;
    //车在正线
    outputData["Depot"] = (statusByte342 >> 5) & 0x01;
    //2车再生制动能耗脉冲 

    outputData["RgnBrkCnsPls_2"] = (statusByte342 >> 6) & 0x01;
    //2车牵引能耗脉冲
    outputData["TrcCnsPls_2"] = (statusByte342 >> 7) & 0x01;
    //2车斩波制动能耗脉冲
    uint8_t statusByte343 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 153);
    outputData["ChpWCnsPls_2"] = (statusByte343 >> 0) & 0x01;
    //3车再生制动能耗脉冲
    outputData["RgnBrkCnsPls_3"] = (statusByte343 >> 1) & 0x01;

    //3车牵引能耗脉冲
    outputData["TrcCnsPls_3"] = (statusByte343 >> 2) & 0x01;
    //3车斩波制动能耗脉冲
    outputData["ChpWCnsPls_3"] = (statusByte343 >> 3) & 0x01;

    //4车再生制动能耗脉冲
    outputData["RgnBrkCnsPls_4"] = (statusByte343 >> 4) & 0x01;

    //4车牵引能耗脉冲
    outputData["TrcCnsPls_4"] = (statusByte343 >> 5) & 0x01;
    

    //4车斩波制动能耗脉冲
    outputData["ChpWCnsPls_4"] = (statusByte343 >> 6) & 0x01;
    //5车再生制动能耗脉冲
    outputData["RgnBrkCnsPls_5"] = (statusByte343 >> 7) & 0x01;

    uint8_t statusByte344 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 154);
    //5车牵引能耗脉冲
    outputData["TrcCnsPls_5"] = (statusByte344 >> 0) & 0x01;

    //5车斩波制动能耗脉冲
    outputData["ChpWCnsPls_5"] = (statusByte344 >> 1) & 0x01;

    //1车1号辅助变流器能耗 
    outputData["SIV1_SIVEngPuls_1"] = (statusByte344 >> 2) & 0x01;
    //1车1号充电机能耗
    outputData["SIV1_ChgEngPuls_1"] = (statusByte344 >> 3) & 0x01;
    //1车2号辅助变流器能耗 
   
    outputData["SIV2_SIVEngPuls_1"] = (statusByte344 >> 4) & 0x01;
    //1车2号充电机能耗
    outputData["SIV2_ChgEngPuls_1"] = (statusByte344 >> 5) & 0x01;
    //2车1号辅助变流器能耗
    outputData["SIV1_SIVEngPuls_2"] = (statusByte344 >> 6) & 0x01;
    //2车1号充电机能耗
    outputData["SIV1_ChgEngPuls_2"] = (statusByte344 >> 7) & 0x01;
    //2车2号辅助变流器能耗   1KW  3S脉冲
    uint8_t statusByte345 = ByteArrayTools::readFromVectorBE<uint8_t>(data, 155);
    outputData["SIV2_SIVEngPuls_2"] = (statusByte345 >> 0) & 0x01;
    //2车2号充电机能耗
    outputData["SIV2_ChgEngPuls_2"] = (statusByte345 >> 1) & 0x01;
    //1车能耗脉冲  1kwh发一个脉冲，3秒
    outputData["PwrPulse_1"] = (statusByte345 >> 2) & 0x01;
    //2车能耗脉冲
    outputData["PwrPulse_2"] = (statusByte345 >> 3) & 0x01;
    //3车能耗脉冲
    outputData["PwrPulse_3"] = (statusByte345 >> 4) & 0x01;
    //4车能耗脉冲
    outputData["PwrPulse_4"] = (statusByte345 >> 5) & 0x01;
    //5车能耗脉冲
    outputData["PwrPulse_5"] = (statusByte345 >> 6) & 0x01;
    //6车能耗脉冲
    outputData["PwrPulse_6"] = (statusByte345 >> 7) & 0x01;
    //2车参考轴轮径
    outputData["CusWD_2"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 157);
    
   
    //3车参考轴轮径  1=1mm, 范围 770-840mm
    outputData["CusWD_3"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 158);
    //4车参考轴轮径
    outputData["CusWD_4"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 159);
    //5车参考轴轮径
    outputData["CusWD_5"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 160);
    //6车参考轴轮径
    outputData["CusWD_6"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 161);

    //线路号
    outputData["CusLineNumber"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 162);
    //列车号 范围001-255，1bit=1
    outputData["CusTrainNumber"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 164);
    //1车轴2速度  1=0.01km/h
    outputData["CuiAxleSpeedA12_1"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 166);
    //6车轴2速度 1=0.01km/h
    outputData["CuiAxleSpeedA12_6"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 168);
    //列车参考速度
    outputData["CuiTrainSpeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 170);
    //一单元牵引辅助总电流（牵引中间电流+辅助输入电流）  1=1A
    outputData["CuiPCESIVCurrentU1"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 172));

    //1车参考轴轮径 1=1mm, 范围 770-840mm 
    outputData["CusWD_1"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 174);


    //目标距离(源自ATC)，列车从当前位置到“下一站ID”对应站台停车点的距离 1=1m
    outputData["CuiTargetDis"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 176);

    //起始距离(源自ATC)，列车从“当前站ID”对应停车点到当前位置的距离
    outputData["CuiStartDis"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 178);
    //1车室外温度     
    outputData["CiExtTemp_1"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 184));
    //2车室外温度
    outputData["CiExtTemp_2"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 186));
    //3车室外温度
    outputData["CiExtTemp_3"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 188));
    //4车室外温度
    outputData["CiExtTemp_4"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 190));
    //5车室外温度
    outputData["CiExtTemp_5"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 192));
    //6车室外温度  0.1℃/bit
    outputData["CiExtTemp_6"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 194));

    //A车转向架1载荷重量（含转动惯量）  载荷重量范围：0 – 85吨, 0.01ton/bit
    //该信号仅为转向架的载重，当某个转向架该信号无效时，具体分析
    outputData["LoadWeightB1_A"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 196);
    //A车转向架2载荷重量（含转动惯量）
    outputData["LoadWeightB2_A"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 198);
    //B车转向架1载荷重量（含转动惯量）
    outputData["LoadWeightB1_B"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 200);

    //B车转向架2载荷重量（含转动惯量）
    outputData["LoadWeightB2_B"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 202);
    //C车转向架1载荷重量（含转动惯量）
    outputData["LoadWeightB1_C"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 204);

    //C车转向架2载荷重量（含转动惯量）
    outputData["LoadWeightB2_C"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 206);
    //累计运行里程
    outputData["TotalMileage"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 208);



    // // CCU生命信号
    // outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);

    // uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    // std::bitset<8> bit(modeData);
    // // 1车司机室激活
    // outputData["cab1Occupied"] = static_cast<bool>(bit[0]);
    // // 6车司机室激活
  
    // // 5车乘车率
    // outputData["rateLoadC5"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 30);
    // // 6车乘车率
    // outputData["rateLoadC6"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 31);
}

Json::Value MVBController::convertMvbDataToJson(const QVariantMap & portData)
{
    Json::Value jsonData;
    for (auto it = portData.constBegin(); it != portData.constEnd(); ++it) {
        std::string key = it.key().toStdString();
        QVariant value = it.value();
        
        // 根据QVariant类型转换为对应的Json::Value类型
        if (value.isNull()) {
            jsonData[key] = Json::nullValue;
        }
        else if (value.type() == QVariant::Bool) {
            jsonData[key] = value.toBool();
        }
        else if (value.type() == QVariant::Int) {
            jsonData[key] = value.toInt();
        }
        else if (value.type() == QVariant::UInt) {
            jsonData[key] = value.toUInt();
        }
        else if (value.type() == QVariant::LongLong) {
            jsonData[key] = (Json::Int64)value.toLongLong();
        }
        else if (value.type() == QVariant::ULongLong) {
            jsonData[key] = (Json::UInt64)value.toULongLong();
        }
        else if (value.type() == QVariant::Double) {
            jsonData[key] = value.toDouble();
        }
        else if (value.type() == QVariant::String) {
            jsonData[key] = value.toString().toStdString();
        }
        else if (value.type() == QVariant::StringList) {
            Json::Value array(Json::arrayValue);
            QStringList list = value.toStringList();
            for (const QString &str : list) {
                array.append(str.toStdString());
            }
            jsonData[key] = array;
        }
        else if (value.type() == QVariant::Map) {
            // 递归处理嵌套的Map
            jsonData[key] = convertMvbDataToJson(value.toMap());
        }
        else if (value.type() == QVariant::List) {
            Json::Value array(Json::arrayValue);
            QVariantList list = value.toList();
            for (const QVariant &item : list) {
                if (item.type() == QVariant::Map) {
                    array.append(convertMvbDataToJson(item.toMap()));
                } else if (item.type() == QVariant::String) {
                    array.append(item.toString().toStdString());
                } else if (item.type() == QVariant::Int) {
                    array.append(item.toInt());
                } else if (item.type() == QVariant::Double) {
                    array.append(item.toDouble());
                } else if (item.type() == QVariant::Bool) {
                    array.append(item.toBool());
                } else {
                    array.append(item.toString().toStdString());
                }
            }
            jsonData[key] = array;
        }
        else {
            // 其他类型默认转字符串
            jsonData[key] = value.toString().toStdString();
        }
    }
    
    return jsonData;


}
void MVBController::displayRecvPortData(QVariantMap &portData)
{
    // 给页面传递数据展示
    if (portData.isEmpty()) {
        LogDebug("No data received to display.");
        return;
    }
    Json::Value jsonData = convertMvbDataToJson(portData);
    if (!jsonData.isMember("dataSource")) {
        // 如果没有dataSource，根据内容推断
       
        jsonData["dataSource"] = "ccu_data";
    }

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, jsonData);


   

}

// void MVBController::onUdpAlarmReceived(const std::vector<uint8_t> &&data)
// {
//     auto alarmData = std::move(data);
//     std::string jsonStr(reinterpret_cast<const char *>(alarmData.data()), alarmData.size());
//     Json::Value jsonValue = stringToJson(jsonStr);
//     if (jsonValue["msgType"].asString() == "amif")
//     {
//         parseAmifData(jsonValue["data"]);
//     }
//     LogInfo("recv alarm data = {}", jsonStr);
// }
void MVBController::onRecvSimuteMvbData(const Json::Value & simulateHeart)
{
    LogInfo("json={}", simulateHeart.toStyledString());
    std::unique_lock<std::mutex> lock(m_mutex);
    // 软件版本
    if (simulateHeart.isMember("Version"))
    {
        auto data = simulateHeart["Version"].asString();
        m_version = parseVersionString(data);
       // m_version = data;
        //uint8_t versionHigh = static_cast<uint8_t>(simulateHeart["versionHigh"].asUInt());
        //ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, versionHigh, 2);
    }

    // 软件版本
    // if (simulateHeart.isMember("versionLow"))
    // {
    //     uint8_t versionLow = static_cast<uint8_t>(simulateHeart["versionLow"].asUInt());
    //     ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, versionLow, 3);
    // }

    if(simulateHeart.isMember("TestRes"))
    {
        auto selfstatus = simulateHeart["TestRes"].asBool();
        m_selfstatus.store(selfstatus);
    }
    if(simulateHeart.isMember("Module1Flt"))
    {
        auto module1Flt = simulateHeart["Module1Flt"].asBool();
        m_Module1Flt.store(module1Flt);
    }
    if(simulateHeart.isMember("Module2Flt"))
    {
        auto module2Flt = simulateHeart["Module2Flt"].asBool();
        m_Module2Flt.store(module2Flt);

    }
    if(simulateHeart.isMember("Module3Flt"))
    {
        auto module3Flt = simulateHeart["Module3Flt"].asBool();
        m_Module3Flt.store(module3Flt);

    }
    if (simulateHeart.isMember("Module4Flt"))
    {
        auto module4Flt = simulateHeart["Module4Flt"].asBool();
        m_Module4Flt.store(module4Flt);
    }
    if(simulateHeart.isMember("HorDisFlt"))
    {
        auto HorDisFlt_ = simulateHeart["HorDisFlt"].asBool();
        m_HorDisFlt.store(HorDisFlt_);

    }
    if(simulateHeart.isMember("VerDisFlt"))
    {
        auto VertDisFlt_ = simulateHeart["VerDisFlt"].asBool();
        m_VerDisFlt.store(VertDisFlt_);
    }
    if(simulateHeart.isMember("ComFlt"))
    {
        auto ComFlt_ = simulateHeart["ComFlt"].asBool();
        m_ComFlt.store(ComFlt_);

    }
    if(simulateHeart.isMember("HorDis"))
    {
        auto HorDis_ = simulateHeart["HorDis"].asUInt();
        m_HorDis.store(HorDis_);
    }
    if(simulateHeart.isMember("VerDis"))
    {
        auto VertDis_ = simulateHeart["VerDis"].asUInt();
        m_VerDis.store(VertDis_);
    }
    if(simulateHeart.isMember("Com"))
    {
        auto Com_ = simulateHeart["Com"].asUInt();
        m_Com.store(Com_);
    }
    
    // 上电自检状态
    if (simulateHeart.isMember("CheckStatus"))
    {
        uint8_t checkStatus = static_cast<uint8_t>(simulateHeart["CheckStatus"].asUInt());
        m_pmsSelfCheckStatus = checkStatus;
        //ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, checkStatus, 4);
    }
    lock.unlock();
    if (simulateHeart.isMember("NetFLT"))
    {
        auto netFLT = simulateHeart["NetFLT"].asBool();
        m_pmsNetFault.store(static_cast<bool>(netFLT));
    }
    if (simulateHeart.isMember("RhdeviceMFlt"))
    {
        auto rcModuleFault = simulateHeart["RhdeviceMFlt"].asBool();
        m_pmsArcModuleFault.store(static_cast<bool>(rcModuleFault));
    }
    if(simulateHeart.isMember("CameradeviceFlt"))
    {
        auto pmsCameraFault = simulateHeart["CameradeviceFlt"].asBool();
        m_pmsCameraFault.store(static_cast<bool>(pmsCameraFault));


    }
    //
    if(simulateHeart.isMember("GeodeviceFlt"))
    {
        auto pmsGeoFault = simulateHeart["GeodeviceFlt"].asBool();
        m_pmsGeoDeviceFault.store(static_cast<bool>(pmsGeoFault));
    }
    if(simulateHeart.isMember("pisdeviceFlt"))
    {
        auto pmsCompDeviceFault = simulateHeart["pisdeviceFlt"].asBool();
        m_pmsCompDeviceFault.store(static_cast<bool>(pmsCompDeviceFault));
    }

    if(simulateHeart.isMember("tempdeviceFlt"))
    {
        auto TempDeviceFault = simulateHeart["tempdeviceFlt"].asBool();
        m_pmsTempDeviceFault.store(static_cast<bool>(TempDeviceFault));
    }

    if(simulateHeart.isMember("SusdeviceFlt"))
    {
        auto SusDeviceFault = simulateHeart["SusdeviceFlt"].asBool();
        m_pmsSusDeviceFault.store(static_cast<bool>(SusDeviceFault));
    }

    if(simulateHeart.isMember("SustrideviceFlt"))  
    {
        auto SusTrigDeviceFault = simulateHeart["SustrideviceFlt"].asBool();
        m_pmsSusTrigDeviceFault.store(static_cast<bool>(SusTrigDeviceFault));
    }
    if(simulateHeart.isMember("FibanalFlt"))
    {
        auto FibanalFault = simulateHeart["FibanalFlt"].asBool();
        m_pmsFiberAnalyzerFault.store(static_cast<bool>(FibanalFault));
    }
    if(simulateHeart.isMember("PowboxFlt"))
    {
        auto FibTrigDeviceFault = simulateHeart["PowboxFlt"].asBool();
        m_pmsPowerBoxFault.store(static_cast<bool>(FibTrigDeviceFault));
    }

    if(simulateHeart.isMember("ArcAlarm1"))
    {
        auto arcAlarm1 = simulateHeart["ArcAlarm1"].asBool();
        m_pmsArcAlarm1.store(static_cast<bool>(arcAlarm1));
    }
    if(simulateHeart.isMember("ArcAlarm2"))
    {
        auto ArcAlarm2 = simulateHeart["ArcAlarm2"].asBool();
        m_pmsArcAlarm2.store(static_cast<bool>(ArcAlarm2));
    }
    if(simulateHeart.isMember("ArcAlarm3"))
     {
        auto ArcAlarm3 = simulateHeart["ArcAlarm3"].asBool();
        m_pmsArcAlarm3.store(static_cast<bool>(ArcAlarm3));
     }
    if(simulateHeart.isMember("TempAlarm1"))
     {
        auto TempAlarm1 = simulateHeart["TempAlarm1"].asBool();
        m_pmsTempAlarm1.store(static_cast<bool>(TempAlarm1));

    }
    if(simulateHeart.isMember("TempAlarm2"))
    {
    auto TempAlarm2 = simulateHeart["TempAlarm2"].asBool();
    m_pmsTempAlarm2.store(static_cast<bool>(TempAlarm2));
    }

    if(simulateHeart.isMember("TempAlarm3"))
    {
        auto TempAlarm3 = simulateHeart["TempAlarm3"].asBool();
        m_pmsTempAlarm3.store(static_cast<bool>(TempAlarm3));
    }

    if(simulateHeart.isMember("HeigcontwirAbn1"))
    {
        auto HeigcontwirAbn1 = simulateHeart["HeigcontwirAbn1"].asBool();
        m_pmsHeightAlarm1.store(static_cast<bool>(HeigcontwirAbn1));
    }

    if(simulateHeart.isMember("HeigcontwirAbn2"))
    {
        auto HeigcontwirAbn2 = simulateHeart["HeigcontwirAbn2"].asBool();
        m_pmsHeightAlarm2.store(static_cast<bool>(HeigcontwirAbn2));
    }
    if(simulateHeart.isMember("HeigcontwirAbn3"))
    {
        auto HeigcontwirAbn3 = simulateHeart["HeigcontwirAbn3"].asBool();
        m_pmsHeightAlarm3.store(static_cast<bool>(HeigcontwirAbn3));
    }
    if(simulateHeart.isMember("PullValAbn1"))
    {
        auto PullValAbn1 = simulateHeart["PullValAbn1"].asBool();
        m_pmsPullValAlarm1.store(static_cast<bool>(PullValAbn1));

    }
    if(simulateHeart.isMember("PullValAbn2"))
    {
        auto PullValAbn2 = simulateHeart["PullValAbn2"].asBool();
        m_pmsPullValAlarm2.store(static_cast<bool>(PullValAbn2));
    }
    if(simulateHeart.isMember("PullValAbn3"))
    {
        auto PullValAbn3 = simulateHeart["PullValAbn3"].asBool();
        m_pmsPullValAlarm3.store(static_cast<bool>(PullValAbn3));
    }
    if(simulateHeart.isMember("pancontPrealarm1"))
    {
        auto ContactForceAlarm1 = simulateHeart["pancontPrealarm1"].asBool();
        m_pmsContactForceAlarm1.store(static_cast<bool>(ContactForceAlarm1));

    }
    if(simulateHeart.isMember("pancontPrealarm2"))
     {
        auto ContactForceAlarm2 = simulateHeart["pancontPrealarm2"].asBool();
        m_pmsContactForceAlarm2.store(static_cast<bool>(ContactForceAlarm2));
     }
    if(simulateHeart.isMember("pancontPrealarm3"))
    {
        auto ContactForceAlarm3 = simulateHeart["pancontPrealarm3"].asBool();
        m_pmsContactForceAlarm3.store(static_cast<bool>(ContactForceAlarm3));
    }
    if(simulateHeart.isMember("Conthardalarm1"))
    {
        auto HardPointAlarm1 = simulateHeart["Conthardalarm1"].asBool();
        m_pmsHardPointAlarm1.store(static_cast<bool>(HardPointAlarm1));
    }
    if(simulateHeart.isMember("Conthardalarm2"))
    {
        auto HardPointAlarm2 = simulateHeart["Conthardalarm2"].asBool();
        m_pmsHardPointAlarm2.store(static_cast<bool>(HardPointAlarm2));
    }
    if(simulateHeart.isMember("Conthardalarm3"))
    {
        auto HardPointAlarm3 = simulateHeart["Conthardalarm3"].asBool();
        m_pmsHardPointAlarm3.store(static_cast<bool>(HardPointAlarm3));
    }

    if(simulateHeart.isMember("suspensionAbn"))
    {
        auto SuspensionAbnormal = simulateHeart["suspensionAbn"].asBool();
        m_pmsSuspensionAbnormal.store(static_cast<bool>(SuspensionAbnormal));
    }
    if(simulateHeart.isMember("busbarAbn"))
     {
        auto BusbarAbnormal = simulateHeart["busbarAbn"].asBool();
        m_pmsBusbarAbnormal.store(static_cast<bool>(BusbarAbnormal));
     }
  


   
    
}
void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConfig)
{
    // TIS_Info::MVBConfig mvbConfig;
    m_mvbPublicConfig = mvbConfig.mvbPublicCfg;

    m_trdpConfig.direction = mvbConfig.netPortCfg.direction;
    m_trdpConfig.sysID = mvbConfig.netPortCfg.sysID;
    m_trdpConfig.unitNum = mvbConfig.netPortCfg.unitNum;
    m_trdpConfig.carNum = mvbConfig.netPortCfg.carNum;
    m_trdpConfig.commonComID = mvbConfig.netPortCfg.commonPortNetA;
    m_trdpConfig.heartComID = mvbConfig.netPortCfg.heartPortNetA;
    m_trdpConfig.tcmsComID = mvbConfig.netPortCfg.tcmsPortNetA;



    /*
    unsigned int heartComID = 0;  // 发送心跳数据comid
    unsigned int commonComID = 0; // 接收公共端口数据comid
    unsigned int tcmsComID = 0;   // 接收tcms数据comid
    
    uint8_t direction = 0xEB; // 流向，默认为0xEB，表示VCU接收数据
    uint8_t sysID = 0;             // 系统标识
    uint8_t unitNum = 1;           // 单元号
    uint8_t carNum = 1;            // 车厢号
    uint8_t masterMark = 0; //预留，默认为0，表示不区分主从
    
    
    
    */
    // m_amifSwitch = mvbConfig.amifCfg;
    // m_trdpConfig = mvbConfig.trdpCfg;
    // m_mvbPublicConfig = mvbConfig.mvbPublicCfg;
    m_version = parseVersionString(m_mvbPublicConfig.version);
    const std::string udpbc_name = "mvb_udp_client";
    auto udpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(udpbc_name);
    //  m_udpClient.lock()->subscribe([this](_Kits::UdpClient::SharedDataBuffer data)
    //   { 
    //     if (!data) 
    //     { 
    //         return; 
    //     } 
    //     processTask(std::vector<uint8_t>(data->begin(), data->end())); 
    // });
    if (udpClient)
    {
        udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer data)
        {
            if (!data)
            {
                return;
            }
            onUdpDataReceived(std::vector<uint8_t>(data->begin(), data->end()));
        });
        //udpClient->setReceiveCallback([this](const std::vector<uint8_t> &&data) { onUdpDataReceived(std::move(data)); });
        //udpClient->start();
    }
    //auto alarmUdp = _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(m_mvbAmifName);
   
    //发送udp 到 vcm
    //const std::string send_udp_name = "udp_send_vcm";
   // m_udpClient =  _Service::UdpCenter::getUdpClient<std::shared_ptr<UdpClient>>(send_udp_name);
    // if (auto sender = m_udpClient.lock())
    // {
    //     sender->start();
     
    // }




}




void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        LogError("recv data error, len ={}", data.size());
        return;
    }

    TIS_Info::MVBuDPHeader mvbData;
    //TIS_Info::TrdpHeader header;
    parseTrdpHeader(data, mvbData);
    LogInfo("recv all udp comId={},data={}", mvbData.comid, ByteArrayTools::hexString(data.data(), data.size()));
    const std::size_t actualPayloadLen = data.size() - m_headLength - 2;
    if (mvbData.length != actualPayloadLen)
    {
        LogError("recv udp payload length mismatch, comId={}, headerLen={}, actualLen={}",
                mvbData.comid, mvbData.length, actualPayloadLen);
        return;
    }

    //const std::size_t payloadLength = data.size() - m_headLength;
    // if (header.datasetLength > payloadLength)
    // {
    //     LogError("recv trdp payload mismatch, comId={}, headerLen={}, actualLen={}", header.comId, header.datasetLength, payloadLength);
    //     return;
    // }

    QVariantMap dataMap;
    std::vector<uint8_t> processData(data.begin() + m_headLength, data.begin() + data.size() - 2);
    if (mvbData.comid == m_trdpConfig.commonComID)
    {
        parseCommonData(processData, dataMap);
        //sendTcmsData(dataMap);
        dataMap["dataSource"] = "ccu_data";
        LogInfo("recv udp comId={},data={}", mvbData.comid, ByteArrayTools::hexString(data.data(), data.size()));
    }
    else if (mvbData.comid == m_trdpConfig.tcmsComID)
    {
       // parseCCUData(processData, dataMap);
        dataMap["dataSource"] = "hangkuai_test_ccu_data";
    }
    displayRecvPortData(dataMap);
}

// void MVBController::sendTcmsData(const QVariantMap &recvData)
// {
//     int curStartStation = recvData["startStation"].toInt();
//     int curEndStation = recvData["endStation"].toInt();
//     // 行别切换
//     TIS_Info::MVBCommunicationInfo mvbCommInfo;
//     mvbCommInfo.startStation = curStartStation;
//     mvbCommInfo.endStation = curEndStation;
//     mvbCommInfo.currentStationId = recvData["currentStation"].toInt();
//     mvbCommInfo.strLineName = m_mvbPublicConfig.lineName;
//     mvbCommInfo.dSpeed = recvData["trainSpeed"].toDouble() / 100;
//     if (m_startStation != curStartStation && m_endStation != curEndStation && curStartStation != 0 && curEndStation != 0)
//     {
//         m_lineDir = curStartStation < curEndStation ? 0 : 1;
//         m_startStation = curStartStation;
//         m_endStation = curEndStation;
//         LogInfo("行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
//                 m_lineDir,
//                 m_startStation,
//                 m_endStation,
//                 mvbCommInfo.currentStationId,
//                 mvbCommInfo.dSpeed);
//     }
//     mvbCommInfo.nLineDirection = m_lineDir;
//     senderMVBCommunicationsendMVBComInfo(mvbCommInfo);
// }
void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::MVBuDPHeader &header)
{
    if (data.size() < m_headLength + 2)
    {
        return;
    }
    header.head[0]      = ByteArrayTools::readFromVectorBE<uint8_t>(data, 0);
    header.head[1]     = ByteArrayTools::readFromVectorBE<uint8_t>(data, 1);
    header.direction  = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    header.sysID      = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    header.counter    = ByteArrayTools::readFromVectorBE<uint32_t>(data, 4);
    header.time       = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.comid      = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.unitNum    = ByteArrayTools::readFromVectorBE<uint8_t>(data, 16);
    header.carNum     = ByteArrayTools::readFromVectorBE<uint8_t>(data, 17);
    header.masterMark = ByteArrayTools::readFromVectorBE<uint8_t>(data, 18);
    header.reserve[0]   = ByteArrayTools::readFromVectorBE<uint8_t>(data, 19);
    header.reserve[1]   = ByteArrayTools::readFromVectorBE<uint8_t>(data, 20);
    header.reserve[2]   = ByteArrayTools::readFromVectorBE<uint8_t>(data, 21);
    header.length     = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);


}
void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
{
    if (data.size() < m_headLength)
    {
        return;
    }
    header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
    header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
    header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
    header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
    header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
    header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(1000);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}
uint16_t MVBController::parseVersionString(const std::string &versionStr)
{
    std::vector<int> parts;
    size_t start = 0;
    size_t end = versionStr.find('.');
    
    // 解析三个部分
    while (end != std::string::npos && parts.size() < 2) {
        std::string part = versionStr.substr(start, end - start);
        try {
            parts.push_back(std::stoi(part));
        } catch (...) {
            return 0;
        }
        start = end + 1;
        end = versionStr.find('.', start);
    }
    
    // 最后一部分
    if (start < versionStr.length()) {
        std::string part = versionStr.substr(start);
        try {
            parts.push_back(std::stoi(part));
        } catch (...) {
            return 0;
        }
    }
    
    if (parts.size() != 3) {
        return 0;
    }
    
    int major = parts[0];
    int minor = parts[1];
    int revision = parts[2];
    
    if (major < 0 || major > 15 || minor < 0 || minor > 15 || revision < 0 || revision > 255) {
        return 0;
    }
    
    return (major << 12) | (minor << 8) | revision;
}
void MVBController::createHLGMVBData(std::vector<uint8_t> & data)
{
    if(data.empty())
    {
        return;

    }
    //应用程序对计数器进行周期性累加。 回流轨心跳
    ByteArrayTools::writeToVectorBE<uint16_t>(data, m_aliveId, m_headLength);

    //反馈TCMS心跳。
    ByteArrayTools::writeToVectorBE<uint16_t>(data, m_tcmsaliveId.load(), m_headLength + 2);

    //版本信息
    ByteArrayTools::writeToVectorBE<uint16_t>(data, m_version, m_headLength +4);


    //自检结果

    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 0, m_selfstatus);
    //回流轨几何测量模块故障
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 1, m_Module1Flt);
    //回流轨连续成像模块故障
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 2, m_Module2Flt);
    //靴轨监控模块故障
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 3, m_Module3Flt);

    //靴轨燃弧传感器故障
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 4, m_Module4Flt);
    //回流轨水平距离超限
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 5, m_HorDisFlt);
    //回流轨垂直距离超限
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 6, m_VerDisFlt);
    //回流轨缺陷报警
    ByteArrayTools::setBitInVectorLSB(data, m_headLength + 6, 7, m_ComFlt);

    //回流轨水平距离超限值
    ByteArrayTools::writeToVectorBE<uint8_t>(data, m_HorDis, m_headLength + 7);

    //回流轨垂直距离超限值
    ByteArrayTools::writeToVectorBE<uint8_t>(data, m_VerDis, m_headLength + 8);

    //回流轨缺陷报警原因
    ByteArrayTools::writeToVectorBE<uint8_t>(data, m_Com, m_headLength + 9);







}
void MVBController::sendAliveData()
{
    std::shared_ptr<_Kits::UdpClient> strongPtr = m_udpClient.lock();
    if (!strongPtr)
    {
        strongPtr = m_udpClient.lock();
    }
    if (strongPtr)
    {
        ++m_aliveId; // 心跳id自增

        // TIS_Info::TrdpHeader header;
        // header.comId = m_trdpConfig.heartComID; // 4X150 待验证
        // header.sequenceCounter = m_aliveId;
        // header.datasetLength = 800;//
        // header.protocolVersion = 0x0100;
        // header.msgType = 0x5064;

        TIS_Info::MVBuDPHeader header;
        header.head[0] = 0x68;
        header.head[1] = 0x69;
        header.direction = m_trdpConfig.direction;
        header.sysID = m_trdpConfig.sysID;
        header.counter = m_aliveId;
        header.time = static_cast<uint32_t>(std::time(nullptr));
        header.comid = m_trdpConfig.heartComID;
        // 这三个也建议从配置文件读
        header.unitNum = m_trdpConfig.unitNum;
        header.carNum = m_trdpConfig.carNum;
        header.masterMark = m_trdpConfig.masterMark;

        header.reserve[0] = 0;
        header.reserve[1] = 0;
        header.reserve[2] = 0;

        header.length = 10;
        LogInfo("trdpConfig.direction = 0x{:02X}", m_trdpConfig.direction);


        //这里是协议头
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, m_aliveId, 0);
        // ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.protocolVersion, 4);
        // ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.msgType, 6);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comId, 8);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.etbTopoCnt, 12);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.opTrnTopoCnt, 16);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.datasetLength, 20);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.reserved01, 24);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyComId, 28);
        // ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyIpAddress, 32);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.head[0], 0);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.head[1], 1);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.direction, 2);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.sysID, 3);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.counter, 4);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.time, 8);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comid, 12);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.unitNum, 16);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.carNum, 17);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.masterMark, 18);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.reserve[0], 19);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.reserve[1], 20);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, header.reserve[2], 21);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.length, 22);

        // // 生成校验码
        // header.headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, 36);
        // LogInfo("sheader.headerFcs={}", header.headerFcs);

      
            // 协议里面定义的是大端，但是四方所是按小端来的
       // ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, header.headerFcs, 36);
        if(m_isHLGdata)
        {
            createHLGMVBData(m_heartData);
            uint16_t checksum = getUdpProxyChecksum16(m_heartData.data(), 34);
            ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, checksum, m_headLength + header.length);
            const std::size_t totalLen = 36;
            LogInfo("crc input len={}", totalLen - 2);
            LogInfo("crc input={}", ByteArrayTools::hexString(m_heartData.data(), totalLen - 2));

            uint16_t crc = getUdpProxyChecksum16(m_heartData.data(), static_cast<uint16_t>(totalLen - 2));
            LogInfo("local crc=0x{:04X}", crc);


        }
        else
        {
            // ========== 应用数据部分 (从 m_headLength = 40 开始) ==========
            // ComId: 2i12j, 对应弓网系统(PMS)发送给VCU的数据

            // // 应用数据    
            // ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_aliveId, m_headLength + 40);
            // //// Byte272-273: 版本信息 (UNSIGNED16)   // 格式: xxxx.yyyy.zzzzzzzz, 高4位主版本, 低8位修正版本
            // ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_version, m_headLength + 42);

            // // Byte274: 自检状态 (UNSIGNED8)
            // // 0=不可用, 1=正在自检, 2=自检通过, 3=自检失败
            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, m_pmsSelfCheckStatus, m_headLength + 274);

            // //============================================================
        

            // bool faults[8] = {
            //     m_pmsNetFault.load(),
            //     m_pmsArcModuleFault.load(),
            //     m_pmsCameraFault.load(),
            //     m_pmsGeoDeviceFault.load(),
            //     m_pmsCompDeviceFault.load(),
            //     m_pmsTempDeviceFault.load(),
            //     m_pmsSusDeviceFault.load(),
            //     m_pmsSusTrigDeviceFault.load()
            // };
            // LogInfo("Fault values: [{}, {}, {}, {}, {}, {}, {}, {}]", 
            // faults[0], faults[1], faults[2], faults[3], 
            // faults[4], faults[5], faults[6], faults[7]);

            // // 设置前的值
            // uint8_t beforeVal = m_heartData[m_headLength + 275];
            // LogInfo("Before setting: 0x{:02X} (binary: {:08b})", beforeVal, beforeVal);

            // // 设置位
            // for (int i = 0; i < 8; i++) {
            //     ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, i, faults[i]);
            // }

            // // 设置后的值
            // uint8_t afterVal = m_heartData[m_headLength + 275];
            // LogInfo("After setting: 0x{:02X} (binary: {:08b})", afterVal, afterVal);

            // //============================================================



            // //弓网系统网络通讯故障（内网故障）   // Bit0: 弓网系统网络通讯故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 0, m_pmsNetFault.load());
            // // // // Bit1: 弓网系统燃弧检测模块故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 1, m_pmsArcModuleFault.load());
            // //  // Bit2: 弓网系统视频监控相机状态故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 2, m_pmsCameraFault.load());
            // // // Bit3: 弓网系统几何参数检测设备故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 3, m_pmsGeoDeviceFault.load());
            // // // Bit4: 弓网系统车底补偿设备故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 4, m_pmsCompDeviceFault.load());
            // //     // Bit5: 弓网系统温度检测设备故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 5, m_pmsTempDeviceFault.load());
            // // //bit 6 弓网系统悬挂检测设备故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 6, m_pmsSusDeviceFault.load());
            // // //bit 7 弓网系统悬挂触发模块检测设备故障
            // // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 275, 7, m_pmsSusTrigDeviceFault.load());

            // //byte 276  bit0 :弓网系统光纤分析仪故障
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 0, m_pmsFiberAnalyzerFault.load());
            // // Bit1: 弓网系统电源控制箱故障
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 1, m_pmsPowerBoxFault.load());
            // // Bit2: 燃弧一级告警  燃弧时长≥500ms
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 2, m_pmsArcAlarm1.load());
            // // Bit3: 燃弧二级告警  燃弧时长300ms＜X＜500ms
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 3, m_pmsArcAlarm2.load());
            //     // Bit4: 燃弧三级告警  燃弧时长100ms＜X＜300ms
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 4, m_pmsArcAlarm3.load());
            //     // Bit5: 温度一级告警  温度范围≥250℃
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 5, m_pmsTempAlarm1.load());
            //     // Bit6: 温度二级告警 温度范围150℃＜X＜250℃
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 6, m_pmsTempAlarm2.load());
            // //Bit7 :温度三级告警 温度范围100℃＜X＜150℃
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 276, 7, m_pmsTempAlarm3.load());

            // //byte 277 bit0: 接触线导高异常一级  X＜D-18mm，X＞D+18mm（导高根据线路提供）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 0, m_pmsHeightAlarm1.load());
            // // Bit1: 接触线导高异常二级 D-18mm≤X＜D-13mm，D+13mm＜X≤D+18mm（导高根据线路提供）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 1, m_pmsHeightAlarm2.load());
            // // Bit2: 接触线导高异常三级 D-13mm≤X＜D-8mm，D+8mm＜X≤D+13mm（导高根据线路提供）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 2, m_pmsHeightAlarm3.load());
            // // bit 3  接触线拉出值异常一级 L＞320mm
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 3, m_pmsPullValAlarm1.load());

            // // Bit4: 接触线拉出值异常二级 300mm＜L≤320mm
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 4, m_pmsPullValAlarm2.load());

            // // bit 5 : 接触线拉出值异常三级 300mm＜L≤310mm
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 5, m_pmsPullValAlarm3.load());

            // // bit 6 : 弓网接触力异常一级145N≤X＜160N，60N＜X≤75N（速度V=80km/h）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 6, m_pmsContactForceAlarm1.load());

            // //bit 7 : 弓网接触力异常二级 160N≤X＜175N，45N＜X≤60N（速度V=80km/h）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 277, 7, m_pmsContactForceAlarm2.load());

            // // byte 278 bit0: 弓网接触力异常三级 145N≤X＜160N，60N＜X≤75N（速度V=80km/h）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 0, m_pmsContactForceAlarm3.load());
            //     ByteArrayTools::write
            // // bit 1 :接触线硬点异常一级 硬点＞100g（限值根据实际设置接触力提供）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 1, m_pmsHardPointAlarm1.load());
            // // bit2 :接触线硬点异常二级  70g＜硬点≤100g（限值根据实际设置接触力提供）

            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 2, m_pmsHardPointAlarm2.load());
            // // bit3: 接触线硬点异常三级 50g＜硬点≤70g（限值根据实际设置接触力提供）
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 3, m_pmsHardPointAlarm3.load());
            // //bit 4 : 弓网检测到悬挂异常
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 4, m_pmsSuspensionAbnormal.load());
            // //bit 5 :弓网检测到汇流排异常
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 278, 5, m_pmsBusbarAbnormal.load());
            // // bit 6 bit 7  保留



        }


            // 软件版本v1.0

            // uint8_t major = static_cast<uint8_t>(m_version >> 8);
            // uint8_t minor = static_cast<uint8_t>(m_version & 0xFF);
            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, major, m_headLength + 2);
            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, minor, m_headLength + 3);
            // // 自检结果
            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, 0, m_headLength + 4);
            // // TCMS生命信号异常
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 0, false);
            // // 设备状态
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 1, false);
            // // 受电弓严重异常
            // ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 2, false);
            auto headvector = m_heartData;
            const std::size_t totalLen = m_headLength + header.length + 2;  // 24 + 10 + 2 = 36
            std::vector<uint8_t> sendData(headvector.begin(), headvector.begin() + totalLen);

            std::vector<uint8_t> processData(sendData.begin() + m_headLength, sendData.end() - 2);
            LogInfo("send headvector data={}", ByteArrayTools::hexString(processData.data(), processData.size()));

            

            //发送
            // if(auto client = m_udpClient.lock())
            // {
            //     client->sendAsync(m_heartUdpName, std::move(headvector));
            // }
        // strongPtr->sendAsync("udp_send_vcm", std::move(headvector));
        // strongPtr->sendCoro("udp_send_vcm1", std::move(headvector));
        // std::vector<uint8_t> processData(headvector.begin() + m_headLength, headvector.end());
        //     LogInfo("send  headvector data={}", ByteArrayTools::hexString(processData.data(), processData.size()));
            
            strongPtr->post("udp_send_vcm1", std::move(sendData));
            //strongPtr->sendAsync("udp_send_vcm1", std::move(headvector));
            
            // std::vector<uint8_t> processData(m_heartData.begin() + m_headLength, m_heartData.end());
            // LogInfo("send data={}", ByteArrayTools::hexString(processData.data(), processData.size()));
        
        displayHeartData();
    }
}

// void MVBController::parseCCUData(const std::vector<uint8_t> &data, QVariantMap &outputData)
// {
//     if (data.size() == 0)
//     {
//         return;
//     }
//     // CCU生命信号
//     outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
//     std::bitset<8> batteryStatus(ByteArrayTools::readFromVectorBE<uint8_t>(data, 2));
//     // 蓄电池牵引预备
//     outputData["batteryTrcOK"] = static_cast<bool>(batteryStatus[0]);
//     // 蓄电池牵引启动
//     outputData["batteryTrcOn"] = static_cast<bool>(batteryStatus[1]);

//     std::bitset<8> alarm(ByteArrayTools::readFromVectorBE<uint8_t>(data, 3));
//     // 火灾报警系统复位
//     outputData["alarmReset"] = static_cast<bool>(alarm[0]);
//     // 火灾报警系统消音
//     outputData["alarmSilence"] = static_cast<bool>(alarm[1]);

//     std::bitset<8> odd(ByteArrayTools::readFromVectorBE<uint8_t>(data, 4));
//     // ODD休眠信号
//     outputData["sleepSgnl"] = static_cast<bool>(odd[0]);
//     // ODD远程复位信号
//     outputData["resetSgnl"] = static_cast<bool>(odd[1]);

//     std::bitset<8> panData(ByteArrayTools::readFromVectorBE<uint8_t>(data, 5));
//     // 列车休眠指令
//     outputData["sleep"] = static_cast<bool>(panData[0]);
//     // 2车受电弓升起
//     outputData["pan2Up"] = static_cast<bool>(panData[1]);
//     // 5车受电弓升起
//     outputData["pan5Up"] = static_cast<bool>(panData[2]);
//     // 列车开门状态
//     outputData["doorOpen"] = static_cast<bool>(panData[3]);
//     // 列车关门状态
//     outputData["doorCls"] = static_cast<bool>(panData[4]);
//     // 正线
//     outputData["lineNorm"] = static_cast<bool>(panData[5]);
//     // 折返线
//     outputData["lineTurn"] = static_cast<bool>(panData[6]);
//     // 出入段线
//     outputData["lineInout"] = static_cast<bool>(panData[7]);

//     // 列车车次号
//     outputData["trainNum"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
//     // 网压
//     outputData["vluVlt"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
//     // 网流
//     outputData["vluCur"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);

//     std::bitset<8> mode(ByteArrayTools::readFromVectorBE<uint8_t>(data, 12));
//     // 零速信号
//     outputData["nonspeed"] = static_cast<bool>(mode[0]);
//     // 洗车模式
//     outputData["carWashVal"] = static_cast<bool>(mode[1]);
//     // AM模式
//     outputData["AMMode"] = static_cast<bool>(mode[2]);
//     // FAM模式
//     outputData["FAMMode"] = static_cast<bool>(mode[3]);

//     // 列车外部温度
//     outputData["outTemp"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 13);
//     // 列车车次号
//     outputData["trainNumb"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
//     // 1车2轴1架参考轮径值
//     outputData["wheel112"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
//     // 2车2轴1架参考轮径值
//     outputData["wheel212"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
//     // 3车2轴1架参考轮径值
//     outputData["wheel312"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
//     // 4车2轴1架参考轮径值
//     outputData["wheel412"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
//     // 5车2轴1架参考轮径值
//     outputData["wheel512"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
//     // 6车2轴1架参考轮径值
//     outputData["wheel612"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 26);
// }

// void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
// {
//     if (data.size() == 0)
//     {
//         return;
//     }
//     // CCU生命信号
//     outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
//     // 软件版本
//     outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
//     // 自检结果
//     outputData["testRlt"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
//     // 受电弓严重异常
//     uint8_t panData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
//     std::bitset<8> bit(panData);
//     outputData["tcmsLife"] = static_cast<bool>(bit[0]);
//     outputData["pmsStatus"] = static_cast<bool>(bit[1]);
//     outputData["panFault"] = static_cast<bool>(bit[2]);
// }

void MVBController::displayHeartData()
{
     Json::Value heartData(Json::objectValue);
    if(m_isHLGdata)
    {
        //heartData["Version"] = m_version;
        heartData["Version"] = fmt::format("{}.{}.{}",
                                   (m_version >> 12) & 0x0F,
                                   (m_version >> 8) & 0x0F,
                                   m_version & 0xFF);

        heartData["TestRes"] = m_selfstatus.load();
        heartData["Module1Flt"] = m_Module1Flt.load();
        heartData["Module2Flt"] = m_Module2Flt.load();
        heartData["Module3Flt"] = m_Module3Flt.load();
        heartData["Module4Flt"] = m_Module4Flt.load();
        heartData["HorDisFlt"] = m_HorDisFlt.load();
        heartData["VerDisFlt"] = m_VerDisFlt.load();
        heartData["ComFlt"] = m_ComFlt.load();

        heartData["HorDis"] = m_HorDis.load();

        heartData["VerDis"]= m_VerDis.load();
        heartData["Com"] = m_Com.load();
        heartData["dataSource"] = "hangkuai_test_hlg_heart";


    }
    else
    {
       
        heartData["Version"] = m_version;
        heartData["CheckStatus"] = m_pmsSelfCheckStatus;
        heartData["NetFLT"] = m_pmsNetFault.load();
        heartData["RhdeviceMFlt"] = m_pmsArcModuleFault.load();
        heartData["CameradeviceFlt"] = m_pmsCameraFault.load();
        heartData["GeodeviceFlt"] = m_pmsGeoDeviceFault.load();
        heartData["pisdeviceFlt"] = m_pmsCompDeviceFault.load();
        heartData["tempdeviceFlt"] = m_pmsTempDeviceFault.load();
        heartData["SusdeviceFlt"] = m_pmsSusDeviceFault.load();
        heartData["SustrideviceFlt"] = m_pmsSusTrigDeviceFault.load();
        heartData["FibanalFlt"] = m_pmsFiberAnalyzerFault.load();
        heartData["PowboxFlt"] = m_pmsPowerBoxFault.load();
        heartData["ArcAlarm1"] = m_pmsArcAlarm1.load();
        heartData["ArcAlarm2"] = m_pmsArcAlarm2.load();
        heartData["ArcAlarm3"] = m_pmsArcAlarm3.load();
        heartData["TempAlarm1"] = m_pmsTempAlarm1.load();
        heartData["TempAlarm2"] = m_pmsTempAlarm2.load();
        heartData["TempAlarm3"] = m_pmsTempAlarm3.load();
        heartData["HeigcontwirAbn1"] = m_pmsHeightAlarm1.load();
        heartData["HeigcontwirAbn2"] = m_pmsHeightAlarm2.load();
        heartData["HeigcontwirAbn3"] = m_pmsHeightAlarm3.load();
        heartData["PullValAbn1"] = m_pmsPullValAlarm1.load();
        heartData["PullValAbn2"] = m_pmsPullValAlarm2.load();
        heartData["PullValAbn3"] = m_pmsPullValAlarm3.load();
        heartData["pancontPrealarm1"] = m_pmsContactForceAlarm1.load();
        heartData["pancontPrealarm2"] = m_pmsContactForceAlarm2.load();
        heartData["pancontPrealarm3"] = m_pmsContactForceAlarm3.load();
        heartData["Conthardalarm1"] = m_pmsHardPointAlarm1.load();
        heartData["Conthardalarm2"] = m_pmsHardPointAlarm2.load();
        heartData["Conthardalarm3"] = m_pmsHardPointAlarm3.load();
        heartData["suspensionAbn"] = m_pmsSuspensionAbnormal.load();
        heartData["busbarAbn"] = m_pmsBusbarAbnormal.load();
        heartData["dataSource"] = "hangkuai_test_heart";

    }

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, heartData);
}

// void MVBController::updateCommonInfo(QVariantMap &data)
// {

//     m_CurrentMvbInfo.cur_station_id = data.value("currentStation").toInt();
//     m_CurrentMvbInfo.next_station_id = data.value("nextStation").toInt();
//     m_CurrentMvbInfo.start_station_id = data.value("startStation").toInt();
//     m_CurrentMvbInfo.end_station_id = data.value("endStation").toInt();
//     m_CurrentMvbInfo.line_id = -1;
//     m_CurrentMvbInfo.train_id = data.value("trainNumb").toInt();
//     m_CurrentMvbInfo.iyear = data.value("year").toInt();
//     m_CurrentMvbInfo.imonth = data.value("month").toInt();
//     m_CurrentMvbInfo.iday = data.value("day").toInt();
//     m_CurrentMvbInfo.ihour = data.value("hour").toInt();
//     m_CurrentMvbInfo.iminute = data.value("minute").toInt();
//     m_CurrentMvbInfo.isecond = data.value("second").toInt();
//     m_CurrentMvbInfo.speed = data.value("trainSpeed").toFloat();
//     // m_CurrentMvbInfo.voltage = data.value("voltage").toFloat();
//     // m_CurrentMvbInfo.elec = data.value("electricity").toFloat();
//     // m_CurrentMvbInfo.atb_mode = data.value("ATBMode").toInt();
//     if (0 == m_CurrentMvbInfoStatus)
//     {
//         m_CurrentMvbInfoStatus = 1;
//     }
//     else if (2 == m_CurrentMvbInfoStatus)
//     {
//         std::lock_guard<std::mutex> lock(m_mutex);
//         m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
//         if (m_mvbInfoSqlvec.size() > 1000)
//         {
//             m_condition.notify_one();
//         }
//         m_CurrentMvbInfoStatus = 0;
//     }
// }
// void MVBController::updateCCUDataInfo(QVariantMap &data)
// {
//     m_CurrentMvbInfo.battery_status = -1;
//     m_CurrentMvbInfo.door_state = data.value("doorCls").toInt();
//     m_CurrentMvbInfo.panto_up = data.value("pan2Up").toInt();
//     if (0 == m_CurrentMvbInfoStatus)
//     {
//         m_CurrentMvbInfoStatus = 2;
//     }
//     else if (1 == m_CurrentMvbInfoStatus)
//     {
//         std::lock_guard<std::mutex> lock(m_mutex);
//         m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
//         if (m_mvbInfoSqlvec.size() > 1000)
//         {
//             m_condition.notify_one();
//         }
//         m_CurrentMvbInfoStatus = 0;
//     }
// }


} // namespace _Controllers
