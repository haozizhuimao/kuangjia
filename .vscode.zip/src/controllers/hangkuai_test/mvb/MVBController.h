#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>
// #include "kits/common/database/orm/TableStructs.h"
#include "tis_global/struct_details/mvb_struct.h"
#include <vector>
#include <thread>
#include <condition_variable>
#include <QVariantMap>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;

    //void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    void onRecvSimuteMvbData(const Json::Value &);
    TASK_LIST_BEGIN
    //SYNC_TASK_ADD(_Service::UdpCenter::dispatchClient, MVBController::setUdpClient);
 
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::MVBSimluteHeartData, MVBController::onRecvSimuteMvbData);
    TASK_LIST_END

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&);
    void sendTcmsData(const QVariantMap &);
    void onUdpAlarmReceived(const std::vector<uint8_t> &&);
    // void setConfigSwitch(const TIS_Info::MvbAmifConfig &,
    //                      const TIS_Info::MvbAsatConfig &,
    //                      const TIS_Info::TrdpConfig &,
    //                      const TIS_Info::MvbPublicConfig &);

     void setConfigSwitch(const TIS_Info::MVBConfig &);

    
     void createHLGMVBData(std::vector<uint8_t> &);// 回流轨 数据发送

  private:
    void heartFunc();
    void sendAliveData();
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // // 解析心跳数据
    // void parseHeartData(const std::vector<uint8_t> &, QVariantMap &);
    // // 解析trdp协议头
    void parseTrdpHeader(const std::vector<uint8_t> &, TIS_Info::TrdpHeader &);
    //杭15 udp协议头
    void parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::MVBuDPHeader &header);

    // // 解析车辆数据
    // void parseCCUData(const std::vector<uint8_t> &, QVariantMap &);
    // 界面展示接收数据
    void displayRecvPortData(QVariantMap &);
    Json::Value convertMvbDataToJson(const QVariantMap &);
    
    // 界面展示心跳数据
    void displayHeartData();
    // 解析告警数据
    //void parseAmifData(const Json::Value &);
    void setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue);

    // void updateCommonInfo(QVariantMap &);
    // void updateCCUDataInfo(QVariantMap &);
   // void writeMvbInfoToDBFun();
    uint16_t parseVersionString(const std::string &versionStr);

  private:
    std::atomic_bool m_bHolder = true;
    const std::string m_heartUdpName = "mvb_heart";
    const std::string m_udpName = "mvb";
    const std::string m_mvbAmifName = "mvb_amif";
    std::weak_ptr<_Kits::UdpClient> m_heartUdpClient;
    std::vector<uint8_t> m_recvData;
    std::vector<uint8_t> m_heartData;
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    bool m_isHLGdata = true;
    uint8_t m_pmsMajorVersion = 1;
    uint8_t m_pmsMinorVersion = 2;
    uint8_t m_pmsPatchVersion = 52;              // 补丁版本号 (对应0x34)
    uint8_t m_pmsSelfCheckStatus = 2;            // 自检状态 (2=通过)
    uint16_t m_version;
    std::atomic<uint16_t> m_tcmsaliveId = 0; // TCMS心跳使用的计数器
    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    int m_headLength = 0;   // trdp协议头长度

    int m_startStation = -1;
    int m_endStation = -1;
    int m_lineDir = -1;
    float m_speed = 0;
    
    TIS_Info::MvbAmifConfig m_amifSwitch;
    // std::vector<_Kits::_Orm::mvb_info> m_mvbInfoSqlvec;
    // _Kits::_Orm::mvb_info m_CurrentMvbInfo;
    std::atomic_int16_t m_CurrentMvbInfoStatus{0};
    std::thread m_mvbInfoWirteSqlThread;
    std::mutex m_mutex;
    std::condition_variable m_condition;
    std::atomic_bool m_writeDBFlag = false;

    TIS_Info::HKTrdpHeader m_trdpConfig;
    TIS_Info::MvbPublicConfig m_mvbPublicConfig;


     // 故障标志位
    std::atomic_bool m_pmsNetFault{false};                  // 网络通讯故障
    
    std::atomic_bool m_pmsArcModuleFault{false};             // 燃弧检测模块故障
    std::atomic_bool m_pmsCameraFault{false};                 // 视频监控相机故障
    std::atomic_bool m_pmsGeoDeviceFault{false};              // 几何参数检测设备故障
    std::atomic_bool m_pmsCompDeviceFault{false};             // 车底补偿设备故障
    std::atomic_bool m_pmsTempDeviceFault{false};             // 温度检测设备故障
    std::atomic_bool m_pmsSusDeviceFault{false};              // 悬挂检测设备故障
    std::atomic_bool m_pmsSusTrigDeviceFault{false};          // 悬挂触发模块故障
    std::atomic_bool m_pmsFiberAnalyzerFault{false};          // 光纤分析仪故障
    std::atomic_bool m_pmsPowerBoxFault{false};               // 电源控制箱故障

    // 告警标志位
     std::atomic_bool m_pmsArcAlarm1 {false};                   // 燃弧一级告警
    std::atomic_bool m_pmsArcAlarm2 {false};                   // 燃弧二级告警
    std::atomic_bool m_pmsArcAlarm3 {false};                   // 燃弧三级告警
    std::atomic_bool m_pmsTempAlarm1 {false};                  // 温度一级告警
    std::atomic_bool m_pmsTempAlarm2 {false};                  // 温度二级告警
    std::atomic_bool m_pmsTempAlarm3 {false};                  // 温度三级告警
    std::atomic_bool m_pmsHeightAlarm1 {false};                // 导高异常一级
    std::atomic_bool m_pmsHeightAlarm2 {false};                // 导高异常二级
    std::atomic_bool m_pmsHeightAlarm3 {false};                // 导高异常三级
    std::atomic_bool m_pmsPullValAlarm1 {false};               // 拉出值异常一级
    std::atomic_bool m_pmsPullValAlarm2 {false};               // 拉出值异常二级
    std::atomic_bool m_pmsPullValAlarm3 {false};               // 拉出值异常三级
    std::atomic_bool m_pmsContactForceAlarm1 {false};          // 接触力异常一级
    std::atomic_bool m_pmsContactForceAlarm2 {false};          // 接触力异常二级
    std::atomic_bool m_pmsContactForceAlarm3 {false};          // 接触力异常三级
    std::atomic_bool m_pmsHardPointAlarm1 {false};             // 硬点异常一级
    std::atomic_bool m_pmsHardPointAlarm2 {false};             // 硬点异常二级
    std::atomic_bool m_pmsHardPointAlarm3 {false};             // 硬点异常三级
    std::atomic_bool m_pmsSuspensionAbnormal {false};          // 悬挂异常
    std::atomic_bool m_pmsBusbarAbnormal {false};              // 汇流排异常


    //回流轨
    std::atomic_bool m_selfstatus {false};//自检结果
    std::atomic_bool m_Module1Flt {false};//回流轨几何测量模块故障
    
    std::atomic_bool m_Module2Flt {false};//回流轨连续成像模块故障
    std::atomic_bool m_Module3Flt {false};//靴轨监控模块故障
    std::atomic_bool m_Module4Flt {false};//靴轨燃弧传感器故障
    
    std::atomic_bool m_HorDisFlt{false}; // 回流轨水平距离超限
    std::atomic_bool  m_VerDisFlt{false};//回流轨垂直距离超限
    std::atomic_bool m_ComFlt{false};//回流轨缺陷报警

    std::atomic<uint8_t> m_HorDis;
    //uint8_t m_HorDis;//回流轨水平距离超限值
    std::atomic<uint8_t> m_VerDis;
    //uint8_t m_VerDis;//回流轨垂直距离超限值
    std::atomic<uint8_t> m_Com;

};
} // namespace _Controllers
