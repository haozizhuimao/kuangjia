/**
 *   用于定位任务结束Db生成与导出功能调起
 */
#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <json/value.h>
#include <memory>
#include "tis_global/enum_public/task_enum.h"
#include "tis_global/struct_details/sql_struct.h"
#include "kits/common/location_general/LocationBase.h"
#include "kits/database/postgresql_interface/location_export/PgLocationExport.h"


namespace _Controllers {
class LocationDbExportCtrl final : public ControllerBase<LocationDbExportCtrl>
{
    public:
        void onLocationEnd(const TIS_Info::task_data &);
        void moduleStarted(const TIS_Info::LocationConfigs &, const std::shared_ptr<_Kits::LocationBase> &);

        TASK_LIST_BEGIN
        ASYNC_TASK_ADD(_Service::LocationService::locationFinished, LocationDbExportCtrl::onLocationEnd);
        ASYNC_TASK_ADD(_Service::LocationService::initConfigInfo, LocationDbExportCtrl::moduleStarted);
        TASK_LIST_END
    private:
        std::unique_ptr<PgLocationExport> m_pgLocationExport = nullptr;
        bool m_isUseExport = false;
        bool m_isExporting = false;
};
}   // namespace _Controllers

