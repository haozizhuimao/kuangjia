#include "LocationDbExportCtrl.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/database/postgresql_interface/location_export/PgLocationExport.h"
#include "tis_global/Struct.h"

namespace _Controllers {
void LocationDbExportCtrl::onLocationEnd(const TIS_Info::task_data &taskInfo)
{
    PgLocationExport exporter;
    if (m_isUseExport && taskInfo.id != -1 && !m_isExporting)
    {
        m_isExporting = true;
        auto callBack = [](_Kits::Exporterv2::LogLevel level, const std::string &msg, float progress, bool isOk) {
            switch (level)
            {
            case _Kits::Exporterv2::LogLevel::Error:
                _Kits::LogError("{}", msg);
                break;
            case _Kits::Exporterv2::LogLevel::Information:
                _Kits::LogInfo("{}", msg);
                break;
            case _Kits::Exporterv2::LogLevel::Warning:
                _Kits::LogWarn("{}", msg);
                break;
            default:
                break;
            }

            Json::Value value;
            value["msg"] = msg;
            value["isOk"] = isOk;
            value["progress"] = progress;

            _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::exportInfo, value);
        };
        // exporter.Export("", 1, "D:/gwkj/test", callBack);
        exporter.Export("", taskInfo.id, taskInfo.save_path, callBack);
        m_isExporting = false;
    }
}

void LocationDbExportCtrl::moduleStarted(const TIS_Info::LocationConfigs &config, const std::shared_ptr<_Kits::LocationBase> &location)
{
    m_isUseExport = config.usd_export;
}
} // namespace _Controllers