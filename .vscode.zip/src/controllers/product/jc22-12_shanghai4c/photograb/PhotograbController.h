#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include "kits/camera/basler/base/BaslerBase.h"
#include <unordered_map>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <condition_variable>
#include "kits/utility/object_pool/ObjectPool.h"
//#include "tis_global/Function.h"
#include "tis_global/Field.h"
#include "tis_global/Struct.h"
#include <QMap>
#include <QReadWriteLock>
#include <QString>

struct ImageData
{
    QByteArray image;
    qint64 timestamp;
    QString camera;
};

class TimestampMap
{
  public:
    void insert(qint64 timestamp, const QString &value)
    {
        QWriteLocker locker(&lock);
        if (map.size() > 1000)
        {
            QList<qint64> keyList = map.keys();
            map.remove(keyList[0]);
        }
        map.insert(timestamp, value);
    }
    QString findClosest(qint64 target) const
    {
        QReadLocker locker(&lock);

        if (map.isEmpty())
        {
            return QString();
        }

        auto it = map.lowerBound(target);

        if (it == map.end())
        {
            --it;
            return it.value();
        }

        if (it == map.begin())
        {
            return it.value();
        }

        auto prev = it;
        --prev;
        const qint64 diffPrev = target - prev.key();
        const qint64 diffCurrent = it.key() - target;

        return (diffPrev <= diffCurrent) ? prev.value() : it.value();
    }

  private:
    mutable QReadWriteLock lock;
    QMap<qint64, QString> map;
};

namespace _Controllers {
class PhotograbController : public ControllerBase<PhotograbController>
{
  public:
    PhotograbController();
    ~PhotograbController();
    void getcaminfoString(const QVariant &);
    void savePictureInFile(const ImageData &, const QString &);
    void refreshTask(const QString &);
    void savePictureInFileNetcam(std::shared_ptr<TIS_Info::ImageBuffer>);
    void refreshInitinfo(const QVariantMap &);
    void refreshInitinfoNet(const QVariantMap &);
    void RefreshLocation(const TIS_Info::LocationData &);

    void onNewClient(const std::string &, std::shared_ptr<_Kits::TcpClient>);
    void onClientDisconnect(qintptr);
    void onRecvData(const QByteArray &, const QString &);
    void onRecvClientdata_0(const std::vector<uint8_t> &&);
    void onRecvClientdata_1(const std::vector<uint8_t> &&);
    void onRecvClientdata_2(const std::vector<uint8_t> &&);
    void onRecvClientdata_3(const std::vector<uint8_t> &&);

    void onReleaseClient_0();
    void onReleaseClient_1();
    void onReleaseClient_2();
    void onReleaseClient_3();
    void praseData(std::shared_ptr<QByteArray> data);

    void initNetCamera(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>,
                       std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>>);

    void onTaskBegin(const TIS_Info::TaskInfo &taskinfo);
    void onTaskEnd(const TIS_Info::TaskInfo &taskinfo);
    void onReleaseCamera(int);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::initPatrolCtrls, PhotograbController::initNetCamera);
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::initinfo, PhotograbController::refreshInitinfoNet);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::initinfosend, PhotograbController::refreshInitinfo);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::sendinitinfoTopage, PhotograbController::getcaminfoString);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, PhotograbController::RefreshLocation);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, PhotograbController::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, PhotograbController::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::BaslerManager::sendStopsignal, onReleaseCamera);
    SYNC_TASK_ADD(TIS_Info::TcpServerCenter::newClient, PhotograbController::onNewClient);
    TASK_LIST_END
  private:
    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>> m_udm_cam =
        std::make_shared<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>();
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> m_udm_camInfo =
        std::make_shared<std::unordered_map<std::string, TIS_Info::CameraInfo>>();
    QVariantMap m_initinfo;
    QStringList ipandsnlist;
    QStringList m_iplist;
    TimestampMap timestampMap;
    QString mytaskdir;
    QMap<QString, int> countmap;
    mutable QReadWriteLock tasklocker;
    void softTriger();

    std::atomic_bool mb_thread_recvData_stop = false;
    std::thread m_thread_processData;
    QString poleNow;
    void _dealprocessData();
    size_t findNearestIndex(qint64, size_t);
    std::shared_ptr<_Kits::ObjectPool<QByteArray>> mp_pool;

    int clientcount = 0;
    QMap<int, QString> m_client_count_map;
    QList<QByteArray> m_client_buffer_list;
    inline const static QByteArray TCP_HEADER = "{[(tcp_header)]}";
    inline const static QByteArray TCP_TAIL = "{[(tcp_tail)]}";
    void processImage(const QByteArray &, const QString &);

    // 数据包格式常量
    static constexpr int TIMESTAMP_SIZE = 8;
    static constexpr int IMG_SIZE_SIZE = 4;
};
} // namespace _Controllers
