#include "PhotograbController.h"
#include "service/AppFramework.h"
#include <QDateTime>
#include <QImage>
#include <QVariantMap>
#include <qvariant.h>
#include <QBuffer>
#include <QDir>
#include <QFile>
#include <QList>
#include <QMutex>
#include <functional>
#include <fstream>

#ifndef Q_MOC_RUN
#if defined(emit)
#undef emit
#include <tbb/concurrent_vector.h>
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_vector.h>
#include <tbb/concurrent_queue.h>
#endif // defined(emit)
#endif // Q_MOC_RUN
int testcount = 0;
tbb::concurrent_vector<std::pair<QString, qint64>> pathVector;
tbb::concurrent_queue<ImageData> imageQueue;
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

QImage ConvertToQImage(const uint8_t *buffer, int width, int height, int channels)
{
    if (channels == 1)
    {
        // 灰度图像
        QImage image(width, height, QImage::Format_Grayscale8);
        for (int y = 0; y < height; ++y)
        {
            memcpy(image.scanLine(y), buffer + y * width, width);
        }
        return image;
    }
    else if (channels == 3)
    {
        // RGB彩色图像
        QImage image(width, height, QImage::Format_RGB888);
        for (int y = 0; y < height; ++y)
        {
            memcpy(image.scanLine(y), buffer + y * width * 3, width * 3);
        }
        return image;
    }
    return QImage();
}

size_t PhotograbController::findNearestIndex(qint64 target, size_t currentSize)
{
    size_t left = 0;
    size_t right = currentSize;
    while (left < right)
    {
        size_t mid = left + (right - left) / 2;
        qint64 midVal = pathVector[mid].second;

        if (midVal < target)
        {
            left = mid + 1;
        }
        else
        {
            right = mid;
        }
    }
    if (left == currentSize)
        return currentSize - 1;
    if (left == 0)
        return 0;
    qint64 diffLeft = std::abs(pathVector[left - 1].second - target);
    qint64 diffRight = std::abs(pathVector[left].second - target);
    return (diffLeft <= diffRight) ? left - 1 : left;
}

/**
 * @brief 删除指定目录下所有包含特定子字符串的文件
 * @param substring 需要匹配的文件名子字符串
 * @param directory 目标目录路径（默认当前目录）
 * @return 成功删除文件的数量（-1表示目录错误）
 */
int deleteFilesContaining(const QString &substring, const QString &directory = QDir::currentPath())
{
    static QMutex mutex;
    QMutexLocker locker(&mutex);

    // 验证目录有效性
    QDir targetDir(directory);
    if (!targetDir.exists())
    {
        qWarning().nospace() << "[错误] 目录不存在: " << directory;
        return -1;
    }

    // 获取文件列表（排除目录）
    const QStringList files = targetDir.entryList(QDir::Files | QDir::NoDotAndDotDot);
    int deletedCount = 0;
    // 遍历文件
    foreach (const QString &fileName, files)
    {
        if (fileName.contains(substring, Qt::CaseInsensitive))
        { // 大小写不敏感匹配
            const QString fullPath = targetDir.filePath(fileName);
            QFile::setPermissions(directory, QFile::ReadOther | QFileDevice::WriteOther);
            if (QFile::remove(fullPath))
            {
                qDebug().nospace() << "[成功] 已删除文件: " << fullPath;
                ++deletedCount;
            }
            else
            {
                qWarning().nospace() << "[失败] 无法删除文件: " << fullPath << "（可能被占用或权限不足）";
            }
        }
    }

    return deletedCount;
}

// 获取当前 UTC 时间的毫秒时间戳，并转换为微秒
// qint64 msecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
// qint64 usecs = msecs * 1000;

PhotograbController::PhotograbController() : mp_pool(std::make_shared<_Kits::ObjectPool<QByteArray>>(500))
{
    m_thread_processData = std::thread(&PhotograbController::_dealprocessData, this);
}

PhotograbController::~PhotograbController()
{
    mb_thread_recvData_stop.store(true);
    if (m_thread_processData.joinable())
    {
        m_thread_processData.join();
    }
}

void PhotograbController::initNetCamera(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>> cameraMap,
                                        std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> cameraInfo)
{
    {
        m_udm_cam = cameraMap;
        m_udm_camInfo = cameraInfo;

        for (const auto &[name, cam] : (*m_udm_cam))
        {
            cam->setSendImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) {
                if (!img)
                    return;
                _Kits::LogInfo("Receive image:{}", img->name);
                savePictureInFileNetcam(img);
            });
            cam->acquireImage();
        }
    }
}

void PhotograbController::onReleaseCamera(int i)
{
    for (const auto &[name, cam] : (*m_udm_cam))
    {
        cam->closeCamera();
    }
    m_udm_cam->clear();
}

void PhotograbController::onNewClient(const std::string &, std::shared_ptr<_Kits::TcpClient> client)
{
    QStringList ipList = m_initinfo.value("iplist").toStringList();
    std::string stdname = client->getClientName();

    QString ip = "";

    for (QString realip : ipList)
    {
        QString qstdname = m_initinfo.value(realip).value<QString>();
        if (qstdname == QString::fromStdString(stdname))
            ip = realip;
    }

    if (ip == "")
        return;
    int firstemptyclient = -1;
    for (int i = 0; i < 4; i++)
    {
        if (m_client_count_map.value(i) == "")
        {
            firstemptyclient = i;
            break;
        }
    }
    if (firstemptyclient == -1)
        return; // 没有空闲的client
    if (firstemptyclient == 0)
    {
        client->setReceiveCallback([this](std::vector<uint8_t> &&data) { onRecvClientdata_0(std::move(data)); });
        // client->setDisconnectCallback([this](void) { onReleaseClient_0(); });
    }

    if (firstemptyclient == 1)
    {
        client->setReceiveCallback([this](std::vector<uint8_t> &&data) { onRecvClientdata_1(std::move(data)); });
        // client->setDisconnectCallback([this](void) { onReleaseClient_1(); });
    }
    if (firstemptyclient == 2)
    {
        client->setReceiveCallback([this](std::vector<uint8_t> &&data) { onRecvClientdata_2(std::move(data)); });
        // client->setDisconnectCallback([this](void) { onReleaseClient_2(); });
    }
    if (firstemptyclient == 3)
    {
        client->setReceiveCallback([this](std::vector<uint8_t> &&data) { onRecvClientdata_3(std::move(data)); });
        // client->setDisconnectCallback([this](void) { onReleaseClient_3(); });
    }
    // auto adaptedSlot = std::bind(&PhotograbController::onRecvData, this, std::placeholders::_1, ip);
    // QObject::connect(client.get(), &_Kits::TcpPrivateClient::recvData, adaptedSlot);
    m_client_count_map.insert(firstemptyclient, ip);
    QByteArray m_buffer = "";
    m_client_buffer_list.push_back(m_buffer);
}

void PhotograbController::onClientDisconnect(qintptr socketId)
{
}

void PhotograbController::onRecvClientdata_0(const std::vector<uint8_t> &&data)
{
    QByteArray *buffer = &m_client_buffer_list[0];
    QByteArray packetcli(reinterpret_cast<const char *>(data.data()), static_cast<int>(data.size()));
    buffer->append(packetcli);
    while (true)
    {
        int headerpos = buffer->indexOf(TCP_HEADER);
        if (headerpos == -1)
        {
            break;
        }
        int tailSearchStart = headerpos + TCP_HEADER.size();
        int tailPos = buffer->indexOf(TCP_TAIL, tailSearchStart);

        if (tailPos == -1)
        {
            *buffer = buffer->mid(headerpos);
            break;
        }

        int packetStart = headerpos + TCP_HEADER.size();
        int packetSize = tailPos - packetStart;

        QByteArray packet = buffer->mid(packetStart, packetSize);

        // 发送数据给子类处理
        qint64 timestamp;
        QDataStream stream_qint64(packet.left(TIMESTAMP_SIZE));
        stream_qint64.setByteOrder(QDataStream::LittleEndian);
        stream_qint64 >> timestamp;
        int size;
        QDataStream stream_int(packet.mid(TIMESTAMP_SIZE, IMG_SIZE_SIZE));
        stream_int.setByteOrder(QDataStream::LittleEndian);
        stream_int >> size;
        QByteArray image = packet.mid(TIMESTAMP_SIZE + IMG_SIZE_SIZE, size);
        QString cameraname = m_client_count_map[0];
        imageQueue.push({image, timestamp, cameraname});

        *buffer = buffer->mid(tailPos + TCP_TAIL.size());
    }
}

void PhotograbController::onRecvClientdata_1(const std::vector<uint8_t> &&data)
{
    QByteArray *buffer = &m_client_buffer_list[1];
    QByteArray packetcli(reinterpret_cast<const char *>(data.data()), static_cast<int>(data.size()));
    buffer->append(packetcli);
    while (true)
    {
        int headerpos = buffer->indexOf(TCP_HEADER);
        if (headerpos == -1)
        {
            break;
        }
        int tailSearchStart = headerpos + TCP_HEADER.size();
        int tailPos = buffer->indexOf(TCP_TAIL, tailSearchStart);

        if (tailPos == -1)
        {
            *buffer = buffer->mid(headerpos);
            break;
        }

        int packetStart = headerpos + TCP_HEADER.size();
        int packetSize = tailPos - packetStart;

        QByteArray packet = buffer->mid(packetStart, packetSize);

        qint64 timestamp;
        QDataStream stream_qint64(packet.left(TIMESTAMP_SIZE));
        stream_qint64.setByteOrder(QDataStream::LittleEndian);
        stream_qint64 >> timestamp;
        int size;
        QDataStream stream_int(packet.mid(TIMESTAMP_SIZE, IMG_SIZE_SIZE));
        stream_int.setByteOrder(QDataStream::LittleEndian);
        stream_int >> size;
        QByteArray image = packet.mid(TIMESTAMP_SIZE + IMG_SIZE_SIZE, size);
        QString cameraname = m_client_count_map[1];
        imageQueue.push({image, timestamp, cameraname});

        *buffer = buffer->mid(tailPos + TCP_TAIL.size());
    }
}

void PhotograbController::onRecvClientdata_2(const std::vector<uint8_t> &&data)
{
    QByteArray *buffer = &m_client_buffer_list[2];
    QByteArray packetcli(reinterpret_cast<const char *>(data.data()), static_cast<int>(data.size()));
    buffer->append(packetcli);
    while (true)
    {
        int headerpos = buffer->indexOf(TCP_HEADER);
        if (headerpos == -1)
        {
            break;
        }
        int tailSearchStart = headerpos + TCP_HEADER.size();
        int tailPos = buffer->indexOf(TCP_TAIL, tailSearchStart);

        if (tailPos == -1)
        {
            *buffer = buffer->mid(headerpos);
            break;
        }

        int packetStart = headerpos + TCP_HEADER.size();
        int packetSize = tailPos - packetStart;

        QByteArray packet = buffer->mid(packetStart, packetSize);

        qint64 timestamp;
        QDataStream stream_qint64(packet.left(TIMESTAMP_SIZE));
        stream_qint64.setByteOrder(QDataStream::LittleEndian);
        stream_qint64 >> timestamp;
        int size;
        QDataStream stream_int(packet.mid(TIMESTAMP_SIZE, IMG_SIZE_SIZE));
        stream_int.setByteOrder(QDataStream::LittleEndian);
        stream_int >> size;
        QByteArray image = packet.mid(TIMESTAMP_SIZE + IMG_SIZE_SIZE, size);
        QString cameraname = m_client_count_map[2];
        imageQueue.push({image, timestamp, cameraname});

        *buffer = buffer->mid(tailPos + TCP_TAIL.size());
    }
}

void PhotograbController::onRecvClientdata_3(const std::vector<uint8_t> &&data)
{
    QByteArray *buffer = &m_client_buffer_list[3];
    QByteArray packetcli(reinterpret_cast<const char *>(data.data()), static_cast<int>(data.size()));
    buffer->append(packetcli);
    while (true)
    {
        int headerpos = buffer->indexOf(TCP_HEADER);
        if (headerpos == -1)
        {
            break;
        }
        int tailSearchStart = headerpos + TCP_HEADER.size();
        int tailPos = buffer->indexOf(TCP_TAIL, tailSearchStart);

        if (tailPos == -1)
        {
            *buffer = buffer->mid(headerpos);
            break;
        }

        int packetStart = headerpos + TCP_HEADER.size();
        int packetSize = tailPos - packetStart;

        QByteArray packet = buffer->mid(packetStart, packetSize);

        qint64 timestamp;
        QDataStream stream_qint64(packet.left(TIMESTAMP_SIZE));
        stream_qint64.setByteOrder(QDataStream::LittleEndian);
        stream_qint64 >> timestamp;
        int size;
        QDataStream stream_int(packet.mid(TIMESTAMP_SIZE, IMG_SIZE_SIZE));
        stream_int.setByteOrder(QDataStream::LittleEndian);
        stream_int >> size;
        QByteArray image = packet.mid(TIMESTAMP_SIZE + IMG_SIZE_SIZE, size);
        QString cameraname = m_client_count_map[3];
        imageQueue.push({image, timestamp, cameraname});

        *buffer = buffer->mid(tailPos + TCP_TAIL.size());
    }
}

void PhotograbController::onReleaseClient_0()
{
    m_client_buffer_list[0].clear();
    m_client_count_map.insert(0, "");
}

void PhotograbController::onReleaseClient_1()
{
    m_client_buffer_list[1].clear();
    m_client_count_map.insert(1, "");
}

void PhotograbController::onReleaseClient_2()
{
    m_client_buffer_list[2].clear();
    m_client_count_map.insert(2, "");
}

void PhotograbController::onReleaseClient_3()
{
    m_client_buffer_list[3].clear();
    m_client_count_map.insert(3, "");
}
void PhotograbController::_dealprocessData()
{
    while (!mb_thread_recvData_stop.load())
    {
        ImageData imageData;
        if (imageQueue.try_pop(imageData))
        {
            const size_t currentSize = pathVector.size();
            if (currentSize == 0)
            {
                QString str = QString("A-10%1").arg(testcount++);
                savePictureInFile(imageData, str);
                continue;
            }

            size_t index = findNearestIndex(imageData.timestamp, currentSize);
            QString path = pathVector[index].first;
            savePictureInFile(imageData, path); // 存图逻辑
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}
void PhotograbController::processImage(const QByteArray &data, const QString &ip)
{
    qint64 timestamp;
    QDataStream stream_qint64(data.left(TIMESTAMP_SIZE));
    stream_qint64.setByteOrder(QDataStream::LittleEndian);
    stream_qint64 >> timestamp;
    int size;
    QDataStream stream_int(data.mid(TIMESTAMP_SIZE, IMG_SIZE_SIZE));
    stream_int.setByteOrder(QDataStream::LittleEndian);
    stream_int >> size;
    QByteArray image = data.mid(TIMESTAMP_SIZE + IMG_SIZE_SIZE, size);
    QString cameraname = ip;
    imageQueue.push({image, timestamp, cameraname});
}
void PhotograbController::getcaminfoString(const QVariant &data)
{
    QStringList ipList = m_initinfo.value("iplist").toStringList();
    QStringList snList = m_initinfo.value("snlist").toStringList();
    m_iplist = ipList;
    ipandsnlist = snList + ipList;
    QString result = "";
    for (const QString &str : ipandsnlist)
    {
        QString cameraname = QString("[status:%1,name:%2,serial:%3]")
                                 .arg(m_initinfo.value(m_initinfo.value(str).value<QString>()).value<bool>())
                                 .arg(m_initinfo.value(str).value<QString>())
                                 .arg(str);
        result += cameraname;
    }
    // 和页面通信
    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
    // TIS_Info::QmlCommunication::ForQmlSignals::camera_status_recv,
    // QVariant::fromValue(result));
}

void PhotograbController::savePictureInFile(const ImageData &data, const QString &path)
{

    if (mytaskdir == "")
        mytaskdir = "d:/gwkj/无任务图片";
    QByteArray Picture = data.image;
    qint64 timestamp = data.timestamp;
    QString camid = m_initinfo[data.camera].toString();

    // 检查图像是否有效
    if (Picture.isNull())
    {
        qWarning() << "Received invalid image data";
        return;
    }

    // 将图片转换为字节数组
    // QByteArray imageData;
    // QBuffer buffer(&imageData);
    // buffer.open(QIODevice::WriteOnly);
    // writeEncodedImage()
    // Picture.save(&buffer, "JPG", 100);
    // buffer.close();

    // 保存图片到文件
    QDir dir;
    QString filedir = mytaskdir + "/" + path;
    dir.mkpath(filedir);
    qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch() * 1000;
    QString filename = QString("jpgPicture%1_%2.jpg").arg(usecs).arg(camid);
    deleteFilesContaining(camid, filedir);
    QString filepath = filedir + "/" + filename;
    QFile outFile(filepath);
    if (outFile.open(QIODevice::WriteOnly))
    {
        outFile.write(Picture);
        outFile.close();
        _Kits::LogInfo("Image saved to:{},outqueue", filepath.toStdString());
    }
    else
    {
        _Kits::LogInfo("Failed to save image to:{}", filepath.toStdString());
    }
    // 使用 base64 编码图像数据

    QWriteLocker locker(&tasklocker);
    if (countmap.contains(camid))
    {
        int ct = countmap.value(camid);
        countmap.insert(camid, ct + 1);
    }
    else
    {
        countmap.insert(camid, 1);
    }
    m_initinfo[camid] = true;

    QVariantMap sendData;
    sendData["picturedata"] = QString("data:image/jpeg;base64,") + Picture.toBase64();
    sendData["camid"] = camid;
    sendData["tcount"] = countmap.value(camid);

    // mapData[TIS_Info::QmlCommunication::strData] = sendData;

    // qDebug() << "Sending to QML - camid:" << camid << "tcount:" << countmap.value(camid) << "image :" << Picture;

    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
    // TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page,
    // QVariant::fromValue(sendData));
}

void PhotograbController::RefreshLocation(const TIS_Info::LocationData &data)
{
    QString stationName = data.station_name;
    QString poleName = data.pole_name;
    if (poleNow == "")
        poleNow = poleName;
    qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch() * 1000;
    QString insertStr = stationName + "/" + poleNow;
    poleNow = poleName;
    pathVector.push_back({insertStr, usecs});
}

void PhotograbController::refreshTask(const QString &taskdir)
{
    poleNow = "";
    pathVector.clear();
    imageQueue.clear();
    QWriteLocker locker(&tasklocker);
    mytaskdir = taskdir;
}
// 截掉末尾的0
QByteArray truncateTrailingZeros(const QByteArray &data, int maxScanSize = -1)
{
    int scanSize = (maxScanSize < 0 || maxScanSize > data.size()) ? data.size() : maxScanSize;
    int endPos = data.size() - 1;
    for (; endPos >= data.size() - scanSize; --endPos)
    {
        if (static_cast<unsigned char>(data.at(endPos)) != 0)
        {
            break;
        }
    }
    return data.left(endPos + 1);
}

void PhotograbController::savePictureInFileNetcam(std::shared_ptr<TIS_Info::ImageBuffer> data)
{

    // 存图逻辑
    if (mytaskdir == "")
        mytaskdir = "d:/gwkj/无任务图片";
    QByteArray picture_0 = QByteArray(reinterpret_cast<const char *>(data->data.data()), static_cast<int>(data->data.size()));
    QByteArray picture = truncateTrailingZeros(picture_0);
    // QImage picture = ConvertToQImage(data->data.data(), data->width, data->height, 1);
    QString cameraname = m_initinfo.value(QString::fromStdString(data->name)).value<QString>();
    qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch() * 1000;
    QDir dir;
    QString filename = QString("jpgPicture%1_%2.jpg").arg(usecs).arg(cameraname);
    QString filedir = mytaskdir + "/" + timestampMap.findClosest(usecs);
    dir.mkpath(filedir);
    // int ret = deleteFilesContaining(cameraname, filedir);// 删除同名文件
    QString filepath = filedir + "/" + filename;

    QFile outFile(filepath);
    // if (picture.save(filepath, "JPG", 80))
    if (outFile.open(QIODevice::WriteOnly))
    {
        outFile.write(picture);
        outFile.close();
        _Kits::LogInfo("Image saved to:{},outqueue", filepath.toStdString());
    }
    else
    {
        _Kits::LogInfo("Failed to save image to:{}", filepath.toStdString());
    }
    QWriteLocker locker(&tasklocker);
    if (countmap.contains(cameraname))
    {
        int ct = countmap.value(cameraname);
        countmap.insert(cameraname, ct + 1);
    }
    else
    {
        countmap.insert(cameraname, 1);
    }
    // 将图片转换为字节数组
    // QImage sendimg;
    // sendimg.load(filepath);
    // QByteArray imageData;
    // QBuffer buffer(&imageData);
    // buffer.open(QIODevice::WriteOnly);
    // sendimg.save(&buffer, "JPG", 100);
    // buffer.close();
    QVariantMap sendData;
    sendData["picturedata"] = QString("data:image/jpeg;base64,") + picture.toBase64();
    sendData["camid"] = cameraname;
    sendData["tcount"] = countmap.value(cameraname);
    Sleep(500);
    softTriger();
    return;
    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
    // TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page,
    // QVariant::fromValue(sendData));
}

void PhotograbController::refreshInitinfo(const QVariantMap &mymap)
{
    QWriteLocker locker(&tasklocker);
    m_initinfo.insert(mymap);
}

void PhotograbController::refreshInitinfoNet(const QVariantMap &mymap)
{
    QWriteLocker locker(&tasklocker);
    m_initinfo.insert(mymap);
}

void PhotograbController::softTriger()
{
    LogDebug("PhotograbController::softTriger");
    QStringList snList = m_initinfo.value("snlist").toStringList();

    for (const auto &[name, cam] : (*m_udm_cam))
    {
        cam->acquireImage();
    }
}

void _Controllers::PhotograbController::onTaskBegin(const TIS_Info::TaskInfo &taskinfo)
{
    QWriteLocker locker(&tasklocker);
    mytaskdir = taskinfo.strTaskSavePath;
}

void _Controllers::PhotograbController::onTaskEnd(const TIS_Info::TaskInfo &taskinfo)
{
    QWriteLocker locker(&tasklocker);
    mytaskdir = "";
}
