#include "LocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include "kits/common/database/orm/TableStructs.h"
#include "tis_global/enum_public/location_enum.h"
#include <chrono>
#include <QJsonDocument>
#include <cstdint>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void LocationController::initConfig(TIS_Info::LocationConfigs config)
{
    if (m_kitLocation == nullptr)
    {
        m_kitLocation = std::make_unique<LocationGeneral>();
        m_kitLocation->init(config);
    }
}

void LocationController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_curTaskInfo = task;
    LogInfo("[里程清零] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
    if (task.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        m_kitLocation->startTask(task);
    }
    else if (task.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        m_kitLocation->stopTask();
    }
}

void LocationController::recvSpeedData(const TIS_Info::SpeedData &data)
{
    static uint64_t last_mull_pulse = data.mull_pulse;
    static uint64_t last_mileage = data.mull_millimeter;
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START && data.mull_pulse > last_mull_pulse)
    {
        constexpr uint64_t MAX_SPACING = 1 * 1000 * 1000; // 1 km

        auto spacing = data.mull_millimeter - last_mileage;
        if (spacing < MAX_SPACING)
        {
            auto locationData = m_kitLocation->speedSensorUpdate(data.mull_millimeter, data.timestamp, data.mdble_speed);

            if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
            {
                _Service::senderLocationServiceLocationRadio(locationData);
            }
            else
            {
                using clock = std::chrono::steady_clock;
                static auto last_time = clock::now();
                auto cur_time = clock::now();
                auto interval = std::chrono::duration_cast<std::chrono::milliseconds>(cur_time - last_time).count();
                last_time = cur_time;
                constexpr double MAX_DISTANCE = 100; // 默认 100ms
                if (interval > MAX_DISTANCE)
                {
                    _Service::senderLocationServiceLocationRadio(locationData);
                }
            }
        }
    }

    last_mull_pulse = data.mull_pulse;
    last_mileage = data.mull_millimeter;
}

void LocationController::recvRfidDataFromQml(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid rfid data!");
        return;
    }
    m_kitLocation->rfidAdjust(data.toString());

    // auto locationData = m_kitLocation->getCurrentData();
    // locationData.location_type = TIS_Info::LocationType::PT_RFID;
    // _Service::senderLocationServiceLocationRadio(locationData);

    // int count = m_kitLocation->getRfidCount();
    // _Service::senderLocationServicesendRfidCount(count);
}

void LocationController::recvRfidDataFromModule(const std::string &data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.empty())
    {
        LogError("Invalid rfid data!");
        return;
    }

    m_kitLocation->rfidAdjust(data.c_str());

    // auto locationData = m_kitLocation->getCurrentData();
    // locationData.location_type = TIS_Info::LocationType::PT_RFID;
    // _Service::senderLocationServiceLocationRadio(locationData);

    // int count = m_kitLocation->getRfidCount();
    // _Service::senderLocationServicesendRfidCount(count);
}

void LocationController::recvHandData(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid data!");
        return;
    }
    QVariantMap variant = convertDataToJsonOrMap(data);
    QString str = variant.value("pole_name").toString();
    // m_kitLocation->handAdjust(str);

    // auto locationData = m_kitLocation->getCurrentData();
    // locationData.location_type = TIS_Info::LocationType::PT_HAND;
    // _Service::senderLocationServiceLocationRadio(locationData);
}

void LocationController::recvImageData(int64_t timestamp)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    auto locationData = m_kitLocation->ImageAdjust(timestamp);
    if (locationData.location_type == TIS_Info::LocationType::PT_IMG)
    {
        LogInfo("[图像定位成功]: {},{},{}",
                locationData.pole_name.toStdString(),
                locationData.mileage_adjust,
                locationData.created_time.toStdString());
        // _Service::senderLocationServiceLocationRadio(locationData);
    }
}
void LocationController::recvMaoduanData(int64_t timestamp0, int64_t timestamp1)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationData = m_kitLocation->maoduanAdjust(timestamp0, timestamp1);
    if (locationData.location_type == TIS_Info::LocationType::PT_MAODUAN)
    {
        LogInfo("[锚段定位成功]: {}:{},{},{}",
                locationData.maoduan_name.toStdString(),
                locationData.pole_name.toStdString(),
                locationData.mileage_adjust,
                locationData.created_time.toStdString());
        _Service::senderLocationServiceLocationRadio(locationData);
    }
}

QVariantMap LocationController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}
} // namespace _Controllers