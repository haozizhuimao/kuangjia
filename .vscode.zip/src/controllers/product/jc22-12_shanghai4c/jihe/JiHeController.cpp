﻿#include "JiHeController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include <chrono>
#include <cstdint>
#include <qobject.h>
#include <qtpreprocessorsupport.h>
#include <qvariant.h>
#include <vector>
#include "JCWDataDef.h"
#include "kits/common/database/CppBatis.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void JiHeController::sendJiHeToLocationService(const TIS_Info::JiHeData &data)
{
    // 锚段校正
    if (data.lineNum == 2 && m_bMaoduan == false) // 单支锚段
    {
        m_bMaoduan = true;
        m_tpMaoduanlastTime = data.timestamp;
        return;
    }

    if (m_bMaoduan)
    {
        if (data.lineNum == 1)
        {
            m_bMaoduan = false;
            senderJiHeServiceJiHeMaoDuanToLocation(m_tpMaoduanlastTime, data.timestamp);
        }
        return;
    }

    // 图像校正
    if (data.iImgPosType == 4 && m_bImgType == false) // 支柱位置
    {
        m_bImgType = true;
        m_tpTuxianglastTime = data.timestamp;
    }
    if (data.iImgPosType != 4 && m_bImgType == true)
    {
        m_bImgType = false;
        senderJiHeServiceJiHeImgToLocation(m_tpTuxianglastTime);
    }
}
JiHeController::~JiHeController()
{
    m_isDealJiHeThreadRun.store(false);
    if (m_dealJiHeThread.joinable())
    {
        m_dealJiHeThread.join();
    }
    if (m_writeDBThread.joinable())
    {
        m_writeDBThread.join();
    }
}

void JiHeController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    if (TIS_Info::TaskState::TASK_STOPPED == task.nTaskstate || TIS_Info::TaskState::TASK_NONE == task.nTaskstate)
    {
        m_taskID.store(-1, std::memory_order_release);
        return;
    }

    m_taskID.store(task.nTaskID, std::memory_order_release);
}

void JiHeController::sendJiHeData(const TIS_Info::JiHeData &JiHeData)
{
    static int sendNum = 0;
    if (sendNum++ < 20) // 20*2.5ms=50ms
    {
        return;
    }
    else
    {
        sendNum = 0;
    }
    _Service::senderJiHeServiceJiHeDataBroadcast(JiHeData);
}
void JiHeController::initUdpRecvier(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto finderJihe = clients.find(m_udpJiheName);
    if (finderJihe != clients.end())
    {
        auto udpJiheClient = finderJihe->second;
        udpJiheClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } recvUdpJiheData(std::vector<uint8_t>(datas->begin(), datas->end())); });
    }
    m_isDealJiHeThreadRun.store(true);
    m_dealJiHeThread = std::thread(&JiHeController::dealJiHeData, this);
    m_writeDBThread = std::thread(&JiHeController::writeJiHeDataToDB, this);
}

void JiHeController::recvUdpJiheData(std::vector<uint8_t> &&datas)
{
    m_jiheQueue.push(std::move(datas));
}
void JiHeController::dealJiHeData()
{
    QByteArray bytedata;
    while (m_isDealJiHeThreadRun.load())
    {
        std::vector<uint8_t> vecData;
        if (m_jiheQueue.try_pop(vecData))
        {
            handleData(vecData);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}
void JiHeController::handleData(const std::vector<uint8_t> &vecData)
{
    if (m_taskID == -1)
    {
        return;
    }
    std::unique_ptr<JCWD> jcwjh = std::make_unique<JCWD>();
    std::memset(jcwjh.get(), 0, sizeof(JCWD));
    std::memcpy(jcwjh.get(), vecData.data(), sizeof(JCWD));

    TIS_Info::JiHeData jiheData;
    auto lineNumber = jcwjh->uiLineNum < 4 ? jcwjh->uiLineNum : 4;
    for (int i = 0; i < lineNumber; i++)
    {
        if (jcwjh->jcx[i].pntLinePos.x > 8000 || jcwjh->jcx[i].pntLinePos.x <= -8000)
        {
            jiheData.fZig[i] = 8000;
        }
        else
        {
            jiheData.fZig[i] = jcwjh->jcx[i].pntLinePos.x;
        }

        if (jcwjh->jcx[i].pntLinePos.y >= 8000 || jcwjh->jcx[i].pntLinePos.y <= -8000)
        {
            jiheData.fHei[i] = 8000;
        }
        else
        {
            jiheData.fHei[i] = jcwjh->jcx[i].pntLinePos.y;
        }

        if (jcwjh->jcx[i].pntCompPos.x >= 8000 || jcwjh->jcx[i].pntCompPos.x <= -8000)
        {
            jiheData.fZigBc[i] = 8000;
        }
        else
        {
            jiheData.fZigBc[i] = jcwjh->jcx[i].pntCompPos.x;
        }

        if (jcwjh->jcx[i].pntCompPos.y >= 8000 || jcwjh->jcx[i].pntCompPos.y <= -8000)
        {
            jiheData.fHeiBc[i] = 8000;
        }
        else
        {
            jiheData.fHeiBc[i] = jcwjh->jcx[i].pntCompPos.y;
        }

        /**************************磨耗*********************************/
        jiheData.fMoHaoWidth[i] = jcwjh->jcx[i].fMhBotLen;
        jiheData.fMoHaoHeight[i] = jcwjh->jcx[i].fMohaoH;
        jiheData.Diameter[i] = jcwjh->jcx[i].fLineRidus;
        // LogDebug("jcwjh->jcx[i].pntCompPos.x
        // :{},jcwjh->jcx[i].pntCompPos.y:{},{}",jcwjh->jcx[i].pntCompPos.x,jcwjh->jcx[i].pntCompPos.y);
        // LogDebug("fzig:{},fhei:{},fmohaolen:{},jiheData.fZigBc:{} jiheData.fHeiBc:{}
        // i:{},lineNumber:{}",jiheData.fZig[i],jiheData.fHei[i],jiheData.fMoHaoWidth[i],jiheData.fZigBc[i],jiheData.fHeiBc[i],i,lineNumber);
    }

    auto postype = jcwjh->GetPosiflag();

    if (JCXP_POLE == postype)
    {
        jiheData.iImgPosType = 4;
    }
    else
    {
        jiheData.iImgPosType = 1;
    }
    jiheData.lineNum = lineNumber;
    // LogDebug("[jihe] lineNum:{}",jiheData.lineNum);
    if (fabs(jcwjh->pntCompLeft.x) < 100 && fabs(jcwjh->pntCompLeft.y) < 100)
    {
        jiheData.fLeftBCX = jcwjh->pntCompLeft.x;
        jiheData.fLeftBCY = jcwjh->pntCompLeft.y;
    }
    else
    {
        jiheData.fLeftBCX = 8000;
        jiheData.fLeftBCY = 8000;
    }
    if (fabs(jcwjh->pntCompRight.x) < 100 && fabs(jcwjh->pntCompRight.y) < 100)
    {
        jiheData.fRightBCX = jcwjh->pntCompRight.x;
        jiheData.fRightBCY = jcwjh->pntCompRight.y;
    }
    else
    {
        jiheData.fRightBCX = 8000;
        jiheData.fRightBCY = 8000;
    }
    jiheData.timestamp = milisecondsTimestamp(vecData);
    sendJiHeToLocationService(jiheData);
    sendJiHeData(jiheData);

    std::lock_guard<std::mutex> lock(m_jiheMutex);
    m_jiheData.push_back(jiheData);
}
int64_t JiHeController::milisecondsTimestamp(const std::vector<uint8_t> &vecData)
{
    int64_t timestamp = 0;
    auto len = vecData.size();
    if (len >= 8)
    {
        const uint8_t *raw = reinterpret_cast<const uint8_t *>(vecData.data());
        timestamp = static_cast<int64_t>((static_cast<uint64_t>(raw[len - 8]) << 56) | (static_cast<uint64_t>(raw[len - 7]) << 48) |
                                         (static_cast<uint64_t>(raw[len - 6]) << 40) | (static_cast<uint64_t>(raw[len - 5]) << 32) |
                                         (static_cast<uint64_t>(raw[len - 4]) << 24) | (static_cast<uint64_t>(raw[len - 3]) << 16) |
                                         (static_cast<uint64_t>(raw[len - 2]) << 8) | (static_cast<uint64_t>(raw[len - 1])));
    }

    return timestamp / 1000;

    // auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    // return ms;
}

void JiHeController::writeJiHeDataToDB()
{
    while (m_isDealJiHeThreadRun.load())
    {
        if (!m_jiheData.empty())
        {
            std::vector<TIS_Info::JiHeData> vecjiheData;
            {
                std::lock_guard<std::mutex> lock(m_jiheMutex);
                vecjiheData = m_jiheData;
                m_jiheData.clear();
            }
            auto vecData = convertToDBData(vecjiheData);
            DataBaseInsert(vecData);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
    }
}

std::vector<_Kits::_Orm::jihe_data> JiHeController::convertToDBData(const std::vector<TIS_Info::JiHeData> &vecData)
{
    std::vector<_Kits::_Orm::jihe_data> res;
    for (const auto &item : vecData)
    {
        // const auto&data = item.data;
        _Kits::_Orm::jihe_data dbItem;
        dbItem.task_id = m_taskID;
        dbItem.zig0 = item.fZig[0];
        dbItem.hei0 = item.fHei[0];
        dbItem.zig_bc0 = item.fZigBc[0];
        dbItem.hei_bc0 = item.fHeiBc[0];
        dbItem.mohao_width0 = item.fMoHaoWidth[0];
        dbItem.mohao_height0 = item.fMoHaoHeight[0];

        dbItem.zig1 = item.fZig[1];
        dbItem.hei1 = item.fHei[1];
        dbItem.zig_bc1 = item.fZigBc[1];
        dbItem.hei_bc1 = item.fHeiBc[1];
        dbItem.mohao_width1 = item.fMoHaoWidth[1];
        dbItem.mohao_height1 = item.fMoHaoHeight[1];

        dbItem.zig2 = item.fZig[2];
        dbItem.hei2 = item.fHei[2];
        dbItem.zig_bc2 = item.fZigBc[2];
        dbItem.hei_bc2 = item.fHeiBc[2];
        dbItem.mohao_width2 = item.fMoHaoWidth[2];
        dbItem.mohao_height2 = item.fMoHaoHeight[2];

        dbItem.zig3 = item.fZig[3];
        dbItem.hei3 = item.fHei[3];
        dbItem.zig_bc3 = item.fZigBc[3];
        dbItem.hei_bc3 = item.fHeiBc[3];
        dbItem.mohao_width3 = item.fMoHaoWidth[3];
        dbItem.mohao_height3 = item.fMoHaoHeight[3];

        dbItem.left_bc_x = item.fLeftBCX;
        dbItem.left_bc_y = item.fLeftBCY;
        dbItem.right_bc_x = item.fRightBCX;
        dbItem.right_bc_y = item.fRightBCY;

        dbItem.diameter0 = item.Diameter[0];
        dbItem.diameter1 = item.Diameter[1];
        dbItem.diameter2 = item.Diameter[2];
        dbItem.diameter3 = item.Diameter[3];

        QString time = QDateTime::fromMSecsSinceEpoch(item.timestamp).toString("yyyy-MM-dd hh:mm:ss.zzz");
        dbItem.created_time = time;
        dbItem.updated_time = time;
        res.push_back(std::move(dbItem));
    }
    return res;
}

bool JiHeController::DataBaseInsert(const std::vector<_Kits::_Orm::jihe_data> &vecData)
{
    if (!vecData.empty())
    {
        _Kits::SqlInsert<_Kits::_Orm::jihe_data> insert;
        insert.insert(vecData).exec();

        int nums = insert.getNumAffected();
        // _Kits::LogDebug("JiHe data end nums={}", nums);
        return nums > 0;
    }
    return false;
}

} // namespace _Controllers
