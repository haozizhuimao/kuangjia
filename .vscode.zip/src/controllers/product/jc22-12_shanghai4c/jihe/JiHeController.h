#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/common/database/orm/TableStructs.h"
//#include "tis_global/Function.h"
#include <cstdint>
#include <unordered_map>
#include <thread>
#include <atomic>
#include <vector>
#include <mutex>
#include <chrono>
#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#endif // emit
#endif // Q_MOC_RUN
namespace _Controllers {
class JiHeController : public ControllerBase<JiHeController>
{
  public:
    void initUdpRecvier(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    ~JiHeController();
    void recvTaskData(const TIS_Info::TaskInfo &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, JiHeController::initUdpRecvier);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, JiHeController::recvTaskData);
    TASK_LIST_END

  private:
    void recvUdpJiheData(std::vector<uint8_t> &&data);

    void sendJiHeData(const TIS_Info::JiHeData &JiHeData);
    void sendJiHeToLocationService(const TIS_Info::JiHeData &data);
    void dealJiHeData();
    void handleData(const std::vector<uint8_t> &vecData);
    int64_t milisecondsTimestamp(const std::vector<uint8_t> &vecData);
    void writeJiHeDataToDB();
    std::vector<_Kits::_Orm::jihe_data> convertToDBData(const std::vector<TIS_Info::JiHeData> &vecData);
    bool DataBaseInsert(const std::vector<_Kits::_Orm::jihe_data> &);

  private:
    const std::string m_udpJiheName = "jihe"; // 几何
    std::thread m_dealJiHeThread;
    std::atomic_bool m_isDealJiHeThreadRun = false;
    tbb::concurrent_queue<std::vector<uint8_t>> m_jiheQueue;
    std::thread m_writeDBThread;
    std::vector<TIS_Info::JiHeData> m_jiheData;
    std::mutex m_jiheMutex;
    std::atomic_int32_t m_taskID = -1;
    int64_t m_tpMaoduanlastTime;
    int64_t m_tpTuxianglastTime;
    std::atomic_bool m_bMaoduan = false;
    std::atomic_bool m_bImgType = false;
};
} // namespace _Controllers
