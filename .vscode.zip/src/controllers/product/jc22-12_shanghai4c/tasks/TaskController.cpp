#include "TaskController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/product_kits/task_helper/TaskSql.h"
#include "service/AppInterface.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/product_kits/line_helper/LineHelper.h"
#include <QJsonDocument>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TaskController::initFromMoudle(const std::string &trainNum, const std::string &savePath)
{
    if (m_taskHelper == nullptr)
    {
        m_taskHelper = std::make_unique<_Kits::TaskHelper>(savePath, trainNum);
    }
}

void TaskController::onTaskSended(QVariant task_data)
{
    if (m_taskHelper == nullptr)
    {
        LogError("任务服务初始化失败!");
        return;
    }
    if (!task_data.isValid())
    {
        LogError("下发任务数据错误!");
        return;
    }
    auto mapdata = convertDataToJsonOrMap(task_data);
    auto taskstate = mapdata.value("taskState", 1).toInt();
    TIS_Info::TaskInfo taskInfo;
    if (TIS_Info::TASK_START == taskstate)
    {
        taskInfo = m_taskHelper->startTask(mapdata);
        if (taskInfo.nTaskID != -1)
        {
            if (LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
            {
                senderTaskServicetaskBegin(taskInfo);
            }
            else
            {
                LogError("[任务线路表]: 任务线路表信息初始化失败。");
            }
        }
    }
    else if (TIS_Info::TASK_STOPPED == taskstate)
    {
        taskInfo = m_taskHelper->stopTask();
        if (taskInfo.nTaskID != -1)
        {
            senderTaskServicetaskEnd(taskInfo);
        }
    }
}
QVariantMap TaskController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}

} // namespace _Controllers