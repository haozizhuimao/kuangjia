
#include "QmlVideoDisplay.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Service;
using namespace _Kits;
void QmlVideoDisplay::displayVideo(QVariantMap data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page, QVariant::fromValue(data));
}
void QmlVideoDisplay::sendImagePathToQml(QString cameraName, QString save_path)
{
    QVariantMap data = {{"cameraName", cameraName}, {"save_path", save_path}};
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::save_path_send, QVariant::fromValue(data));
}

void QmlVideoDisplay::onSendRecordStateToQml(bool state)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::record_state, QVariant::fromValue(state));
}

void QmlVideoDisplay::sendTaskNameToQml(const TIS_Info::TaskInfo &taskInfo)
{
    auto taskName = taskInfo.strTaskName;

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv, QVariant::fromValue(taskName));
}

} // namespace _Controllers