#include "QmlDropperTrigger.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void QmlDropperTriggerController::onSendDropperTriggerDataToQml(QVariantMap data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvdropper_trigger_page, QVariant::fromValue(data));
}
} // namespace _Controllers
