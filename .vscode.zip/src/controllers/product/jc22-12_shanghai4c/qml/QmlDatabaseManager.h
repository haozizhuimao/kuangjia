#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include <string>
namespace _Controllers {
class QmlDatabaseManager : public ControllerBase<QmlDatabaseManager>
{
  public:
    void onDatabaseConnect(TIS_Info::QmlCommunication::ForQmlSignals, const QVariant &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::DatabaseManager::initStatus, QmlDatabaseManager::onDatabaseConnect);
    TASK_LIST_END
};
} // namespace _Controllers
