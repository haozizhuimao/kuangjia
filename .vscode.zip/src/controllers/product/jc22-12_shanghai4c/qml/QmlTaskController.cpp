
#include "QmlTaskController.h"
#include "kits/product_kits/line_helper/LineHelper.h"
#include "kits/product_kits/qml_task_kit/QmlTaskSql.h"
#include "kits/utility/log/CRossLogger.h"
namespace _Controllers {
using namespace _Service;
using namespace _Kits;
void QmlTaskController::onLineBtnChoose(QVariant)
{
    auto qlineNames = _Kits::QmlTaskSql::selectLineNames();
    if (qlineNames.size() == 0)
    {
        LogError("线路名列表查询失败!");
        return;
    }
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::lineNameList_recv, QVariant::fromValue(qlineNames));
}
void QmlTaskController::onLineNameSended(QVariant qmlLineName)
{
    if (qmlLineName.isNull())
    {
        LogError("Invalid line_name!");
        return;
    }
    QStringList parts = qmlLineName.toString().split("_"); // 按下划线分割
    QString stationPrefix = parts[0];                      // "太原s1"
    QString direction = parts[1];                          // "上行"
    int ndirection = (direction == "上行" ? 0 : 1);

    QVariantList forQmlData = QmlTaskSql::selectlineByLineName(stationPrefix, ndirection);
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::linedata_recv, QVariant::fromValue(forQmlData));
}
void QmlTaskController::displayTask(const TIS_Info::TaskInfo &task)
{
    if (TIS_Info::TASK_RUNNING == task.nTaskstate)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv,
                                                      QVariant::fromValue(task.strTaskName));
    }
}
} // namespace _Controllers