#include "QmlPatrolInspection.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void QmlPatrolInspectionController::onSendPatrolInspectionDataToQml(QVariantMap data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page, QVariant::fromValue(data));
}

} // namespace _Controllers
