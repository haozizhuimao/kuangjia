#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlDropperTriggerController : public ControllerBase<QmlDropperTriggerController>
{
  public:
    void onSendDropperTriggerDataToQml(QVariantMap);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::sendImageToQml, QmlDropperTriggerController::onSendDropperTriggerDataToQml);
    TASK_LIST_END
};
} // namespace _Controllers