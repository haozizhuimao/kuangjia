#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlPatrolInspectionController : public ControllerBase<QmlPatrolInspectionController>
{
  public:
    void onSendPatrolInspectionDataToQml(QVariantMap);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::sendImageToQml, QmlPatrolInspectionController::onSendPatrolInspectionDataToQml);
    TASK_LIST_END
};
} // namespace _Controllers