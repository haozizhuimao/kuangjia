#include "RfidController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include <qvariant.h>
#include "kits/common/database/CppBatis.h"
#include "kits/common/database/connections/DatabaseConnections.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

RfidController::RfidController()
{
    m_rfid_VFR61M = std::make_unique<Rfid_VFR61M>();
}

void RfidController::initNaturalDataBase(bool isSaveNaturalData)
{
    if (!isSaveNaturalData)
    {
        LogInfo("Natural data saving is disabled by configuration");
        return;
    }
    try
    {
        auto result = _Kits::CppBatis<_Kits::SqliteTag>::execSql("natural_rfid_data.db",
                                                                 "CREATE TABLE IF NOT EXISTS natural_rfid_data ("
                                                                 "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                                                 "timestamp TEXT NOT NULL, "
                                                                 "natural_data BLOB NOT NULL,"
                                                                 "parsed_data TEXT)");
        if (result.isEmpty())
        {
            throw std::runtime_error("Table creation failed - empty result returned");
        }
    }
    catch (const std::exception &e)
    {
        LogError("Database initialization failed", e.what());
    }
}

void RfidController::saveNaturalData(TIS_Info::RfidNaturalData rfidNaturalData)
{
    if (rfidNaturalData.naturalData.empty())
    {
        LogInfo("尝试保存空的RFID原始数据");
        return;
    }

    try
    {
        const QString dbPath = "natural_rfid_data.db";

        // 准备数据
        QVariantMap naturalData;
        // 获取当前时间戳（毫秒级）

        // 绑定参数类型
        std::unordered_map<QString, QSql::ParamType> bindTypes = {
            {"timestamp", QSql::In}, {"natural_data", QSql::Binary}, {"parsed_data", QSql::In}};

        // 使用fromRawData避免数据拷贝
        // 注意：这里安全是因为data在函数作用域内保持有效
        QByteArray rawData = QByteArray::fromRawData(reinterpret_cast<const char *>(rfidNaturalData.naturalData.data()),
                                                     static_cast<int>(rfidNaturalData.naturalData.size()));

        // 设置字段值
        naturalData["timestamp"] = rfidNaturalData.timeStamp;
        naturalData["natural_data"] = rawData; // 使用无拷贝的QByteArray
        // LogInfo("原始数据: {}", rawData.constData());
        naturalData["parsed_data"] = QString::fromStdString(rfidNaturalData.tagId);

        // 执行数据库插入
        if (!_Kits::CppBatis<_Kits::SqliteTag>::insert(dbPath, "natural_rfid_data", naturalData, bindTypes))
        {
            throw std::runtime_error("数据库插入失败");
        }
    }
    catch (const std::exception &e)
    {
        LogError("保存原始数据失败: ");
    }
}

void RfidController::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find("RFID");
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", "RFID");
        return;
    }
    m_tcpClient = finder->second;
    m_rfid_VFR61M->setTcpClient(m_tcpClient);
    m_rfid_VFR61M->setSendRfidCallback([this](const std::string &rfid) {
        if (rfid.empty())
            return;

        senderRfidServicesendRfidToQml(QString::fromStdString(rfid));

        // 加锁检查并插入去重集合
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_receiveRfids.find(rfid) != m_receiveRfids.end())
            {
                return; // 已存在，跳过
            }
            m_receiveRfids.insert(rfid);
        }
        // qDebug() << "去重后的RFID: " << QString::fromStdString(rfid);
        senderRfidServicerfidDeduplicated(rfid);
    });

    if (!m_rfid_VFR61M->start())
    {
        LogError("RFID VFR61M failed to start");
    }
}

void RfidController::onInitConfig(TIS_Info::RfidInfo info)
{
    if (m_rfid_VFR61M)
    {
        m_rfid_VFR61M->setInfo(info);
    }

    if (info.isSaveNatural)
    {
        initNaturalDataBase(true);
        m_rfid_VFR61M->setSendNaturalDataCallback([this](const TIS_Info::RfidNaturalData &data) { saveNaturalData(data); });
    }

    if (!m_rfid_VFR61M->start())
    {
        LogError("RFID VFR61M failed to start");
    }
}

} // namespace _Controllers