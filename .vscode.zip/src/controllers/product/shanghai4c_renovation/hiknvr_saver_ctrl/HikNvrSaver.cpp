#include "HikNvrSaver.h"

using namespace _Controllers;

_Controllers::HikNvrSaver::HikNvrSaver()
{
}

_Controllers::HikNvrSaver::~HikNvrSaver()
{
}

void _Controllers::HikNvrSaver::initHikNvrRecord(TIS_Info::HikLogInfo nvrInfo)
{
    _m_hikNvrRecord->init(nvrInfo);
}

void _Controllers::HikNvrSaver::downloadRecord(std::string filePath, std::string cameraIp)
{
    if (_mmap_ip_Time.find(cameraIp) == _mmap_ip_Time.end())
    {
        // 如果没有记录该IP的开始时间，则使用默认时间作为开始时间
        _mmap_ip_Time[cameraIp] = {_m_defaultTime};
    }

    TIS_Info::systemTime endTime = getNowTime();
    _m_hikNvrRecord->DownloadOneFileByTime(filePath, cameraIp, _mmap_ip_Time[cameraIp], endTime);
    _mmap_ip_Time[cameraIp] = std::move(endTime);
}

void _Controllers::HikNvrSaver::downloadRecord(std::string filePath,
                                               std::string cameraIp,
                                               TIS_Info::systemTime startTime,
                                               TIS_Info::systemTime endTime)
{
    if (startTime > endTime)
    {
        return;
    }

    // 直接使用传入的开始时间和结束时间进行下载
    _m_hikNvrRecord->DownloadOneFileByTime(filePath, cameraIp, startTime, endTime);
}

bool _Controllers::HikNvrSaver::reSetStartTime(std::string ip, TIS_Info::systemTime time)
{

    if (time.iYear == 0)
    {
        time = {_m_defaultTime};
    }

    _mmap_ip_Time[ip] = std::move(time);
    return true;
}

TIS_Info::systemTime _Controllers::HikNvrSaver::getNowTime()
{
    // 获取当前系统时间
    std::time_t now = std::time(nullptr);
    std::tm *localTime = std::localtime(&now);

    // 创建systemTime对象并填充
    TIS_Info::systemTime currentTime;

    // 填充时间字段（注意tm_year是从1900开始的偏移，tm_mon从0开始）
    currentTime.iYear = {localTime->tm_year + 1900};
    currentTime.iMonth = {localTime->tm_mon + 1};
    currentTime.iDay = {localTime->tm_mday};
    currentTime.iHour = {localTime->tm_hour};
    currentTime.iMinute = {localTime->tm_min};
    currentTime.iSecond = {localTime->tm_sec};

    return currentTime;
}
