#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/nvr_record/hik_nvr_record/HikNvrRecord.h"
#include <memory>
#include <vector>
#include "tis_global/Struct.h"

namespace _Controllers {
class HikNvrSaver : public ControllerBase<HikNvrSaver>
{
  public:
    HikNvrSaver(/* args */);
    ~HikNvrSaver();

    ///@param ip
    ///@param config
    void initHikNvrRecord(TIS_Info::HikLogInfo);

    ///@param 文件名
    ///@param ip
    ///@note 调用此接口会自动更新ip对应的开始时间
    void downloadRecord(std::string, std::string);

    ///@param 文件名
    ///@param ip
    ///@param 开始时间
    ///@param 结束时间
    ///@note 需要自己输入开始时间和结束时间
    void downloadRecord(std::string, std::string, TIS_Info::systemTime, TIS_Info::systemTime);

    bool reSetStartTime(std::string ip, TIS_Info::systemTime time = TIS_Info::systemTime());

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HikManager::initHikNvrCtrl, HikNvrSaver::initHikNvrRecord);
    TASK_LIST_END

  private:
    std::unique_ptr<_Kits::HikNvrRecord> _m_hikNvrRecord;

    // ip--startTime
    std::unordered_map<std::string, TIS_Info::systemTime> _mmap_ip_Time;

    TIS_Info::systemTime getNowTime();

    const TIS_Info::systemTime _m_defaultTime = getNowTime();
};

} // namespace _Controllers