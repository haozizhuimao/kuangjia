#include "TaskController.h"
#include "kits/common/database/CppBatis.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppDeclare.h"
#include <algorithm>
#include "tis_global/EnumPublic.h"

namespace _Controllers {
TaskController::TaskController() {}

TaskController::~TaskController() {}

void TaskController::recvMvbData(const TIS_Info::mvbTask &mvb_task_data)
{
    QVariantMap task_info;
    auto &state = mvb_task_data.nTaskstate;

    if (state == TIS_Info::EnumPublic::TASK_START)
    {
        _mb_task_state = false; // 重置任务状态
        task_info.insert("taskState", TIS_Info::EnumPublic::TASK_START);
        task_info.insert("lineDirection", mvb_task_data.nLineDir);
        task_info.insert("lineName", mvb_task_data.strLineName);
        task_info.insert("startStation", mvb_task_data.strStartStation);
        task_info.insert("startPole", mvb_task_data.strStartPole);
        task_info.insert("endStation", mvb_task_data.strEndStation);
        task_info.insert("trainNumber", mvb_task_data.strSubWayNum);
        task_info.insert("runDirection", TIS_Info::EnumPublic::TASK_FORWARD_TRAIN); // 默认正向
        task_info.insert("kilometer", mvb_task_data.dKilometer);
        _Service::invokeTaskServicerecvMBLKData_V(task_info);
        return;
    }

    if (state == TIS_Info::EnumPublic::TASK_RUNNING && _mb_task_state == true)
    {
        return; // 任务已经开始
    }

    if (state == TIS_Info::EnumPublic::TASK_RUNNING && _mb_task_state == false)
    {
        _mb_task_state = true;

        auto first_id = selectidByStationDir(mvb_task_data.strStartStation, mvb_task_data.nLineDir);
        auto last_id = selectidByStationDir(mvb_task_data.strEndStation, mvb_task_data.nLineDir);

        if (first_id.begin() == first_id.end() || last_id.begin() == last_id.end())
        {
            _Kits::LogError("TaskController::recvMvbData: start or end station not found in database.");
            return;
        }

        auto runDirection = TIS_Info::EnumPublic::TASK_FORWARD_TRAIN;
        if (first_id.begin()->id < last_id.begin()->id)
        {
            runDirection = TIS_Info::EnumPublic::TASK_BACKWARD_TRAIN;
        }

        task_info.insert("taskState", TIS_Info::EnumPublic::TASK_RUNNING);
        task_info.insert("lineDirection", mvb_task_data.nLineDir);
        task_info.insert("lineName", mvb_task_data.strLineName);
        task_info.insert("startStation", mvb_task_data.strStartStation);
        task_info.insert("startPole", mvb_task_data.strStartPole);
        task_info.insert("endStation", mvb_task_data.strEndStation);
        task_info.insert("trainNumber", mvb_task_data.strSubWayNum);
        task_info.insert("runDirection", runDirection);
        task_info.insert("kilometer", mvb_task_data.dKilometer);
        _Service::invokeTaskServicerecvMBLKData_V(task_info);

        return;
    }

    if (state == TIS_Info::EnumPublic::TASK_STOPPED && _mb_task_state == true)
    {
        _mb_task_state = false;
        task_info.insert("taskState", TIS_Info::EnumPublic::TASK_STOPPED);
        _Service::invokeTaskServicerecvMBLKData_V(task_info);
        return;
    }
}

void TaskController::initTrainNum(const std::string trainNum)
{
    _mstr_trainNum = QString::fromStdString(trainNum);
}

void TaskController::notifyTaskToModules(TIS_Info::TaskInfo data)
{
    _Service::invokeNotifyTask(data);
}

void TaskController::sendLineNameToQml(const QVariant &lineNames)
{
    // 通过QmlPrivateEngine发送数据
    _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::lineNameList_recv,
                                                  QVariant::fromValue(lineNames));
}

void TaskController::sendLineDataToQml(const Json::Value lineData)
{

    // 将 Json::Value 转换为字符串，然后解析为 QJsonDocument
    auto temp = lineData.toStyledString();
    QString jsonString = QString::fromStdString(lineData.toStyledString());
    QJsonDocument doc = QJsonDocument::fromJson(jsonString.toUtf8());

    // 通过QmlPrivateEngine发送数据
    _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::linedata_recv, doc.toVariant());
}

void TaskController::sendTaskNameToQml(const QString &taskname)
{

    // 通过QmlPrivateEngine发送数据
    _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv, QVariant::fromValue(taskname));
}

std::vector<_Kits::_Orm::line_data> TaskController::selectidByStationDir(const QString &station_name, const int &line_dir)
{
    auto select = _Kits::SqlSelect<_Kits::_Orm::line_data>()
                      .select(QStringList{"id"})
                      .where("station_name", _Kits::OperatorComparison::Equal, station_name)
                      .where("line_dir", _Kits::OperatorComparison::Equal, line_dir);

    if (!select.exec())
    {
        return std::vector<_Kits::_Orm::line_data>({});
    }

    return select.getResults();
}

} // namespace _Controllers