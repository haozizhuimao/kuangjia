#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
#include <memory>
#include <vector>
#include "tis_global/Struct.h"
#include "kits/common/database/orm/TableStructs.h"
#include <QMap>

namespace _Controllers {
class TaskController : public ControllerBase<TaskController>
{
  public:
    TaskController(/* args */);
    ~TaskController();

    ///@param data rfid的数据
    void recvMvbData(const TIS_Info::mvbTask &);
    void initTrainNum(const std::string);
    void notifyTaskToModules(TIS_Info::TaskInfo);
    void sendLineNameToQml(const QVariant &);
    void sendLineDataToQml(const Json::Value); // 线路数据发送
    void sendTaskNameToQml(const QString &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::MVBMsgForward::mvbTaskDataForward, TaskController::recvMvbData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::initTaskController, TaskController::initTrainNum);
    ASYNC_TASK_ADD(TIS_Info::TaskService::notifyTaskData, TaskController::notifyTaskToModules);
    SYNC_TASK_ADD(TIS_Info::TaskService::sendLineData, TaskController::sendLineDataToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::sendLineName, TaskController::sendLineNameToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::sendTaskNameToQml, TaskController::sendTaskNameToQml);
    TASK_LIST_END

  private:
    std::vector<_Kits::_Orm::line_data> selectidByStationDir(const QString &station_name, const int &line_dir);

    bool _mb_task_state = true; // 任务状态
    QString _mstr_trainNum;     // 列车编号
};

} // namespace _Controllers