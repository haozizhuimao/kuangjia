
set(CTL_NAME "shanghai4c_renovation")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_camera_hik_nvr>
)       

find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_camera_hik_nvr
)

target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CTL_NAME}>
)     
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

set(RES_QML
    res/qml/engineering_vehicle_qml/mvb_page/mvb_page.qml
    res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/engineering_vehicle_qml/main.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
