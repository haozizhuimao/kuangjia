#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
namespace _Controllers {
class RemoteController final : public ControllerBase<RemoteController>
{
  public:
    RemoteController() = default;
    ~RemoteController() noexcept = default;
    void publishTaskInfo(const TIS_Info::task_data &);
    void publishLocationInfo(const TIS_Info::LocationData &);
    void publishOffsetLocationRadio(const TIS_Info::LocationData &);
    // void publishPressSpotInfo(const TIS_Info::press_data &);
    // void publishVolElecInfo(const TIS_Info::VoltageAndElectric &);
    void publishSpeedInfo(const TIS_Info::SpeedData &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(_Service::TaskService::taskBegin, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(_Service::TaskService::taskEnd, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(_Service::TaskService::taskRunning, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(_Service::LocationService::LocationRadio, RemoteController::publishLocationInfo);
    ASYNC_TASK_ADD(_Service::LocationService::OffsetLocationRadio, RemoteController::publishOffsetLocationRadio);
    // ASYNC_TASK_ADD(_Service::PressSpotVolElecEtcData::sendPressSpotOut, RemoteController::publishPressSpotInfo);
    // ASYNC_TASK_ADD(_Service::PressSpotVolElecEtcData::sendVolElecOut, RemoteController::publishVolElecInfo);
    ASYNC_TASK_ADD(_Service::Sensor6051DataOut::sendSpeedDataOut, RemoteController::publishSpeedInfo);
    TASK_LIST_END
};
} // namespace _Controllers
