﻿#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "kits/common/orm_user/MvbInfoSql.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <qobject.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_heartData.resize(m_headLength + 32, 0);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
    m_mvbInfoWirteSqlThread = std::thread(&MVBController::writeMvbInfoToDBFun, this);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
    m_condition.notify_one();
    if (m_mvbInfoWirteSqlThread.joinable())
    {
        m_mvbInfoWirteSqlThread.join();
    }
}

void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    // mvb tcms数据接收
    auto finder = clients.find(m_udpName);
    if (finder == clients.end())
    {
        LogError("can not find udp client.name = {}", m_udpName);
        return;
    }
    auto udpClient = finder->second;
    udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } onUdpDataReceived(std::vector<uint8_t>(datas->begin(), datas->end())); });
    // mvb 告警数据接收
    auto alarmUdp = clients.find(m_mvbAmifName);
    if (alarmUdp == clients.end())
    {
        LogError("can not find udp client.name = {}", m_mvbAmifName);
        return;
    }
    alarmUdp->second->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } onUdpAlarmReceived(std::vector<uint8_t>(datas->begin(), datas->end())); });
    // mvb 心跳数据发送
    auto heartUdp = clients.find(m_heartUdpName);
    if (heartUdp == clients.end())
    {
        LogError("can not find udp client.name = {}", m_heartUdpName);
        return;
    }
    m_heartUdpClient = heartUdp->second;
}

// void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
// {
//     if (data.size() == 0)
//     {
//         return;
//     }
//     // CCU生命信号
//     outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);

//     uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
//     std::bitset<8> bit(modeData);
//     // 1车司机室激活
//     outputData["cab1Occupied"] = static_cast<bool>(bit[0]);
//     // 6车司机室激活
//     outputData["cab6Occupied"] = static_cast<bool>(bit[1]);
//     // 列车开A侧门指令
//     outputData["doorCmdOpnA"] = static_cast<bool>(bit[2]);
//     // 列车开B侧门指令
//     outputData["doorCmdOpnB"] = static_cast<bool>(bit[3]);
//     // 列车关A侧门指令
//     outputData["doorCmdClsA"] = static_cast<bool>(bit[4]);
//     // 列车关B侧门指令
//     outputData["doorCmdClsB"] = static_cast<bool>(bit[5]);
//     // 列车上行
//     outputData["trainUpLine"] = static_cast<bool>(bit[6]);
//     // 列车下行
//     outputData["trainDownLine"] = static_cast<bool>(bit[7]);

//     uint8_t panData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
//     std::bitset<8> bit1(panData);
//     // TCMS时间有效
//     outputData["timeSetValid"] = static_cast<bool>(bit1[0]);
//     // 列车参考速度有效
//     outputData["trainSpeedVld"] = static_cast<bool>(bit1[1]);
//     // 报站数据有效
//     outputData["codeVld"] = static_cast<bool>(bit1[2]);

//     // 时间
//     outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
//     outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
//     outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
//     outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
//     outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 8);
//     outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
//     // 列车参考速度
//     outputData["trainSpeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
//     // 列车号
//     outputData["trainNumb"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
//     // 始发站ID
//     outputData["startStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
//     // 当前站ID
//     outputData["currentStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
//     // 下一站ID
//     outputData["nextStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
//     // 终点站ID
//     outputData["endStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
//     // 离站距离
//     outputData["distLv"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
//     // 目标距离
//     outputData["distAr"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
//     // 1车乘车率
//     outputData["rateLoadC1"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 26);
//     // 2车乘车率
//     outputData["rateLoadC2"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 27);
//     // 3车乘车率
//     outputData["rateLoadC3"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 28);
//     // 4车乘车率
//     outputData["rateLoadC4"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 29);
//     // 5车乘车率
//     outputData["rateLoadC5"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 30);
//     // 6车乘车率
//     outputData["rateLoadC6"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 31);
// }

// void MVBController::displayRecvPortData(QVariantMap &portData)
// {
//     // 给页面传递数据展示
//     QVariantMap mapData;

//     QDateTime time = QDateTime::currentDateTime();
//     QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
//     portData["recvTime"] = timeFmt;

//     receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(portData));
// }

void MVBController::onUdpAlarmReceived(const std::vector<uint8_t> &&data)
{
    auto alarmData = std::move(data);
    std::string jsonStr(reinterpret_cast<const char *>(alarmData.data()), alarmData.size());
    Json::Value jsonValue = stringToJson(jsonStr);
    if (jsonValue["msgType"].asString() == "amif")
    {
        parseAmifData(jsonValue["data"]);
    }
    LogInfo("recv alarm data = {}", jsonStr);
}

void MVBController::setConfigSwitch(const TIS_Info::MvbAmifSwitch &amif,
                                    const TIS_Info::MvbAsatSwitch &asat,
                                    const TIS_Info::TrdpConfig &trdpConfig,
                                    const TIS_Info::MvbPublic &mvbConf)
{
    m_amifSwitch = amif;
    m_trdpConfig = trdpConfig;
    m_mvbPublicConfig = mvbConf;
    m_version = getConfigVersion(mvbConf.version);
}

uint16_t MVBController::getConfigVersion(const std::string &versionStr)
{
    if (versionStr.empty())
    {
        return 0;
    }
    static const std::regex verRegex(R"(\b(\d+)\.(\d+)\.(\d+)\b)");
    std::smatch m;
    if (!std::regex_search(versionStr, m, verRegex))
    {
        return 0;
    }
    unsigned major = std::stoi(m[1]);
    unsigned minor = std::stoi(m[2]);
    major = std::clamp(major, 0u, 255u);
    minor = std::clamp(minor, 0u, 255u);
    return static_cast<uint16_t>((major << 8) | minor);
}

void MVBController::parseAmifData(const Json::Value &jsonObj)
{
    TIS_Info::AmifAlarmType amifType = static_cast<TIS_Info::AmifAlarmType>(jsonObj["alarmType"].asInt());
    TIS_Info::AmifAlarmLevel amifLevel = static_cast<TIS_Info::AmifAlarmLevel>(jsonObj["alarmLevel"].asInt());
    int alarmValue = jsonObj["alarmValue"].asInt();
    // int targetOffset = amifLevel - 1; // 目标位偏移

    switch (amifType)
    {
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanAttitude: {
        // 受电弓姿态
        if (!m_amifSwitch.panAttitude)
        {
            break;
        }
        setAmifAlarm(m_headLength + 2, 0, 0, 0, 1);
        break;
    }
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanYangJiao: {
        // 羊角缺少
        if (!m_amifSwitch.panYangJiao)
        {
            break;
        }
        setAmifAlarm(m_headLength + 2, 4, 4, 4, 1);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    std::bitset<8> amifBit = m_heartData.at(offset);
    // 该类型超限所有的状态复位
    for (int i = startBit; i <= endBit; i++)
    {
        amifBit.set(i, 0);
    }
    // 设置目标位超限值
    amifBit.set(targetBit, alarmValue);
    m_heartData.at(offset) = static_cast<uint8_t>(amifBit.to_ulong());
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        LogError("recv data error, len ={}", data.size());
        return;
    }
    // TIS_Info::TrdpHeader header;
    // parseTrdpHeader(data, header);
    // LogInfo("recv all udp comId={},data={}", header.comId, ByteArrayTools::hexString(data.data(), data.size()));

    // QVariantMap dataMap;
    // std::vector<uint8_t> processData(data.begin() + m_headLength, data.end());
    // if (header.comId == m_trdpConfig.commonComID)
    // {
    //     parseCommonData(processData, dataMap);
    //     sendTcmsData(dataMap);
    //     dataMap["dataSource"] = "chongqing27_common_data";
    //     LogInfo("recv udp comId={},data={}", header.comId, ByteArrayTools::hexString(data.data(), data.size()));
    // }
    // else if (header.comId == m_trdpConfig.tcmsComID)
    // {
    //     parseCCUData(processData, dataMap);
    //     dataMap["dataSource"] = "chongqing27_ccu_data";
    // }
    // displayRecvPortData(dataMap);
}

// void MVBController::sendTcmsData(const QVariantMap &recvData)
// {
//     int curStartStation = recvData["startStation"].toInt();
//     int curEndStation = recvData["endStation"].toInt();
//     // 行别切换
//     TIS_Info::MVBCommunicationInfo mvbCommInfo;
//     mvbCommInfo.startStation = curStartStation;
//     mvbCommInfo.endStation = curEndStation;
//     mvbCommInfo.currentStationId = recvData["currentStation"].toInt();
//     mvbCommInfo.strLineName = m_mvbPublicConfig.lineName;
//     mvbCommInfo.dSpeed = recvData["trainSpeed"].toDouble() / 100;
//     if (m_startStation != curStartStation && m_endStation != curEndStation && curStartStation != 0 && curEndStation != 0)
//     {
//         m_lineDir = curStartStation < curEndStation ? 0 : 1;
//         m_startStation = curStartStation;
//         m_endStation = curEndStation;
//         LogInfo("行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
//                 m_lineDir,
//                 m_startStation,
//                 m_endStation,
//                 mvbCommInfo.currentStationId,
//                 mvbCommInfo.dSpeed);
//     }
//     mvbCommInfo.nLineDirection = m_lineDir;
//     senderMVBCommunicationsendMVBComInfo(mvbCommInfo);
// }

// void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
// {
//     if (data.size() < m_headLength)
//     {
//         return;
//     }
//     header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
//     header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
//     header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
//     header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
//     header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
//     header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
//     header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
//     header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
//     header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
//     header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
//     header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
// }

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(1000);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::sendAliveData()
{
    if (auto strongPtr = m_heartUdpClient.lock())
    {
        ++m_aliveId; // 心跳id自增

        TIS_Info::TrdpHeader header;
        header.comId = m_trdpConfig.heartComID; // 4X150
        header.sequenceCounter = m_aliveId;
        header.datasetLength = 32;
        header.protocolVersion = 0x0100;
        header.msgType = 0x5064;
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, m_aliveId, 0);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.protocolVersion, 4);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.msgType, 6);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comId, 8);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.etbTopoCnt, 12);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.opTrnTopoCnt, 16);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.datasetLength, 20);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.reserved01, 24);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyComId, 28);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyIpAddress, 32);

        // 生成校验码
        header.headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, 36);
        LogInfo("sheader.headerFcs={}", header.headerFcs);
        // 协议里面定义的是大端，但是四方所是按小端来的
        ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, header.headerFcs, 36);

        // 应用数据
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_aliveId, m_headLength + 0);
        // 软件版本v1.0
        uint8_t major = static_cast<uint8_t>(m_version >> 8);
        uint8_t minor = static_cast<uint8_t>(m_version & 0xFF);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, major, m_headLength + 2);
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, minor, m_headLength + 3);
        // 自检结果
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, 0, m_headLength + 4);
        // TCMS生命信号异常
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 0, false);
        // 设备状态
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 1, false);
        // 受电弓严重异常
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 5, 2, false);
        auto headvector = m_heartData;
        strongPtr->sendDataAsync("mvb_heart", std::move(headvector));
        std::vector<uint8_t> processData(m_heartData.begin() + m_headLength, m_heartData.end());
        LogInfo("send data={}", ByteArrayTools::hexString(processData.data(), processData.size()));

        displayHeartData();
    }
}

// void MVBController::parseCCUData(const std::vector<uint8_t> &data, QVariantMap &outputData)
// {
//     if (data.size() == 0)
//     {
//         return;
//     }
//     // CCU生命信号
//     outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
//     std::bitset<8> batteryStatus(ByteArrayTools::readFromVectorBE<uint8_t>(data, 2));
//     // 蓄电池牵引预备
//     outputData["batteryTrcOK"] = static_cast<bool>(batteryStatus[0]);
//     // 蓄电池牵引启动
//     outputData["batteryTrcOn"] = static_cast<bool>(batteryStatus[1]);

//     std::bitset<8> alarm(ByteArrayTools::readFromVectorBE<uint8_t>(data, 3));
//     // 火灾报警系统复位
//     outputData["alarmReset"] = static_cast<bool>(alarm[0]);
//     // 火灾报警系统消音
//     outputData["alarmSilence"] = static_cast<bool>(alarm[1]);

//     std::bitset<8> odd(ByteArrayTools::readFromVectorBE<uint8_t>(data, 4));
//     // ODD休眠信号
//     outputData["sleepSgnl"] = static_cast<bool>(odd[0]);
//     // ODD远程复位信号
//     outputData["resetSgnl"] = static_cast<bool>(odd[1]);

//     std::bitset<8> panData(ByteArrayTools::readFromVectorBE<uint8_t>(data, 5));
//     // 列车休眠指令
//     outputData["sleep"] = static_cast<bool>(panData[0]);
//     // 2车受电弓升起
//     outputData["pan2Up"] = static_cast<bool>(panData[1]);
//     // 5车受电弓升起
//     outputData["pan5Up"] = static_cast<bool>(panData[2]);
//     // 列车开门状态
//     outputData["doorOpen"] = static_cast<bool>(panData[3]);
//     // 列车关门状态
//     outputData["doorCls"] = static_cast<bool>(panData[4]);
//     // 正线
//     outputData["lineNorm"] = static_cast<bool>(panData[5]);
//     // 折返线
//     outputData["lineTurn"] = static_cast<bool>(panData[6]);
//     // 出入段线
//     outputData["lineInout"] = static_cast<bool>(panData[7]);

//     // 列车车次号
//     outputData["trainNum"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
//     // 网压
//     outputData["vluVlt"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
//     // 网流
//     outputData["vluCur"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);

//     std::bitset<8> mode(ByteArrayTools::readFromVectorBE<uint8_t>(data, 12));
//     // 零速信号
//     outputData["nonspeed"] = static_cast<bool>(mode[0]);
//     // 洗车模式
//     outputData["carWashVal"] = static_cast<bool>(mode[1]);
//     // AM模式
//     outputData["AMMode"] = static_cast<bool>(mode[2]);
//     // FAM模式
//     outputData["FAMMode"] = static_cast<bool>(mode[3]);

//     // 列车外部温度
//     outputData["outTemp"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 13);
//     // 列车车次号
//     outputData["trainNumb"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
//     // 1车2轴1架参考轮径值
//     outputData["wheel112"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
//     // 2车2轴1架参考轮径值
//     outputData["wheel212"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
//     // 3车2轴1架参考轮径值
//     outputData["wheel312"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
//     // 4车2轴1架参考轮径值
//     outputData["wheel412"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
//     // 5车2轴1架参考轮径值
//     outputData["wheel512"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
//     // 6车2轴1架参考轮径值
//     outputData["wheel612"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 26);
// }

// void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
// {
//     if (data.size() == 0)
//     {
//         return;
//     }
//     // CCU生命信号
//     outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
//     // 软件版本
//     outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
//     // 自检结果
//     outputData["testRlt"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
//     // 受电弓严重异常
//     uint8_t panData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
//     std::bitset<8> bit(panData);
//     outputData["tcmsLife"] = static_cast<bool>(bit[0]);
//     outputData["pmsStatus"] = static_cast<bool>(bit[1]);
//     outputData["panFault"] = static_cast<bool>(bit[2]);
// }

void MVBController::displayHeartData()
{
    // 转发数据到界面
    // QVariantMap heartData;
    // std::vector<uint8_t> data(m_heartData.begin() + m_headLength, m_heartData.end());
    // parseHeartData(data, heartData);

    // QDateTime time = QDateTime::currentDateTime();
    // QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    // heartData["sendTime"] = timeFmt;
    // heartData["dataSource"] = "chongqing27_heart";
    // try
    // {
    //     receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(heartData));
    // }
    // catch (const std::exception &e)
    // {
    //     // qDebug() << "MVBController::displayHeartData" << e.what();
    // }
}

// void MVBController::updateCommonInfo(QVariantMap &data)
// {

//     m_CurrentMvbInfo.cur_station_id = data.value("currentStation").toInt();
//     m_CurrentMvbInfo.next_station_id = data.value("nextStation").toInt();
//     m_CurrentMvbInfo.start_station_id = data.value("startStation").toInt();
//     m_CurrentMvbInfo.end_station_id = data.value("endStation").toInt();
//     m_CurrentMvbInfo.line_id = -1;
//     m_CurrentMvbInfo.train_id = data.value("trainNumb").toInt();
//     m_CurrentMvbInfo.iyear = data.value("year").toInt();
//     m_CurrentMvbInfo.imonth = data.value("month").toInt();
//     m_CurrentMvbInfo.iday = data.value("day").toInt();
//     m_CurrentMvbInfo.ihour = data.value("hour").toInt();
//     m_CurrentMvbInfo.iminute = data.value("minute").toInt();
//     m_CurrentMvbInfo.isecond = data.value("second").toInt();
//     m_CurrentMvbInfo.speed = data.value("trainSpeed").toFloat();
//     // m_CurrentMvbInfo.voltage = data.value("voltage").toFloat();
//     // m_CurrentMvbInfo.elec = data.value("electricity").toFloat();
//     // m_CurrentMvbInfo.atb_mode = data.value("ATBMode").toInt();
//     if (0 == m_CurrentMvbInfoStatus)
//     {
//         m_CurrentMvbInfoStatus = 1;
//     }
//     else if (2 == m_CurrentMvbInfoStatus)
//     {
//         std::lock_guard<std::mutex> lock(m_mutex);
//         m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
//         if (m_mvbInfoSqlvec.size() > 1000)
//         {
//             m_condition.notify_one();
//         }
//         m_CurrentMvbInfoStatus = 0;
//     }
// }
// void MVBController::updateCCUDataInfo(QVariantMap &data)
// {
//     m_CurrentMvbInfo.battery_status = -1;
//     m_CurrentMvbInfo.door_state = data.value("doorCls").toInt();
//     m_CurrentMvbInfo.panto_up = data.value("pan2Up").toInt();
//     if (0 == m_CurrentMvbInfoStatus)
//     {
//         m_CurrentMvbInfoStatus = 2;
//     }
//     else if (1 == m_CurrentMvbInfoStatus)
//     {
//         std::lock_guard<std::mutex> lock(m_mutex);
//         m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
//         if (m_mvbInfoSqlvec.size() > 1000)
//         {
//             m_condition.notify_one();
//         }
//         m_CurrentMvbInfoStatus = 0;
//     }
// }

void MVBController::writeMvbInfoToDBFun()
{
    // std::vector<_Kits::_Orm::mvb_info> mvbInfoSqlList;
    // mvbInfoSqlList.clear();
    // while (m_bHolder)
    // {
    //     {
    //         std::unique_lock<std::mutex> lock(m_mutex);
    //         m_condition.wait_for(
    //             lock, std::chrono::seconds(5), [this]() { return (!m_mvbInfoSqlvec.empty() && m_writeDBFlag) || !m_bHolder; });
    //         if (!m_bHolder)
    //         {
    //             LogInfo("MVBController::writeMvbInfoToDBFun exit");
    //             break;
    //         }
    //         m_mvbInfoSqlvec.swap(mvbInfoSqlList);
    //         m_writeDBFlag.store(false);
    //     }

    //     _Kits::MvbInfoSql::insertMvbinfoData(mvbInfoSqlList);
    //     mvbInfoSqlList.clear();
    // }
}
} // namespace _Controllers

