#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>
// #include "kits/common/database/orm/TableStructs.h"
#include "tis_global/struct_details/mvb_struct.h"
#include <vector>
#include <thread>
#include <condition_variable>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::UdpCenter::dispatchClient, MVBController::setUdpClient);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    TASK_LIST_END

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&);
    // void sendTcmsData(const QVariantMap &);
    void onUdpAlarmReceived(const std::vector<uint8_t> &&);
    void setConfigSwitch(const TIS_Info::MvbAmifSwitch &,
                         const TIS_Info::MvbAsatSwitch &,
                         const TIS_Info::TrdpConfig &,
                         const TIS_Info::MvbPublic &);

  private:
    void heartFunc();
    void sendAliveData();
    // 解析公共数据
    // void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // // 解析心跳数据
    // void parseHeartData(const std::vector<uint8_t> &, QVariantMap &);
    // // 解析trdp协议头
    // void parseTrdpHeader(const std::vector<uint8_t> &, TIS_Info::TrdpHeader &);
    // // 解析车辆数据
    // void parseCCUData(const std::vector<uint8_t> &, QVariantMap &);
    // // 界面展示接收数据
    // void displayRecvPortData(QVariantMap &);
    // 界面展示心跳数据
    void displayHeartData();
    // 解析告警数据
    void parseAmifData(const Json::Value &);
    void setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue);

    // void updateCommonInfo(QVariantMap &);
    // void updateCCUDataInfo(QVariantMap &);
    void writeMvbInfoToDBFun();

  private:
    std::atomic_bool m_bHolder = true;
    const std::string m_heartUdpName = "mvb_heart";
    const std::string m_udpName = "mvb";
    const std::string m_mvbAmifName = "mvb_amif";
    std::weak_ptr<_Kits::UdpClient> m_heartUdpClient;
    std::vector<uint8_t> m_recvData;
    std::vector<uint8_t> m_heartData;

    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    int m_headLength = 0;   // trdp协议头长度

    int m_startStation = -1;
    int m_endStation = -1;
    int m_lineDir = -1;
    float m_speed = 0;

    TIS_Info::MvbAmifSwitch m_amifSwitch;
    // std::vector<_Kits::_Orm::mvb_info> m_mvbInfoSqlvec;
    // _Kits::_Orm::mvb_info m_CurrentMvbInfo;
    std::atomic_int16_t m_CurrentMvbInfoStatus{0};
    std::thread m_mvbInfoWirteSqlThread;
    std::mutex m_mutex;
    std::condition_variable m_condition;
    std::atomic_bool m_writeDBFlag = false;

    TIS_Info::TrdpConfig m_trdpConfig;
    TIS_Info::MvbPublic m_mvbPublicConfig;
};
} // namespace _Controllers
