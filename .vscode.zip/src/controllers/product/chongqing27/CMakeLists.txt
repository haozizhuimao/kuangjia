
set(CTL_NAME "ctl_chongqing_27")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
      
target_sources(${LIB_CONTROLLERS} PUBLIC 
    $<TARGET_OBJECTS:${CTL_NAME}>
    $<TARGET_OBJECTS:kit_orm_user>
    $<TARGET_OBJECTS:kit_infrared_general>
    $<TARGET_OBJECTS:kit_save_video_by_ffmpeg>
    $<TARGET_OBJECTS:kit_rfid_kpcid1>
    $<TARGET_OBJECTS:kit_algorithm_detect_tcp>
    # $<TARGET_OBJECTS:kit_camera_hik_temperature>
    $<TARGET_OBJECTS:kit_video_manage>
    $<TARGET_OBJECTS:kit_subtitle_general>
    $<TARGET_OBJECTS:kit_video_painter>
)    

target_include_directories(${CTL_NAME} PUBLIC
    ${THIRD_PARTY_INCLUDE}/JCWLib/
)  

target_link_libraries(${CTL_NAME} PUBLIC 
        shared_dependencies 
        kit_log
        kit_orm_user
        kit_infrared_general
        kit_save_video_by_ffmpeg
        kit_rfid_kpcid1
        kit_algorithm_detect_tcp
        # kit_camera_hik_temperature
        kit_video_manage
        kit_subtitle_general
        kit_video_painter
)

find_package(OpenCV REQUIRED COMPONENTS core imgproc highgui)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
)  

target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
    res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
    res/qml/engineering_vehicle_qml/rfid_page/rfid_page.qml
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/engineering_vehicle_qml/mvb_page/mvb_page.qml
    res/qml/engineering_vehicle_qml/egv_ir_page/egv_irvideo_page.qml
    res/qml/engineering_vehicle_qml/arc_data_page/arc_data_page.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Table.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/public_controls/HighFrequencyChart.qml
    res/qml/public_controls/YunTai.qml
    res/qml/public_controls/Magnifier.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end