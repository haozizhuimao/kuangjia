#pragma once
#include "kits/common/camera/hik/base/HikBase.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include <cstdint>
#include <mutex>
#include <json/json.h>
#include <mutex>
#include "kits/communication/asio/tcp_client/TcpClient.h"
// #include "kits/common/database/orm/TableStructs.h"
#include <QImage>
#include "kits/common/algorithm_detect_tcp/algorithmMannger.h"
#include "kits/common/algorithm_detect_tcp/algorithmParseRecginze.h"
#include "kits/common/video_manage/VideoManage.h"
#include "kits/common/subtitle_general/SubtitleGeneral.h"
// #include "kits/camera/tools/LocationCtrl.h"
#include "kits/common/video_painter/VideoPainter.h"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <filesystem>

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();
    void onStopVideoMaker();

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraMap(std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>> &&) 录像kit的名称列表
    /// @param cameraInfo(std::vector<TIS_Info::HikLogInfo> &&) 相机信息
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> &);

    void onDisplayImgOption(QVariant);

    void SetExposureTimeAndGain(QVariant);
    void PTZControl(QVariant);
    void SetPTZSpeed(QVariant);

    void onGetLocation(const TIS_Info::LocationData &);
    void onTaskBegin(const TIS_Info::task_data&);
    void onTaskEnd(const TIS_Info::task_data &);
    // void onPressSpotInfo(const TIS_Info::PressAndSpot &);
    // void onVolElecInfo(const TIS_Info::VoltageAndElectric &);
    // void onJiheInfo(std::shared_ptr<TIS_Info::JiHeData>);

    void onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    void onInitHikCtrl(std::string);
    void onInitAlgorithm(const std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>> &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(_Service::HikManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(_Service::LocationService::LocationRadio, VideoMaker::onGetLocation);
    ASYNC_TASK_ADD(_Service::TaskService::taskBegin, VideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(_Service::TaskService::taskEnd, VideoMaker::onTaskEnd);
    SYNC_TASK_ADD(_Service::HikManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);
    // ASYNC_TASK_ADD(_Service::PressSpotVolElecEtcData::sendPressSpotOut, VideoMaker::onPressSpotInfo);
    // ASYNC_TASK_ADD(_Service::PressSpotVolElecEtcData::sendVolElecOut, VideoMaker::onVolElecInfo);
    // ASYNC_TASK_ADD(_Service::JiHeService::broadcast, VideoMaker::onJiheInfo);
    ASYNC_TASK_ADD(_Service::TcpClientCenter::dispatchClient, VideoMaker::onSetTcpClient);
    ASYNC_TASK_ADD(_Service::HikManager::initHikCtrl, VideoMaker::onInitHikCtrl);
    ASYNC_TASK_ADD(_Service::AlgorithmService::initAlgorithm, VideoMaker::onInitAlgorithm);

    // QML_ADD(_Service::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetExposureTimeAndGain);
    // QML_ADD(_Service::QmlCommunication::QmlActions::ParameterModification, VideoMaker::PTZControl);
    // QML_ADD(_Service::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetPTZSpeed);
    // QML_ADD(_Service::QmlCommunication::QmlActions::ParameterModification, VideoMaker::onDisplayImgOption);

    TASK_LIST_END

  public:
    void onStartRecord(QString);
    void onStopRecord();

  private:
    std::mutex m_createMutex;
    std::unordered_map<std::string, std::shared_ptr<_Kits::VideoManage>> m_videoManageMap;
    std::unordered_map<std::string, std::shared_ptr<_Kits::VideoPainter>> m_videoPainterMap;
    std::unordered_map<std::string, TIS_Info::EncoderInfo> m_encoderInfoMap;
    std::shared_ptr<std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>>> m_udm_algorithmInfo;
    std::unordered_map<std::string, std::weak_ptr<_Kits::TcpClient>> m_mpTcpClient;
    std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> m_cameraObjects;
    TIS_Info::task_data m_taskInfo;
    std::atomic_bool m_bSaveVideo;
    std::thread m_thread_alogorithmResultProcess;
    std::mutex m_subMutex;
    std::unique_ptr<_Kits::SubtitleGeneral> m_subtitleobject = nullptr;
    QString m_qstr_SavePath; // 保存路径
    // std::unique_ptr<_Kits::LocationCtrl> m_locationCtrl;
    std::mutex m_mutex;
    std::unordered_map<std::string, std::unique_ptr<_Kits::algorithmManager>> m_udm_algorithmManager;
    std::mutex m_mutex_pantoGraph;                                               // 相机名-受电弓算法结果
    std::unordered_map<std::string, TIS_Info::JiHeData> m_mpGeometricParameters; // 相机名-几何参数
    std::atomic_bool m_bAlgorithmResultProcess;
    std::mutex m_mutex_AlgorithmResultProcess;
    std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>> m_mapvAlgorithmInfo;
    std::condition_variable m_cv_AlgorithmResultProcess;
    std::unique_ptr<_Kits::AlgorithmResultParser> m_algorithmResultParser;
    std::string m_firstPath;
    TIS_Info::LocationData m_locationData;
    bool m_carbonStripWearSent; // 碳滑板数据发送标志
  private:
    void createVideoManage(const std::string &cameraName);
    void initAlogrithmResultCallback(const std::string &cameraName);
    void initAlogrithmCallback(const std::string &cameraName, std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer);
    void pantoGraphDetectResult(const std::string &cameraName, std::vector<uint8_t> &&result);
    void carbonStripWearResult(const std::string &cameraName, std::vector<uint8_t> &&result);
    void geometricParametersResult(const std::string &cameraName, std::vector<uint8_t> &&result);
    void updateSubTitle(const std::vector<std::string> &subTitles);
    void handlePantoGraphDetectResult(std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer,
                                      const std::vector<TIS_Info::pantograph_info> &pantoGraphInfo,
                                      const std::string &jsonvalue);
    void processAlogrithmResultThread();
    void startAllThread();
    void stopAllThread();
    void saveImageBuffer(std::shared_ptr<TIS_Info::ImageBuffer> &img, std::filesystem::path folderName);
    void handleTaskBegin(const TIS_Info::task_data &task_info);
    void handleTaskEnd(const TIS_Info::task_data &task_info);
    bool createDirectory(const QString &dirPath);
    std::filesystem::path getSaveName(const std::string &fileName, const std::string &middleName);
    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yv12);
    void initAlogrithm();
};
} // namespace _Controllers
