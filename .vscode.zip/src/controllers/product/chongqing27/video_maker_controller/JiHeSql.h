#pragma once

#include "tis_global/Struct.h"
#include <string>
namespace _Kits
{

    // class JiHeSql
    // {
    //   public:
    //     static int insertJiheDataToDB(const TIS_Info::JiHeData &data,const int taskID);
    // };

} // namespace _Kits