#include "WritePGDefectSql.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"

namespace _Kits {
// int WritePGDefectSql::insertPantoGraphData(const std::vector<TIS_Info::pantograph_info> &pgInfo,
//                                            const std::string &savePath,
//                                            const Json::Value &jsonData,
//                                            const int taskID)
// {
//     auto PGDefectData = initPantoGraphData(pgInfo, savePath, jsonData, taskID);
//     auto ret = writePGDefectDataToDatabase(PGDefectData);
//     if (!ret)
//     {
//         return 1;
//     }
//     return 0;
// }

// _Kits::_Orm::pantograph_defect_data WritePGDefectSql::initPantoGraphData(const std::vector<TIS_Info::pantograph_info> &pgInfo,
//                                                                          const std::string &savePath,
//                                                                          const Json::Value &jsonData,
//                                                                          const int taskID)
// {
//     _Kits::_Orm::pantograph_defect_data PGDefectData;
//     for (const auto &info : pgInfo)
//     {
//         if (info.conponentNameID == 11)
//         {
//             PGDefectData.yangjiao_front_left = 1;
//         }
//         else if (info.conponentNameID == 53 || info.conponentNameID == 10)
//         {
//             PGDefectData.pantowear = 1;
//         }
//     }
//     PGDefectData.task_id = (taskID == -1) ? 0 : taskID;
//     PGDefectData.csv_file_path = "";
//     PGDefectData.defect_image_path = QString::fromStdString(savePath);
//     PGDefectData.defect_json = QString::fromStdString(_Kits::jsonToString(jsonData));
//     return PGDefectData;
// }

// bool WritePGDefectSql::writePGDefectDataToDatabase(const _Kits::_Orm::pantograph_defect_data &PGDefectData)
// {
//     _Kits::SqlInsert<_Kits::_Orm::pantograph_defect_data> sqlInsert;
//     sqlInsert.insert(PGDefectData);
//     if (!sqlInsert.exec())
//     {
//         return false;
//     }
//     return true;
//}

} // namespace _Kits