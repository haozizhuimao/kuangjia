#pragma once
#include <opencv2/opencv.hpp>
#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>

namespace _Kits
{
    class DrawCarbonStripWearPoints
    {
      public:
        static  bool drawImage(const std::vector<std::unordered_map<std::string, double>> &points,const std::filesystem::path &savePath);

      private:
        static std::vector<cv::Point2d> splineInterpolation(const std::vector<cv::Point2d>& points, int num_points);
        static std::vector<cv::Point2d> sort_points_by_x(const std::vector<cv::Point2d>& points);
        static std::vector<cv::Point2d> sample_points(const std::vector<cv::Point2d>& points, int step);
        static cv::Point2d dataToPixelCoords(const cv::Point2d& data_point, double x_min, double x_max, double y_min, double y_max,int width, int height);
        static void scaleCanvasYAxis(cv::Mat& canvas, float scaleFactor);
        static std::vector<cv::Point2d> symmetrizeDataPoints(const std::vector<cv::Point2d>& input_points);
        static bool preprocessData(const std::vector<std::unordered_map<std::string, double>>& points,std::vector<cv::Point2d>& input_pts,double& min_x, double& max_x, double& min_y, double& max_y);
        static void drawScatterPoints(cv::Mat& image,const std::vector<cv::Point2d>& points,double min_x, double max_x, double min_y, double max_y,int width, int height, int margin); 
        static std::vector<cv::Point2d> sampleDataPoints(const std::vector<cv::Point2d>& points, int step);
        static std::vector<cv::Point2d> sortPointsByX(const std::vector<cv::Point2d>& points);
        static void drawCurve(cv::Mat& image, const std::vector<cv::Point2d>& points,double min_x, double max_x, double min_y, double max_y,int width, int height, int margin,bool use_spline = true);
        static void drawSmoothCurve(cv::Mat& image, const std::vector<cv::Point2d>& original_pts,double min_x, double max_x, double min_y, double max_y, int width, int height, int margin);
        static void adjustDataRange(double& min_x, double& max_x, double& min_y, double& max_y, double margin_ratio = 0.05);
    };

} // namespace _Kits