#pragma once

#include "tis_global/Struct.h"
#include <QString>
namespace _Kits
{

    class SaveCarbonStripPoints
    {
      public:
        static void saveCarbonStripPointsToCSV(const std::vector<std::unordered_map<std::string, double>> &points,const QString &savePath);
    };

} // namespace _Kits