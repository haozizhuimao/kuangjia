#include "JiHeSql.h"
// #include "kits/common/database/CppBatis.h"
// #include "kits/utility/log/CRossLogger.h"

namespace _Kits {
// int JiHeSql::insertJiheDataToDB(const TIS_Info::JiHeData &data, const int taskID)
// {
//     _Kits::_Orm::jihe_data jiheData;
//     jiheData.task_id = (taskID == -1) ? 0 : taskID;
//     jiheData.zig0 = data.fZig[0];
//     if (data.fZig[1] != 0)
//     {
//         jiheData.zig1 = data.fZig[1];
//     }

//     _Kits::SqlInsert<_Kits::_Orm::jihe_data> sqlInsert;
//     sqlInsert.insert(jiheData);
//     if (!sqlInsert.exec())
//     {
//         _Kits::LogInfo("Failed to write jihe data to database.");
//         return 1;
//     }
//     return 0;
// }

} // namespace _Kits