#include "DrawCarbonStripWearPoints.h"
#include "kits/utility/log/CRossLogger.h"
#include <filesystem>
#include <algorithm>

namespace _Kits {
using namespace cv;
using namespace std;
std::vector<cv::Point2d> DrawCarbonStripWearPoints::splineInterpolation(const std::vector<cv::Point2d> &points, int num_points)
{
    std::vector<cv::Point2d> interpolated;
    if (points.size() < 2)
        return points;

    // 确保输入点已经按x坐标排序
    std::vector<cv::Point2d> sorted_points = points;
    std::sort(sorted_points.begin(), sorted_points.end(), [](const cv::Point2d &a, const cv::Point2d &b) { return a.x < b.x; });

    double x_min = sorted_points.front().x;
    double x_max = sorted_points.back().x;

    for (int i = 0; i < num_points; i++)
    {
        double t = static_cast<double>(i) / (num_points - 1);
        double target_x = x_min + t * (x_max - x_min);

        // 找到目标x值所在的区间
        bool found = false;
        for (size_t j = 0; j < sorted_points.size() - 1; j++)
        {
            if (target_x >= sorted_points[j].x && target_x <= sorted_points[j + 1].x)
            {
                double ratio = (target_x - sorted_points[j].x) / (sorted_points[j + 1].x - sorted_points[j].x);
                double y = sorted_points[j].y + ratio * (sorted_points[j + 1].y - sorted_points[j].y);

                interpolated.push_back(cv::Point2d(target_x, y));
                found = true;
                break;
            }
        }

        if (!found)
        {
            if (target_x <= sorted_points.front().x)
            {
                interpolated.push_back(sorted_points.front());
            }
            else
            {
                interpolated.push_back(sorted_points.back());
            }
        }
    }

    return interpolated;
}

vector<Point2d> DrawCarbonStripWearPoints::sample_points(const vector<Point2d> &points, int step)
{
    vector<Point2d> sampled;
    for (size_t i = 0; i < points.size(); i += step)
    {
        sampled.push_back(points[i]);
    }
    return sampled;
}

std::vector<Point2d> DrawCarbonStripWearPoints::sort_points_by_x(const vector<Point2d> &points)
{
    vector<Point2d> sorted_points = points;
    sort(sorted_points.begin(), sorted_points.end(), [](const Point2d &a, const Point2d &b) { return a.x < b.x; });
    return sorted_points;
}
vector<Point2d> sample_points(const vector<Point2d> &points, int step)
{
    vector<Point2d> sampled;
    for (size_t i = 0; i < points.size(); i += step)
    {
        sampled.push_back(points[i]);
    }
    return sampled;
}

Point2d DrawCarbonStripWearPoints::dataToPixelCoords(
    const Point2d &data_point, double x_min, double x_max, double y_min, double y_max, int width, int height)
{
    // double x_ratio = (data_point.x - x_min) / (x_max - x_min);
    // double y_ratio = (data_point.y - y_min) / (y_max - y_min);

    if (x_max <= x_min)
        x_max = x_min + 1.0;
    if (y_max <= y_min)
        y_max = y_min + 1.0;

    double x_ratio = (data_point.x - x_min) / (x_max - x_min);
    double y_ratio = (data_point.y - y_min) / (y_max - y_min);

    // 限制比例在 [0, 1] 范围内，防止超出
    x_ratio = std::max(0.0, std::min(1.0, x_ratio));
    y_ratio = std::max(0.0, std::min(1.0, y_ratio));

    return Point2d(x_ratio * width, y_ratio * height);
}

std::vector<cv::Point2d> DrawCarbonStripWearPoints::symmetrizeDataPoints(const std::vector<cv::Point2d> &input_points)
{
    std::vector<cv::Point2d> result;
    if (input_points.empty())
    {
        return result;
    }

    // 找到第一个y=19的位置
    size_t first_19_index = input_points.size();
    for (size_t i = 0; i < input_points.size(); i++)
    {
        if (std::abs(input_points[i].y - 19.0) < 1e-6)
        {
            first_19_index = i;
            break;
        }
    }

    // 找到最后一个y=19的位置
    size_t last_19_index = 0;
    for (size_t i = input_points.size() - 1; i < input_points.size(); i--)
    {
        if (std::abs(input_points[i].y - 19.0) < 1e-6)
        {
            last_19_index = i;
            break;
        }
        if (i == 0)
            break; // 防止无符号整数下溢
    }

    // 如果没有找到y=19的点，返回原始数据
    if (first_19_index == input_points.size() || last_19_index == 0)
    {
        return input_points;
    }

    // 计算两段的数量
    size_t count_to_first_19 = first_19_index;                           // 起始到第一个19的数量
    size_t count_from_last_19 = input_points.size() - last_19_index - 1; // 最后一个19到结尾的数量

    // 取两段长度的最小值
    size_t min_count = std::min(count_to_first_19, count_from_last_19);
    auto diff = count_to_first_19 - count_from_last_19;
    if (diff > 0)
    {
        result.insert(result.end(), input_points.begin() + diff, input_points.end());
    }
    else if (diff < 0)
    {
        size_t count = input_points.size() - diff;
        result.insert(result.end(), input_points.begin(), input_points.begin() + count);
    }
    else
    {
        result = input_points;
    }

    return result;
}

bool DrawCarbonStripWearPoints::preprocessData(const std::vector<std::unordered_map<std::string, double>> &points,
                                               std::vector<cv::Point2d> &input_pts,
                                               double &min_x,
                                               double &max_x,
                                               double &min_y,
                                               double &max_y)
{
    if (points.size() < 2)
        return false;

    input_pts.clear();
    input_pts.reserve(points.size());

    min_x = std::numeric_limits<double>::max();
    max_x = std::numeric_limits<double>::lowest();
    min_y = std::numeric_limits<double>::max();
    max_y = std::numeric_limits<double>::lowest();

    for (const auto &p : points)
    {
        auto itX = p.find("x");
        auto itY = p.find("y");
        if (itX == p.end() || itY == p.end())
            return false;

        double x = itX->second;
        double y = itY->second;
        if (y > 19)
        {
            y = 19;
        }

        input_pts.emplace_back(x, y);

        // 更新范围
        if (x < min_x)
            min_x = x;
        if (x > max_x)
            max_x = x;
        if (y < min_y)
            min_y = y;
        if (y > max_y)
            max_y = y;
    }

    return !input_pts.empty();
}
void DrawCarbonStripWearPoints::drawScatterPoints(cv::Mat &image,
                                                  const std::vector<cv::Point2d> &points,
                                                  double min_x,
                                                  double max_x,
                                                  double min_y,
                                                  double max_y,
                                                  int width,
                                                  int height,
                                                  int margin)
{
    for (const auto &point : points)
    {
        cv::Point2d pixel = dataToPixelCoords(point, min_x, max_x, min_y, max_y, width - 2 * margin, height - 2 * margin);
        cv::Point center(margin + pixel.x, height - margin - pixel.y);
        cv::circle(image, center, 5, cv::Scalar(0, 0, 255), -1); // 红色圆点
    }
}

std::vector<cv::Point2d> DrawCarbonStripWearPoints::sampleDataPoints(const std::vector<cv::Point2d> &points, int step)
{
    std::vector<cv::Point2d> sampled;
    for (size_t i = 0; i < points.size(); i += step)
    {
        sampled.push_back(points[i]);
    }
    return sampled;
}

// 5. 按x坐标排序函数
std::vector<cv::Point2d> DrawCarbonStripWearPoints::sortPointsByX(const std::vector<cv::Point2d> &points)
{
    std::vector<cv::Point2d> sorted_points = points;
    std::sort(sorted_points.begin(), sorted_points.end(), [](const cv::Point2d &a, const cv::Point2d &b) { return a.x < b.x; });
    return sorted_points;
}

// 7. 绘制曲线函数
void DrawCarbonStripWearPoints::drawCurve(cv::Mat &image,
                                          const std::vector<cv::Point2d> &points,
                                          double min_x,
                                          double max_x,
                                          double min_y,
                                          double max_y,
                                          int width,
                                          int height,
                                          int margin,
                                          bool use_spline)
{
    if (points.size() < 2)
        return;

    std::vector<cv::Point> pixel_points;
    for (const auto &point : points)
    {
        cv::Point2d pixel = dataToPixelCoords(point, min_x, max_x, min_y, max_y, width - 2 * margin, height - 2 * margin);
        int y_coord = height - margin - pixel.y;
        pixel_points.push_back(cv::Point(margin + pixel.x, y_coord));
    }

    if (pixel_points.size() > 1)
    {
        cv::polylines(image, pixel_points, false, cv::Scalar(255, 0, 0), 3, cv::LINE_AA);
    }
}

// 8. 绘制平滑曲线函数
void DrawCarbonStripWearPoints::drawSmoothCurve(cv::Mat &image,
                                                const std::vector<cv::Point2d> &original_pts,
                                                double min_x,
                                                double max_x,
                                                double min_y,
                                                double max_y,
                                                int width,
                                                int height,
                                                int margin)
{
    if (original_pts.size() <= 2)
    {
        // 点太少，直接绘制直线
        drawCurve(image, original_pts, min_x, max_x, min_y, max_y, width, height, margin, false);
        return;
    }

    // 数据抽样
    std::vector<cv::Point2d> sampled_points;
    std::vector<cv::Point2d> curve_points;

    if (original_pts.size() > 20)
    {
        std::vector<cv::Point2d> sorted_points = sortPointsByX(original_pts);
        sampled_points = sampleDataPoints(sorted_points, 20);
        curve_points = sampled_points;
    }
    else
    {
        curve_points = sortPointsByX(original_pts);
    }

    if (curve_points.size() > 2)
    {
        // 使用插值创建平滑曲线
        std::vector<cv::Point2d> smooth_points = splineInterpolation(curve_points, 500);
        drawCurve(image, smooth_points, min_x, max_x, min_y, max_y, width, height, margin, true);
    }
    else
    {
        drawCurve(image, original_pts, min_x, max_x, min_y, max_y, width, height, margin, false);
    }
}

// 9. 调整数据范围函数
void DrawCarbonStripWearPoints::adjustDataRange(double &min_x, double &max_x, double &min_y, double &max_y, double margin_ratio)
{
    double x_range = max_x - min_x;
    double y_range = max_y - min_y;
    min_x -= x_range * margin_ratio;
    max_x += x_range * margin_ratio;
    min_y -= y_range * margin_ratio;
    max_y += y_range * margin_ratio;
}

bool DrawCarbonStripWearPoints::drawImage(const std::vector<std::unordered_map<std::string, double>> &points,
                                          const std::filesystem::path &savePath)
{
    try
    {
        /* 1. 参数检查 */
        if (points.size() < 2)
            return false;

        /* 2. 提取 x/y 并计算实际数据范围 */
        std::vector<cv::Point2d> input_pts; // 使用Point2d保持精度
        double min_x = std::numeric_limits<double>::max();
        double max_x = std::numeric_limits<double>::lowest();
        double min_y = std::numeric_limits<double>::max();
        double max_y = std::numeric_limits<double>::lowest();

        preprocessData(points, input_pts, min_x, max_x, min_y, max_y);

        auto original_pts = input_pts;
        // auto original_pts = symmetrizeDataPoints(input_pts);

        const int width = 1000;
        const int height = 600;
        const int margin = 80;
        Mat image(height, width, CV_8UC3, Scalar(255, 255, 255));

        // 4. 调整数据范围
        adjustDataRange(min_x, max_x, min_y, max_y, 0.05);

        // 5. 数据抽样和散点绘制
        if (original_pts.size() > 20)
        {
            std::vector<cv::Point2d> sorted_points = sortPointsByX(original_pts);
            std::vector<cv::Point2d> sampled_points = sampleDataPoints(sorted_points, 20);
            drawScatterPoints(image, sampled_points, min_x, max_x, min_y, max_y, width, height, margin);
        }
        else
        {
            drawScatterPoints(image, original_pts, min_x, max_x, min_y, max_y, width, height, margin);
        }

        // 6. 绘制平滑曲线
        drawSmoothCurve(image, original_pts, min_x, max_x, min_y, max_y, width, height, margin);

        /* 12. 确保目录存在并保存 */
        scaleCanvasYAxis(image, 0.15);
        std::filesystem::create_directories(savePath.parent_path());
        return cv::imwrite(savePath.string(), image);
    }
    catch (const std::exception &e)
    {
        std::cerr << "Error in drawSmoothedCurve: " << e.what() << std::endl;
        return false;
    }
}

void DrawCarbonStripWearPoints::scaleCanvasYAxis(cv::Mat &canvas, float scaleFactor)
{
    if (canvas.empty() || scaleFactor <= 0)
    {
        return;
    }

    cv::Mat scaledCanvas;
    cv::resize(canvas, scaledCanvas, cv::Size(), 1.0, scaleFactor, cv::INTER_LINEAR);
    canvas = scaledCanvas;
}

} // namespace _Kits