#include "SaveCarbonStripPoints.h"
#include "kits/utility/log/CRossLogger.h"
#include <QFile>
#include <QTextStream>

namespace _Kits {
void SaveCarbonStripPoints::saveCarbonStripPointsToCSV(const std::vector<std::unordered_map<std::string, double>> &points,
                                                       const QString &savePath)
{
    QFile file(savePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
    {
        _Kits::LogError("无法打开文件:{},{}", savePath.toStdString(), file.errorString().toStdString());
        return;
    }

    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);

    // 写入表头
    out << "x,y,height\n";

    // 遍历每个点
    int pointCount = 0;
    for (const auto &point : points)
    {
        double x = 0.0, y = 0.0;

        if (auto it = point.find("x"); it != point.end())
            x = it->second;
        if (auto it = point.find("y"); it != point.end())
            y = it->second;

        out << x << "," << y << ",\n";
        pointCount++;
    }

    file.close();
    _Kits::LogInfo("CSV文件保存成功:{},{}", savePath.toStdString(), pointCount);
    return;
}

} // namespace _Kits