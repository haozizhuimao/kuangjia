# product 目录说明

`src/controllers/product/` 存放各产品版本或交付场景的控制器装配代码。

## 如何定位一个产品版本

通常建议按这个顺序查：

1. 根目录 `.version`
2. `tis_cmake/version_build/<CURRENT_VERSION>.cmake`
3. 本目录下对应的产品目录
4. `config/` 下对应的场景配置目录

## 当前特点

- 产品目录数量较多，命名基本与版本或项目场景对应
- 不是所有 `CURRENT_VERSION` 都严格和这里的目录一一同名
- 当前仍有入口漂移，例如 `ROSEEK_VIDEO` 的声明路径和实际源码目录并不一致

## 与其他目录的关系

- 需要结合 [版本矩阵](../../../doc/version-matrix.md) 看
- 需要结合 [config 目录说明](../../../config/README.md) 看
