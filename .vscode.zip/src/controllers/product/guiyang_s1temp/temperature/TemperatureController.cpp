#include "TemperatureController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "kits/common/utils/TimeToString.h"
#include "kits/common/histroy_uniqueidrecv/HistoryUniqueIDRecviever.h"
// #include "kits/serialization/serialize_jsoncpp.h"
#include <QPainter>

#include <iostream>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TemperatureController::recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
{
    m_IRImageQueue.pushItemNoBlocking(std::move(IRimagebuffer));
}
void TemperatureController::recvTempRect(const int startx, const int starty, const int endx, const int endy, const int w, const int h)
{
    m_startx = startx;
    m_starty = starty;
    m_endx = endx;
    m_endy = endy;
    m_normalwidth = w;
    m_normalheight = h;
}
void TemperatureController::init(const QVariant &data)
{
    auto configpath = data.toMap().value("configpath").toByteArray().toStdString();
    auto config = YAML::LoadFile(configpath);

    m_strSavePicRoot = config["rootpath"].as<std::string>();

    auto irconfig = config["irdata"];
    m_fAlarmTemp1 = irconfig["alarmtemp1"].as<double>();
    m_fAlarmTemp2 = irconfig["alarmtemp2"].as<double>();
    m_fAlarmTemp3 = irconfig["alarmtemp3"].as<double>();

    m_fmaxTemperature_calibration = irconfig["maxtemperatrue"].as<double>();
    m_favgTemperature_coefficient = irconfig["avgtemperatrue_coeff"].as<double>();
    // m_iAlarmTimeInterval = irconfig["limittime"].as<uint32_t>();
    m_getTemperatrueType = irconfig["irtype"].as<uint32_t>();
    m_model = std::make_shared<_Kits::AlgorithmGuiyang>();
    int res = m_model->init();

    m_startFalg.store(true);
    m_IRImageThread = std::thread(&TemperatureController::handleIRImageThread, this);
    m_sendUDP = std::thread(&TemperatureController::sendUDPThread, this);
}
void TemperatureController::notifyTaskfunc(const QVariant &data)
{
    auto taskinfomap = data.toMap();
    auto taskname = taskinfomap.value("taskname").toByteArray().toStdString();

    auto taskstate = taskinfomap.value("taskstate").toInt();
    if (0 == taskstate)
    {
        createSaveDiretory(taskname);
        // m_taskFlag.store(true);
    }
    else if (1 == taskstate)
    {
        m_taskFlag.store(false);
    }
}
void TemperatureController::stop()
{
    exitthread();
    m_model->moduleFree();
}
void TemperatureController::sendDisplayLog(const QString &data)
{
    App().invokeModuleAsync(
        TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::displaylog_send, QVariant::fromValue(data));
}
void TemperatureController::handleIRImageThread()
{
    std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer = nullptr;
    while (m_startFalg.load())
    {
        {
            IRimagebuffer = m_IRImageQueue.popItem();
        }
        if (nullptr == IRimagebuffer)
        {
            break;
        }

        QByteArray byteArray(reinterpret_cast<const char *>(IRimagebuffer->data.data()), IRimagebuffer->iamgesize);
        QImage image = QImage::fromData(byteArray, "JPG");
        // 转换图像格式
        QImage BGRImage = image.convertToFormat(QImage::Format_BGR888);
        // 推理模型
        std::unordered_map<int, QRect> rects;
        LogInfo("开始推理模型");
        //    QString filepath = "D:/workspace/贵阳s1红外测温程序/贵阳s1红外测温程序/test_data/save/result_1.jpg";
        //    QImage img(filepath);
        //    QImage img_ = img.convertToFormat(QImage::Format_BGR888);
        m_model->inferenceAlgorithmModel(BGRImage, rects);
        if (!rects.empty())
        {
            // 框选出检测区域
            dealSendToQmlRectData(BGRImage, rects);
        }
        else
        {
            // 没检测出结果，使用默认框选结果
            dealSendToQmlData(BGRImage, IRimagebuffer->width, IRimagebuffer->height);
        }

        m_model->inferenceAlgorithmModel(image, rects);
        dealSendToQmlData(image, IRimagebuffer->width, IRimagebuffer->height);
        dealSendToQmlRectData(image, rects);
        QImage imagesave = image.copy();

        if (1 == m_getTemperatrueType)
        {
            if (!rects.empty())
            {
                analysisHotPicData(
                    IRimagebuffer->tempdata.data(), rects, IRimagebuffer->width, IRimagebuffer->height); // 支持多输出框的温度筛选
            }
            else
            {
                analysisHotPicData(IRimagebuffer->tempdata.data(), IRimagebuffer->width, IRimagebuffer->height);
            }

            // analysisHotPicData(IRimagebuffer->tempdata.data(),IRimagebuffer->width,IRimagebuffer->height);
        }
        else
        {
            m_avgtemp.store(IRimagebuffer->avgtemp);
            m_maxtemp.store(IRimagebuffer->maxtemp);
            m_mintemp.store(IRimagebuffer->mintemp);
            m_tempPoint.setX(IRimagebuffer->maxpointx * IRimagebuffer->width);
            m_tempPoint.setY(IRimagebuffer->maxpointy * IRimagebuffer->height);
        }

        auto maxTemp = m_favgTemperature_coefficient * m_maxtemp.load() + m_fmaxTemperature_calibration;
        m_maxtemp.store(maxTemp);

        sendMaxTempToQml(QVariant::fromValue(m_maxtemp.load()));

        dealIRImageData(imagesave);
    }
}
void TemperatureController::dealSendToQmlRectData(QImage &image, std::unordered_map<int, QRect> &rects)
{
    QVariantMap imgMap;
    for (auto &[index, rect] : rects)
    {
        if (rect.isValid())
        {
            QPainter painter(&image);
            painter.setPen(Qt::green);
            painter.setBrush(Qt::NoBrush); // 不填充
            painter.drawRect(rect);        // 绘制矩形
        }
        // image.save("./test222.jpg");
    }
    imgMap["img"] = image.convertToFormat(QImage::Format_BGR888);
    imgMap["camera_name"] = QString::fromStdString("");
    sendImage(QVariant::fromValue(imgMap));
}
void TemperatureController::dealSendToQmlData(QImage &image, int width, int height)
{
    QVariantMap imgMap;
    int offsetx = m_startx * width / m_normalwidth;
    int offsety = m_starty * height / m_normalheight;
    int endoffsetx = m_endx * width / m_normalwidth;
    int endoffsety = m_endy * height / m_normalheight;

    QPainter painter(&image);
    QPoint topleft(offsetx, height - endoffsety);
    QPoint bottomRight(endoffsetx, height - offsety);
    QRect rect(topleft, bottomRight);
    painter.setPen(Qt::green);
    painter.setBrush(Qt::NoBrush); // 不填充
    painter.drawRect(rect);        // 绘制矩形

    imgMap["img"] = image.convertToFormat(QImage::Format_BGR888);
    imgMap["camera_name"] = QString::fromStdString("");
    sendImage(QVariant::fromValue(imgMap));
}
void TemperatureController::dealIRImageData(QImage &image)
{
    if (!m_taskFlag.load())
    {
        return;
    }

    bool bLimitByTime = true;
    auto now = std::chrono::high_resolution_clock::now();
    auto durationtime = std::chrono::duration_cast<std::chrono::seconds>(now - m_saveImageTime);

    if (m_saveImageTime != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_iAlarmTimeInterval)
    {
        bLimitByTime = false;
    }

    int alarmLevel = isAlarm(m_maxtemp.load());
    if (alarmLevel > 0)
    {
        if (bLimitByTime)
        {
            m_saveImageTime = now;
            QPainter paintermax(&image);

            QPoint topleft = m_tempPoint - QPoint(20, 20);
            QPoint bottomRight = m_tempPoint + QPoint(20, 20);
            QRect rect(topleft, bottomRight);

            paintermax.setPen(Qt::black);
            paintermax.setBrush(Qt::NoBrush); // 不填充
            paintermax.drawRect(rect);        // 绘制矩形
            paintermax.setFont(QFont("Arial", 10));
            paintermax.drawText(m_tempPoint.x(), m_tempPoint.y() + 15, QString::number(m_maxtemp.load()));
            auto picname = generatePictureName();
            image.save((QString::fromLocal8Bit(picname.data())));
        }
        QString strShowMaxTemp = "最高温度:" + QString::number(m_maxtemp.load()) + "警告等级:" + QString::number(alarmLevel);
        sendDisplayLog(strShowMaxTemp);

        // 发送数据库
    }
    m_avgtemp.store((m_mintemp + m_maxtemp) / 2);
    dealIRAlarmData(alarmLevel, m_mintemp.load(), m_maxtemp.load(), m_avgtemp.load());
}
void TemperatureController::createSaveDiretory(const std::string &taskName)
{
    LogInfo("ArcDataDeal::startTask:{}", taskName);
    // m_taskFlag.store(true);

    // if(m_taskFlag.load())
    // {
    // 	stopTask();
    // }
    QString strPath = QString::fromStdString(m_strSavePicRoot);
    // std::filesystem::path path(strPath.toStdWString());
    std::filesystem::path path(strPath.toStdWString());
    path.append(TimeToString::getYearMonthDayStr());
    path.append(taskName);
    path.append(L"红外超限");

    m_taskSvaePath = path.string();

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    LogInfo("start success:{}", m_taskSvaePath);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    m_taskFlag.store(true);
}
std::string TemperatureController::generatePictureName()
{
    std::string strPicName = std::to_string(m_iSaveImgCount++) + "_" + TimeToString::getHourMinSecStr() + "_" + std::to_string(m_fgpsx) +
                             "_" + std::to_string(m_fgpsy) + ".jpg";
    std::string picname = m_taskSvaePath + "\\" + strPicName;
    return picname;
}
void TemperatureController::calculateTempRect(int &offsetx, int &offsety, int &endx, int &endy, const int width, const int height)
{
    if (0 != m_normalheight && 0 != m_normalwidth)
    {
        offsetx = m_startx * width / m_normalwidth;
        offsety = height - m_endy * height / m_normalheight;

        int endoffsetx = m_endx * width / m_normalwidth;
        endx = endoffsetx > width ? width : endoffsetx;

        int endoffsety = height - m_starty * height / m_normalheight;
        endy = endoffsety > height ? height : endoffsety;
    }
    else
    {
        offsetx = 0;
        offsety = 0;
        endx = width;
        endy = height;
    }
}
void TemperatureController::analysisHotPicData(const uint8_t *buf, std::unordered_map<int, QRect> &rects, int w, int h)
{
    int iIndex = 0;
    char temp[10] = {0};
    float minTemp = 10000.0;
    float maxTemp = -10000.0;

    for (auto [index, rect] : rects)
    {
        int offsetx = rect.x();
        int offsety = rect.y();
        int endoffsetx = offsetx + rect.width();
        int endoffsety = offsety + rect.height();
        int weight = rect.width();
        int height = rect.height();
        calculateTempRect(offsetx, offsety, endoffsetx, endoffsety, w, h);
        int dataoffset = offsety * weight * 4 + offsetx * 4;
        // 根据宽高遍历所有数据
        for (int iWriteHeight = offsety; iWriteHeight < endoffsety; ++iWriteHeight)
        {
            iIndex = 0;
            for (int iWriteWidth = offsetx; iWriteWidth < endoffsetx; ++iWriteWidth)
            {
                // 解析数据
                float fTemp = *((float *)(buf + dataoffset + iIndex));

                // 判断fTemp是否是一个正常值，不是则赋值最大或最小，防止设备崩溃
                fTemp = (9999 < fTemp) ? 9999 : ((-9999 > fTemp) ? -9999 : fTemp);

                minTemp = (minTemp > fTemp) ? fTemp : minTemp;
                if (maxTemp < fTemp)
                {
                    maxTemp = fTemp;
                    m_tempPoint.setX(iWriteWidth);
                    m_tempPoint.setY(iWriteHeight);
                }

                memset(temp, 0, sizeof(temp));
                sprintf(temp, "%.2f,", fTemp);
                iIndex += 4;
            }
            dataoffset += weight * 4;
        }
    }
    m_mintemp.store(minTemp);
    m_maxtemp.store(maxTemp);
    LogTrace("************************ minTemp: {}, maxTemp: {}", m_mintemp.load(), m_maxtemp.load());
}
void TemperatureController::analysisHotPicData(const uint8_t *buf, int width, int height)
{
    int iIndex = 0;
    char temp[10] = {0};
    float minTemp = 10000.0;
    float maxTemp = -10000.0;

    int offsetx = 0;
    int offsety = 0;
    int endoffsetx = width;
    int endoffsety = height;
    calculateTempRect(offsetx, offsety, endoffsetx, endoffsety, width, height);

    int dataoffset = offsety * width * 4 + offsetx * 4;
    // 根据宽高遍历所有数据
    for (int iWriteHeight = offsety; iWriteHeight < endoffsety; ++iWriteHeight)
    {
        iIndex = 0;
        for (int iWriteWidth = offsetx; iWriteWidth < endoffsetx; ++iWriteWidth)
        {
            // 解析数据
            float fTemp = *((float *)(buf + dataoffset + iIndex));

            // 判断fTemp是否是一个正常值，不是则赋值最大或最小，防止设备崩溃
            fTemp = (9999 < fTemp) ? 9999 : ((-9999 > fTemp) ? -9999 : fTemp);

            minTemp = (minTemp > fTemp) ? fTemp : minTemp;
            if (maxTemp < fTemp)
            {
                maxTemp = fTemp;
                m_tempPoint.setX(iWriteWidth);
                m_tempPoint.setY(iWriteHeight);
            }

            memset(temp, 0, sizeof(temp));
            sprintf(temp, "%.2f,", fTemp);
            iIndex += 4;
        }
        dataoffset += width * 4;
    }

    m_mintemp.store(minTemp);
    m_maxtemp.store(maxTemp);
    LogTrace("************************ minTemp: {}, maxTemp: {}", m_mintemp.load(), m_maxtemp.load());
    return;
}
int TemperatureController::isAlarm(const float tempValue)
{
    int alarmLeve = 0;

    if (tempValue >= m_fAlarmTemp1)
    {
        alarmLeve = 1;
    }
    if (tempValue >= m_fAlarmTemp2 && tempValue < m_fAlarmTemp1)
    {
        alarmLeve = 2;
    }
    if (tempValue >= m_fAlarmTemp3 && tempValue < m_fAlarmTemp2)
    {
        alarmLeve = 3;
    }

    if (alarmLeve > 0)
    {
        // if (m_timer.GetElapseTime() > m_iAlarmTimeInterval * 1000.0)    //10秒只保存1张图
        // {
        // 	m_timer.StartTiming();
        // 	return alarmLeve;
        // }
        // else
        // {
        // 	return 0;   //不报警不存图但是会记录数据库
        // }
    }

    return alarmLeve;
}
void TemperatureController::dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp)
{
    long long lFileTime = 0;
    double dtimeStamp = 0;
    HistoryUniqueIDRecviever::Instance().getFileTimeAndTimeStamp(lFileTime, dtimeStamp);
    QVariantMap irDatamap;
    irDatamap.insert("irlevel", level);
    irDatamap.insert("mintemperature", mintemp);
    irDatamap.insert("maxtemperature", maxtemp);

    irDatamap.insert("lltimestamp", lFileTime);
    irDatamap.insert("dtimestamp", dtimeStamp);
    irDatamap.insert("avgtemperature", avgtemp);
    // emit sendIRData(irDatamap);
    App().invokeModuleAsync(TIS_Info::HistroyProgramComm::writeIRData, QVariant::fromValue(irDatamap));

    if (level > 0)
    {
        QVariantMap IRamifDatamap;
        IRamifDatamap.insert("amiflevel", level);
        IRamifDatamap.insert("amiftype", 1);
        IRamifDatamap.insert("lltimestamp", lFileTime);
        IRamifDatamap.insert("dtimestamp", dtimeStamp);

        App().invokeModuleAsync(TIS_Info::HistroyProgramComm::sendAmifData, QVariant::fromValue(IRamifDatamap));
    }
}
void TemperatureController::sendImage(const QVariant &data)
{
    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page, data);
}
void TemperatureController::sendMaxTempToQml(const QVariant &data)
{
    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::maxtemp_recv, data);
}
void TemperatureController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto iter = clients.find(client_title);
    if (iter != clients.end())
    {
        m_udpClient = iter->second;
    }
    else
    {
        LogError("TemperatureController::setUdpClient: {} not found", client_title);
    }
}
void TemperatureController::exitthread()
{
    m_startFalg.store(false);
    recvIRImageData(nullptr);
    if (m_IRImageThread.joinable())
    {
        m_IRImageThread.join();
    }
}
void TemperatureController::sendState(QByteArray &data)
{
    // if (auto strongPtr = m_udpClient.lock())
    // {
    //     strongPtr->sendData(m_udpName, data);
    // }
    // else
    // {
    //     LogError("TemperatureController::sendState: m_udpClient is nullptr");
    // }
}
void TemperatureController::parseJsonSendData()
{
    // Json::Value jsonValue;

    // jsonValue["msgType"] = "asat";
    // Json::Value data;
    // data["moduleType"] = 1;
    // data["moduleState"] = 1;
    // data["jcState"] = 0;
    // jsonValue["data"] = data;

    // Json::StreamWriterBuilder writerBuilder;
    // writerBuilder.settings_["indentation"] = "";  // 4空格缩进
    // std::string jsonString = Json::writeString(writerBuilder, jsonValue);

    std::ostringstream oss;
    oss << "{"
        << "\"msgType\":\"asat\","
        << "\"data\":{"
        << "\"moduleType\":3,"
        << "\"moduleState\":0,"
        << "\"jcState\":0"
        << "}"
        << "}";
    QByteArray Qbytearraydata = QByteArray::fromStdString(oss.str());
    sendState(Qbytearraydata);
}
void TemperatureController::sendUDPThread()
{
    while (m_startFalg)
    {
        parseJsonSendData();
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
}
} // namespace _Controllers