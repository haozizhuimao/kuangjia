#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include "kits/common/utils/BlockingQueue.h"
#include <thread>
#include <atomic>
#include <string>
#include <QPoint>
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/algorithm/algo_guiyangs1/AlgorithmGuiyang.h"

namespace _Controllers {
class TemperatureController : public ControllerBase<TemperatureController>
{
  public:
    // void doRecv(const QVariant &);
    void recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer>);
    void recvTempRect(const int, const int, const int, const int, const int, const int);

    void notifyTaskfunc(const QVariant &);
    void init(const QVariant &);
    void stop();
    void sendDisplayLog(const QString &);
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRImageReady, TemperatureController::recvIRImageData);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRTempRect, TemperatureController::recvTempRect);
    ASYNC_TASK_ADD(TIS_Info::HistroyProgramComm::notifyTaskInfo, TemperatureController::notifyTaskfunc);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::initSignal, TemperatureController::init);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::stopSignal, TemperatureController::stop);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::displayLogSignal, TemperatureController::sendDisplayLog);
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, TemperatureController::setUdpClient);
    TASK_LIST_END

  private:
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    const std::string client_title = "temperature";
    const QString m_udpName = "temperature_dev";
    _Kits::BlockingQueue<std::shared_ptr<TIS_Info::IRImageBuffer>> m_IRImageQueue{10};
    std::thread m_IRImageThread;
    std::thread m_sendUDP;

    std::atomic_bool m_startFalg = false;
    int m_startx = 0;
    int m_starty = 0;
    int m_endx = 0;
    int m_endy = 0;
    int m_normalwidth = 0;
    int m_normalheight = 0;
    float m_fAlarmTemp1 = 0;       // 温度超限报警1级
    float m_fAlarmTemp2 = 0;       // 温度超限报警2级
    float m_fAlarmTemp3 = 0;       // 温度超限报警3级
    int m_iAlarmTimeInterval = 10; // 报警时间间隔，人为干预
    std::string m_taskName = "";
    std::string m_strSavePicRoot = "";
    int m_iSaveImgCount = 0;
    float m_fgpsx = 0.0;
    float m_fgpsy = 0.0;
    int m_getTemperatrueType = 0;
    double m_fmaxTemperature_calibration = 0; // 最大温度校准
    double m_favgTemperature_coefficient = 0; // 系数
    std::atomic<float> m_avgtemp = 0.0;
    std::atomic<float> m_mintemp = 0.0;
    std::atomic<float> m_maxtemp = 0.0;
    std::atomic_bool m_taskFlag = false;
    std::string m_taskSvaePath = "";
    std::chrono::steady_clock::time_point m_saveImageTime = std::chrono::steady_clock::time_point(std::chrono::seconds(0));
    QPoint m_tempPoint;
    _Kits::BlockingQueue<QImage> m_IRImageInferenceQueue{10};

  private:
    std::shared_ptr<_Kits::AlgorithmGuiyang> m_model = nullptr;
    void parseJsonSendData();
    void sendState(QByteArray &data);
    void sendUDPThread();
    void handleIRImageThread();
    void analysisHotPicData(const uint8_t *buf, int width, int height);
    void analysisHotPicData(const uint8_t *buf, std::unordered_map<int, QRect> &rects, int width, int height);
    void calculateTempRect(int &offsetx, int &offsety, int &endx, int &endy, const int width, const int height);
    int isAlarm(const float tempValue);
    std::string generatePictureName();
    void dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp);
    void sendImage(const QVariant &data);
    void sendMaxTempToQml(const QVariant &data);
    void createSaveDiretory(const std::string &taskName);
    void exitthread();
    void dealIRImageData(QImage &image);
    void dealSendToQmlData(QImage &image, int width, int height);
    void dealSendToQmlRectData(QImage &image, std::unordered_map<int, QRect> &rects);
};
} // namespace _Controllers
