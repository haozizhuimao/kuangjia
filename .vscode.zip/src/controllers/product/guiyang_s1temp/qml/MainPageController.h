#pragma once
#include "kits/common/controller_base/QmlControllerBase.h"
#include <qvariant.h>
namespace _Controllers
{
    class MainPageController : public QmlControllerBase<MainPageController>
    {
      public:
        void onPageChanged(const QVariant &);
        void onTaskSended(const QVariant &);

        QML_LIST_BEGIN
        QML_ADD(TIS_Info::QmlCommunication::QmlActions::PageChange, MainPageController::onPageChanged);
        QML_ADD(TIS_Info::QmlCommunication::QmlActions::LocationRecv, MainPageController::onPageChanged);
        QML_LIST_END
    };
} // namespace _Controllers
