#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <QString>
#include "kits/ui/qml_engine/ImagePainter.h"

namespace _Controllers
{
    class QmlVideoDisplay : public ControllerBase<QmlVideoDisplay>
    {
      public:
        void displayVideo(std::shared_ptr<TIS_Info::ImageBuffer>);
        void recvImagePainter(QVariant);
        TASK_LIST_BEGIN
        // ASYNC_TASK_ADD(TIS_Info::PullerCenter::sendImageToQml, QmlVideoDisplay::displayVideo);
        // QML_ADD(TIS_Info::QmlCommunication::QmlActions::sendImagePainter, QmlVideoDisplay::recvImagePainter);
        TASK_LIST_END
      private:
        std::unordered_map<std::string,  _Kits::ImagePainter *> m_mapImageptr;
        std::unordered_map<std::string, bool> m_mapIsDisplay;
        std::unordered_map<std::string, bool> m_mapFirstFPS;
    };
} // namespace _Controllers