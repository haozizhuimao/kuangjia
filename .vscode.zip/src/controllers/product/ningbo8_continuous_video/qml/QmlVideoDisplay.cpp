
#include "QmlVideoDisplay.h"
#include "kits/utility/log/CRossLogger.h"
#include <QVariantMap>
#include <QVariant>
#include <QImage>
// #include "kits/qtcommon/jsontomap/QmlJsonToMap.h"

namespace _Controllers
{
    using namespace _Service;
    using namespace _Kits;

    // void QmlVideoDisplay::recvImagePainter(QVariant data)
    // {
    //     _Kits::ImagePainter * ImagePainter = data.value<_Kits::ImagePainter *>();
    //     QString camera_name = ImagePainter->getObjectName();
    //     LogInfo("camera_name {}", camera_name.toStdString());
    //     m_mapImageptr.insert(std::make_pair(camera_name.toStdString(), ImagePainter));
    //     m_mapIsDisplay.insert(std::make_pair(camera_name.toStdString(), true));
    //     m_mapFirstFPS.insert(std::make_pair(camera_name.toStdString(), true));
    //     //LogInfo("QmlVideoDisplay {}", camera_name.toStdString());
    // }
    // void QmlVideoDisplay::displayVideo(std::shared_ptr<TIS_Info::ImageBuffer> img)
    // {
    //     if (img == nullptr)
    //     {
    //         return;
    //     }
    //     if (!m_mapIsDisplay[img->name])
    //     {
    //         return;
    //     }
    //     if(m_mapFirstFPS[img->name])
    //     {
    //         m_mapFirstFPS[img->name] = false;
    //     }
    //     QImage img_temp(img->data.data(), img->width, img->height, QImage::Format_RGB888);
    //     img_temp = img_temp.rgbSwapped();
    //     auto it = m_mapImageptr.find(img->name);
    //     if(it != m_mapImageptr.end())
    //     {
    //         if(nullptr != it->second)
    //         {
    //             it->second->setImage(img_temp);
    //         }
    //     }
    // }

} // namespace _Controllers