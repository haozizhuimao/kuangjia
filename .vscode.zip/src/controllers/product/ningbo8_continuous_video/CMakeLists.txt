
set(CTL_NAME "ningbo8_continuous_video")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_asio_tcp_client>
$<TARGET_OBJECTS:kit_encode_video_operate>
$<TARGET_OBJECTS:kit_simple_mysql_writer>
$<TARGET_OBJECTS:kit_algorithm_detect_tcp>
$<TARGET_OBJECTS:kit_ffmpeg_puller>
$<TARGET_OBJECTS:kit_video_manage>
$<TARGET_OBJECTS:kit_video_painter>
)       

find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_asio_tcp_client
kit_encode_video_operate
kit_simple_mysql_writer
kit_algorithm_detect_tcp
kit_ffmpeg_puller
kit_cuda
kit_video_manage
kit_video_painter
)

set(RES_QML
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Table.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/public_controls/HighFrequencyChart.qml
    res/qml/public_controls/YunTai.qml
    res/qml/public_controls/Magnifier.qml

)

target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CTL_NAME}>
)     
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})
