#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <cstdint>
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include "tis_global/Struct.h"
#include "kits/utility/object_pool/ObjectPool.h"
#include <thread>
#include <atomic>
#include <memory>
#include <QVariant>
#include <string>
#include "kits/common/algorithm_detect_tcp/algorithmMannger.h"
#include "kits/common/algorithm_detect_tcp/algorithmParseRecginze.h"
#include "kits/common/simple_mysql_writer/SimpleMySqlWriter.h"
#include "kits/common/ffmpeg_puller/FFmpegPuller.h"
#include "kits/common/cuda/YuvConverter.h"
#include "kits/common/video_manage/VideoManage.h"
#include "kits/common/video_painter/VideoPainter.h"
#include <mutex>
namespace _Controllers
{
    class VideoController : public ControllerBase<VideoController>
    {
      public:
        VideoController();
        ~VideoController();

    /// @brief 接收老任务数据
    /// @param taskData(QVariant)
    /// @return void
    void notifyTaskfunc(const QVariant &);

    /// @brief 接收旧任务的位置信息
    /// @param locationData(QVariant)
    /// @return void
    void recvOldLocation(const QVariant &);

    void onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    void onInitAlgorithm(const std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>> &);
    void onInitSimpleMysqlInfo(const TIS_Info::SimpleMysqlInfo &);
    void onInitEncodeVideoInfo(const std::unordered_map<std::string, TIS_Info::EncoderInfo> &);
    void onSetPullObject(const std::unordered_map<std::string, std::shared_ptr<_Kits::FFmpegPuller>> &);

    TASK_LIST_BEGIN
      // ASYNC_TASK_ADD(_Service::TaskService::taskInfo, LocationController::recvTaskData);
    SYNC_TASK_ADD(_Service::TcpClientCenter::dispatchClient, VideoController::onSetTcpClient);
    ASYNC_TASK_ADD(_Service::SimpleMysqlService::initSimpleMysqlInfo, VideoController::onInitSimpleMysqlInfo);
    SYNC_TASK_ADD(_Service::VideoEncoderService::initVideoEncoderInfo, VideoController::onInitEncodeVideoInfo);
    ASYNC_TASK_ADD(_Service::PullerCenter::dispatchPullerObject, VideoController::onSetPullObject);
    ASYNC_TASK_ADD(_Service::HistroyProgramComm::notifyTaskInfo, VideoController::notifyTaskfunc);
    ASYNC_TASK_ADD(_Service::HistroyProgramComm::updateLocationInfo, VideoController::recvOldLocation);
    ASYNC_TASK_ADD(_Service::AlgorithmService::initAlgorithm, VideoController::onInitAlgorithm);

    TASK_LIST_END

  private:
    void writeDetectResultDB(const _Kits::SimpleMySqlWriter::DefectData &defectData);
    bool extractJsonData(const std::vector<uint8_t> &data, std::string &jsonStr, uint16_t &serialNum);
    void createSaveDirectory(const std::string &taskName);
    void createDirectory(const std::string &path);
    size_t findStringPosition(const std::vector<uint8_t> &data, const size_t offset, const std::string &substr);
    std::string generateVideoName(const std::string &strStationName);
    std::string saveDetectResultImage(std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer, const TIS_Info::pantograph_info &pantographInfo);
    std::vector<TIS_Info::pantograph_info> parseDetectResult(const std::vector<uint8_t> &data, uint16_t &serialNum);

    void createVideoManage(const std::string &taskName);

    void handleDetectResult(const std::string &picpath, const TIS_Info::pantograph_info &pantographInfo);
    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p);

  private:
    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> m_frameDataInfoPool = nullptr;
    std::unordered_map<std::string, std::shared_ptr<_Kits::algorithmManager>> m_algorithmManager ;
    std::unordered_map<std::string, std::shared_ptr<_Kits::VideoManage>> m_videoManageMap;
    std::unique_ptr<_Kits::SimpleMySqlWriter> m_simpleMySqlWriter = nullptr;
    int m_taskState = -1;
    std::vector<uint8_t> m_resultbuffer;
    std::string m_currentTaskName {""};
    TIS_Info::LocationData m_currentLocationData;
    std::unique_ptr<_Kits::YuvConverter> m_yuvConverter = nullptr;
    std::mutex m_createMutex;
    std::mutex m_detectMutex;
    std::atomic<int> m_detectFps = 10;
    std::unordered_map<std::string, std::string> m_strpavepathmap;
    std::unordered_map<std::string, std::shared_ptr<_Kits::VideoPainter>> m_videoPainterMap;


    };
} // namespace _Controllers
