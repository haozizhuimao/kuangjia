#include "VideoController.h"
#include "kits/primary/io_manager/io_manager.h"
#include "service/AppInterface.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/utility/system_config/SystemConfig.h"
#include <QImage>
#include <filesystem>
#include <opencv2/opencv.hpp>
#include "kits/utility/datetime/datetime.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

VideoController::VideoController()
{
    m_frameDataInfoPool = std::make_shared<ObjectPool<TIS_Info::ImageBuffer>>(150);
    m_simpleMySqlWriter = std::make_unique<SimpleMySqlWriter>();
}
VideoController::~VideoController() {}
void VideoController::onInitAlgorithm(const std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>> &info)
{
    for(const auto &[name,vecinfo] : info)
    {
        if(nullptr == m_algorithmManager[name])
        {
            m_algorithmManager[name] = std::make_shared<_Kits::algorithmManager>();
        }
        m_algorithmManager[name]->setAlgorithmMap(vecinfo);
        auto ret = m_algorithmManager[name]->startAlogorithm();
        for (auto &it : vecinfo)
        {
            LogInfo("algorithmName = {}", it.m_str_algorithm_name);
            m_algorithmManager[name]->setAlgorithmCallback([this,name](const std::string &algorithmName, std::vector<uint8_t> &&result) {
                uint16_t serialNum = 0;
                auto detectret = parseDetectResult(std::move(result), serialNum);
                auto imagebuffer = m_algorithmManager[name]->findImageBuffer(algorithmName, serialNum);
                for (auto &it : detectret)
                {
                    if (nullptr != imagebuffer)
                    {
                        LogTrace("detect result.algorithmName = {},{}", algorithmName, serialNum);
                        auto imagepath = saveDetectResultImage(imagebuffer, it);
                        // LogInfo("save image.{}", imagepath);
                        handleDetectResult(imagepath, it);
                    }
                    else
                    {
                        LogError("can not find imagebuffer.algorithmName = {},{}", algorithmName, serialNum);
                    }
                }
            });
        }
    }
}
void VideoController::handleDetectResult(const std::string &picpath, const TIS_Info::pantograph_info &pantographInfo)
{
    if (m_currentTaskName.empty())
    {
        return;
    }
    SimpleMySqlWriter::DefectData defectData;
    defectData.sCollectTime = datetime::current_string("%Y/%m/%d %H:%M:%S");
    defectData.sTaskName = QString::fromLocal8Bit(m_currentTaskName).toUtf8().toStdString();
    ;
    defectData.sTime = datetime::current_string("%Y/%m/%d %H:%M:%S");
    // defectData.sTrainNum = info.mstr_trainNum;
    defectData.fKilometer = m_currentLocationData.mileage_normal / 1000.0;
    defectData.StationName = QString::fromLocal8Bit(m_currentLocationData.station_name).toUtf8().toStdString();
    defectData.PoleName = m_currentLocationData.pole_name;
    LogInfo(
        "detect result. {} {},{},{}", picpath, m_currentLocationData.station_name, m_currentTaskName, m_currentLocationData.mileage_normal);
    defectData.Left = pantographInfo.x1;
    defectData.Top = pantographInfo.y1;
    defectData.Right = pantographInfo.x2;
    defectData.Down = pantographInfo.y2;
    defectData.Path = QString::fromLocal8Bit(picpath).toUtf8().toStdString();
    defectData.iDefectType = pantographInfo.defectItemID;
    defectData.Level = 3;
    defectData.componentName = pantographInfo.conponentNameID;

    writeDetectResultDB(defectData);
}
void VideoController::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    for (const auto&[name,client]:clients)
    {
        auto it = m_algorithmManager.find(name);
        if(it != m_algorithmManager.end())
        {
            client->start();
            std::unordered_map<std::string, std::weak_ptr<TcpClient>> tcpClientMap;
            tcpClientMap["pantoGraphDetect"] = client;
            m_algorithmManager[name]->setTcpClient(tcpClientMap);
        }
    }
}
void VideoController::notifyTaskfunc(const QVariant &task_data)
{
    auto taskinfomap = task_data.toMap();
    auto taskstate = taskinfomap.value("taskstate").toInt();
    LogTrace("taskname = {}", taskinfomap.value("taskname").toByteArray().toStdString());
    if (m_taskState == taskstate)
    {
        // 如果任务状态没有变化，则不处理
        return;
    }
    if (0 == taskstate)
    {
        m_currentTaskName = taskinfomap.value("taskname").toByteArray().toStdString();
        createSaveDirectory(m_currentTaskName);
    }
    else if (1 == taskstate)
    {
        for (auto &it : m_videoManageMap)
        {
            it.second->updataVideoName("");
        }
    }
    m_taskState = taskstate;
}
void VideoController::createSaveDirectory(const std::string &taskName)
{
    std::filesystem::path arcvideopath = L"/视频文件";
    std::filesystem::path rootpath = std::filesystem::u8path(_Kits::SystemConfig::appOutputPath());

    auto fullpathstring = rootpath.string() +"/"+ datetime::current_string("%Y%m%d")  + "/" + taskName + arcvideopath.string();
    std::filesystem::path fullpath(fullpathstring);
    auto  utf8strTaskVideoRoot = fullpath.u8string();
    std::string strTaskVideoRoot (utf8strTaskVideoRoot.begin(), utf8strTaskVideoRoot.end());
     for(auto &it:m_videoManageMap)
     {
         it.second->setVideoSaveRootPath(strTaskVideoRoot);
     }

    for (auto &it : m_strpavepathmap)
    {
        std::filesystem::path detecpath = L"/连续视频缺陷图片";
        detecpath = detecpath.string() + "/" + it.first;
        auto currentdetecpath = rootpath.string() + "/" + datetime::current_string("%Y%m%d") + "/" + taskName + detecpath.string();
        createDirectory(currentdetecpath);
        it.second = currentdetecpath;
    }
}
void VideoController::createDirectory(const std::string &strpath)
{
    std::filesystem::path path(strpath);

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    else
    {
        LogInfo("Directories already exist:{}", path.string());
    }
}
void VideoController::onInitSimpleMysqlInfo(const TIS_Info::SimpleMysqlInfo &mysqlInfo)
{
    if (nullptr == m_simpleMySqlWriter)
    {
        m_simpleMySqlWriter = std::make_unique<SimpleMySqlWriter>();
    }
    auto ret = m_simpleMySqlWriter->connect(mysqlInfo.ip, mysqlInfo.port, mysqlInfo.userName, mysqlInfo.password, mysqlInfo.dbName);
    if (!ret)
    {
        std::string title = "connect_simplemysql";
        _Kits::thread_pool::runEvery(title,60* 1000, [this, title,mysqlInfo]()
        {
            LogInfo("onInitSimpleMysqlInfo::runEvery {}",title);
            auto ret = m_simpleMySqlWriter->connect(mysqlInfo.ip, mysqlInfo.port, mysqlInfo.userName, mysqlInfo.password, mysqlInfo.dbName);
            if(ret)
            {
                _Kits::thread_pool::cancelTimer(title);
            }
        });
        LogError("connect mysql failed");
    }
    else
    {
        LogInfo("connect mysql success");
    }
}
void VideoController::onInitEncodeVideoInfo(const std::unordered_map<std::string, TIS_Info::EncoderInfo> &encoderobjects)
{
    for (auto &it : encoderobjects)
    {
        auto name = it.first;
        auto videoManageObject = m_videoManageMap.find(name);
        if (videoManageObject == m_videoManageMap.end())
        {
            createVideoManage(name);
        }
        m_videoManageMap[name]->init(it.second,it.second.subtitleInputInfo);
    }
}
void VideoController::recvOldLocation(const QVariant &location_data)
{
    auto locationinfomap = location_data.toMap();
    auto locationstation = locationinfomap.value("locationstation").toByteArray().toStdString();
    auto locationlinedir = locationinfomap.value("locationlinedir").toInt();
    auto locationpole = locationinfomap.value("locationpole").toByteArray().toStdString();
    auto locationmovedistance = locationinfomap.value("locationmovedistance").toDouble();
    auto locationmovespeed = locationinfomap.value("locationspeed").toDouble();
    m_currentLocationData.pole_name = locationpole;
    m_currentLocationData.mileage_normal = locationmovedistance * 1000;

    if (!locationstation.empty() && m_currentLocationData.station_name != locationstation && !m_currentTaskName.empty())
    {
        auto videoName = generateVideoName(locationstation);
        LogInfo("start video:{},{}", m_currentLocationData.station_name, locationstation);
        for (auto &it : m_videoManageMap)
        {
            it.second->updataVideoName(videoName);
        }
        m_currentLocationData.station_name = locationstation;
    }
    for (auto &it : m_videoManageMap)
    {
        it.second->updateSubtitles(datetime::current_string("%Y%m%d %H:%M:%S"));
    }
}
void VideoController::onSetPullObject(const std::unordered_map<std::string, std::shared_ptr<_Kits::FFmpegPuller>> &pullerobjects)
{

    for (auto &it : pullerobjects)
    {
        auto name = it.first;
        createVideoManage(name);
        m_strpavepathmap[name] = name;
        it.second->setFrameCallback([this, name](std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer) {
            if (nullptr != imagebuffer)
            {
                if(nullptr != m_videoManageMap[name] && name == imagebuffer->name)
                {
                     m_videoManageMap[name]->pushImage(imagebuffer);
                }
                if (nullptr != m_videoPainterMap[name] && name == imagebuffer->name)
                {
                   m_videoPainterMap[name]->pushImage(imagebuffer);
                }
            }
        });
        it.second->start();
    }
}
std::string VideoController::generateVideoName(const std::string &strStationName)
{
    std::string strVideoName = "";
    if (!strStationName.empty())
    {
        strVideoName += strStationName;
        strVideoName += "_";
        strVideoName += datetime::current_string("%Y_%m_%d_%H_%M");
    }
    else
    {
        strVideoName += datetime::current_string("%Y_%m_%d_%H_%M");
    }
    strVideoName += ".mp4";

    std::filesystem::path videoName(strVideoName);
    auto  utf8strvideoName = videoName.u8string();
    std::string resultVideoName(utf8strvideoName.begin(), utf8strvideoName.end());

    LogInfo("liveVideoName:{} {}", strVideoName,resultVideoName);
    return resultVideoName;
}
std::shared_ptr<TIS_Info::ImageBuffer> VideoController::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = m_frameDataInfoPool->getObject(w, h, 3); // RGB24

    if (nullptr == m_yuvConverter)
    {
        m_yuvConverter = std::make_unique<_Kits::YuvConverter>();
        m_yuvConverter->init(img_yuv420p->width, img_yuv420p->height);
    }

    m_yuvConverter->yuv420pTorgb_cuda(img_yuv420p->data.data(), img_rgb->data.data());

    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(2);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}
size_t VideoController::findStringPosition(const std::vector<uint8_t> &data, const size_t offset, const std::string &substr)
{
    if (data.empty() || data.size() < substr.size() || substr.empty())
    {
        return std::string::npos;
    }

    auto it = std::search(data.begin() + offset, data.end(), substr.begin(), substr.end());
    if (it != data.end())
    {
        return std::distance(data.begin() + offset, it);
    }
    return std::string::npos;
}
bool VideoController::extractJsonData(const std::vector<uint8_t> &data, std::string &jsonStr, uint16_t &serialNum)
{
    // 检查数据是否为空
    // m_resultbuffer.clear();
    m_resultbuffer.insert(m_resultbuffer.end(), data.begin(), data.end());
    auto buffer_size = m_resultbuffer.size();
    // 鐩存帴浣跨敤浼犲叆鐨勬暟鎹繘琛屽鐞?
    if (buffer_size >= head_tcp_size + 6)
    { // 最小消息长度检查
        // 检查头部
        auto head_pos = findStringPosition(m_resultbuffer, 0, head_tcp);
        if (std::string::npos == head_pos)
        {
            std::cerr << "无效的头部，无法解析数据\n";
            return false;
        }

        // 解析元数据（跳过HEAD_SIZE）
        int offset = head_pos + head_tcp_size;
        auto cma_id = ByteArrayTools::readFromVectorBE<uint16_t>(m_resultbuffer, offset);
        auto image_id = ByteArrayTools::readFromVectorBE<uint16_t>(m_resultbuffer, offset + 2);
        auto json_len = ByteArrayTools::readFromVectorBE<uint32_t>(m_resultbuffer, offset + 4);

        // auto json_len = ntohl(json_len1);
        serialNum = image_id;
        offset = 8 + offset + json_len;
        LogTrace("offset:{},json_len:{},buffer_size:{}", offset, json_len, buffer_size);
        if (buffer_size < offset + tail_tcp_size)
        {
            return false;
        }

        auto tail_pos = findStringPosition(m_resultbuffer, offset, tail_tcp);
        if (std::string::npos == tail_pos)
        {
            m_resultbuffer.clear();
            return false;
        }

        jsonStr.assign(m_resultbuffer.data() + head_tcp_size + 8, m_resultbuffer.data() + head_tcp_size + 8 + json_len);

        if (buffer_size == offset + tail_tcp_size)
        {
            m_resultbuffer.clear();
        }
        else if (buffer_size > offset + tail_tcp_size)
        {
            m_resultbuffer.erase(m_resultbuffer.begin(), m_resultbuffer.begin() + offset + tail_tcp_size);
        }

        return true;
    }
    else
    {
        std::cerr << "数据长度不足，无法解析\n";
        return false;
    }
}
std::vector<TIS_Info::pantograph_info> VideoController::parseDetectResult(const std::vector<uint8_t> &data, uint16_t &serialNum)
{
    std::vector<TIS_Info::pantograph_info> resultVector;
    std::string jsonStr;

    if (!extractJsonData(data, jsonStr, serialNum))
        return resultVector;

    if (jsonStr.empty())
    {
        return resultVector;
    }
    // 解析JSON数据
    auto root = _Kits::stringToJson(jsonStr);
    LogDebug("jsonStr:{}", jsonStr);

    // 检查resultNum字段是否存在
    if (!root.isMember("det"))
    {
        // qWarning() << "resultNum field not found in JSON data.";
        static int count = 0;
        if (count++ > 100)
        {
            count = 0;
            LogError("det field not found in JSON data.");
        }

        return resultVector;
    }

    const Json::Value &results = root["det"];
    if (!results.isArray())
    {
        LogError("det field is not an array.");
        return resultVector;
    }
    // LogInfo("resultNum:{}",results.size());
    for (int i = 0; i < results.size(); ++i)
    {
        const Json::Value &result = results[i];
        TIS_Info::pantograph_info RecognizeInfo;
        // 提取结果信息，添加字段存在性检查
        if (result.isMember("componentName"))
        {
            RecognizeInfo.conponentNameID = result["componentName"].asInt();
        }

        if (result.isMember("confidence"))
        {
            auto str = result["confidence"].asCString();
            RecognizeInfo.confidence = std::stod(str);
        }

        if (result.isMember("defectItem"))
        {
            RecognizeInfo.defectItemID = result["defectItem"].asInt();
        }

        // 提取坐标信息，添加字段存在性检查
        if (result.isMember("x1"))
        {
            RecognizeInfo.x1 = result["x1"].asDouble();
        }

        if (result.isMember("y1"))
        {
            RecognizeInfo.y1 = result["y1"].asDouble();
        }

        if (result.isMember("x2"))
            RecognizeInfo.x2 = result["x2"].asDouble();

        if (result.isMember("y2"))
            RecognizeInfo.y2 = result["y2"].asDouble();

        // LogInfo("conponentNameID:{}, confidence:{}, defectItemID:{}, x1:{}, y1:{}, x2:{}, y2:{} serialNum:{}",
        //         RecognizeInfo.conponentNameID, RecognizeInfo.confidence, RecognizeInfo.defectItemID,
        //         RecognizeInfo.x1, RecognizeInfo.y1, RecognizeInfo.x2, RecognizeInfo.y2,serialNum);
        resultVector.push_back(RecognizeInfo);
    }

    return resultVector;
}
std::string VideoController::saveDetectResultImage(std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer,
                                                   const TIS_Info::pantograph_info &pantographInfo)
{
    std::string picname = "detect_" + datetime::current_string("%Y_%m_%d_%H_%M_%S.%3f") + ".jpg";
    std::filesystem::path path(m_strpavepathmap[imagebuffer->name]);
    std::string rootpath = path.string();
    rootpath += "/";
    rootpath += picname;

    cv::Mat color_mat(imagebuffer->height, imagebuffer->width, CV_8UC3, imagebuffer->data.data());

    // 1. 绘制矩形
    cv::Point topleft = cv::Point(pantographInfo.x1, pantographInfo.y1);
    cv::Point bottomRight = cv::Point(pantographInfo.x2, pantographInfo.y2);
    cv::Rect rect(topleft, bottomRight);
    cv::Mat draw_mat = color_mat.clone();

    cv::rectangle(draw_mat, rect, cv::Scalar(0, 0, 255), 2);

    bool ret = cv::imwrite(rootpath, draw_mat);

    if (!ret)
    {
        LogError("cv::imwrite failed for: {}", rootpath);
        return "";
    }
    LogInfo("saveDetectResultImage:{}", rootpath);
    return rootpath;
}
void VideoController::writeDetectResultDB(const SimpleMySqlWriter::DefectData &defectData)
{
    if (nullptr != m_simpleMySqlWriter)
    {
        m_simpleMySqlWriter->insertDefectData(defectData);
    }
    else
    {
        LogError("m_simpleMySqlWriter is nullptr");
    }
}
void VideoController::createVideoManage(const std::string &name)
{
    std::lock_guard<std::mutex> lock(m_createMutex);
    auto videoManageObject = m_videoManageMap.find(name);
    if (videoManageObject == m_videoManageMap.end())
    {
        m_videoManageMap.insert(std::make_pair(name, std::make_shared<VideoManage>(name)));
        m_videoManageMap[name]->start();
        m_videoManageMap[name]->setAlgorithPushCallback([this,name](std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer) {
            if(nullptr == m_algorithmManager[name])
            {
                m_algorithmManager[name] = std::make_shared<_Kits::algorithmManager>();
            }
            if (nullptr != imagebuffer)
            {
                std::lock_guard<std::mutex> lock(m_detectMutex);
                auto img = YUV420ptoRGB(imagebuffer);
                m_algorithmManager[name]->algorithmDetectQueue("pantoGraphDetect", std::move(img));
            }
        });
       // m_videoManageMap[name]->setDetectTimes(m_detectFps);
    }

    auto videoPainterobject = m_videoPainterMap.find(name);
    if (videoPainterobject == m_videoPainterMap.end())
    {
        m_videoPainterMap.insert(std::make_pair(name, std::make_shared<VideoPainter>(name)));
        m_videoPainterMap[name]->start();
        m_videoPainterMap[name]->setSendToUICallback([this](std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer,
                                                            const std::vector<TIS_Info::pantograph_info> &pantoGraphInfo,
                                                            const std::string &jsonVaue) {
            try
            {
                //senderPullerCentersendImageToQml(imagebuffer);
                _Service::PullerCenter::sendImageToQml(imagebuffer);
            }
            catch (const std::exception &e)
            {
                // std::cerr << e.what() << '\n';
            }
        });
    }
}

} // namespace _Controllers


