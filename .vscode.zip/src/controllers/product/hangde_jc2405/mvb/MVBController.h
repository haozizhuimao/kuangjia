#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include <atomic>
#include <cstdint>
#include <memory>
#include <unordered_map>
#include <vector>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    MVBController();
    ~MVBController();
    void afterMVBData(const int, const std::vector<uint8_t> &);
    void setAlivePort(const int, const int); // 使用阻塞方式初始化配置信息，防止异步导致未配置完成其他接口已经使用
    void setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::MVBDistribution::configWritePort, MVBController::setAlivePort);
    SYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, MVBController::setTcpClient);
    ASYNC_TASK_ADD(TIS_Info::MVBDistribution::duagonData, MVBController::afterMVBData);
    TASK_LIST_END
  private:
    void heartFunc();
    void sendAliveData();
    // 解析车辆数据
    void parseCarInfo(const std::vector<uint8_t> &, QVariantMap &);
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, QVariantMap &);
    // 界面展示接收数据
    void displayRecvPortData(const int, QVariantMap &);
    // 界面展示心跳数据
    void displayHeartData();

    int m_alivePortId = 0;

    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    std::mutex m_mtxAliveData;
    std::vector<uint8_t> m_aliveData;
    std::thread m_thHeart;
    std::atomic_bool m_bHolder = true;
    const std::string m_tcpName = "mvb";
    std::shared_ptr<_Kits::TcpClient> m_tcpClient = nullptr;
    std::vector<uint8_t> m_recvData;
};
} // namespace _Controllers
