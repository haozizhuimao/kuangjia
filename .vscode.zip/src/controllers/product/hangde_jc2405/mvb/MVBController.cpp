#include "MVBController.h"
#include "kits/third_devices/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include <algorithm>
#include <chrono>
#include <mutex>
#include <qglobal.h>
#include <qlogging.h>
#include <qvariant.h>
#include <thread>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_recvData.resize(50, 0);
}
MVBController::~MVBController()
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
}
void MVBController::afterMVBData(const int portId, const std::vector<uint8_t> &data)
{
    // 待解析
    QVariantMap mapData;
    constexpr int offset = 16;
    if (portId == 1)
    {
        // VCU向所有设备发送的公共数据 长度16字节固定
        std::copy(data.begin(), data.end(), m_recvData.begin());
        parseCommonData(data, mapData);
    }
    else
    {
        // VCU发送给弓网的数据 偏移16字节存放
        std::copy(data.begin(), data.end(), m_recvData.begin() + offset);
        parseCarInfo(data, mapData);
    }
    if (m_tcpClient && !m_tcpClient->getConnect())
    {
        LogError("{} tcp client disconnected.", m_tcpName);
        return;
    }
    QByteArray byteArray(reinterpret_cast<const char *>(m_recvData.data()), m_recvData.size());
    m_tcpClient->sendData(byteArray);

    // 给页面传递数据展示
    displayRecvPortData(portId, mapData);
    LogInfo("afterMVBData before json, data={}", ByteArrayTools::hexString(data.data(), data.size()));
}
void MVBController::setAlivePort(const int portId, const int portSize)
{
    m_alivePortId = portId;
    m_aliveData.resize(portSize);
    LogInfo("setAlivePort port id = {}, size ={}.", m_alivePortId, portSize);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}
void MVBController::setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find(m_tcpName);
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", m_tcpName);
    }
    m_tcpClient = finder->second;
}

void MVBController::sendAliveData()
{
    std::lock_guard<std::mutex> lock(m_mtxAliveData);
    ++m_aliveId; // 心跳id自增
    ByteArrayTools::writeToVectorBE(m_aliveData, m_aliveId, 0);
    App().invokeModuleAsync(TIS_Info::MVBDistribution::dataToDuagonCard, m_alivePortId, m_aliveData);

    displayHeartData();
}

void MVBController::heartFunc()
{
    while (m_bHolder)
    {
        sendAliveData();
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

void MVBController::parseCarInfo(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    std::bitset<8> byte0(data[0]);
    outputData["panrun"] = static_cast<bool>(byte0[0]);   // 1=运维模式
    outputData["panmnt"] = static_cast<bool>(byte0[1]);   // 1=维护模式
    outputData["autosign"] = static_cast<bool>(byte0[6]); // 1=全自动报站
    outputData["panrise2"] = static_cast<bool>(byte0[7]); // 2车受电弓升弓标志位

    std::bitset<8> byte1(data.at(1));
    outputData["panrise5"] = static_cast<bool>(byte1[0]);  // 5车受电弓升弓标志位
    outputData["atbsign"] = static_cast<bool>(byte1[1]);   // 1=自动折返
    outputData["sleepmode"] = static_cast<bool>(byte1[2]); // 休眠指令

    // 离站及预到站信息
    outputData["tardis"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
    // 终点站
    outputData["endstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    // 当前站
    outputData["currtstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    // 下一站
    outputData["nextstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
    // Tc1轮径（来自于DDU）；车轮直径770-840mm，1mm/bit（0x00=0mm，0x348=840mm）
    outputData["wd1"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    // Tc2轮径（来自于DDU）；车轮直径770-840mm，1mm/bit（0x00=0mm，0x348=840mm）
    outputData["wd2"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
}
void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    // VCU生命信号
    outputData["tcmsalive"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    // 速度
    outputData["realspeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    // 列车编号
    outputData["trainset"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);

    std::bitset<8> bits(data[12]);
    outputData["timevalid"] = static_cast<bool>(bits[0]);  // 1=时间有效
    outputData["speedvalid"] = static_cast<bool>(bits[1]); // 1=速度有效
    outputData["cabact_1"] = static_cast<bool>(bits[2]);   // 1车司机室激活
    outputData["cabact_6"] = static_cast<bool>(bits[3]);   // 6车司机室激活
    outputData["ATOmode"] = static_cast<bool>(bits[4]);    // 1=ATO模式激活
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    // VCU生命信号
    outputData["tcmsalive"] = ByteArrayTools::readFromVectorBE<uint16_t>(m_aliveData, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(m_aliveData, 7);

    std::bitset<8> bits8(m_aliveData[8]);
    // 拉出值严重超限
    outputData["catOffGraveALarm"] = static_cast<bool>(bits8[0]);
    // 拉出值中等超限
    outputData["catOffMiddlingALarm"] = static_cast<bool>(bits8[1]);
    // 拉出值轻微超限
    outputData["catOffSlightALarm"] = static_cast<bool>(bits8[2]);
    // 导高严重超限
    outputData["catHeiGraveALarm"] = static_cast<bool>(bits8[3]);
    // 导高中等超限
    outputData["catHeiMiddlingALarm"] = static_cast<bool>(bits8[4]);
    // 导高轻微超限
    outputData["catHeiSlightALarm"] = static_cast<bool>(bits8[5]);
    // 弓网接触线温度严重超限
    outputData["tempGraveALarm"] = static_cast<bool>(bits8[6]);
    // 弓网接触线温度中等超限
    outputData["tempMiddlingALarm"] = static_cast<bool>(bits8[7]);

    std::bitset<8> bits9(m_aliveData[9]);
    // 弓网接触线温度轻微超限
    outputData["tempSlightALarm"] = static_cast<bool>(bits9[0]);
    // 弓网燃弧严重超限
    outputData["arcGraveALarm"] = static_cast<bool>(bits9[1]);
    // 弓网燃弧中等超限
    outputData["arcMiddlingALarm"] = static_cast<bool>(bits9[2]);
    // 弓网燃弧轻微超限
    outputData["arcSlightALarm"] = static_cast<bool>(bits9[3]);
    // 受电弓结构严重故障
    outputData["strGraveALarm"] = static_cast<bool>(bits9[4]);
    // 受电弓结构中等故障
    outputData["strMiddlingALarm"] = static_cast<bool>(bits9[5]);
    // 受电弓结构轻微故障
    outputData["strSlightALarm"] = static_cast<bool>(bits9[6]);
    // 拉出值导高测量模块故障
    outputData["catHeiModeFault"] = static_cast<bool>(bits9[7]);

    std::bitset<8> bits10(m_aliveData[10]);
    // 接触线温度测量模块故障
    outputData["tmpModFault"] = static_cast<bool>(bits10[0]);
    // 弓网燃弧测量模块故障
    outputData["arcModFault"] = static_cast<bool>(bits10[1]);
    // 受电弓结构故障监测模型故障
    outputData["iPanModStatus"] = static_cast<bool>(bits10[2]);
    // 系统通信模块故障
    outputData["sysNetModStatus"] = static_cast<bool>(bits10[3]);
    // 准备休眠信号
    outputData["readyToSleep"] = static_cast<bool>(bits10[4]);
    // 弓网系统轻微故障
    outputData["bowNetGraveALarm"] = static_cast<bool>(bits10[5]);
    // 弓网系统中等故障
    outputData["bowNetMiddlingALarm"] = static_cast<bool>(bits10[6]);
    // 弓网系统严重故障
    outputData["bowNetSlightALarm"] = static_cast<bool>(bits10[7]);

    std::bitset<8> bits11(m_aliveData[11]);
    // 接触线磨耗值严重超限
    outputData["abrValGraveALarm"] = static_cast<bool>(bits11[0]);
    // 接触线磨耗值中等超限
    outputData["abrValMiddlingALarm"] = static_cast<bool>(bits11[1]);
    // 接触线磨耗值轻微超限
    outputData["abrValSlightALarm"] = static_cast<bool>(bits11[2]);
    // 接触线磨耗检测模块故障
    outputData["abrValOModStatus"] = static_cast<bool>(bits11[3]);
    // 运行模式
    outputData["panrun"] = static_cast<bool>(bits11[4]);
    // 维护模式
    outputData["panmnt"] = static_cast<bool>(bits11[5]);

    // 弓网版本
    outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(m_aliveData, 12);
}

void MVBController::displayRecvPortData(const int portId, QVariantMap &portData)
{
    // 给页面传递数据展示
    QVariantMap mapData;
    if (portId == 1)
    {
        mapData[TIS_Info::QmlCommunication::strForQmlSignals] =
            QVariant::fromValue(TIS_Info::QmlCommunication::ForQmlSignals::mvbCommonData_recv);
    }
    else
    {
        mapData[TIS_Info::QmlCommunication::strForQmlSignals] =
            QVariant::fromValue(TIS_Info::QmlCommunication::ForQmlSignals::mvbCarInfo_recv);
    }

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt;
    mapData[TIS_Info::QmlCommunication::strData] = portData;

    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, QVariant::fromValue(mapData));
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    QVariantMap mapData;
    mapData[TIS_Info::QmlCommunication::strForQmlSignals] = QVariant::fromValue(TIS_Info::QmlCommunication::ForQmlSignals::mvbHeart_send);
    QVariantMap heartData;

    parseHeartData(m_aliveData, heartData);
    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    heartData["sendTime"] = timeFmt;
    mapData[TIS_Info::QmlCommunication::strData] = heartData;

    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, QVariant::fromValue(mapData));
}

} // namespace _Controllers
