#pragma once
#include "kits/utility/object_pool/ObjectPool.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

namespace _Controllers {
class ArcVideoMaker : public ControllerBase<ArcVideoMaker>
{
  public:
    ArcVideoMaker();
    ~ArcVideoMaker();

    void sendArcImage(std::shared_ptr<TIS_Info::ImageBuffer>);
    void onStartRecord(TIS_Info::arcData, QString);
    void onStopRecord();

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraName(std::vector<std::string>) 录像kit的名称列表
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveArc(std::vector<std::string>);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::sendArcImage, ArcVideoMaker::sendArcImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendArcImage, ArcVideoMaker::sendArcImage);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::startArc, ArcVideoMaker::onStartRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::stopArc, ArcVideoMaker::onStopRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::startArc, ArcVideoMaker::onStartRecord);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::stopArc, ArcVideoMaker::onStopRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::initArcCtrl, ArcVideoMaker::onInitSaveArc);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::initArcCtrl, ArcVideoMaker::onInitSaveArc);
    TASK_LIST_END

  private:
    std::unordered_map<std::string, std::deque<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideoCache>> _mmap_saveVideo;

    std::thread _m_thread_saveVideo;
    std::condition_variable _m_cond_saveVideo;
    std::mutex _m_mutex_saveVideo;
    std::atomic_bool _mb_SaveVideo;

  private:
    void saveVideoThread();

  signals:
    void saveImage(std::shared_ptr<TIS_Info::ImageBuffer> img);
};
} // namespace _Controllers