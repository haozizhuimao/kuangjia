#pragma once
#include "kits/utility/object_pool/ObjectPool.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();

    void sendImage(std::shared_ptr<TIS_Info::ImageBuffer>);
    void onStartRecord(QString, QString);
    void onStopRecord();

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraName(std::vector<std::string>) 录像kit的名称列表
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(std::vector<std::string>);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::sendImage, VideoMaker::sendImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendImage, VideoMaker::sendImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::initVideoCtrl, VideoMaker::onInitSaveVideo);

    TASK_LIST_END

  private:
    std::unordered_map<std::string, std::deque<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> _mmap_saveVideo;

    std::thread _m_thread_saveVideo;
    std::condition_variable _m_cond_saveVideo;
    std::mutex _m_mutex_saveVideo;
    std::atomic_bool _mb_SaveVideo;
    std::atomic_bool _mb_stop;

    QString _mqstr_SavePath;

  private:
    void saveVideoThread();
};
} // namespace _Controllers