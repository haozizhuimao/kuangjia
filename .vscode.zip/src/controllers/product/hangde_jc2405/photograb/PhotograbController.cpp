#include "PhotograbController.h"
#include "service/AppFramework.h"
#include <QDateTime>
#include <QImage>
#include <QVariantMap>
#include <qvariant.h>
#include <QBuffer>
#include <QDir>
#include <QFile>
#include <QList>
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

/**
 * @brief 删除指定目录下所有包含特定子字符串的文件
 * @param substring 需要匹配的文件名子字符串
 * @param directory 目标目录路径（默认当前目录）
 * @return 成功删除文件的数量（-1表示目录错误）
 */
int deleteFilesContaining(const QString &substring, const QString &directory = QDir::currentPath())
{
    static QMutex mutex;
    QMutexLocker locker(&mutex);

    // 验证目录有效性
    QDir targetDir(directory);
    if (!targetDir.exists())
    {
        qWarning().nospace() << "[错误] 目录不存在: " << directory;
        return -1;
    }

    // 获取文件列表（排除目录）
    const QStringList files = targetDir.entryList(QDir::Files | QDir::NoDotAndDotDot);
    int deletedCount = 0;
    // 遍历文件
    foreach (const QString &fileName, files)
    {
        if (fileName.contains(substring, Qt::CaseInsensitive))
        { // 大小写不敏感匹配
            const QString fullPath = targetDir.filePath(fileName);
            QFile::setPermissions(directory, QFile::ReadOther | QFileDevice::WriteOther);
            if (QFile::remove(fullPath))
            {
                qDebug().nospace() << "[成功] 已删除文件: " << fullPath;
                ++deletedCount;
            }
            else
            {
                qWarning().nospace() << "[失败] 无法删除文件: " << fullPath << "（可能被占用或权限不足）";
            }
        }
    }

    return deletedCount;
}

// 获取当前 UTC 时间的毫秒时间戳，并转换为微秒
// qint64 msecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch();
// qint64 usecs = msecs * 1000;
void PhotograbController::getcaminfoString(const QVariant &data)
{
    QStringList ipList = m_initinfo.value("iplist").toStringList();
    QStringList snList = m_initinfo.value("snlist").toStringList();
    ipandsnlist = snList + ipList;
    QString result = "";
    for (const QString &str : ipandsnlist)
    {
        QString cameraname = QString("[status:%1,name:%2,serial:%3]")
                                 .arg(m_initinfo.value(m_initinfo.value(str).value<QString>()).value<bool>())
                                 .arg(m_initinfo.value(str).value<QString>())
                                 .arg(str);
        result += cameraname;
    }
    // 和页面通信
    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
                            TIS_Info::QmlCommunication::ForQmlSignals::camera_status_recv,
                            QVariant::fromValue(result));
}

void PhotograbController::savePictureInFile(const QVariant &data)
{

    if (mytaskdir == "")
        return;
    QVariantMap PictureData = data.toMap();
    QImage Picture = PictureData.value("picturedata").value<QImage>();
    qint64 timestamp = PictureData.value("timestamp").value<qint64>();
    QString camid = PictureData.value("camid").value<QString>();

    // 检查图像是否有效
    if (Picture.isNull())
    {
        qWarning() << "Received invalid image data";
        return;
    }

    // 将图片转换为字节数组
    QByteArray imageData;
    QBuffer buffer(&imageData);
    buffer.open(QIODevice::WriteOnly);
    Picture.save(&buffer, "JPG", 100);
    buffer.close();

    // 保存图片到文件
    QDir dir;
    QString cameraname = QString("camera%1").arg(camid);
    QString filename = QString("jpgPicture%1_camera%2.jpg").arg(timestamp).arg(camid);
    QString filedir = mytaskdir + "/" + timestampMap.findClosest(timestamp);
    dir.mkpath(filedir);
    deleteFilesContaining(cameraname, filedir);
    QString filepath = filedir + "/" + filename;
    if (!Picture.save(filepath, "JPG", 100))
    {
        qWarning() << "Failed to save image to file:" << filename;
    }

    // 使用 base64 编码图像数据

    QWriteLocker locker(&tasklocker);
    if (countmap.contains(camid))
    {
        int ct = countmap.value(camid);
        countmap.insert(camid, ct + 1);
    }
    else
    {
        countmap.insert(camid, 1);
    }
    m_initinfo[camid] = true;

    QVariantMap sendData;
    sendData["picturedata"] = QString("data:image/jpeg;base64,") + imageData.toBase64();
    sendData["camid"] = camid;
    sendData["tcount"] = countmap.value(camid);

    // mapData[TIS_Info::QmlCommunication::strData] = sendData;

    qDebug() << "Sending to QML - camid:" << camid << "tcount:" << countmap.value(camid) << "image :" << imageData;

    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
                            TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page,
                            QVariant::fromValue(sendData));
}

void PhotograbController::refreshLocation(const QVariant &data)
{
    QVariantMap PositionData = data.toMap();
    QString stationName = PositionData.value("stationName", QString()).toString();
    QString poleName = PositionData.value("poleName", QString()).toString();
    qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch() * 1000;
    QString insertStr = stationName + "/" + poleName;
    timestampMap.insert(usecs, insertStr);
}

void _Controllers::PhotograbController::refreshTask(const QString &taskdir)
{
    QWriteLocker locker(&tasklocker);
    mytaskdir = taskdir;
}

void _Controllers::PhotograbController::savePictureInFileNetcam(TIS_Info::ImageInfo data)
{
    // 存图逻辑
    if (mytaskdir == "")
        return;
    QImage picture = data.image;
    QString cameraname = QString::fromStdString(data.name);
    qint64 usecs = QDateTime::currentDateTimeUtc().toMSecsSinceEpoch() * 1000;
    QDir dir;
    QString filename = QString("jpgPicture%1_%2.jpg").arg(usecs).arg(cameraname);
    QString filedir = mytaskdir + "/" + timestampMap.findClosest(usecs);
    dir.mkpath(filedir);
    int ret = deleteFilesContaining(cameraname, filedir);
    QString filepath = filedir + "/" + filename;
    if (!picture.save(filepath, "JPG", 100))
    {
        qWarning() << "Failed to save image to file:" << filename;
    }
    QWriteLocker locker(&tasklocker);
    if (countmap.contains(cameraname))
    {
        int ct = countmap.value(cameraname);
        countmap.insert(cameraname, ct + 1);
    }
    else
    {
        countmap.insert(cameraname, 1);
    }
    // 将图片转换为字节数组
    QByteArray imageData;
    QBuffer buffer(&imageData);
    buffer.open(QIODevice::WriteOnly);
    picture.save(&buffer, "JPG", 100);
    buffer.close();
    QVariantMap sendData;
    sendData["picturedata"] = QString("data:image/jpeg;base64,") + imageData.toBase64();
    sendData["camid"] = cameraname;
    sendData["tcount"] = countmap.value(cameraname);

    App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
                            TIS_Info::QmlCommunication::ForQmlSignals::egvinspectionimage_page,
                            QVariant::fromValue(sendData));
}

void _Controllers::PhotograbController::refreshInitinfo(const QVariantMap &mymap)
{
    QWriteLocker locker(&tasklocker);
    m_initinfo.insert(mymap);
}

void _Controllers::PhotograbController::refreshInitinfoNet(const QVariantMap &mymap)
{
    QWriteLocker locker(&tasklocker);
    m_initinfo.insert(mymap);
}
