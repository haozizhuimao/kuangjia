#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Field.h"
#include "tis_global/Struct.h"
#include <QMap>
#include <QReadWriteLock>
#include <QString>

class TimestampMap
{
  public:
    void insert(qint64 timestamp, const QString &value)
    {
        QWriteLocker locker(&lock);
        if (map.size() > 1000)
        {
            QList<qint64> keyList = map.keys();
            map.remove(keyList[0]);
        }
        map.insert(timestamp, value);
    }
    QString findClosest(qint64 target) const
    {
        QReadLocker locker(&lock);

        if (map.isEmpty())
        {
            return QString();
        }

        auto it = map.lowerBound(target);

        if (it == map.end())
        {
            --it;
            return it.value();
        }

        if (it == map.begin())
        {
            return it.value();
        }

        auto prev = it;
        --prev;
        const qint64 diffPrev = target - prev.key();
        const qint64 diffCurrent = it.key() - target;

        return (diffPrev <= diffCurrent) ? prev.value() : it.value();
    }

  private:
    mutable QReadWriteLock lock;
    QMap<qint64, QString> map;
};

namespace _Controllers {
class PhotograbController : public ControllerBase<PhotograbController>
{
  public:
    void getcaminfoString(const QVariant &);
    void savePictureInFile(const QVariant &);
    void refreshLocation(const QVariant &);
    void refreshTask(const QString &);
    void savePictureInFileNetcam(TIS_Info::ImageInfo);
    void refreshInitinfo(const QVariantMap &);
    void refreshInitinfoNet(const QVariantMap &);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::imageReceived, PhotograbController::savePictureInFile);
    ASYNC_TASK_ADD(TIS_Info::LocationService::sendPositionData, PhotograbController::refreshLocation);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::taskChange, PhotograbController::refreshTask);
    ASYNC_TASK_ADD(TIS_Info::NetcamService::imgout, PhotograbController::savePictureInFileNetcam);
    ASYNC_TASK_ADD(TIS_Info::NetcamService::initinfo, PhotograbController::refreshInitinfoNet);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::initinfosend, PhotograbController::refreshInitinfo);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::sendinitinfoTopage, PhotograbController::getcaminfoString);
    TASK_LIST_END
  private:
    QVariantMap m_initinfo;
    QStringList ipandsnlist;
    TimestampMap timestampMap;
    QString mytaskdir;
    QMap<QString, int> countmap;
    mutable QReadWriteLock tasklocker;
};
} // namespace _Controllers