
set(CONTROLER_NAME "ctl_temperature")

message("---------- Building ${CONTROLER_NAME}  ----------")

file(GLOB_RECURSE TEMPERATURE_CTL ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)
                          
add_library(${CONTROLER_NAME} OBJECT ${TEMPERATURE_CTL})

target_sources(${CONTROLER_NAME} PUBLIC 
    $<TARGET_OBJECTS:kit_uniqueid_recv_kits>
)         
target_link_libraries(${CONTROLER_NAME} PUBLIC 
        shared_dependencies 
        kit_log
        kit_uniqueid_recv_kits
)


target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CONTROLER_NAME}>
)     
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CONTROLER_NAME})