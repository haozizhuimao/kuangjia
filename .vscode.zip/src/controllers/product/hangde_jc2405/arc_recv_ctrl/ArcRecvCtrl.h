#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

namespace _Controllers {
class ArcRecvCtrl : public ControllerBase<ArcRecvCtrl>
{
  public:
}
} // namespace _Controllers
