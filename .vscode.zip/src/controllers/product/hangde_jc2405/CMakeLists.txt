set(CTL_NAME "ctl_hangde_jc2405")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_save_video_by_ffmpeg>
)         
target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_save_video_by_ffmpeg
)

if (BUILD_TYPE_LOWER MATCHES "debug")   # 算法没有debug版本

else()
    target_link_libraries(${CTL_NAME} PUBLIC
        ${THIRD_PARTY_LIB}/drop_trigger_reco/DropperTrigger.lib
    )
endif()

add_custom_target(drop_trigger_dll ALL
    COMMAND ${CMAKE_COMMAND} -E copy_directory ${THIRD_PARTY_BIN}/drop_trigger_reco ${CMAKE_RUNTIME_OUTPUT_DIRECTORY}
)


target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
    res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/engineering_vehicle_qml/egv_dropper_trigger_page/egv_dropper_trigger_page.qml
    res/qml/engineering_vehicle_qml/egv_inspectionimage_page/egv_inspectionimage_page.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end
