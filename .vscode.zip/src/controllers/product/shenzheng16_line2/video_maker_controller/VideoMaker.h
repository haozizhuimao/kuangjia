#pragma once
#include "kits/utility/object_pool/ObjectPool.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <QImage>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#include "ningbo_low_panto_detect/TogeeAlgorithmLib.h"

#include <QTime>

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();

    void sendImage(std::shared_ptr<TIS_Info::ImageBuffer>);
    void onStartRecord(QString, QString);
    void onStopRecord();

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraName(std::vector<std::string>) 录像kit的名称列表
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(std::vector<std::string>);

    /// @brief 接收老任务数据
    /// @param taskData(QVariant)
    /// @return void
    void notifyTaskfunc(const QVariant &);

    /// @brief 接收旧任务的位置信息
    /// @param locationData(QVariant)
    /// @return void
    void recvOldLocation(const QVariant &);

    /// @brief 接收MVB信息
    /// @param mvbInfo(QVariant)
    /// @return void
    void recvMVBInfo(const QVariant &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::sendImage, VideoMaker::sendImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendImage, VideoMaker::sendImage);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::startRecord, VideoMaker::onStartRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::startRecord, VideoMaker::onStartRecord);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::stopRecord, VideoMaker::onStopRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::stopRecord, VideoMaker::onStopRecord);
    ASYNC_TASK_ADD(TIS_Info::HikManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::HistroyProgramComm::notifyTaskInfo, VideoMaker::notifyTaskfunc);
    ASYNC_TASK_ADD(TIS_Info::HistroyProgramComm::updateLocationInfo, VideoMaker::recvOldLocation);

    TASK_LIST_END

  private:
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> _mmap_saveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForQml;

    std::thread _m_thread_saveVideo;
    std::atomic_bool _mb_SaveVideo;
    std::atomic_bool _mb_stop;

    std::thread _m_thread_processImage;
    std::thread _m_thread_sendToQml;

    QString _mqstr_SavePath; // 保存路径

    const QString _mqstr_SaveVideo_RootPath = QStringLiteral("D:/gwkj"); // 保存录像的根路径
    int _mi_Task_state = 1;
    QTime _m_time_toDay;

  private:
    void saveVideoThread();

    void processImageThread();

    void sendToQmlThread();

    bool pantoDetect(std::shared_ptr<TIS_Info::ImageBuffer> img, detectResults &results);
};
} // namespace _Controllers