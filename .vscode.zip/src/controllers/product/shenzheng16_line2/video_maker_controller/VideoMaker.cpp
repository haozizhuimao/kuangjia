#include "VideoMaker.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"
#include <QVariant>

using namespace _Controllers;

_Controllers::VideoMaker::VideoMaker()
    : _m_thread_saveVideo(std::thread(&VideoMaker::saveVideoThread, this)), _mb_SaveVideo(true),
      _m_thread_sendToQml(std::thread(&VideoMaker::sendToQmlThread, this)),
      _m_thread_processImage(std::thread(&VideoMaker::processImageThread, this))
{
}

_Controllers::VideoMaker::~VideoMaker()
{
    _mb_SaveVideo.store(false);

    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }
}

void VideoMaker::notifyTaskfunc(const QVariant &task_data)
{
    auto taskinfomap = task_data.toMap();
    auto taskstate = taskinfomap.value("taskstate").toInt();

    if (_mi_Task_state == taskstate)
    {
        // 如果任务状态没有变化，则不处理
        return;
    }

    TIS_Info::TaskInfo taskinfo;
    if (0 == taskstate)
    {
        auto taskname = taskinfomap.value("taskname").toString();
        auto rootpath = _mqstr_SaveVideo_RootPath + "/" + _m_time_toDay.toString("yyyyMMdd") + "/" + taskname;

        taskinfo.strTaskSavePath = rootpath;
        taskinfo.nTaskstate = 0;
    }
    else if (1 == taskstate)
    {
        taskinfo.nTaskstate = 1;
    }
    _Service::invokeHikManagernotifyTask_A(taskinfo);
}

void VideoMaker::recvOldLocation(const QVariant &location_data)
{
    auto locationinfomap = location_data.toMap();
    auto locationstation = locationinfomap.value("locationstation").toByteArray().toStdString();
    auto locationlinedir = locationinfomap.value("locationlinedir").toInt();
    auto locationpole = locationinfomap.value("locationpole").toByteArray().toStdString();
    auto locationmovedistance = locationinfomap.value("locationmovedistance").toDouble();
    auto locationmovespeed = locationinfomap.value("locationspeed").toDouble();

    QVariantMap PositionData1;
    PositionData1["站区名"] = locationinfomap.value("locationstation");
    PositionData1["杆号名"] = locationinfomap.value("locationpole");
    PositionData1["公里标"] = locationinfomap.value("locationmovedistance");
    PositionData1["速度"] = locationinfomap.value("locationspeed");

    _Service::invokeHikManageronLocation_V(PositionData1);
}

void recvMVBInfo(const QVariant &mvb_data)
{
}

void VideoMaker::sendImage(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    auto &processQueue = _mmap_imgQueueForProcess[img->name];
    processQueue.push(img);
}

void _Controllers::VideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(img);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::onStartRecord(QString rootPath, QString fileName)
{
    QString dirPath, filePath;

    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        // 构建完整路径
        dirPath = rootPath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";
        if (_mqstr_SavePath != rootPath)
        {
            _mqstr_SavePath = rootPath; // 更新保存路径
        }

        // 创建目录结构
        QDir dir;
        if (!dir.exists(dirPath))
        {
            if (!dir.mkpath(dirPath))
            {
                qWarning() << "Failed to create directory:" << dirPath;
                continue; // 跳过当前摄像头
            }
        }

        // 创建并打开文件以确保路径可写
        QFile file(filePath);
        if (!file.open(QIODevice::WriteOnly))
        {
            qWarning() << "Failed to create/open file:" << filePath << "Error:" << file.errorString();
            continue; // 跳过当前摄像头
        }
        file.close(); // 关闭文件，实际写入由saveVideo处理

        // 开始录像
        saveVideo->startRecord(filePath);

        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::save_path_send,
                                                      QVariant::fromValue(dirPath));
    }
}

void _Controllers::VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
}

void _Controllers::VideoMaker::onInitSaveVideo(std::vector<std::string> cameraName)
{
    for (const auto &name : cameraName)
    {
        if (_mmap_saveVideo.find(name) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[name] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[name]->initSaveVideo(1); // 初始化录像kit
        }
    }
}

void _Controllers::VideoMaker::processImageThread()
{
    static int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */
                detectResults results;
                if (pantoDetect(img, results))
                {
                }
                /* 发送图像 */
                if (++i % 5 == 0)
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[img->name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                // 发送图像到QML
                QImage qimg(img->data.data(), img->width, img->height, QImage::Format_RGB888);
                if (!qimg.isNull())
                {

                    _Service::receiverQmlPrivateEnginecallFromCpp(
                        TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page,
                        QVariant::fromValue(QVariantMap{{"img", qimg}, {"camera_name", QString::fromStdString(img->name)}}));
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

bool _Controllers::VideoMaker::pantoDetect(std::shared_ptr<TIS_Info::ImageBuffer> img, detectResults &results)
{
#if __has_include(<unistd.h>)
    pantographDetectionModel m_detect_model;
    detectResults m_detect_results;
    pantographDetectionInput m_detect_input;

    m_detect_input.m_img_buffer = img->data.data();
    m_detect_input.m_img_width = img->width;
    m_detect_input.m_img_height = img->height;

    if (img->pixFormat == AV_PIX_FMT_RGB24)
    {
        m_detect_input.m_img_channel = 3; // RGB
    }
    else if (img->pixFormat == AV_PIX_FMT_GRAY8)
    {
        m_detect_input.m_img_channel = 1; // 灰度图
    }
    else
    {
        qWarning() << "Unsupported image format for pantograph detection.";
        return false;
    }

    if (PantographDetection_Process(m_detect_input, &m_detect_results) == 0)
    {
        if (m_detect_results.m_result_num > 0)
        {
            for (int i = 0; i < m_detect_results.m_result_num; i++)
            {
                qDebug() << "检测到电视弓缺陷: " << m_detect_results.m_results[i].label_ID;
            }
            return ReturnCode_OVER;
        }
    }
#elif __has_include(<windows.h>)
    return false;
#endif
}