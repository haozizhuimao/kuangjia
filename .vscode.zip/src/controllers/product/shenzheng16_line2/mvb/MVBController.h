#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, MVBController::setUdpClient);
    TASK_LIST_END

  private slots:
    void onUdpDataReceived(const std::shared_ptr<std::vector<QByteArray>> &ptrDatas);

  private:
    void heartFunc();
    void sendAliveData();
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, QVariantMap &);
    // 界面展示接收数据
    void displayRecvPortData(QVariantMap &);
    // 界面展示心跳数据
    void displayHeartData();
    // 发送mvb接收到的公共数据给其他模块
    void sendRecvDataToModule(const std::vector<uint8_t> &);

    std::atomic_bool m_bHolder = true;
    const std::string m_udpName = "mvb";
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    std::vector<uint8_t> m_recvData;
    std::vector<uint8_t> m_heartData;

    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    int m_heardLen = 0;
};
} // namespace _Controllers
