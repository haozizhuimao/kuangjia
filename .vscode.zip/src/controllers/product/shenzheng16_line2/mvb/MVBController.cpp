#include "MVBController.h"
#include "kits/third_devices/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"
//#include "tis_global/Function.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <qobject.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_heardLen = sizeof(TIS_Info::TrdpHeader);
    m_recvData.resize(m_heardLen + 124, 0);
    m_heartData.resize(m_heardLen + 32, 0);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
}

void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto finder = clients.find(m_udpName);
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", m_udpName);
        return;
    }
    m_udpClient = finder->second;

    finder->second->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) {
        if (!data)
        {
            return;
        }

        auto packets = std::make_shared<std::vector<QByteArray>>();
        packets->emplace_back(reinterpret_cast<const char *>(data->data()), static_cast<int>(data->size()));
        onUdpDataReceived(packets);
    });
    // m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 列车车次号
    outputData["lineNum"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);

    // A1车司机室激活
    uint8_t lineData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    std::bitset<8> bit(lineData);
    outputData["a1Active"] = static_cast<bool>(bit[7]);
    // A2车司机室激活
    outputData["a2Active"] = static_cast<bool>(bit[6]);
    // 列车前向状态
    outputData["forward"] = static_cast<bool>(bit[5]);
    // 列车后向状态
    outputData["backward"] = static_cast<bool>(bit[4]);
    // 列车牵引工况
    outputData["carPull"] = static_cast<bool>(bit[2]);
    // 列车制动工况
    outputData["carBrake"] = static_cast<bool>(bit[1]);
    // 列车惰行工况
    outputData["carCoasting"] = static_cast<bool>(bit[0]);

    uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    std::bitset<8> bit1(modeData);
    // B1车降弓到位
    outputData["b1Lowerbow"] = static_cast<bool>(bit[6]);
    // B2车降弓到位
    outputData["b2Lowerbow"] = static_cast<bool>(bit[5]);
    // 列车休眠指令
    outputData["carDormancy"] = static_cast<bool>(bit[4]);
    // ATB模式
    outputData["ATBMode"] = static_cast<bool>(bit[3]);
    // ATO模式
    outputData["ATOMode"] = static_cast<bool>(bit[2]);
    // 时间设置标志位
    outputData["timeSet"] = static_cast<bool>(bit[1]);
    // 时间有效标志位
    outputData["timeValid"] = static_cast<bool>(bit[0]);

    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 8);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 10);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 11);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 12);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 13);

    // 列车参考速度
    outputData["speed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
    // 全列车牵引力
    outputData["allTraction"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
    // 全列车空气制动力
    outputData["allAirForce"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
    // 全列车电制动力
    outputData["allElectricForce"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
    // 1车载荷
    outputData["a1Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
    // 2车载荷
    outputData["a2Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
    // 3车载荷
    outputData["a3Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 26);
    // 4车载荷
    outputData["a4Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 28);
    // 5车载荷
    outputData["a5Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 30);
    // 6车载荷
    outputData["a6Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 32);
    // 全列车载荷
    outputData["allLoad"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 34);
    // 1车乘车率
    outputData["a1RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 36);
    // 2车乘车率
    outputData["a2RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 37);
    // 3车乘车率
    outputData["a3RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 38);
    // 4车乘车率
    outputData["a4RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 39);
    // 5车乘车率
    outputData["a5RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 40);
    // 6车乘车率
    outputData["a6RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 41);
    // 整车乘车率
    outputData["allRidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 42);
    // Tc1车 Block ID
    outputData["tc1BlockID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 43);
    // Tc2车 Block ID
    outputData["tc2BlockID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 45);
    // Tc1车 abcsissa
    outputData["tc1Abcsissa"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 47);
    // Tc2车 abcsissa
    outputData["tc2Abcsissa"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 49);
    // 蓄电池电压
    outputData["batteryVoltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 51);
    // 网压
    outputData["voltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 53);
    // 网流
    outputData["electricity"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 55);
    // 站点信息反馈-起始站
    outputData["startStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 72);
    // 站点信息反馈-当前站
    outputData["currentStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 74);
    // 站点信息反馈-下一站
    outputData["nextStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 76);
    // 站点信息反馈-终点站
    outputData["endStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 78);
    // 列车总行驶里程
    outputData["accumulatedKM"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 82);

    uint8_t closeStatus = ByteArrayTools::readFromVectorBE<uint8_t>(data, 98);
    std::bitset<8> bit2(closeStatus);
    // 所有门关闭状态
    outputData["doorsClosed"] = static_cast<bool>(bit2[7]);
    // 占有端左侧门关好
    outputData["leftDoorsClosed"] = static_cast<bool>(bit2[6]);
    // 占有端右侧门关好
    outputData["rightDoorsClosed"] = static_cast<bool>(bit2[5]);

    uint8_t panStatus = ByteArrayTools::readFromVectorBE<uint8_t>(data, 99);
    std::bitset<8> bit3(panStatus);
    // 升弓状态
    outputData["panUP"] = static_cast<bool>(bit3[7]);
    // 降弓状态
    outputData["panDown"] = static_cast<bool>(bit3[6]);
    // 所有门关好
    outputData["allClose"] = static_cast<bool>(bit3[6]);
    // 休眠请求
    outputData["sleepCmd"] = static_cast<bool>(bit3[1]);
    // 低功耗指令
    outputData["blowPower"] = static_cast<bool>(bit3[0]);
}

void MVBController::displayRecvPortData(QVariantMap &portData)
{
    // 给页面传递数据展示
    QVariantMap mapData;

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt;
    portData["dataSource"] = "shenzhen16_common_data";

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(portData));
}

void MVBController::onUdpDataReceived(const std::shared_ptr<std::vector<QByteArray>> &ptrDatas)
{
    for (const auto &data : *ptrDatas)
    {
        std::vector<uint8_t> commonData(data.begin() + m_heardLen, data.end());
        LogInfo("recv udp data={}", data.toStdString());
        QVariantMap dataMap;
        parseCommonData(commonData, dataMap);
        displayRecvPortData(dataMap);

        // 转发数据给其他模块
        sendRecvDataToModule(commonData);
        if (auto strongPtr = m_udpClient.lock())
        {
            // 转发数据给旧mvb程序
            strongPtr->sendData("mvb_common_data", data);
        }
    }
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(1000);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::sendAliveData()
{
    auto strongPtr = m_udpClient.lock();

    if (!strongPtr)
    {
        return;
    }

    ++m_aliveId; // 心跳id自增
    TIS_Info::TrdpHeader header;
    header.sequenceCounter = m_aliveId;
    header.comId = 111;
    header.datasetLength = 32;
    std::memcpy(m_heartData.data(), &header, m_heardLen);
    ByteArrayTools::writeToVectorBE(m_heartData, m_aliveId, m_heardLen + 0);

    QByteArray byteArray(reinterpret_cast<const char *>(m_heartData.data()), m_heartData.size());
    // m_udpClient->sendData("mvb_heart", byteArray);
    displayHeartData();
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 软件版本
    outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
    // 自检结果
    uint8_t checkStatus = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    std::bitset<8> bit(checkStatus);
    // 自检失败
    outputData["selfCheckFailed"] = static_cast<bool>(bit[7]);
    // 自检完成
    outputData["selfCheckOver"] = static_cast<bool>(bit[6]);
    // 自检成功
    outputData["selfCheckSuccess"] = static_cast<bool>(bit[5]);
    // 自检中
    outputData["selfChecking"] = static_cast<bool>(bit[4]);
    // WTS车地网络通信故障
    uint8_t connectStatus = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    std::bitset<8> bit1(connectStatus);
    outputData["wtsConnectFailed"] = static_cast<bool>(bit1[0]);
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    QVariantMap heartData;
    std::vector<uint8_t> data(m_heartData.begin() + m_heardLen, m_heartData.end());
    parseHeartData(data, heartData);

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    heartData["sendTime"] = timeFmt;
    heartData["dataSource"] = "shenzhen16_heart";

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(heartData));
}

void MVBController::sendRecvDataToModule(const std::vector<uint8_t> &data)
{
    QVariantMap recvData;
    // 列车车次号
    recvData["lineNum"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    // 列车参考速度
    recvData["speed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
    // 网压
    recvData["voltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 53);
    // 网流
    recvData["electricity"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 55);

    invokeMVBMsgForwardsendMvbRecvData_A(recvData);
}
} // namespace _Controllers
