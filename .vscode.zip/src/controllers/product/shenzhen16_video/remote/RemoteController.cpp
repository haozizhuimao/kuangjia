#include "RemoteController.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
//#include "tis_global/Function.h"
#include "kits/utility/log/CRossLogger.h"
#include <atomic>

namespace _Controllers {
using namespace _Kits;
void RemoteController::publishTaskInfo(const TIS_Info::TaskInfo &data)
{

    static std::atomic_int32_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);

    // LogInfo("[remote] recv task info ");

    if (data.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        mes.topic = TIS_Info::TaskService::taskBegin;
    }
    else if (data.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        mes.topic = TIS_Info::TaskService::taskEnd;
    }
    else if (data.nTaskstate == TIS_Info::TaskState::TASK_RUNNING)
    {
        mes.topic = TIS_Info::TaskService::taskRunning;
    }

    Json::Value json;
    json["strTaskName"] = data.strTaskName;
    json["strCreateTime"] = data.timestamp;
    json["strsubwayNum"] = data.strTrainNumber;
    json["strLineName"] = data.strLineName;
    json["strstartstation"] = data.strStartStation;
    json["strEndstation"] = data.strEndStation;
    json["strstartPole"] = data.strStartPole;
    json["nLineDir"] = data.nLineDirection;               // 上行
    json["nDirection"] = data.nDirection;                 // 正向
    json["nTaskstate"] = static_cast<int>(data.taskType); // 开始
    json["nTaskID"] = data.nTaskID;

    // 新加一段
    json["strTaskSavePath"] = data.strTaskSavePath;

    mes.json_data = _Kits::jsonToString(json);

    // LogInfo("[remote] json:{}",mes.json_data);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishLocationInfo(const TIS_Info::LocationData &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::LocationService::LocationRadio;
    Json::Value json;
    json["station_name"] = data.station_name;
    json["maoduan_name"] = data.maoduan_name;
    json["pole_name"] = data.pole_name;
    json["mileage_adjust"] = data.mileage_adjust;
    json["speed"] = data.speed;
    json["task_id"] = data.task_id;
    json["location_type"] = static_cast<int>(data.location_type);
    json["mileage_normal"] = data.mileage_normal;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut;
    Json::Value json;
    json["press0"] = data.md_press0;
    json["press1"] = data.md_press1;
    json["press2"] = data.md_press2;
    json["press3"] = data.md_press3;
    json["press4"] = data.md_press4;
    json["press5"] = data.md_press5;
    json["press6"] = data.md_press6;
    json["press7"] = data.md_press7;
    json["spot0x"] = data.md_spot0x;
    json["spot0y"] = data.md_spot0y;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::PressSpotVolElecEtcData::sendVolElecOut;
    Json::Value json;
    json["voltage"] = data.md_voltage0;
    json["electric"] = data.md_electric0;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

} // namespace _Controllers