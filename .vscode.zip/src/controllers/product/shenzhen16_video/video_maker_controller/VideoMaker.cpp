#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include "kits/utility/log/CRossLogger.h"
#include <QJsonValue>
#include <opencv2/opencv.hpp>
#include <QDir>
#include "tis_global/enum_public/video_enum.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/camera/tools/RemoteParser.h"
#include <QJsonDocument>
#include <QVariantMap>
#include <QJsonObject>

namespace _Controllers {
using namespace _Service;

_Controllers::VideoMaker::VideoMaker()
    : _m_ImageBufferPools(std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>()),
      _m_locationCtrl(std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); })),
      _m_task_info({}), _mb_SaveVideo(true), _mqstr_SavePath({"d:/gwkj/video_Notask"}), _m_thread_saveVideo{}, _m_thread_sendToQml{},
      _m_thread_processImage{}, _m_thread_sendTitle{}
{}

_Controllers::VideoMaker::~VideoMaker()
{
    onStopVideoMaker();
}

void VideoMaker::onStopVideoMaker()
{
    for (auto &[name, cam] : (*m_udm_cam))
    {
        cam->closeCamera();
    }
    _mb_SaveVideo.store(false);

    onStopRecord();

    stopAllThread();

    _m_locationCtrl->stop();
}

// 辅助函数：创建目录
bool VideoMaker::createDirectory(const QString &dirPath)
{
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            _Kits::LogError("Failed to create directory: {}", dirPath.toStdString());
            return false;
        }
    }
    return true;
}

void _Controllers::VideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> yuv420p;
            while (queue.try_pop(yuv420p))
            {
                if (!yuv420p)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(yuv420p);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::onStartRecord(QString fileName)
{
    QString dirPath, filePath;
    std::vector<std::pair<QString, QString>> savePaths;

    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        // 构建完整路径
        dirPath = _mqstr_SavePath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";

        // 创建目录结构
        if (!createDirectory(dirPath))
        {
            continue; // 跳过当前摄像头
        }

        // 开始录像
        saveVideo->startRecord(filePath);
        savePaths.push_back({QString::fromStdString(name), dirPath});
    }

    // 批量发送保存路径
    for (const auto &[name, path] : savePaths)
    {
        senderHikManagersendSavePathOut(name, path);
    }
    senderHikManagersendRecordState(true);
}

void _Controllers::VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
}

void _Controllers::VideoMaker::onInitSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>> cameraMap,
                                               std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>> cameraInfo,
                                               std::shared_ptr<std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>>>)
{
    m_udm_cam = cameraMap;
    m_udm_camInfo = cameraInfo;

    for (const auto &[name, info] : (*m_udm_camInfo))
    {
        if (_mmap_saveVideo.find(info.mstr_deviceName) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[info.mstr_deviceName] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[info.mstr_deviceName]->initSaveVideo(1); // 初始化录像kit
        }

        if (_mmap_isDisplay.find(info.mstr_deviceName) == _mmap_isDisplay.end())
        {
            _mmap_isDisplay[info.mstr_deviceName] = true;
        }
    }

    for (const auto &[name, cam] : (*m_udm_cam))
    {
        cam->setSendImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) {
            if (!img)
                return;

            static uint32_t count = 0;

            if (count++ % 500 == 0)
                _Kits::LogInfo("Receive image:{}", img->name);

            _mmap_imgQueueForProcess[img->name].push(img);
        });
    }

    startAllThread();

    _Kits::LogInfo("VideoMaker initialized successfully.");
}

void _Controllers::VideoMaker::processImageThread()
{
    static int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */

                /* 发送图像 */
                if (_mmap_isDisplay[name])
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img || queue.unsafe_size() > 5)
                    continue;

                if (img->pixFormat == (int)TIS_Info::AVPixelFormat::AV_PIX_FMT_YUV420P)
                {
                    img = YUV420ptoRGB(img);
                }

                if (img->camera_type == (int)TIS_Info::CameraType::CameraType_HIK)
                {
                    senderHikManagersendImageToQml(img);
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::SetExposureTimeAndGain(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD exposureTime = static_cast<DWORD>(dataMap.value("exposure").toUInt());
    BYTE gainValue = static_cast<BYTE>(dataMap.value("gain").toUInt());
    QString type = dataMap.value("type").toString();

    if (type == "setExposureAndGain")
    {
        auto it = m_udm_cam->find(cameraName);
        if (it != m_udm_cam->end())
        {
            it->second->onSetExposureTimeAndGain(exposureTime, gainValue);
        }
    }
}

void _Controllers::VideoMaker::PTZControl(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    QString dir = dataMap.value("dir").toString();
    QString command = dataMap.value("command").toString();
    QString type = dataMap.value("type").toString();
    if (type == "PTZControl")
    {
        auto it = m_udm_cam->find(cameraName);
        if (it != m_udm_cam->end())
        {
            it->second->onPTZControl(dir, command);
        }
    }
}

void _Controllers::VideoMaker::SetPTZSpeed(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD speed = static_cast<DWORD>(dataMap.value("speed").toUInt());
    QString type = dataMap.value("type").toString();
    if (type == "SetPTZSpeed")
    {
        auto it = m_udm_cam->find(cameraName);
        if (it != m_udm_cam->end())
        {
            it->second->onSetPTZSpeed(speed);
        }
    }
}

QVariantMap _Controllers::VideoMaker::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: data is not a string");
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: invalid JSON object");
        return {};
    }

    return doc.object().toVariantMap();
}

void _Controllers::VideoMaker::sendTitleThread()
{
    std::vector<QString> subtitles;
    subtitles.reserve(16);

    std::vector<QString> empty_subtitle = {""};

    while (_mb_SaveVideo.load())
    {
        if (_m_task_info.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || _m_task_info.nTaskstate == TIS_Info::TaskState::TASK_NONE)
        {
            for (const auto &name_cam : (*m_udm_cam))
            {
                name_cam.second->onWriteSubTitle(empty_subtitle);
            }
        }
        else if (_m_task_info.nTaskstate == TIS_Info::TaskState::TASK_RUNNING || _m_task_info.nTaskstate == TIS_Info::TaskState::TASK_START)
        {

            // 使用tbb::concurrent_unordered_map的安全访问方式
            auto station_it = _m_map_subTitle.find("站区名");
            if (station_it != _m_map_subTitle.end())
            {
                subtitles.push_back("站区名:" + station_it->second.toString());
            }

            auto anchor_it = _m_map_subTitle.find("锚段名");
            if (anchor_it != _m_map_subTitle.end())
            {
                subtitles.push_back("锚段名:" + anchor_it->second.toString());
            }

            auto linedirection_it = _m_map_subTitle.find("行别");
            if (linedirection_it != _m_map_subTitle.end())
            {
                subtitles.push_back("行别:" + linedirection_it->second.toString());
            }

            auto pole_it = _m_map_subTitle.find("杆号名");
            if (pole_it != _m_map_subTitle.end())
            {
                subtitles.push_back("杆号:" + pole_it->second.toString());
            }

            auto km_it = _m_map_subTitle.find("公里标");
            if (km_it != _m_map_subTitle.end())
            {
                subtitles.push_back("公里标:" + QString::number(km_it->second.toDouble() / 1000 / 1000, 'f', 3));
            }

            auto speed_it = _m_map_subTitle.find("速度");
            if (speed_it != _m_map_subTitle.end())
            {
                subtitles.push_back("速度:" + QString::number(speed_it->second.toDouble(), 'f', 3));
            }

            auto press_it = _m_map_subTitle.find("压力");
            if (press_it != _m_map_subTitle.end())
            {
                subtitles.push_back("压力:" + QString::number(press_it->second.toDouble(), 'f', 3));
            }

            auto temp_it = _m_map_subTitle.find("硬点");
            if (temp_it != _m_map_subTitle.end())
            {
                subtitles.push_back("硬点:" + QString::number(temp_it->second.toDouble(), 'f', 3));
            }

            auto vol_it = _m_map_subTitle.find("电压");
            if (vol_it != _m_map_subTitle.end())
            {
                subtitles.push_back("电压:" + QString::number(vol_it->second.toDouble(), 'f', 3));
            }

            auto height_it = _m_map_subTitle.find("导高");
            if (height_it != _m_map_subTitle.end())
            {
                subtitles.push_back("导高:" + QString::number(height_it->second.toDouble(), 'f', 3));
            }

            auto zig_it = _m_map_subTitle.find("拉出值");
            if (zig_it != _m_map_subTitle.end())
            {
                subtitles.push_back("拉出值:" + QString::number(zig_it->second.toDouble(), 'f', 3));
            }

            for (const auto &name_cam : (*m_udm_cam))
            {
                name_cam.second->onWriteSubTitle(subtitles);
            }

            subtitles.clear();
            std::this_thread::sleep_for(std::chrono::milliseconds(200)); // 发送一次标题
        }
    }
}

void _Controllers::VideoMaker::onGetLocation_(const TIS_Info::RemoteMessage &location_data)
{
    std::map<std::string, std::string> result;
    if (!_Kits::RemoteParser::parseLocationInfo(location_data, result))
    {
        _Kits::LogWarn("Failed to parse location info");
        return;
    }

    if (result.find("站区名") != result.end())
        _m_map_subTitle["站区名"] = QString::fromStdString(result["站区名"]);
    if (result.find("锚段名") != result.end())
        _m_map_subTitle["锚段名"] = QString::fromStdString(result["锚段名"]);
    if (result.find("杆号名") != result.end())
        _m_map_subTitle["杆号名"] = QString::fromStdString(result["杆号名"]);
    if (result.find("公里标") != result.end())
        _m_map_subTitle["公里标"] = QString::fromStdString(result["公里标"]);
    if (result.find("速度") != result.end())
        _m_map_subTitle["速度"] = QString::fromStdString(result["速度"]);

    _m_locationCtrl->updateLocation(QString::fromStdString(_Kits::RemoteParser::getLocationName(result)));
}

void VideoMaker::onJiheInfo(std::shared_ptr<TIS_Info::JiHeData> data)
{
    _m_map_subTitle["导高"] = data->fHei[0];
    _m_map_subTitle["拉出值"] = data->fZig[0];
}

void VideoMaker::onPressSpotInfo_(const TIS_Info::RemoteMessage &msg)
{
    std::map<std::string, std::string> result;
    if (_Kits::RemoteParser::parsePressSpotInfo(msg, result))
    {
        if (result.find("压力") != result.end())
            _m_map_subTitle["压力"] = QString::fromStdString(result["压力"]);
        if (result.find("硬点") != result.end())
            _m_map_subTitle["硬点"] = QString::fromStdString(result["硬点"]);
    }
}

void VideoMaker::onVolElecInfo_(const TIS_Info::RemoteMessage &msg)
{
    std::map<std::string, std::string> result;
    if (_Kits::RemoteParser::parseVolElecInfo(msg, result))
    {
        if (result.find("电压") != result.end())
            _m_map_subTitle["电压"] = QString::fromStdString(result["电压"]);
        if (result.find("电流") != result.end())
            _m_map_subTitle["电流"] = QString::fromStdString(result["电流"]);
    }
}

void VideoMaker::onPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    auto ret = (data.md_press0 == 8000 ? 0 : data.md_press0) + (data.md_press1 == 8000 ? 0 : data.md_press1) +
               (data.md_press2 == 8000 ? 0 : data.md_press2) + (data.md_press3 == 8000 ? 0 : data.md_press3);

    _m_map_subTitle["压力"] = (ret == 0 ? 8000 : ret);
    _m_map_subTitle["硬点"] = data.md_spot0x;
}

void VideoMaker::onVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    _m_map_subTitle["电压"] = data.md_voltage0;
    _m_map_subTitle["电流"] = data.md_electric0;
}

void _Controllers::VideoMaker::onQmlRecordSignal(QVariant data)
{
    QVariantMap map = convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    bool isCheck = map.value("isCheck").toBool();

    if (isCheck)
    {
        onStartRecordOneCame(camera_name, "");
    }
    else
    {
        // onStopRecordOneCame(camera_name);
    }
}

void VideoMaker::onStartRecordOneCame(QString camera_name, QString file_name)
{
    QString dirPath = _mqstr_SavePath + "/" + QDateTime::currentDateTime().toString("yyyyMMdd") + "/" + camera_name;
    QString filePath = dirPath + "/" + file_name + ".mp4";

    // 创建目录结构
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            qWarning() << "Failed to create directory:" << dirPath;
            _Kits::LogError("[HikCamera::onStartRecordOneCame] 创建文件夹失败，录像失败");
            return;
        }
    }

    _mmap_saveVideo[camera_name.toStdString()]->startRecord(filePath);
}

void VideoMaker::onStopRecordOneCame(QString camera_name)
{
    _mmap_saveVideo[camera_name.toStdString()]->stopRecord();
}

void _Controllers::VideoMaker::onDisplayImgOption(QVariant data)
{
    QVariantMap map = convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    QString type = map.value("type").toString();
    if (type == "isDisplay")
    {
        bool isDisplay = map.value("state").toBool();
        _mmap_isDisplay[camera_name.toStdString()] = isDisplay;
    }
    else
    {
        return;
    }
}

void _Controllers::VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    _m_map_subTitle["站区名"] = location_data.station_name.c_str();
    _m_map_subTitle["行别"] = location_data.line_direction == 0 ? "上行" : "下行";
    _m_map_subTitle["杆号名"] = location_data.pole_name.c_str();
    //_m_map_subTitle["公里标"] = location_data.mileage_adjust;
    _m_map_subTitle["速度"] = location_data.speed;

    //_Kits::LogError("[VideoMaker::onGetLocation] : 从定位处收到速度{}", location_data.speed);

    _m_locationCtrl->updateLocation(location_data.station_name.c_str());
}

void _Controllers::VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    handleTaskBegin(task_info);
}

void _Controllers::VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    handleTaskEnd(task_info);
}

void _Controllers::VideoMaker::onTaskBegin_(const TIS_Info::RemoteMessage &task_data)
{
    auto task_info = _Kits::RemoteParser::parseTaskBeginMessage(task_data);

    handleTaskBegin(task_info);
}

void _Controllers::VideoMaker::onTaskEnd_(const TIS_Info::RemoteMessage &task_data)
{
    auto task_info = _Kits::RemoteParser::parseTaskEndMessage(task_data);

    handleTaskEnd(task_info);
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = _m_ImageBufferPools->getObject(w, h, 3); // RGB24

    cv::Mat yuv_mat(h * 3 / 2, w, CV_8UC1, img_yuv420p->data.data());
    cv::Mat rgb_mat(h, w, CV_8UC3, img_rgb->data.data());
    cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}

void _Controllers::VideoMaker::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskBegin: Task start");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;
    _m_locationCtrl->updateLocation("");
    // 更新保存路径
    if (!task_info.strTaskSavePath.empty())
    {

        _mqstr_SavePath = QString::fromStdString(task_info.strTaskSavePath);
        //_Kits::LogInfo("VideoMaker::handleTaskBegin: Task start path:{}",_mqstr_SavePath.toStdString());
        createDirectory(_mqstr_SavePath);
    }
    else
    {
        _Kits::LogError("VideoMaker::handleTaskBegin: Task error:path is empty");
    }
}

void _Controllers::VideoMaker::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskEnd: Task end");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;

    // 停止所有录像
    onStopRecord();
    senderHikManagersendRecordState(false);
}

void VideoMaker::startAllThread()
{
    if (!_m_thread_processImage.joinable())
    {
        _m_thread_processImage = std::thread(&VideoMaker::processImageThread, this);
    }
    if (!_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo = std::thread(&VideoMaker::saveVideoThread, this);
    }
    if (!_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml = std::thread(&VideoMaker::sendToQmlThread, this);
    }
    if (!_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle = std::thread(&VideoMaker::sendTitleThread, this);
    }
}

void VideoMaker::stopAllThread()
{
    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }
    if (_m_thread_processImage.joinable())
    {
        _m_thread_processImage.join();
    }
    if (_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml.join();
    }
    if (_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle.join();
    }
}
} // namespace _Controllers
