#include "TaskController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/product_kits/line_helper/LineHelper.h"
#include "tis_global/enum_public/task_enum.h"
#include "TaskSql.h"
#include <filesystem>
#include <iostream>
#include <fmt/core.h>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TaskController::initFromMoudle(const int type, const std::string &trainNum, const std::string &savePath)
{
    m_task_type = static_cast<TIS_Info::TaskType>(type);
    m_trainNum = trainNum;
    m_savePath = savePath;
}

void TaskController::onQmlTask(QVariant data)
{
    if (m_task_type != TIS_Info::TaskType::TYPE_MANUAL)
    {
        LogError("任务类型错误{}，不能手动创建任务", static_cast<int>(m_task_type));
        return;
    }
    // 前端发来的是 JSON 字符串

    if (!data.canConvert<QString>())
    {
        LogError("下发任务数据错误!");
        return;
    }

    auto json = _Kits::stringToJson(data.toString().toUtf8().constData());
    std::cout << json;
    if (!json.isMember("taskState"))
    {
        LogError("下发任务数据错误!");
        return;
    }
    auto state = static_cast<TIS_Info::TaskState>(std::stoi(json["taskState"].asString()));
    if (state == TIS_Info::TaskState::TASK_START)
    {
        auto taskInfo = jsonTaskInfo(json);

        if (taskInfo.nTaskID == -1)
        {
            return;
        }
        taskInfo.nTaskstate = state;
        m_currentTask = taskInfo;
        if (!LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
        {
            LogError("[任务线路表]: 任务线路表信息初始化失败。");
            return;
        }
        senderTaskServicetaskBegin(taskInfo);
    }
    else if (TIS_Info::TaskState::TASK_STOPPED == state)
    {
        m_currentTask.nTaskstate = state;
        TaskSql::updateStopTask(m_currentTask.nTaskID);
        if (m_currentTask.nTaskID != -1)
        {
            senderTaskServicetaskEnd(m_currentTask);
        }
    }
}

void TaskController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &mvb_info)
{
    if (m_task_type != TIS_Info::TaskType::TYPE_STATION)
    {
        LogError("任务类型错误{}，不能创建任务", static_cast<int>(m_task_type));
        return;
    }
    // 行别切换时创建站区id任务，其他消息用于更新速度
    if (m_line_direction != mvb_info.nLineDirection)
    {
        
        if (m_currentTask.nTaskID != -1 && m_currentTask.taskType == TIS_Info::TaskType::TYPE_STATION &&
            m_currentTask.nTaskstate == TIS_Info::TaskState::TASK_START)
        {
            m_currentTask.nTaskstate = TIS_Info::TaskState::TASK_STOPPED;
            senderTaskServicetaskEnd(m_currentTask);
        }
        if (LineHelper::initTaskLineData(mvb_info.strLineName, mvb_info.nLineDirection))
        {
            auto lineDatas = LineHelper::getLineDatas(mvb_info.strLineName, mvb_info.nLineDirection);
            auto taskInfo = mvbTaskInfo(mvb_info);
            if(taskInfo.strStartStation.empty() || taskInfo.strEndStation.empty())
            {
                LogError("任务起始站或终点站为空，不能创建任务");
                return;
            }
            m_line_direction = mvb_info.nLineDirection;
            taskInfo.nTaskstate = TIS_Info::TaskState::TASK_START;
            m_currentTask = taskInfo;
            senderTaskServicetaskBegin(taskInfo);
        }
        else
        {
            LogError("[任务线路表]: 任务线路表信息初始化失败。");
        }
        
    }
}

TIS_Info::TaskInfo TaskController::mvbTaskInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_STATION;
    task.nLineDirection = data.nLineDirection;
    task.strLineName = data.strLineName;
    task.strStartStation = LineHelper::getStationName(data.startStation, data.strLineName, data.nLineDirection);
    task.strEndStation = LineHelper::getStationName(data.endStation, data.strLineName, data.nLineDirection);

    if(task.strStartStation.empty() || task.strEndStation.empty())
    {
        LogError("任务起始站或终点站为空，不能创建任务");
        return task;
    }
    task.strTrainNumber = data.strTrainNum;
    task.nStationId = data.currentStationId;
    auto strCreateTime = _Kits::datetime::current_string("%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::current_string();
    task.timestamp = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;
    task.strTaskSavePath = createTaskSavePath(task.strTaskName);
    task.nTaskID = TaskSql::insertTaskToDB(strSqlTime, task);
    task.nDirection = data.nDirection;
    return task;
}
TIS_Info::TaskInfo TaskController::jsonTaskInfo(const Json::Value &json)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_MANUAL;

    task.strTrainNumber = m_trainNum;

    task.nDirection = std::stoi(json["runDirection"].asString());
    task.nLineDirection = json["lineDirection"].asString() == "上行" ? 0 : 1;
    task.strLineName = json["lineName"].asString();
    task.strStartStation = json["startStation"].asString();
    task.strStartPole = json["startPole"].asString();
    task.strEndStation = json["endStation"].asString();

    auto strCreateTime = _Kits::datetime::current_string("%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::current_string();
    task.timestamp = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;

    // task.strTaskSavePath = std::format("{}tasks/{}/{}", m_savePath, strDateTime, task.strTaskName);

    task.strTaskSavePath = createTaskSavePath(task.strTaskName);
    task.nTaskID = TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}

std::string TaskController::createTaskSavePath(const std::string &taskName)
{
    auto strDateTime = _Kits::datetime::current_string("%Y%m%d");
    std::string strTaskSavePath = fmt::format("{}tasks/{}/{}", m_savePath, strDateTime, taskName);
    std::filesystem::path savePath = std::filesystem::u8path(strTaskSavePath.c_str());

    if (!std::filesystem::exists(savePath))
    {
        if (std::filesystem::create_directories(savePath))
        {
            LogDebug("[任务开始]: 任务保存路径创建成功, {}", strTaskSavePath);
        }
        else
        {
            LogDebug("[任务开始]: 任务保存路径创建失败, {}", strTaskSavePath);
        }
    }

    return strTaskSavePath;
}
} // namespace _Controllers
