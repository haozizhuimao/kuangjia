
set(CTL_NAME "ningbo8_low")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
    $<TARGET_OBJECTS:kit_orm_user>
    $<TARGET_OBJECTS:kit_algorithm_detect_tcp>
    $<TARGET_OBJECTS:kit_video_painter>
    $<TARGET_OBJECTS:kit_video_manage>
    $<TARGET_OBJECTS:kit_subtitle_general>
    $<TARGET_OBJECTS:kit_encode_video_operate>
)       

target_include_directories(${CTL_NAME} PRIVATE 
)       

find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

# 添加OpenCV库依赖
find_package(OpenCV REQUIRED COMPONENTS core imgproc highgui)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
)

target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_orm_user
kit_algorithm_detect_tcp
kit_video_painter
kit_video_manage
kit_subtitle_general
kit_encode_video_operate
)

if(LINUX)
target_link_libraries(${CTL_NAME} PRIVATE
)
else()
# 暂时没有windows版本
endif()


target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CTL_NAME}>
)     
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

set(RES_QML
    res/qml/engineering_vehicle_qml/mvb_page/mvb_page.qml
    res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
    res/qml/public_controls/YunTai.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/public_controls/Magnifier.qml
    res/qml/engineering_vehicle_qml/rfid_page/rfid_page.qml
    res/qml/public_controls/HighFrequencyChart.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
