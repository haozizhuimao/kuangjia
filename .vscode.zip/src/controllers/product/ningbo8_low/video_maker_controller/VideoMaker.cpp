#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include <QPainter>
#include <QDir>
#include <codecvt>
#include "kits/utility/log/CRossLogger.h"
#include <codecvt>
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/enum_public/video_enum.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/camera/tools/RemoteParser.h"
#include "tis_global/Struct.h"
#include "kits/common/database/CppBatis.h"
#include "kits/product_kits/algorithm_detect_tcp/algorithmDetetTcp.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/qtcommon/jsontomap/QmlJsonToMap.h"
#include "kits/product_kits/algorithm_detect_tcp/algorithmDetetTcp.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/qtcommon/jsontomap/QmlJsonToMap.h"
#include "WritePGDefectSql.h"

namespace _Controllers {
using namespace _Service;
using namespace _Kits;

VideoMaker::VideoMaker() : m_bSaveVideo(true), m_carbonStripWearSent(false)
{
    m_algorithmResultParser = std::make_unique<_Kits::AlgorithmResultParser>();
    m_locationCtrl = std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); });
    m_subtitleobject = std::make_unique<_Kits::SubtitleGeneral>();
    m_subtitleobject->setSendSubtitleCallback([this](const std::vector<std::string> &subtitle) { updateSubTitle(subtitle); });
    m_subtitleobject->setFixMode(true);//设置固定四行字幕
    m_qstr_SavePath = "d:/gwkj/video_Notask";
}
VideoMaker::~VideoMaker()
{
    onStopVideoMaker();
}
void VideoMaker::onStopVideoMaker()
{
    for (auto &[name, cam] : (m_cameraObjects))
        for (auto &[name, cam] : (m_cameraObjects))
        {
            cam->closeCamera();
        }

    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    m_bSaveVideo.store(false);

    onStopRecord();

    m_locationCtrl->stop();
    m_locationCtrl->stop();
}
bool VideoMaker::createDirectory(const QString &dirPath)
{
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            _Kits::LogError("Failed to create directory: {}", dirPath.toStdString());
            return false;
        }
    }
    return true;
}
void _Controllers::VideoMaker::onStartRecord(QString fileName)
{
    for (auto &[name, manageobject] : m_videoManageMap)
    {
        auto filePath = fileName + ".mp4";
        manageobject->updataVideoName(filePath.toUtf8().toStdString());
    }
    senderHikManagersendRecordState(true);
}
void _Controllers::VideoMaker::onStopRecord()
{
    for (auto &[name, manageobject] : m_videoManageMap)
    {
        if (nullptr != manageobject)
        {
            manageobject->updataVideoName("");
        }
    }
}
std::filesystem::path _Controllers::VideoMaker::getSaveName(const std::string &fileName, const std::string &middleName)
{

    std::string timeStr = _Kits::datetime::current_string("%Y_%m_%d_%H_%M_%S.%3f");
    std::string picName = fileName + "_" + timeStr + ".jpg";

    auto task_path = m_taskInfo.strTaskSavePath;
    std::filesystem::path root = std::filesystem::u8path(task_path);
    root /= std::filesystem::u8path(fileName).filename();

    // 自动创建文件夹
    std::error_code ec;
    std::filesystem::create_directories(root, ec);

    std::filesystem::path fullPath = root / std::filesystem::u8path(picName).filename();

    return fullPath;
}

void VideoMaker::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &tcpClient)
{
    // 保存到临时存储，无论m_pAlgorithmManager是否已初始化
    for (const auto &[name, client] : tcpClient)
    {
        m_mpTcpClient[name] = client;
    }
}
void VideoMaker::SetExposureTimeAndGain(QVariant data)
{
    auto dataMap = QmlJsonToMap::convertDataToJsonOrMap(data);
    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD exposureTime = static_cast<DWORD>(dataMap.value("exposure").toUInt());
    BYTE gainValue = static_cast<BYTE>(dataMap.value("gain").toUInt());
    QString type = dataMap.value("type").toString();

    if (type == "setExposureAndGain")
    {
        auto it = m_cameraObjects.find(cameraName);
        if (it != m_cameraObjects.end())
        {
            it->second->onSetExposureTimeAndGain(exposureTime, gainValue);
        }
    }
}
void VideoMaker::PTZControl(QVariant data)
{
    auto dataMap = QmlJsonToMap::convertDataToJsonOrMap(data);
    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    QString dir = dataMap.value("dir").toString();
    QString command = dataMap.value("command").toString();
    QString type = dataMap.value("type").toString();
    if (type == "PTZControl")
    {
        auto it = m_cameraObjects.find(cameraName);
        if (it != m_cameraObjects.end())
        {
            it->second->onPTZControl(dir.toStdString(), command.toStdString());
        }
    }
}
void VideoMaker::SetPTZSpeed(QVariant data)
{
    auto dataMap = QmlJsonToMap::convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD speed = static_cast<DWORD>(dataMap.value("speed").toUInt());
    QString type = dataMap.value("type").toString();
    if (type == "SetPTZSpeed")
    {
        auto it = m_cameraObjects.find(cameraName);
        if (it != m_cameraObjects.end())
        {
            it->second->onSetPTZSpeed(speed);
        }
    }
}
void VideoMaker::onJiheInfo(std::shared_ptr<TIS_Info::JiHeData> data)
{
    if (nullptr != m_subtitleobject)
    {
        m_subtitleobject->updateJiHeData(*data);
    }
}
void VideoMaker::onPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    if (nullptr != m_subtitleobject)
    {
        m_subtitleobject->updatePressAndSpot(data);
    }
}
void VideoMaker::onVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    if (nullptr != m_subtitleobject)
    {
        m_subtitleobject->updateVoltageAndElectric(data);
    }
}
void VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    if (nullptr != m_subtitleobject)
    {
        m_subtitleobject->updateLocationData(location_data);
    }
    m_locationCtrl->updateLocation(QString::fromStdString(location_data.station_name));
}
void VideoMaker::onInitHikCtrl(std::string firstPath)
{
    m_firstPath = firstPath;
}

void VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    handleTaskBegin(task_info);
}
void VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    handleTaskEnd(task_info);
}
void VideoMaker::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskBegin: Task start");
    std::lock_guard<std::mutex> lock(m_mutex);
    m_taskInfo = task_info;
    m_locationCtrl->updateLocation("");
    // 更新保存路径
    if (!task_info.strTaskSavePath.empty())
    {
        for (auto &[name, manageobject] : m_videoManageMap)
        {
            auto dirPath = QString::fromStdString(task_info.strTaskSavePath) + "/" + QString::fromStdString(name);
            senderHikManagersendSavePathOut(QString::fromStdString(name), dirPath);
            manageobject->setVideoSaveRootPath(m_taskInfo.strTaskSavePath);
            // manageobject->updataVideoName(fileName.toUtf8().toStdString());
        }
        m_qstr_SavePath = QString::fromStdString(task_info.strTaskSavePath);
        createDirectory(m_qstr_SavePath);
    }
}
void VideoMaker::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskEnd: Task end");

    std::lock_guard<std::mutex> lock(m_mutex);
    m_taskInfo = task_info;

    // 停止所有录像
    onStopRecord();
    senderHikManagersendRecordState(false);
}
void VideoMaker::onInitSaveVideo(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> &cameraMap)
{
    m_cameraObjects = cameraMap;
    // TIS_Info::EncoderInfo encoderinfo;
    // encoderinfo.width = 2560;
    // encoderinfo.height = 1440;
    // TIS_Info::SubtitleInputInfo subtitleinfo;
    for (auto &it : cameraMap)
    {
        std::string cameraName = it.first;
        createVideoManage(cameraName);
        auto videomangeit = m_videoManageMap.find(cameraName);
        if (videomangeit == m_videoManageMap.end())
        {
            continue;
        }
        auto manageptr = videomangeit->second;
        // manageptr->init(encoderinfo, subtitleinfo);
        it.second->setSendImageCallback([this, manageptr, cameraName](std::shared_ptr<TIS_Info::ImageBuffer> img) {
            if (nullptr == img)
            {
                return;
            }
            if (nullptr != manageptr)
            {
                manageptr->pushImage(img);
            }
            if (nullptr != m_videoPainterMap[cameraName])
            {
                m_videoPainterMap[cameraName]->pushImage(img);
            }
        });
    }
    initAlogrithm();
}
void VideoMaker::onInitAlgorithm(const std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>> &algorithmInfo)
{
    m_mapvAlgorithmInfo = algorithmInfo;
}

void VideoMaker::recvMVBInfo(const TIS_Info::MVBCommunicationInfo & info)
{
    m_mvbInfo = info;
}
void VideoMaker::initAlogrithm()
{
    for (auto &info : m_mapvAlgorithmInfo)
    {
        std::string cameraName = info.first;
        // createVideoManage(cameraName);
        auto videomangeit = m_videoManageMap.find(cameraName);
        if (m_videoManageMap.end() != videomangeit)
        {
            m_udm_algorithmManager[cameraName] = std::make_unique<_Kits::algorithmManager>();

            m_udm_algorithmManager[cameraName]->setAlgorithmMap(info.second);

            m_udm_algorithmManager[cameraName]->setTcpClient(m_mpTcpClient);
            auto ret = m_udm_algorithmManager[cameraName]->startAlogorithm();
            videomangeit->second->setAlgorithPushCallback(
                [this, cameraName](std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer) { initAlogrithmCallback(cameraName, imagebuffer); });
        }
        initAlogrithmResultCallback(cameraName);
    }
}
void VideoMaker::pantoGraphDetectResult(const std::string &cameraName, std::vector<uint8_t> &&result)
{
    uint16_t serialNum = 0;
    auto pgInfo = m_algorithmResultParser->parsePantograph(std::move(result), serialNum);
    auto defectInfoJson = m_algorithmResultParser->parseJson(std::move(result), serialNum); // 受电弓异常识别结果，用于绘图保存
    if (nullptr != m_videoPainterMap[cameraName])
    {
        m_videoPainterMap[cameraName]->updateDefectResult(pgInfo, defectInfoJson.toStyledString());
    }
}
void VideoMaker::initAlogrithmResultCallback(const std::string &cameraName)
{
    auto algorithmit = m_udm_algorithmManager.find(cameraName);
    if (algorithmit == m_udm_algorithmManager.end())
    {
        return;
    }
    algorithmit->second->setAlgorithmCallback([this, cameraName](const std::string &algorithmName, std::vector<uint8_t> &&result) {
        std::lock_guard<std::mutex> lock(m_mutex_pantoGraph);
        if (algorithmName == "pantoGraphDetect")
        {
            pantoGraphDetectResult(cameraName, std::move(result));
        }
    });
}
void VideoMaker::initAlogrithmCallback(const std::string &cameraName, std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    auto it = m_mapvAlgorithmInfo.find(cameraName);
    if (it != m_mapvAlgorithmInfo.end())
    {
        for (const auto &algorithm_info : it->second)
        {
            const std::string &algorithm_name = algorithm_info.m_str_algorithm_name;
            auto mgrIt = m_udm_algorithmManager.find(cameraName);
            if (mgrIt != m_udm_algorithmManager.end() && m_mvbInfo.dSpeed != 0)
            {
                mgrIt->second->algorithmDetectQueue(algorithm_name, img);
            }
        }
    }
}
void VideoMaker::createVideoManage(const std::string &name)
{
    std::lock_guard<std::mutex> lock(m_createMutex);
    auto videoManageObject = m_videoManageMap.find(name);
    if (videoManageObject == m_videoManageMap.end())
    {
        m_videoManageMap.insert(std::make_pair(name, std::make_shared<VideoManage>(name)));
        m_videoManageMap[name]->start();
    }
    auto videoPainterobject = m_videoPainterMap.find(name);
    if (videoPainterobject == m_videoPainterMap.end())
    {
        m_videoPainterMap.insert(std::make_pair(name, std::make_shared<VideoPainter>(name)));
        m_videoPainterMap[name]->start();
        m_videoPainterMap[name]->setSendToUICallback([this](std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer,
                                                            const std::vector<TIS_Info::pantograph_info> &pantoGraphInfo,
                                                            const std::string &jsonVaue) {
            if (!jsonVaue.empty())
            {
                thread_pool::runTask([this, imagebuffer, pantoGraphInfo, jsonVaue]() {
                    handlePantoGraphDetectResult(imagebuffer, pantoGraphInfo, jsonVaue);
                });
            }
            try
            {
                senderHikManagersendImageToQml(imagebuffer);
            }
            catch (const std::exception &e)
            {
                // std::cerr << e.what() << '\n';
            }
        });
    }
}
void VideoMaker::updateSubTitle(const std::vector<std::string> &subTitles)
{
    if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE)
    {
        return;
    }
    for (const auto &name_cam : m_cameraObjects)
    {
        name_cam.second->onWriteSubTitle(subTitles);
    }
}
void VideoMaker::handlePantoGraphDetectResult(std::shared_ptr<TIS_Info::ImageBuffer> imagebuffer,
                                              const std::vector<TIS_Info::pantograph_info> &pantoGraphInfo,
                                              const std::string &jsonvalue)
{
    if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE)
    {
        return;
    }
    if (m_taskInfo.strTaskSavePath.empty())
    {
        _Kits::LogInfo("m_taskInfo.strTaskSavePath为空，保存图片失败");
        return;
    }
    // 创建保存目录
    createDirectory(m_qstr_SavePath + "/受电弓异常");

    // 生成唯一的文件名（使用时间戳）
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
    QString savePath = m_qstr_SavePath + "/受电弓异常/受电弓异常" + timestamp + ".jpg";
    if (!imagebuffer || imagebuffer->data.empty() || imagebuffer->width == 0 || imagebuffer->height == 0)
    {
        return;
    }

    // 将ImageBuffer转换为QImage
    QImage qImg(imagebuffer->data.data(), imagebuffer->width, imagebuffer->height, QImage::Format_RGB888);
    qImg = qImg.rgbSwapped();
    if (!qImg.save(savePath))
    {
        qWarning() << "Failed to save image: " << savePath;
    }
    else
    {
        _Kits::LogInfo("保存图片成功：{}", savePath.toStdString());
        WritePGDefectSql::insertPantoGraphData(pantoGraphInfo, savePath.toStdString(), jsonvalue, m_taskInfo.nTaskID);
    }
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = std::make_shared<TIS_Info::ImageBuffer>(w, h, 3);
    if (nullptr == img_rgb)
    {
        return nullptr;
    }

    cv::Mat yuv_mat(h * 3 / 2, w, CV_8UC1, img_yuv420p->data.data());
    cv::Mat rgb_mat(h, w, CV_8UC3, img_rgb->data.data());
    cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}
} // namespace _Controllers
