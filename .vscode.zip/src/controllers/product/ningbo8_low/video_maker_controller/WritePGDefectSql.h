#pragma once

#include "tis_global/Struct.h"
#include <string>
#include "kits/common/database/CppBatis.h"
namespace _Kits
{

    class WritePGDefectSql
    {
      public:
        static int insertPantoGraphData(const std::vector<TIS_Info::pantograph_info>& pgInfo,
                                        const std::string &savePath, const Json::Value &jsonData,const int taskID);
      private:
        static bool writePGDefectDataToDatabase(const _Kits::_Orm::pantograph_defect_data &PGDefectData);
        static _Kits::_Orm::pantograph_defect_data initPantoGraphData(const std::vector<TIS_Info::pantograph_info>& pgInfo,
                                        const std::string &savePath, const Json::Value &jsonData,const int taskID);
    };

} // namespace _Kits