#include "QmlSpeedController.h"
#include "kits/utility/log/CRossLogger.h"
#include <qvariant.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlSpeedController::sendMvbSpeedToPage(const TIS_Info::MVBCommunicationInfo &data)
{
    QVariantMap dataMap;
    dataMap["speed"] = data.dSpeed;
    // 发送所有数据到QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::speed_data_send, QVariant::fromValue(dataMap));
}

} // namespace _Controllers
