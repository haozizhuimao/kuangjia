#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <mutex>
namespace _Controllers {
class QmlSpeedController : public ControllerBase<QmlSpeedController>
{
  public:
    void sendMvbSpeedToPage(const TIS_Info::MVBCommunicationInfo &); // 接收mvb速度
    void sendSimulateSpeedToPage(double);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::MVBCommunication::sendMVBComInfo, QmlSpeedController::sendMvbSpeedToPage);
    TASK_LIST_END
};
} // namespace _Controllers