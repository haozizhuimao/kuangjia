#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <memory>
#include "kits/common/location_general/LocationBase.h"
//#include "tis_global/Function.h"
namespace _Controllers {
class LocationController : public ControllerBase<LocationController>
{
  public:
    void initConfig(TIS_Info::LocationConfigs, std::shared_ptr<_Kits::LocationBase>);
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::LocationService::moduleStarted, LocationController::initConfig);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::MVBCommunication::sendMVBComInfo, LocationController::recvMVBInfo);
    TASK_LIST_END
  private:
    TIS_Info::TaskInfo m_curTaskInfo;
    std::weak_ptr<_Kits::LocationBase> m_kitLocation;
};

} // namespace _Controllers
