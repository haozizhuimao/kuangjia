#include "LocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/common/location_general/LocationGeneral.h"
#include "kits/common/location_general/LocationMVB.h"
#include "tis_global/enum_public/location_enum.h"
#include <chrono>
#include <QJsonDocument>
#include <cstdint>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void LocationController::initConfig(TIS_Info::LocationConfigs, std::shared_ptr<_Kits::LocationBase> base)
{
    m_kitLocation = base;
}

void LocationController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_curTaskInfo = task;

    if (task.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto data = locationTools->startTask(task);
        if (!data.pole_name.empty())
        {
            _Service::senderLocationServiceLocationRadio(data);
            LogInfo("[定位开始] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
        }
    }
    else if (task.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        locationTools->stopTask();
        LogInfo("[定位结束] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
    }
}
void LocationController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto locationPtr = static_cast<LocationMVB *>(locationTools.get());

        auto locationData = locationPtr->speedMVBUpdate(datetime::current_timestamp(datetime::TimestampUnit::Milliseconds), data.dSpeed);

        if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
        {
            _Service::senderLocationServiceLocationRadio(locationData);
        }
        else
        {

            static auto last_mm = locationData.mileage_normal;
            auto interval = locationData.mileage_normal - last_mm;
            constexpr double MAX_DISTANCE = 500; // 默认 500mm
            if (interval > MAX_DISTANCE)
            {
                _Service::senderLocationServiceLocationRadio(locationData);
                last_mm = locationData.mileage_normal;
            }
        }
    }
}

} // namespace _Controllers