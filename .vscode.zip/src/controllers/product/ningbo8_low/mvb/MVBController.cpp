﻿#include "MVBController.h"
#include "kits/utility/system_config/SystemConfig.h"
#include "kits/third_devices/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "kits/product_kits/orm_user/MvbInfoSql.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <qobject.h>
#include <time.h>

#ifdef Q_OS_UNIX
#include <sys/time.h>
#include <errno.h>
#include <QProcess>
#include "kits/utility/system_config/SystemConfig.h"
#endif

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_heartData.resize(m_headLength + 32, 0);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
    m_mvbInfoWirteSqlThread = std::thread(&MVBController::writeMvbInfoToDBFun, this);
    m_writeDBFlag.store(true);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
    m_condition.notify_one();
    if (m_mvbInfoWirteSqlThread.joinable())
    {
        m_mvbInfoWirteSqlThread.join();
    }
}

void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    // mvb 心跳数据发送
    auto finder = clients.find(m_mvbHeartName);
    if (finder == clients.end())
    {
        LogError("can not find udp client.name = {}", m_mvbHeartName);
        return;
    }
    auto mvbudpHeartClient = finder->second;
    m_udpClient = mvbudpHeartClient;
    // mvb tcms数据接收
    finder = clients.find(m_udpName);
    if (finder == clients.end())
    {
        LogError("can not find udp client.name = {}", m_udpName);
        return;
    }
    auto udpClient = finder->second;
    udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } onUdpDataReceived(std::vector<uint8_t>(datas->begin(), datas->end())); });
    // mvb 告警数据接收
    auto alarmUdp = clients.find(m_mvbAmifName);
    if (alarmUdp == clients.end())
    {
        LogError("can not find udp client.name = {}", m_mvbAmifName);
        return;
    }
    alarmUdp->second->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } onUdpAlarmReceived(std::vector<uint8_t>(datas->begin(), datas->end())); });
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 列车车次号
    outputData["lineNum"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);

    // A1车司机室激活
    uint8_t lineData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    std::bitset<8> bit(lineData);
    outputData["a1Active"] = static_cast<bool>(bit[7]);
    // A2车司机室激活
    outputData["a2Active"] = static_cast<bool>(bit[6]);
    // 列车前向状态
    outputData["forward"] = static_cast<bool>(bit[5]);
    // 列车后向状态
    outputData["backward"] = static_cast<bool>(bit[4]);
    // 列车牵引工况
    outputData["carPull"] = static_cast<bool>(bit[2]);
    // 列车制动工况
    outputData["carBrake"] = static_cast<bool>(bit[1]);
    // 列车惰行工况
    outputData["carCoasting"] = static_cast<bool>(bit[0]);

    uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    std::bitset<8> bit1(modeData);
    // B1车降弓到位
    outputData["b1Lowerbow"] = static_cast<bool>(bit[6]);
    // B2车降弓到位
    outputData["b2Lowerbow"] = static_cast<bool>(bit[5]);
    // 列车休眠指令
    outputData["carDormancy"] = static_cast<bool>(bit[4]);
    // ATB模式
    outputData["ATBMode"] = static_cast<bool>(bit[3]);
    // ATO模式
    outputData["ATOMode"] = static_cast<bool>(bit[2]);
    // 时间设置标志位
    outputData["timeSet"] = static_cast<bool>(bit[1]);
    // 时间有效标志位
    outputData["timeValid"] = static_cast<bool>(bit[0]);

    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 8);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 10);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 11);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 12);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 13);

    // 列车参考速度
    outputData["speed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
    // 全列车牵引力
    outputData["allTraction"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
    // 全列车空气制动力
    outputData["allAirForce"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
    // 全列车电制动力
    outputData["allElectricForce"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
    // 1车载荷
    outputData["a1Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
    // 2车载荷
    outputData["a2Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
    // 3车载荷
    outputData["a3Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 26);
    // 4车载荷
    outputData["a4Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 28);
    // 5车载荷
    outputData["a5Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 30);
    // 6车载荷
    outputData["a6Load"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 32);
    // 全列车载荷
    outputData["allLoad"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 34);
    // 1车乘车率
    outputData["a1RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 36);
    // 2车乘车率
    outputData["a2RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 37);
    // 3车乘车率
    outputData["a3RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 38);
    // 4车乘车率
    outputData["a4RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 39);
    // 5车乘车率
    outputData["a5RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 40);
    // 6车乘车率
    outputData["a6RidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 41);
    // 整车乘车率
    outputData["allRidingRate"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 42);
    // Tc1车 Block ID
    outputData["tc1BlockID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 43);
    // Tc2车 Block ID
    outputData["tc2BlockID"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 45);
    // Tc1车 abcsissa
    outputData["tc1Abcsissa"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 47);
    // Tc2车 abcsissa
    outputData["tc2Abcsissa"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 49);
    // 蓄电池电压
    outputData["batteryVoltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 51);
    // 网压
    outputData["voltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 53);
    // 网流
    outputData["electricity"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 55);

    // 1车参考轴轮径
    outputData["wd1"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 57);
    // 2车参考轴轮径
    outputData["wd2"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 59);
    // 3车参考轴轮径
    outputData["wd3"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 61);
    // 4车参考轴轮径
    outputData["wd4"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 63);
    // 5车参考轴轮径
    outputData["wd5"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 65);
    // 6车参考轴轮径
    outputData["wd6"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 67);

    std::bitset<8> wdData(ByteArrayTools::readFromVectorBE<uint8_t>(data, 69));
    // 1车轮径设置有效
    outputData["wd1Vaild"] = static_cast<bool>(wdData[7]);
    // 2车轮径设置有效
    outputData["wd2Vaild"] = static_cast<bool>(wdData[6]);
    // 3车轮径设置有效
    outputData["wd3Vaild"] = static_cast<bool>(wdData[5]);
    // 4车轮径设置有效
    outputData["wd4Vaild"] = static_cast<bool>(wdData[4]);
    // 5车轮径设置有效
    outputData["wd5Vaild"] = static_cast<bool>(wdData[3]);
    // 6车轮径设置有效
    outputData["wd6Vaild"] = static_cast<bool>(wdData[2]);

    // 站点信息反馈-起始站
    outputData["startStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 72);
    // 站点信息反馈-当前站
    outputData["currentStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 74);
    // 站点信息反馈-下一站
    outputData["nextStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 76);
    // 站点信息反馈-终点站
    outputData["endStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 78);
    // 列车总行驶里程
    outputData["accumulatedKM"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 82);
}

void MVBController::displayRecvPortData(QVariantMap &portData)
{
    // 给页面传递数据展示
    QVariantMap mapData;

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt;

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(portData));
}

void MVBController::onUdpAlarmReceived(const std::vector<uint8_t> &&data)
{
    auto alarmData = std::move(data);
    std::string jsonStr(reinterpret_cast<const char *>(alarmData.data()), alarmData.size());
    Json::Value jsonValue = stringToJson(jsonStr);
    if (jsonValue["msgType"].asString() == "amif")
    {
        parseAmifData(jsonValue["data"]);
    }
    LogInfo("recv alarm data = {}", jsonStr);
}

void MVBController::setConfigSwitch(const TIS_Info::MvbAmifSwitch &amif,
                                    const TIS_Info::MvbAsatSwitch &asat,
                                    const TIS_Info::TrdpConfig &trdpConfig,
                                    const TIS_Info::MvbPublic &mvbConf)
{
    m_amifSwitch = amif;
    m_trdpConfig = trdpConfig;
    m_MvbConf = mvbConf.version;
    m_sysPsw = mvbConf.sysPsw;
    m_mvbPublic = mvbConf;
}

void MVBController::parseAmifData(const Json::Value &jsonObj)
{
    TIS_Info::AmifAlarmType amifType = static_cast<TIS_Info::AmifAlarmType>(jsonObj["alarmType"].asInt());
    TIS_Info::AmifAlarmLevel amifLevel = static_cast<TIS_Info::AmifAlarmLevel>(jsonObj["alarmLevel"].asInt());
    int alarmValue = jsonObj["alarmValue"].asInt();
    // int targetOffset = amifLevel - 1; // 目标位偏移

    switch (amifType)
    {
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanAttitude: {
        // 受电弓姿态
        if (!m_amifSwitch.panAttitude)
        {
            break;
        }
        setAmifAlarm(m_headLength + 2, 0, 0, 0, 1);
        break;
    }
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanYangJiao: {
        // 羊角缺少
        if (!m_amifSwitch.panYangJiao)
        {
            break;
        }
        setAmifAlarm(m_headLength + 2, 4, 4, 4, 1);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    std::bitset<8> amifBit = m_heartData.at(offset);
    // 该类型超限所有的状态复位
    for (int i = startBit; i <= endBit; i++)
    {
        amifBit.set(i, 0);
    }
    // 设置目标位超限值
    amifBit.set(targetBit, alarmValue);
    m_heartData.at(offset) = static_cast<uint8_t>(amifBit.to_ulong());
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        LogError("recv data error, len ={}", data.size());
        return;
    }
    TIS_Info::TrdpHeader header;
    parseTrdpHeader(data, header);
    LogInfo("recv udp all data,header.headerFcs={}, comId={},size={},data={}",
            header.headerFcs,
            header.comId,
            data.size(),
            ByteArrayTools::hexString(data.data(), data.size()));

    QVariantMap dataMap;
    std::vector<uint8_t> processData(data.begin() + m_headLength, data.end());
    if (header.comId == m_trdpConfig.commonComID)
    {
        parseCommonData(processData, dataMap);
        adjustSysTime(dataMap);
        sendTcmsData(dataMap);
        dataMap["dataSource"] = "ningbo8_common_data";
        LogInfo("recv udp ningbo8_common_data,header.headerFcs={}, comId={},data={}",
                header.headerFcs,
                header.comId,
                ByteArrayTools::hexString(data.data(), data.size()));
    }
    else if (header.comId == m_trdpConfig.tcmsComID)
    {
        parseCCUData(processData, dataMap);
        dataMap["dataSource"] = "ningbo8_ccu_data";
        LogInfo("recv udp ningbo8_ccu_data,header.headerFcs={}, comId={},data={}",
                header.headerFcs,
                header.comId,
                ByteArrayTools::hexString(data.data(), data.size()));
    }
    displayRecvPortData(dataMap);
}

    void MVBController::sendTcmsData(const QVariantMap &recvData)
    {
        int curStartStation = recvData["startStation"].toInt();
        int curEndStation = recvData["endStation"].toInt();
        // 行别切换
        TIS_Info::MVBCommunicationInfo mvbCommInfo;
        mvbCommInfo.startStation = curStartStation;
        mvbCommInfo.endStation = curEndStation;
        mvbCommInfo.currentStationId = recvData["currentStation"].toInt();
        mvbCommInfo.strLineName = m_mvbPublic.lineName;
        mvbCommInfo.dSpeed = recvData["speed"].toDouble() / 100;
        if (m_startStation != curStartStation && m_endStation != curEndStation && curStartStation != 0 && curEndStation != 0)
        {
            m_lineDir = curStartStation < curEndStation ? 0 : 1;
            m_startStation = curStartStation;
            m_endStation = curEndStation;
            LogInfo("行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
                    m_lineDir,
                    m_startStation,
                    m_endStation,
                    mvbCommInfo.currentStationId,
                    mvbCommInfo.dSpeed);
        }
        mvbCommInfo.nLineDirection = m_lineDir;
        mvbCommInfo.nDirection = recvData["forward"].toBool() ? 0 : 1;
        senderMVBCommunicationsendMVBComInfo(mvbCommInfo);
    }

void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
{
    if (data.size() < m_headLength)
    {
        return;
    }
    header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
    header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
    header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
    header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
    header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
    header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(1000);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::sendAliveData()
{
    if (auto strongPtr = m_udpClient.lock())
    {
        ++m_aliveId; // 心跳id自增

        TIS_Info::TrdpHeader header;
        header.comId = m_trdpConfig.heartComID; // 4X150
        header.sequenceCounter = m_aliveId;
        header.datasetLength = 32;
        header.protocolVersion = 0x0100;
        header.msgType = 0x5064;
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, m_aliveId, 0);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.protocolVersion, 4);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.msgType, 6);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comId, 8);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.etbTopoCnt, 12);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.opTrnTopoCnt, 16);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.datasetLength, 20);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.reserved01, 24);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyComId, 28);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyIpAddress, 32);

        // 生成校验码
        header.headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, 36);
        LogInfo("sheader.headerFcs={}", header.headerFcs);
        // 协议里面定义的是大端，但是四方是按小端来的
        ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, header.headerFcs, 36);

        // 应用数据
        // TCMS生命信号异常
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_aliveId, m_headLength + 0);
        // 软件版本
        if (m_versionInfo.empty())
        {
            getConfVersion();
        }

        if (m_versionInfo.size() == 2)
        {
            ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, m_versionInfo[0], m_headLength + 30);
            ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, m_versionInfo[1], m_headLength + 31);
        }

            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, 0x18, m_headLength + 30);
            // ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, 0x34, m_headLength + 31);
            auto headvector = m_heartData;
            strongPtr->post("mvb_heart", std::move(headvector));
            std::vector<uint8_t> processData(m_heartData.begin() + m_headLength, m_heartData.end());
            LogInfo("send comID={},size={},data={}",
                    header.comId,
                    processData.size(),
                    ByteArrayTools::hexString(processData.data(), processData.size()));

        displayHeartData();
    }
}

void MVBController::parseCCUData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // tcms生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);

    uint8_t closeStatus = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    std::bitset<8> bit(closeStatus);
    // 所有门关闭状态
    outputData["doorsClosed"] = static_cast<bool>(bit[7]);
    // 占有端左侧门关好
    outputData["leftDoorsClosed"] = static_cast<bool>(bit[6]);
    // 占有端右侧门关好
    outputData["rightDoorsClosed"] = static_cast<bool>(bit[5]);
    // b1车升弓指令
    outputData["b1PanUP"] = static_cast<bool>(bit[4]);
    //  b2车升弓指令
    outputData["b2PanUP"] = static_cast<bool>(bit[3]);
    // b1车升弓到位
    outputData["b1PanUPFit"] = static_cast<bool>(bit[2]);
    // b2车升弓到位
    outputData["b2PanUPFit"] = static_cast<bool>(bit[1]);

    // 列车总行驶里程
    outputData["accumulatedKM"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 3);
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 受电弓
    std::bitset<8> b2Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 2));
    // 受电弓姿态异常告警
    outputData["strAttitudeAlarm"] = static_cast<bool>(b2Bit[0]);
    // 受电弓碳滑板异常告警
    outputData["strCarbonStripAlarm"] = static_cast<bool>(b2Bit[1]);
    // 受电弓弓头异常告警
    outputData["strBowheadAlarm"] = static_cast<bool>(b2Bit[2]);
    // 受电弓羊角异常告警
    outputData["yangjiaoAlarm"] = static_cast<bool>(b2Bit[4]);
    // 受电弓检测到异物告警
    outputData["foreignAlarm"] = static_cast<bool>(b2Bit[5]);
    // 受电弓导流线异常故障
    outputData["diversionLieAlarm"] = static_cast<bool>(b2Bit[7]);

    std::bitset<8> b3Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 3));
    // 燃弧严重告警
    outputData["arcAlaLevel1"] = static_cast<bool>(b3Bit[0]);
    // 燃弧中等告警
    outputData["arcAlaLevel2"] = static_cast<bool>(b3Bit[1]);
    // 燃弧轻微告警
    outputData["arcAlaLevel3"] = static_cast<bool>(b3Bit[2]);
    // 磨耗轻微告警
    outputData["abrAlaLevel3"] = static_cast<bool>(b3Bit[4]);
    // 磨耗中等告警
    outputData["abrAlaLevel2"] = static_cast<bool>(b3Bit[5]);
    // 磨耗严重告警
    outputData["abrAlaLevel1"] = static_cast<bool>(b3Bit[6]);

    std::bitset<8> b4Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 4));
    // 温度轻微告警
    outputData["tmpAlaLevel3"] = static_cast<bool>(b4Bit[0]);
    // 温度中等告警
    outputData["tmpAlaLevel2"] = static_cast<bool>(b4Bit[1]);
    // 温度严重告警
    outputData["tmpAlaLevel1"] = static_cast<bool>(b4Bit[2]);

    std::bitset<8> b5Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 5));
    // 接触网硬点轻微告警
    outputData["hardPotAlaLevel3"] = static_cast<bool>(b5Bit[0]);
    // 接触网硬点中等告警
    outputData["hardPotAlaLevel2"] = static_cast<bool>(b5Bit[1]);
    // 接触网硬点严重告警
    outputData["hardPotAlaLevel1"] = static_cast<bool>(b5Bit[2]);
    // 弓网接触力轻微告警
    outputData["contactForcAlaLevel3"] = static_cast<bool>(b5Bit[4]);
    // 弓网接触力中等告警
    outputData["contactForcAlaLevel2"] = static_cast<bool>(b5Bit[5]);
    // 弓网接触力严重告警
    outputData["contactForcAlaLevel1"] = static_cast<bool>(b5Bit[6]);

    std::bitset<8> b6Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 6));
    // 拉出值超限轻微告警
    outputData["zigzagAlaLevel3"] = static_cast<bool>(b6Bit[0]);
    // 拉出值超限中等告警
    outputData["zigzagAlaLevel2"] = static_cast<bool>(b6Bit[1]);
    // 拉出值超限严重告警
    outputData["zigzagAlaLevel1"] = static_cast<bool>(b6Bit[2]);
    // 回流轨水平间距轻微告警
    outputData["hspaceAlaLevel3"] = static_cast<bool>(b6Bit[4]);
    // 回流轨水平间距中等告警
    outputData["hspaceAlaLevel2"] = static_cast<bool>(b6Bit[5]);
    // 回流轨水平间距严重告警
    outputData["hspaceAlaLevel1"] = static_cast<bool>(b6Bit[6]);

    std::bitset<8> b7Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 7));
    // 导高值超限轻微告警
    outputData["wireHeiAlaLevel3"] = static_cast<bool>(b7Bit[0]);
    // 导高值超限中等告警
    outputData["wireHeiAlaLevel2"] = static_cast<bool>(b7Bit[1]);
    // 导高值超限严重告警
    outputData["wireHeiAlaLevel1"] = static_cast<bool>(b7Bit[2]);
    // 回流轨垂直高度轻微告警
    outputData["retRailSpaceAlaLevel3"] = static_cast<bool>(b7Bit[4]);
    // 回流轨垂直高度中等告警
    outputData["retRailSpaceAlaLevel2"] = static_cast<bool>(b7Bit[5]);
    // 回流轨垂直高度严重告警
    outputData["retRailSpaceAlaLevel1"] = static_cast<bool>(b7Bit[6]);

    std::bitset<8> b8Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 8));
    // 回流轨硬点轻微告警
    outputData["retRailHardPotAlaLevel3"] = static_cast<bool>(b8Bit[0]);
    // 回流轨硬点中等告警
    outputData["retRailHardPotAlaLevel2"] = static_cast<bool>(b8Bit[1]);
    // 回流轨硬点严重告警
    outputData["retRailHardPotAlaLevel1"] = static_cast<bool>(b8Bit[2]);

    std::bitset<8> b10Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 10));
    // 温度检测模块故障
    outputData["tmpModFault"] = static_cast<bool>(b10Bit[0]);
    // 弓网视频模块故障
    outputData["videoFault"] = static_cast<bool>(b10Bit[1]);
    // 燃弧模块故障
    outputData["arcModFault"] = static_cast<bool>(b10Bit[2]);
    // 硬点模块故障
    outputData["hardPotModFault"] = static_cast<bool>(b10Bit[3]);
    // 压力模块故障
    outputData["pressureModFault"] = static_cast<bool>(b10Bit[4]);
    // 接触网几何、磨耗检测模块故障
    outputData["geoAbrModFault"] = static_cast<bool>(b10Bit[5]);
    // 巡检录像模块故障
    outputData["insVideoModFault"] = static_cast<bool>(b10Bit[6]);
    // 巡检抓拍模块故障
    outputData["insSnapModFault"] = static_cast<bool>(b10Bit[7]);

    std::bitset<8> b11Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 11));
    // 硬盘故障
    outputData["nvrDskFault"] = static_cast<bool>(b11Bit[0]);
    // 接触网巡检拍照模块故障
    outputData["xunjianPhotoModFault"] = static_cast<bool>(b11Bit[1]);
    // 回流轨几何参数检测模块故障
    outputData["retRailGeoModFault"] = static_cast<bool>(b11Bit[2]);
    // 回流轨视频模块故障
    outputData["retRailCameraFault"] = static_cast<bool>(b11Bit[3]);
    // 回流轨硬点检测模块故障
    outputData["retRailHardPotModFault"] = static_cast<bool>(b11Bit[4]);
    // MP1车压力硬点采集主机
    outputData["mp1HardPotHost"] = static_cast<bool>(b11Bit[7]);

    std::bitset<8> b12Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 12));
    // MP1车温度检测模块状态
    outputData["mp1TmpModStatus"] = static_cast<bool>(b12Bit[0]);
    // 高清模块状态（远端弓网视频）
    outputData["hdVideoModStatus"] = static_cast<bool>(b12Bit[1]);
    // MP1车燃弧模块状态
    outputData["mp1ArcModStatus"] = static_cast<bool>(b12Bit[2]);
    // MP1车硬点模块状态
    outputData["mp1HardPotModStatus"] = static_cast<bool>(b12Bit[3]);
    // MP1车压力模块状态
    outputData["mp1PressureModStatus"] = static_cast<bool>(b12Bit[4]);
    // MP1车接触网几何、磨耗检测模块
    outputData["mp1GeoAbrModStatus"] = static_cast<bool>(b12Bit[5]);
    // MP1车车底补偿模块状态0
    outputData["mp1UnderbodyModStatus"] = static_cast<bool>(b12Bit[6]);
    // 通信模块故障
    outputData["netModFault"] = static_cast<bool>(b12Bit[7]);

    std::bitset<8> b13Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 13));
    // 硬盘故障(仅宁波6有)
    outputData["dskFault6"] = static_cast<bool>(b13Bit[0]);
    // MP1车接触网巡检拍照模块0
    outputData["mp1InsSnapMod0"] = static_cast<bool>(b13Bit[1]);
    // MP1车回流轨几何参数检测模块0
    outputData["mp1RetRailGeoMod0"] = static_cast<bool>(b13Bit[2]);
    // MP1车回流轨与回流器视频监控模块0
    outputData["mp1RetRailCameraMod0"] = static_cast<bool>(b13Bit[3]);
    // MP1车回流轨硬点模块状态
    outputData["mp1RetRailHardPotMod"] = static_cast<bool>(b13Bit[4]);
    // MP1车接触网巡检拍照模块1
    outputData["mp1XunjianPhotoMod1"] = static_cast<bool>(b13Bit[5]);
    // MP1车接触网巡检触发模块0
    outputData["mp1XunjianTriggerMod0"] = static_cast<bool>(b13Bit[6]);
    // MP1车接触网巡检拍照模块2
    outputData["mp1XunjianPhotoMod2"] = static_cast<bool>(b13Bit[7]);

    std::bitset<8> b14Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 14));
    // Mp1接触网巡检拍照模块3
    outputData["mp1XunjianCamera3Fault"] = static_cast<bool>(b14Bit[0]);
    // Mp1接触网巡检触发模块1
    outputData["mp1XunjianTrigger1Fault"] = static_cast<bool>(b14Bit[1]);
    // Mp1接触网连续视频模块0
    outputData["mp1Video0Fault"] = static_cast<bool>(b14Bit[2]);
    // Mp1接触网连续视频模块1
    outputData["mp1Video1Fault"] = static_cast<bool>(b14Bit[3]);
    // 弓网视频监控1（近端）
    outputData["camera1Fault"] = static_cast<bool>(b14Bit[4]);
    // Mp1车体振动补偿检测模块1
    outputData["mp1Compensation1Fault"] = static_cast<bool>(b14Bit[5]);
    // Mp1回流轨几何参数检测模块1
    outputData["mp1GeoMod1Fault"] = static_cast<bool>(b14Bit[6]);
    // Mp1回流轨与回流器视频监控模块1
    outputData["mp1Camera1Fault"] = static_cast<bool>(b14Bit[7]);

    std::bitset<8> b25Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 25));
    // 响应休眠指令
    outputData["responseSleepCmd"] = static_cast<bool>(b25Bit[3]);
    // 自检结果
    outputData["chkRes"] = static_cast<bool>(b25Bit[4]);
    // 自检完成
    outputData["chkComplete"] = static_cast<bool>(b25Bit[5]);
    // 自检中断
    outputData["chkBreakoff"] = static_cast<bool>(b25Bit[6]);
    // 上电自检中
    outputData["chking"] = static_cast<bool>(b25Bit[7]);
    // 软件版本
    outputData["version"] = QString::number(static_cast<int>(ByteArrayTools::readFromVectorBE<uint8_t>(data, 30))) +
                            QString::number(static_cast<int>(ByteArrayTools::readFromVectorBE<uint8_t>(data, 31)));
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    QVariantMap heartData;
    std::vector<uint8_t> data(m_heartData.begin() + m_headLength, m_heartData.end());
    parseHeartData(data, heartData);

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    heartData["sendTime"] = timeFmt;
    heartData["dataSource"] = "ningbo8_heart";

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(heartData));
}

void MVBController::updateCommonInfo(QVariantMap &data)
{

    m_CurrentMvbInfo.cur_station_id = data.value("currentStation").toInt();
    m_CurrentMvbInfo.next_station_id = data.value("nextStation").toInt();
    m_CurrentMvbInfo.start_station_id = data.value("startStation").toInt();
    m_CurrentMvbInfo.end_station_id = data.value("endStation").toInt();
    m_CurrentMvbInfo.line_id = -1;
    m_CurrentMvbInfo.train_id = data.value("lineNum").toInt();
    m_CurrentMvbInfo.iyear = data.value("year").toInt();
    m_CurrentMvbInfo.imonth = data.value("month").toInt();
    m_CurrentMvbInfo.iday = data.value("day").toInt();
    m_CurrentMvbInfo.ihour = data.value("hour").toInt();
    m_CurrentMvbInfo.iminute = data.value("minute").toInt();
    m_CurrentMvbInfo.isecond = data.value("second").toInt();
    m_CurrentMvbInfo.speed = data.value("speed").toFloat();
    m_CurrentMvbInfo.voltage = data.value("voltage").toFloat();
    m_CurrentMvbInfo.elec = data.value("electricity").toFloat();
    m_CurrentMvbInfo.atb_mode = data.value("ATBMode").toInt();
    if (0 == m_CurrentMvbInfoStatus)
    {
        m_CurrentMvbInfoStatus = 1;
    }
    else if (2 == m_CurrentMvbInfoStatus)
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
        if (m_mvbInfoSqlvec.size() > 1000)
        {
            m_condition.notify_one();
        }
        m_CurrentMvbInfoStatus = 0;
    }
}
void MVBController::updateCCUDataInfo(QVariantMap &data)
{
    m_CurrentMvbInfo.battery_status = -1;
    m_CurrentMvbInfo.door_state = data.value("doorsClosed").toInt();
    m_CurrentMvbInfo.panto_up = data.value("b1PanUPFit").toInt();
    if (0 == m_CurrentMvbInfoStatus)
    {
        m_CurrentMvbInfoStatus = 2;
    }
    else if (1 == m_CurrentMvbInfoStatus)
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_mvbInfoSqlvec.push_back(m_CurrentMvbInfo);
        if (m_mvbInfoSqlvec.size() > 1000)
        {
            m_condition.notify_one();
        }
        m_CurrentMvbInfoStatus = 0;
    }
}

void MVBController::writeMvbInfoToDBFun()
{
    std::vector<_Kits::_Orm::mvb_info> mvbInfoSqlList;
    mvbInfoSqlList.clear();
    while (m_bHolder)
    {
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_condition.wait_for(
                lock, std::chrono::seconds(5), [this]() { return (!m_mvbInfoSqlvec.empty() && m_writeDBFlag) || !m_bHolder; });
            m_mvbInfoSqlvec.swap(mvbInfoSqlList);
            // m_writeDBFlag.store(false);
        }

        _Kits::MvbInfoSql::insertMvbinfoData(mvbInfoSqlList);
        mvbInfoSqlList.clear();
    }
}

void MVBController::getConfVersion()
{
    if (m_MvbConf.empty())
    {
        return;
    }

    // 清缓存
    m_versionInfo.clear();

    // 取全局配置
    std::string appVersion = m_MvbConf;

    appVersion = appVersion.size() <= 3 ? std::string(4 - appVersion.length(), '0') + appVersion : appVersion;

    m_versionInfo.push_back(static_cast<uint8_t>(std::atoi(appVersion.substr(0, 2).c_str())));
    m_versionInfo.push_back(static_cast<uint8_t>(std::atoi(appVersion.substr(2, 2).c_str())));
}

void MVBController::adjustSysTime(const QVariantMap &iData)
{
    if (!(iData["timeSet"].toBool()))
    {
        LogError("time is not valid adjust and setting system canced");
        return;
    }

    int year = static_cast<int>(iData.value("year").toUInt()) + 2000;
    int month = static_cast<int>(iData.value("month").toUInt());
    int day = static_cast<int>(iData.value("day").toUInt());
    int hour = static_cast<int>(iData.value("hour").toUInt());
    int minute = static_cast<int>(iData.value("minute").toUInt());
    int second = static_cast<int>(iData.value("second").toUInt());

    tm remtm{second, minute, hour, day, month - 1, year - 1900, 0, 0, -1};
    time_t rst = mktime(&remtm);

#ifdef _WIN32
    SYSTEMTIME st;
    GetSystemTime(&st);
    tm systm{st.wSecond, st.wMinute, st.wHour, st.wDay, st.wMonth - 1, st.wYear - 1900, 0, 0, -1};
    time_t tst = mktime(&systm);

    if (abs(tst - rst) >= 3)
    {

        SYSTEMTIME mt;
        mt.wYear = year;
        mt.wMonth = month;
        mt.wDay = day;
        mt.wHour = hour;
        mt.wMinute = minute;
        mt.wSecond = second;

        // SetLocalTime(const SYSTEMTIME *lpSystemTime)
        if (!SetLocalTime(&mt))
        {
            LogError("adjust and setting system time failed!");
        }
        else
        {
            LogInfo("setting system time sucessed");
        }
    }
#else

    time_t timestamp = time(nullptr);

    if (abs(timestamp - rst) > 3)
    {

        QString qsSetSystime = QString("%1-%2-%3 %4:%5:%6")
                                   .arg(year, 4, 10, QChar('0'))
                                   .arg(month, 2, 10, QChar('0'))
                                   .arg(day, 2, 10, QChar('0'))
                                   .arg(hour, 2, 10, QChar('0'))
                                   .arg(minute, 2, 10, QChar('0'))
                                   .arg(second, 2, 10, QChar('0'));

        std::string psw = m_sysPsw;
        QString Str = QString::fromStdString(psw);

        QString progr = "/bin/sh";
        QString argecho = QString("echo \'%1\' | /usr/bin/sudo -S /bin/date -s \'%2\'").arg(Str).arg(qsSetSystime);
        QStringList args;
        args << "-c" << argecho;

        // QString qstrDateTime = QString("/bin/sh -c echo \'%1\' | /usr/bin/sudo -S /bin/date -s \'%2\'").arg(Str).arg(qsSetSystime);
        // qDebug()<<qstrDateTime;

        if (QProcess::execute(progr, args) == 0)
        {
            LogInfo("setting system time sucessed");
        }
        else
        {
            LogError("adjust and setting system time failed! reasons: {}", strerror(errno));
        }
    }
#endif
}
} // namespace _Controllers

