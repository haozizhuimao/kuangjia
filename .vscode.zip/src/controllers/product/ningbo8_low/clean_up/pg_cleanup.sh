#!/usr/bin/env bash
# =============================================================================
#  PostgreSQL 数据库自动清理脚本 (修复版)
#  修复：日志输出重定向至 stderr，避免污染函数返回值
# =============================================================================
echo "正在运行的脚本路径: $0"

set -euo pipefail

# ==================== 必填：默认配置文件路径 ====================
readonly DEFAULT_CONFIG_FILE="/home/ita560nx/gwkj/program/clean_up/pg_cleanup.conf"

# ==================== 全局变量声明（默认值） ====================
declare DB_NAME=""
declare DB_USER=""
declare DB_PASSWORD=""
declare DB_HOST="localhost"
declare DB_PORT="5432"
declare DEFAULT_RETENTION_DAYS=30
declare WHITELIST_TABLES=()
declare BLACKLIST_TABLES=()
declare LOGFILE="/home/ita560nx/gwkj/logs/pg_auto_cleanup.log"
declare BATCH_SIZE=5000
declare -A TABLE_RETENTION_MAP
declare PSQL=""
declare LOG_TO_FILE=true
declare LOG_WARNED=false

# ==================== 配置修改 ====================

load_config() {
    log "INFO" "使用硬编码配置（跳过文件读取）"
    
    # 硬编码你的配置
    DB_NAME="integration"
    DB_USER="postgres"
    DB_PASSWORD="~postgres@"
    DB_HOST="localhost"
    DB_PORT="6543"
    DEFAULT_RETENTION_DAYS=12  # 清理 n 天前的
    WHITELIST_TABLES=("test")  # 白名单，不清理
    BLACKLIST_TABLES=("line_data") # 黑名单，跳过
    LOGFILE="/home/ita560nx/gwkj/logs/pg_auto_cleanup.log" # 日志路径
    BATCH_SIZE=5000
    
    declare -g PSQL="psql -h ${DB_HOST:-localhost} -p ${DB_PORT:-5432} -U $DB_USER -d $DB_NAME -tAc"
    log "INFO" "硬编码配置加载完成"
}
# ==================== 配置修改 ====================

# ==================== 函数定义 ====================
# 日志函数（输出到 stderr，避免污染函数返回值）
log() {
    local level="$1"; shift
    local msg="$*"
    local log_msg="[$(TZ='Asia/Shanghai' date '+%F %T')] [$level] $msg"
    
    # 修改点：使用 >&2 将日志输出到标准错误，保证 stdout 纯净用于返回数据
    echo "$log_msg" >&2
    
    if [[ "$LOG_TO_FILE" == "true" ]]; then
        echo "$log_msg" >> "$LOGFILE" 2>/dev/null || {
            [[ "$LOG_WARNED" == "false" ]] && {
                echo "WARNING: 无法写入日志文件 $LOGFILE (权限不足)" >&2
                echo "WARNING: 后续日志仅输出到屏幕" >&2
                LOG_WARNED=true
                LOG_TO_FILE=false
            }
        }
    fi
}

# 数据库执行函数
exec_sql() {
    local sql="$1"
    local error_file=$(mktemp)
    local result
    
    result=$(PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t 2>"$error_file" <<< "$sql")
    local exit_code=$?
    
    if [[ $exit_code -ne 0 ]]; then
        local error_msg=$(cat "$error_file")
        rm -f "$error_file"
        log "ERROR" "SQL执行失败: $error_msg"
        return 1
    fi
    
    rm -f "$error_file"
    echo "$result"
}

# 检查表是否在白名单中
in_whitelist() {
    local table="$1"
    for pattern in "${WHITELIST_TABLES[@]}"; do
        [[ -z "$pattern" ]] && continue
        [[ "$table" == $pattern ]] && return 0
    done
    return 1
}

# 检查表是否在黑名单中
in_blacklist() {
    local table="$1"
    for pattern in "${BLACKLIST_TABLES[@]}"; do
        [[ -z "$pattern" ]] && continue
        [[ "$table" == $pattern ]] && return 0
    done
    return 1
}

# 获取包含 created_time 字段的表（增加 trim 去除空格）
get_tables_with_created_time() {
    exec_sql "
        SELECT TRIM(table_name) 
        FROM information_schema.columns 
        WHERE table_schema = 'public' 
          AND column_name = 'created_time'
        ORDER BY table_name;
    " || return 1
}

# 获取表的保留天数
get_retention_days() {
    local table="$1"
    [[ -n "${TABLE_RETENTION_MAP[$table]:-}" ]] && {
        echo "${TABLE_RETENTION_MAP[$table]}"
        return
    }
    echo "$DEFAULT_RETENTION_DAYS"
}

# 统计旧数据
count_old_rows() {
    local table="$1"
    local days="$2"
    exec_sql "
        SELECT COUNT(*) 
        FROM $table 
        WHERE created_time::TIMESTAMP < (NOW() AT TIME ZONE 'Asia/Shanghai') - INTERVAL '$days days'
          AND created_time::TIMESTAMP IS NOT NULL;
    " || echo "0"
}

# 分批删除旧数据
delete_old_rows() {
    local table="$1"
    local days="$2"
    local total_deleted=0
    local batch_deleted=0
    
    log "INFO" "开始清理表 '$table'（CST时间），保留 $days 天内的数据..."
    
    while true; do
        batch_deleted=$(exec_sql "
            WITH deleted AS (
                DELETE FROM $table 
                WHERE ctid = ANY(
                    ARRAY(
                        SELECT ctid 
                        FROM $table 
                        WHERE created_time::TIMESTAMP < (NOW() AT TIME ZONE 'Asia/Shanghai') - INTERVAL '$days days'
                          AND created_time::TIMESTAMP IS NOT NULL
                        LIMIT $BATCH_SIZE
                    )
                )
                RETURNING 1
            )
            SELECT COUNT(*) FROM deleted;
        " || echo "0")
        
        total_deleted=$((total_deleted + batch_deleted))
        [[ "$batch_deleted" -eq 0 ]] && break
        sleep 0.05
    done
    
    log "INFO" "表 '$table' 清理完成（CST时间），共删除 $total_deleted 行"
    # 输出纯数字到 stdout，供主流程捕获
    echo "$total_deleted"
}

# ==================== 主流程 ====================
main() {
    sudo chown -R ita560nx:ita560nx "$(dirname "$LOGFILE")"
    local dry_run=false
    local config_file=""
    
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --dry-run) dry_run=true; shift ;;
            *) 
                [[ -f "$1" ]] && config_file="$1" || log "WARN" "未知参数或文件不存在: $1"
                shift 
                ;;
        esac
    done
    
    config_file="${config_file:-$DEFAULT_CONFIG_FILE}"
    load_config "$config_file"
    
    log "INFO" "================== 清理任务开始 $(TZ='Asia/Shanghai' date) =================="
    log "INFO" "模式: $([[ "$dry_run" == true ]] && echo 'DRY-RUN' || echo 'EXECUTE')"
    
    mkdir -p "$(dirname "$LOGFILE")" || { log "ERROR" "无法创建日志目录"; exit 1; }
    
    local tables=()
    if ! mapfile -t tables < <(get_tables_with_created_time); then
        log "ERROR" "获取包含 created_time 字段的表失败，程序退出"
        exit 1
    fi
    
    if [[ ${#tables[@]} -eq 0 ]]; then
        log "WARN" "未找到任何包含 created_time 字段的表"
        return 0
    fi
        
    log "INFO" "找到 ${#tables[@]} 个候选表: ${tables[*]}"
    
    local total_deleted_all=0
    
    for table in "${tables[@]}"; do
        [[ -z "$table" ]] && continue
        in_blacklist "$table" && { log "INFO" "跳过黑名单表: $table"; continue; }
        in_whitelist "$table" && { log "INFO" "跳过白名单表: $table"; continue; }
        
        local retention_days
        retention_days=$(get_retention_days "$table")
        log "INFO" "处理表 '$table'，保留天数: $retention_days"
        
        if [[ "$dry_run" == "true" ]]; then
            local count
            count=$(count_old_rows "$table" "$retention_days")
            log "INFO" "[DRY-RUN] 表 '$table' 将删除 $count 行数据"
            total_deleted_all=$((total_deleted_all + count))
        else
            local deleted
            # 这里 delete_old_rows 的输出现在只有数字
            deleted=$(delete_old_rows "$table" "$retention_days")
            total_deleted_all=$((total_deleted_all + deleted))
        fi
    done
    
    log "INFO" "================== 清理任务结束 $(TZ='Asia/Shanghai' date) =================="
    log "INFO" "总计删除/可删除行数: $total_deleted_all"
}

# ==================== 执行入口 ====================
[[ "${BASH_SOURCE[0]}" == "${0}" ]] && main "$@"
