#!/usr/bin/env bash
set -euo pipefail

readonly ALLOWED_BASE="/home/ita560nx/gwkj"
readonly LOGFILE="${LOGFILE:-/home/ita560nx/gwkj/logs/auto_cleanup.log}"

# 参数解析：支持 ./clean_up.sh [--dry-run] [config_path]
DRY_RUN=false
CONFIG_FILE="/home/ita560nx/gwkj/program/clean_up/clean_up.conf" # 默认配置

for arg in "$@"; do
  [[ "$arg" == "--dry-run" ]] && DRY_RUN=true
done

(( $# > 0 )) && [[ -f "${!#}" ]] && CONFIG_FILE="${!#}"

# 初始化统计
declare -A STATS=( [files]=0 [dirs]=0 [skipped]=0 [errors]=0 )

# 日志函数（带日志级别）
log() {
  local level=$1; shift
  echo "[$(date '+%F %T')] [$level] $*" | tee -a "$LOGFILE"
}

# 安全删除（带路径验证）
safe_rm() {
  local path=$1 type=$2
  [[ -z "$path" || "$path" == "/" ]] && {
    log "ERROR" "Invalid path"; ((STATS[errors]++)); return 1
  }
  [[ "$path" != "$ALLOWED_BASE/"* ]] && {
    log "ERROR" "Path outside allowed base: $path"; ((STATS[errors]++)); return 1
  }
  
  if [[ "$DRY_RUN" == true ]]; then
    printf "[DRY-RUN] would remove %s: %s\n" "$type" "$path"
    return 0
  fi
  
  if rm -R -- "$path" 2>/dev/null; then
    log "INFO" "[REMOVED] $type: $path"
    ((STATS[$type]++))
  else
    log "ERROR" "Failed to remove $path"
    ((STATS[errors]++))
  fi
}

# 白名单检查（支持 glob）
in_white_list() {
  local item=$1; shift
  local -a patterns=("$@")
  local pat
  for pat in "${patterns[@]}"; do
    [[ -z "$pat" ]] && continue
    if [[ "$item" == $pat || "$item" =~ ^$pat(/.*)?$ ]]; then
      return 0
    fi
  done
  return 1
}

# 主流程
main() {
  [[ -f "$CONFIG_FILE" ]] || { log "ERROR" "Config missing: $CONFIG_FILE"; exit 1; }
  
  # 确保日志目录
  mkdir -p "$(dirname "$LOGFILE")" || { log "ERROR" "Failed to create log dir"; exit 1; }
  sudo chown -R ita560nx:ita560nx "$(dirname "$LOGFILE")"
  
  log "INFO" "Starting cleanup (DRY_RUN=$DRY_RUN, CONFIG=$CONFIG_FILE)"

  # 读取配置
  mapfile -t lines < "$CONFIG_FILE"
  for line in "${lines[@]}"; do
    line=${line%%#*}  # 去掉注释
    [[ -z "$line" ]] && continue
    
    IFS='|' read -r dir days white <<< "$line"
    dir=${dir//[[:space:]]/}
    days=${days//[[:space:]]/}
    white=${white//[[:space:]]/}
    
    [[ ! -d "$dir" ]] && { log "WARN" "Skip: $dir not exist"; continue; }
    [[ "$dir" != "$ALLOWED_BASE/"* ]] && {
      log "WARN" "Skip: $dir outside base"; continue
    }

    log "INFO" "Cleaning $dir (>$days days, whitelist: $white)"
    
    # 解析白名单为数组
    IFS=',' read -ra whitelist <<< "$white"

	# 删除文件
	while IFS= read -r -d '' file; do
	    rel=${file#$dir/}
	    if in_white_list "$rel" "${whitelist[@]}"; then
		log INFO "[SKIP] whitelisted: $rel"
		((STATS[skipped]++))
		continue
	    fi
	    safe_rm "$file" "files" || true
	done < <(find "$dir" -type f -mtime +"$days" -print0 2>/dev/null)

	# 删除空目录
	while IFS= read -r -d '' subdir; do
	    rel=${subdir#$dir/}
	    in_white_list "$rel" "${whitelist[@]}" && { ((STATS[skipped]++)); continue; }
	    [[ -n $(find "$subdir" -mindepth 1 -print -quit) ]] && continue
	    safe_rm "$subdir" "dirs"
	done < <(find "$dir" -mindepth 1 -depth -type d -print0 2>/dev/null)

    log "INFO" "Finished $dir"
  done
  
  log "INFO" "Summary: files=${STATS[files]}, dirs=${STATS[dirs]}, \
skipped=${STATS[skipped]}, errors=${STATS[errors]}"
}

main "$@"
