
set(CTL_NAME "ctl_changchun3rfid")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})

target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_io_manager>
$<TARGET_OBJECTS:kit_asio_tcp_client>
)         
target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies
kit_io_manager 
kit_asio_tcp_client
)


find_package(OpenCV REQUIRED COMPONENTS core imgproc)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
)  

target_include_directories(${CTL_NAME} PUBLIC
    ${THIRD_PARTY_INCLUDE}/JCWLib/
)  

find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})



# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/engineering_vehicle_qml/rfid_page/rfid_page.qml
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/Magnifier.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end