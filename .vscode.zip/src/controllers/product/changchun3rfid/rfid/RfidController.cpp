#include "RfidController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include <qvariant.h>
// #include "kits/common/database/CppBatis.h"
// #include "kits/common/database/connections/DatabaseConnections.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

RfidController::RfidController() {}

void RfidController::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find("RFID");
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", "RFID");
        return;
    }
    m_tcpClient = finder->second;
    m_rfid_VFR61M->setTcpClient(m_tcpClient.lock());
    m_rfid_VFR61M->setSendRfidCallback([this](const std::string &rfid, int64_t timet) {
        if (rfid.empty())
            return;
        // 统计逻辑 - 在发送到QML前
        if (rfid.length() >= 4)
        {
            std::string prefix = rfid.substr(0, 4);

            // 更新统计计数
            m_rfidTypeCount[prefix]++;

            // 打印统计日志
            LogInfo("RFID统计 - 类型: {}, 数量: {}, 最新RFID: {}", prefix, m_rfidTypeCount[prefix], rfid);

            // 可选：定期打印所有类型的统计汇总
            static int counter = 0;
            if (++counter % 100 == 0)
            { // 每100个RFID打印一次汇总
                LogInfo("RFID类型统计汇总:");
                for (const auto &[type, count] : m_rfidTypeCount)
                {
                    LogInfo("  类型 {}: {} 个", type, count);
                }
            }
        }

        senderRfidServicesendRfidToQml(QString::fromStdString(rfid));

        senderRfidServicerfidDeduplicated(rfid, timet);
    });

    if (!m_rfid_VFR61M->start())
    {
        LogError("RFID VFR61M failed to start");
    }
}

void RfidController::onInitConfig(const TIS_Info::RfidInfo &info)
{
    m_rfidInfo = info;
    m_rfid_VFR61M = std::make_shared<Rfid_VFR61M>();

    m_rfid_VFR61M->setInfo(info);

    if (!m_rfid_VFR61M->start())
    {
        LogError("RFID VFR61M failed to start");
    }
}

} // namespace _Controllers