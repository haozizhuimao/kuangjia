#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlRfidController : public ControllerBase<QmlRfidController>
{
  public:
    void onSendRfidDataToQml(QString);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::RfidService::sendRfidToQml, QmlRfidController::onSendRfidDataToQml);
    TASK_LIST_END

  private:
};
} // namespace _Controllers
