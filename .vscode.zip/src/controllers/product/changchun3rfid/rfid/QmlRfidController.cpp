#include "QmlRfidController.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlRfidController::onSendRfidDataToQml(QString data)
{
    LogInfo("Sending RFID data to QML: {}", data.toStdString().c_str());
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_recv, QVariant::fromValue(data));
}

} // namespace _Controllers
