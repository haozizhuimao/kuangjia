#include "ConfigEditerPage.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include <QStringList>
#include <qvariant.h>
#include <QJSValue>
#include <QJSValueIterator>
#include <QJSEngine>
namespace _Controllers {
using namespace _Service;
using namespace _Kits;

ConfigChooserPageController::ConfigChooserPageController()
{
    m_configOperations = std::make_unique<ConfigOperations>();
}
void ConfigChooserPageController::onConfigModifyClicked(const QVariant &data)
{
    QVariantMap map = data.toMap();
    QString sourcePath = map.value("fullpath").toString();
    QString destPath = map.value("path").toString();

    m_configOperations->copyFile(sourcePath, destPath);     // 复制全部配置的配置文件为需要使用的配置文件。
    auto result = m_configOperations->loadConfig(destPath); // 加载复制后的path配置文件。
    auto ret = App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp,
                                       TIS_Info::QmlCommunication::ForQmlSignals::config_recv,
                                       QVariant::fromValue(std::move(result)));
}

void ConfigChooserPageController::onConfigDataSended(const QVariant &configdata)
{
    QVariantMap configdataMap;

    if (configdata.canConvert<QJSValue>())
    {
        QJSValue jsValue = configdata.value<QJSValue>();
        QJSEngine engine;
        QVariant variant = jsValue.toVariant();
        if (variant.type() == QVariant::Map)
        {
            configdataMap = variant.toMap();
        }
        else
        {
            LogError("QJSValue转QVariantMap失败，类型为{}", variant.typeName());
            return;
        }
    }
    else if (configdata.canConvert<QVariantMap>())
    {
        configdataMap = configdata.toMap();
    }
    else
    {
        LogError("QJSValue转QVariantMap失败，类型为{}", configdata.typeName());
        return;
    }

    QString configpath = configdataMap.value("path").toString();
    QVariant data = configdataMap.value("data");
    auto ret = m_configOperations->saveDataToYaml(configpath, data);

    // 发送保存是否成功状态到qml
    App().invokeModuleAsync(
        TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::edit_state, QVariant::fromValue(ret));
}

} // namespace _Controllers
// namespace _Controllers