#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/config_operations/ConfigOperations.h"
#include <qvariant.h>
#include <string>
#include <memory>

namespace _Controllers {
class ConfigChooserPageController : public ControllerBase<ConfigChooserPageController>
{
  public:
    ConfigChooserPageController();
    ~ConfigChooserPageController() = default;
    void onConfigModifyClicked(const QVariant &);
    void onConfigDataSended(const QVariant &);

    TASK_LIST_BEGIN
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::UpdateConfigButton, ConfigChooserPageController::onConfigModifyClicked);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ConfigDataSend, ConfigChooserPageController::onConfigDataSended);

    TASK_LIST_END

  private:
    std::unique_ptr<_Kits::ConfigOperations> m_configOperations = nullptr;
};
} // namespace _Controllers
