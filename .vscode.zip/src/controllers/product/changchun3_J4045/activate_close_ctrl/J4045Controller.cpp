#include "J4045Controller.h"
#include "kits/utility/log/CRossLogger.h"

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

J4045Controller::~J4045Controller()
{
    m_bRunning.store(false);
    if (m_dealtimesThread.joinable())
    {
        m_dealtimesThread.join();
    }
}
void J4045Controller::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{

    auto iter = clients.find("j4045_send");
    if (iter == clients.end())
    {
        LogError("can not find tcp client.name = {}", "j4045_send");
        return;
    }
    m_tcpClient = iter->second;
    // client->start(TcpClient::ConnModel::coroutine, true);
    if (auto it = m_tcpClient.lock())
    {
        it->start(TcpClient::ConnModel::coroutine, true);
    }
    else
    {
        LogError("tcp client is null");
    }
}

void J4045Controller::onRecvLabel(TIS_Info::jyDamData data)
{
    m_curData.enter_id = data.enter_id;
    m_curData.out_id = data.out_id;
    m_curData.flag = data.flag;
    m_curData.enter_hours = data.enter_hours;
    m_curData.enter_minutes = data.enter_minutes;
    m_curData.out_hours = data.out_hours;
    m_curData.out_minutes = data.out_minutes;
    LogInfo("j4045 recv label.enter_id = {},out_id = {},flag = {},enter_hours = {},enter_minutes = {},out_hours = {},out_minutes = {}",
            data.enter_id,
            data.out_id,
            data.flag,
            data.enter_hours,
            data.enter_minutes,
            data.out_hours,
            data.out_minutes);

    m_bRunning.store(true);
    m_dealtimesThread = std::thread(std::bind(&J4045Controller::dealTimes, this));
}

std::vector<uint8_t> J4045Controller::createJ4045Data(int flag)
{
    // close :037a00000500002000000000  open:0326000005000020ffffffff

    if (flag == 0) // close
    {
        // 03 7A 00 00 05 00 00 20 00 00 00 00
        return {0x03, 0x7A, 0x00, 0x00, 0x05, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00};
    }
    else
    {

        // 03 26 00 01 05 00 00 20 FF FF FF FF
        return {0x03, 0x26, 0x00, 0x01, 0x05, 0x00, 0x00, 0x20, 0xFF, 0xFF, 0xFF, 0xFF}; // open
    }
}

void J4045Controller::dealTimes()
{

    static bool isOpen = true;
    while (m_bRunning.load())
    {
        if (!m_bRunning.load())
        {
            LogInfo("j4045 dealTimes thread exit");
            break;
        }

        if (auto it = m_tcpClient.lock())
        {
            if (it->isConnected() && isOpen)
            {
                auto data = createJ4045Data(1);     // 这是断电
                it->sendDataAsync(std::move(data)); // 关
                LogInfo("j4045 close times = {}:{}", m_curData.out_hours, m_curData.out_minutes);
                isOpen = false;
            }
        }

        if (isInTimeRange(m_curData.enter_hours, m_curData.enter_minutes))
        {
            if (auto it = m_tcpClient.lock())
            {
                if (it->isConnected())
                {
                    auto data = createJ4045Data(1); // 断电
                    it->sendDataAsync(std::move(data));
                    LogInfo("j4045 close times = {}:{}", m_curData.enter_hours, m_curData.enter_minutes);

                    std::this_thread::sleep_for(std::chrono::seconds(50));
                }
            }
            else
            {
                LogError("tcp client is null");
            }
        }
        if (isInTimeRange(m_curData.out_hours, m_curData.out_minutes))
        {
            if (auto it = m_tcpClient.lock())
            {
                if (it->isConnected())
                {
                    auto data = createJ4045Data(0); // 开电
                    it->sendDataAsync(std::move(data));
                    LogInfo("j4045 open times = {}:{}", m_curData.out_hours, m_curData.out_minutes);

                    std::this_thread::sleep_for(std::chrono::seconds(50));
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}
std::string J4045Controller::getCurrentTimesString()
{
    auto now = std::chrono::system_clock::now();
    std::time_t now_time = std::chrono::system_clock::to_time_t(now);
    std::tm *local_time = std::localtime(&now_time);
    char buffer[20];
    std::strftime(buffer, sizeof(buffer), "%H:%M:%S", local_time);
    return std::string(buffer);
}

bool J4045Controller::isInTimeRange(const int hours, const int minutes)
{
    auto now = std::chrono::system_clock::now();
    std::time_t currentTime = std::chrono::system_clock::to_time_t(now);
    std::tm *localTime = std::localtime(&currentTime);

    int currentHour = localTime->tm_hour;
    int currentMinute = localTime->tm_min;

    bool isInRange = (currentHour == hours && currentMinute == minutes);

    // 直接判断是否是19:00
    return (currentHour == hours && currentMinute == minutes);
}
