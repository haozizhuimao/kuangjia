#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include <thread>
#include <atomic>
#include <deque>
#include "tis_global/struct_details/jyDam_struct.h"
#include <mutex>

namespace _Controllers {

class J4045Controller : public ControllerBase<J4045Controller>
{
  public:
    ~J4045Controller();
    void onRecvLabel(TIS_Info::jyDamData);

    void onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::JyDamManager::sendLabel, J4045Controller::onRecvLabel);
    SYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, J4045Controller::onSetTcpClient);

    TASK_LIST_END

  private:
    std::weak_ptr<_Kits::TcpClient> m_tcpClient;

    std::atomic_bool m_bRunning{false};
    std::thread m_dealtimesThread;
    std::deque<std::vector<uint8_t>> m_deq_sendData;
    TIS_Info::jyDamData m_curData; // 判断需要执行命令的时间段

    std::string m_lastId = "";
    std::deque<std::string> m_deq_id;
    std::mutex m_mutex;

  private:
    std::vector<uint8_t> createJ4045Data(int flag);
    void dealTimes();
    std::string getCurrentTimesString();
    bool isInTimeRange(const int start, const int end);
};

} // namespace _Controllers