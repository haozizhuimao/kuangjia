#pragma once
#include "kits/communication/asio/tcp_client/TcpSession.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/struct_details/mvb_struct.h"
#include "kits/database/postgresql_interface/PgMvbInfo.h"
#include <yaml-cpp/yaml.h>
#include <json/json.h>
#include <thread>
#include <json/value.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void afterMVBData(const int, const std::vector<uint8_t> &);
    void setConfigHeart(const TIS_Info::DuagonCardData &);
    void setConfigSwitch(const TIS_Info::MVBConfig &, const std::string &path);
    void onRecvSimuteMvbData(const Json::Value &);
    void onStart();

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, MVBController::onStart);
    SYNC_TASK_ADD(_Service::MVBDistribution::setConfigHeart, MVBController::setConfigHeart);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    ASYNC_TASK_ADD(_Service::MVBDistribution::duagonData, MVBController::afterMVBData);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::MVBSimluteHeartData, MVBController::onRecvSimuteMvbData);
    TASK_LIST_END

  private:
    void heartFunc();
    uint16_t getConfVersion(const std::string &);
    void sendAliveData();
    // 解析时间数据
    void parseTimeData(const std::vector<uint8_t> &, Json::Value &);
    // 解析车辆数据
    void parseTCMSData(const std::vector<uint8_t> &, Json::Value &);
    // 解析公共数据
    void parseCarInfo(const std::vector<uint8_t> &, Json::Value &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, Json::Value &);
    // 界面展示接收数据
    void displayRecvPortData(const int, Json::Value &);
    // 界面展示心跳数据
    void displayHeartData();
    std::string getCurrentTimeStr();

    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全

    TIS_Info::DuagonCardData m_heartData;
    std::thread m_thHeart;
    std::atomic_bool m_bHolder = true;
    std::atomic<bool> m_started = false;

    TIS_Info::MVBConfig m_mvbConfig;
    std::mutex m_dataMtx;
    std::mutex m_dbMtx;
    std::once_flag m_onceFlag;
    uint16_t m_version = 0;
    std::vector<uint8_t> m_recvData;
    const std::string m_tcmsSendName = "mvb_tcms";
    std::weak_ptr<_Kits::TcpSession> m_tcpClient;
};
} // namespace _Controllers
