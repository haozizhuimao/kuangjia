#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/struct_details/mvb_struct.h"
#include <asio/steady_timer.hpp>
#include <mutex>
#include <regex>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    // 列车号端口：16、时间端口：16、TCMS数据端口：32
    m_recvData.resize(66, 0);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
    {
        m_thHeart.join();
    }
}

void MVBController::afterMVBData(const int portId, const std::vector<uint8_t> &data)
{
    // 待解析
    Json::Value mapData;
    if (portId == m_mvbConfig.netPortCfg.commonPortNetA)
    {
        // 列车号端口收到的列车数据 长度16字节固定
        std::copy(data.begin(), data.end(), m_recvData.begin());
    }
    else if (portId == m_mvbConfig.netPortCfg.commonPortNetB)
    {
        // 时间端口接收到的时间数据 偏移16字节存放
        std::copy(data.begin(), data.end(), m_recvData.begin() + 16);
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        // TCMS数据端口数据,偏移32字节存放
        std::copy(data.begin(), data.end(), m_recvData.begin() + 32);
        parseTCMSData(data, mapData);
    }
    if (portId == m_mvbConfig.netPortCfg.commonPortNetA || portId == m_mvbConfig.netPortCfg.commonPortNetB)
    {
        parseCarInfo(m_recvData, mapData);
        std::vector<uint8_t> timeData(m_recvData.begin() + 16, m_recvData.begin() + 32);
        parseTimeData(timeData, mapData);
    }
    // 给页面传递数据展示
    displayRecvPortData(portId, mapData);
    auto client = m_tcpClient.lock();
    if (!client)
    {
        LogError("[MVBController] 客户端={},断开连接", m_tcmsSendName);
        return;
    }
    auto tmp = m_recvData;
    client->post(std::move(tmp));
    LogInfo("afterMVBData before json, portId={},data={}", portId, ByteArrayTools::hexString(data.data(), data.size()));
}
void MVBController::onStart()
{
    // 防止重复赋值
    bool expected = false;
    if (!m_started.compare_exchange_strong(expected, true))
    {
        return;
    }
    auto tcpClientPtr = _Service::TcpClientCenter::getClient<std::shared_ptr<_Kits::TcpSession>>(m_tcmsSendName);
    if (nullptr == tcpClientPtr)
    {
        _Kits::LogError("[MVBController] 客户端={}, 获取TCP会话失败", m_tcmsSendName);
        return;
    }
    tcpClientPtr->start();
    m_tcpClient = tcpClientPtr;
}

void MVBController::setConfigHeart(const TIS_Info::DuagonCardData &config)
{
    m_heartData = config;
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}

void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConf, const std::string &path)
{
    m_mvbConfig = std::move(mvbConf);
    m_version = getConfVersion(m_mvbConfig.mvbPublicCfg.version);
}

void MVBController::sendAliveData()
{
    ++m_aliveId; // 心跳id自增
    ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData.m_portData, m_aliveId, 0);
    // 软件版本
    // ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData.m_portData, m_version, 14);
    _Service::MVBDistribution::dataToDuagonCard(m_heartData);
    displayHeartData();
    LogInfo("[MVBController] 发送的心跳数据={}", ByteArrayTools::hexString(m_heartData.m_portData.data(), m_heartData.m_portData.size()));
}

void MVBController::onRecvSimuteMvbData(const Json::Value &simulateHeart) {}

void MVBController::heartFunc()
{
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= m_heartData.m_nextClock)
        {
            m_heartData.m_nextClock = now + m_heartData.portConfig.m_interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, m_heartData.m_nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::parseTimeData(const std::vector<uint8_t> &timeData, Json::Value &outputData)
{
    // 年
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 0);
    // 月
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 2);
    // 日
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 4);
    // 时
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 6);
    // 分
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 8);
    // 秒
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 10);
    // 生命信号
    outputData["alive"] = ByteArrayTools::readFromVectorBE<uint16_t>(timeData, 12);

    uint8_t data0 = ByteArrayTools::readFromVectorBE<uint8_t>(timeData, 14);
    std::bitset<8> bit(data0);
    // 时间和日期调整请求
    outputData["timeAdjustReq"] = static_cast<bool>(bit[0]);
    // 时间和日期有效
    outputData["timeVaild"] = static_cast<bool>(bit[1]);
}

void MVBController::parseCarInfo(const std::vector<uint8_t> &carData, Json::Value &outputData)
{
    // 线路号
    outputData["lineId"] = ByteArrayTools::readFromVectorBE<uint16_t>(carData, 0);
    // 列车号
    outputData["carId"] = ByteArrayTools::readFromVectorBE<uint16_t>(carData, 2);

    uint8_t data0 = ByteArrayTools::readFromVectorBE<uint8_t>(carData, 14);
    // 低8位
    std::bitset<8> bit(data0);
    // 列车号调整请求
    outputData["carIdAdjustReq"] = static_cast<bool>(bit[0]);
    // 列车号有效
    outputData["carIdVaild"] = static_cast<bool>(bit[1]);
}

void MVBController::parseTCMSData(const std::vector<uint8_t> &tcmsData, Json::Value &outputData)
{
    // 生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 0);
    uint8_t data0 = ByteArrayTools::readFromVectorBE<uint8_t>(tcmsData, 2);
    std::bitset<8> bit(data0);
    // 蓄电池休眠信号
    outputData["battrySleep"] = static_cast<bool>(bit[0]);
    // 蓄电池欠压
    outputData["battryUndervoltage"] = static_cast<bool>(bit[1]);
    // 高压断电
    outputData["highVoltageOutage"] = static_cast<bool>(bit[2]);
    // 升弓到位
    outputData["pantoUp"] = static_cast<bool>(bit[3]);
    // 降弓到位
    outputData["pantoDown"] = static_cast<bool>(bit[4]);
    // Mc1车司机室占用
    outputData["mc1Occupy"] = static_cast<bool>(bit[5]);
    // Mc2车司机室占用
    outputData["mc2Occupy"] = static_cast<bool>(bit[6]);
    // ATB模式
    outputData["ATBMode"] = static_cast<bool>(bit[7]);
    uint8_t data1 = ByteArrayTools::readFromVectorBE<uint8_t>(tcmsData, 3);
    std::bitset<8> bit1(data1);
    // 列车门开关
    outputData["closeDoor"] = static_cast<bool>(bit1[0]);

    // 列车速度
    outputData["speed"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 4);
    // 起始站ID
    outputData["startStationId"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 6);
    // 终点站ID
    outputData["endStationId"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 8);
    // 下一站ID
    outputData["nextStationId"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 10);
    // 当前站ID
    outputData["currentStationId"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 12);
    // 目标距离
    outputData["targetDistance"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 14);
    // 起始距离
    outputData["startDistance"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 16);
    // 受电弓电压
    outputData["pantoVoltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 18);
    // 受电弓电流
    outputData["pantoElectric"] = ByteArrayTools::readFromVectorBE<uint16_t>(tcmsData, 20);
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // VCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    outputData["arcHigh"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
    outputData["arcLow"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    outputData["zigHigh"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
    outputData["zigLow"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
    // 弓网版本
    outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
}

void MVBController::displayRecvPortData(const int portId, Json::Value &portData)
{
    // 给页面传递数据展示
    portData["recvTime"] = getCurrentTimeStr();

    if (portId == m_mvbConfig.netPortCfg.commonPortNetA || portId == m_mvbConfig.netPortCfg.commonPortNetB)
    {
        portData["dataSource"] = "chongqing_ring_common_data";
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        portData["dataSource"] = "chongqing_ring_ccu_data";
    }
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

uint16_t MVBController::getConfVersion(const std::string &versionStr)
{
    if (versionStr.empty())
    {
        return 0;
    }

    int majorVersion = 0;
    int minorVersion = 0;
    int patchVersion = 0;

    std::smatch m;
    static const std::regex whole(R"(\b(\d+)\.(\d+)\.(\d+)\b)");
    if (!std::regex_search(versionStr, m, whole))
    {
        return 0;
    }
    majorVersion = std::stoi(m[1]);
    minorVersion = std::stoi(m[2]);
    patchVersion = std::stoi(m[3]);
    return (majorVersion << 8) | (minorVersion << 4) | (patchVersion & 0x0F);
}

std::string MVBController::getCurrentTimeStr()
{
    auto nowTime = std::chrono::system_clock::now();
    auto msTime = std::chrono::time_point_cast<std::chrono::milliseconds>(nowTime);
    auto zonedTime = std::chrono::zoned_time{std::chrono::current_zone(), msTime};
    return std::format("{:%Y-%m-%d %H:%M:%S}", zonedTime);
}

void MVBController::displayHeartData()
{
    if (m_heartData.m_portData.empty())
    {
        return;
    }
    // 转发数据到界面
    Json::Value heartData;
    parseHeartData(m_heartData.m_portData, heartData);
    heartData["sendTime"] = getCurrentTimeStr();
    heartData["dataSource"] = "chongqing_ring_heart";
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, heartData);
}
} // namespace _Controllers