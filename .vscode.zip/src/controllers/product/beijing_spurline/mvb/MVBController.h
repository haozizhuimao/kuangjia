#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/struct_details/mvb_struct.h"
#include <atomic>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>
#include <vector>
#include <thread>
#include <json/value.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void afterMVBData(const int, const std::vector<uint8_t> &);
    void setConfigHeart(const TIS_Info::DuagonCardData &);
    void setConfigSwitch(const TIS_Info::MVBConfig &);
    void onRecvSimuteMvbData(const Json::Value &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::MVBDistribution::setConfigHeart, MVBController::setConfigHeart);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    ASYNC_TASK_ADD(_Service::MVBDistribution::duagonData, MVBController::afterMVBData);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::MVBSimluteHeartData, MVBController::onRecvSimuteMvbData);
    TASK_LIST_END

  private:
    void heartFunc();
    void sendAliveData();
    // 解析车辆数据
    void parseCarInfo(const std::vector<uint8_t> &, Json::Value &);
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, Json::Value &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, Json::Value &);
    // 界面展示接收数据
    void displayRecvPortData(const int, Json::Value &);
    // 界面展示心跳数据
    void displayHeartData();
    std::string getCurrentTimeStr();

    int m_alivePortId = 0;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全

    TIS_Info::DuagonCardData m_heartData;
    std::thread m_thHeart;
    std::atomic_bool m_bHolder = true;
    const std::string m_udpName = "mvb";
    std::vector<uint8_t> m_recvData;

    TIS_Info::MVBConfig m_mvbConfig;
    std::once_flag m_onceflag;
    std::mutex m_dataMtx;
};
} // namespace _Controllers
