#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/struct_details/mvb_struct.h"
#include <mutex>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_recvData.resize(50, 0);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
    {
        m_thHeart.join();
    }
}

void MVBController::afterMVBData(const int portId, const std::vector<uint8_t> &data)
{
    Json::Value mapData;
    // constexpr int offset = 32;
    if (portId == m_mvbConfig.netPortCfg.commonPortNetA)
    {
        // VCU向所有设备发送的公共数据 长度16字节固定
        parseCommonData(data, mapData);
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        // VCU发送给弓网的数据 偏移32字节存放
        parseCarInfo(data, mapData);
    }
    // 给页面传递数据展示
    displayRecvPortData(portId, mapData);
    LogInfo("afterMVBData json,port={},data={}", portId, ByteArrayTools::hexString(data.data(), data.size()));
}

void MVBController::setConfigHeart(const TIS_Info::DuagonCardData &config)
{
    m_heartData = config;
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}

void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConfig)
{
    m_mvbConfig = mvbConfig;
}

void MVBController::sendAliveData()
{
    {
        std::lock_guard<std::mutex> lock(m_dataMtx);
        ++m_aliveId; // 心跳id自增
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData.m_portData, m_aliveId, 0);
        // 设置其它默认值
        std::call_once(m_onceflag, [this]() {
            ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, 1, 2);
            ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, 2, 3);
            ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, 3, 4);
        });
    }
    LogInfo("heart={}", ByteArrayTools::hexString(m_heartData.m_portData.data(), m_heartData.m_portData.size()));
    _Service::MVBDistribution::dataToDuagonCard(m_heartData);
    displayHeartData();
}

void MVBController::heartFunc()
{
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= m_heartData.m_nextClock)
        {
            m_heartData.m_nextClock = now + m_heartData.portConfig.m_interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, m_heartData.m_nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::parseCarInfo(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // VCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    std::bitset<8> bit(data[2]);
    // 1车司机室激活
    outputData["cab1Occupied"] = static_cast<bool>(bit[0]);
    // 6车司机室激活
    outputData["cab6Occupied"] = static_cast<bool>(bit[1]);
    // 始发站ID
    outputData["startStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    // 当前站ID
    outputData["currentStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    // 下一站ID
    outputData["nextStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    // 终点站ID
    outputData["endStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    // 网压
    outputData["voltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    // 网流
    outputData["electricity"] = static_cast<int16_t>(ByteArrayTools::readFromVectorBE<uint16_t>(data, 10));
}
void MVBController::parseCommonData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // VCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);

    std::bitset<8> bit(data[8]);
    // 时间有效
    outputData["timeValid"] = static_cast<bool>(bit[0]);
    // 列车号有效
    outputData["trainNumbValid"] = static_cast<bool>(bit[3]);
    // 列车参考速度有效
    outputData["speedValid"] = static_cast<bool>(bit[4]);
    // 列车号
    outputData["trainNumb"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    // 列车参考速度
    outputData["realSpeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // 生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 软件版本High
    outputData["versionHigh"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    // 软件版本Low
    outputData["versionLow"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    // 上电自检状态
    outputData["checkStatus"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
}

void MVBController::displayRecvPortData(const int portId, Json::Value &portData)
{
    // 给页面传递数据展示
    portData["recvTime"] = getCurrentTimeStr();

    if (portId == m_mvbConfig.netPortCfg.commonPortNetA)
    {
        portData["dataSource"] = "beijing_spurline_common_data";
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        portData["dataSource"] = "beijing_spurline_ccu_data";
    }
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

void MVBController::onRecvSimuteMvbData(const Json::Value &simulateHeart)
{
    // LogInfo("json={}", simulateHeart.toStyledString());
    std::lock_guard<std::mutex> lock(m_dataMtx);
    // 软件版本
    if (simulateHeart.isMember("versionHigh"))
    {
        auto data = simulateHeart["versionHigh"].asUInt();
        uint8_t versionHigh = static_cast<uint8_t>(simulateHeart["versionHigh"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, versionHigh, 2);
    }
    // 软件版本
    if (simulateHeart.isMember("versionLow"))
    {
        uint8_t versionLow = static_cast<uint8_t>(simulateHeart["versionLow"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, versionLow, 3);
    }
    // 上电自检状态
    if (simulateHeart.isMember("checkStatus"))
    {
        uint8_t checkStatus = static_cast<uint8_t>(simulateHeart["checkStatus"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData.m_portData, checkStatus, 4);
    }
}

std::string MVBController::getCurrentTimeStr()
{
    auto nowTime = std::chrono::system_clock::now();
    auto msTime = std::chrono::time_point_cast<std::chrono::milliseconds>(nowTime);
    auto zonedTime = std::chrono::zoned_time{std::chrono::current_zone(), msTime};
    return std::format("{:%Y-%m-%d %H:%M:%S}", zonedTime);
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    Json::Value heartData;
    parseHeartData(m_heartData.m_portData, heartData);
    heartData["sendTime"] = getCurrentTimeStr();
    heartData["dataSource"] = "beijing_spurline_heart";
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, heartData);
}
} // namespace _Controllers
