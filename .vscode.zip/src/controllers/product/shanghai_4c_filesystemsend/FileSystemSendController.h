#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <QFile>
#include <QByteArray>
#include <deque>
#include <thread>
#include <condition_variable>
#include <mutex>
#include "kits/utility/object_pool/ObjectPool.h"
#include <QDirIterator>
#include <QRegularExpression>

namespace _Controllers {
class FileSystemSendController : public ControllerBase<FileSystemSendController>
{
  public:
    FileSystemSendController();
    ~FileSystemSendController();

    // void setConfigHeart(const TIS_Info::FileSystemData &); // 使用阻塞方式初始化配置信息，防止异步导致未配置完成其他接口已经使用
    void setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);

    void reciveRootPath(const QString &, const QString &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::FileSysWatcher::sendrootPath, FileSystemSendController::reciveRootPath); // 设置心跳
    SYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, FileSystemSendController::setTcpClient);
    TASK_LIST_END
  private:
    void onRefreshWatchDirs();
    void watchDirectory(); // 监控目录变化
    void setFileRegex(const QString &pattern);
    void threadSendData(); // 发送线程函数
  private:
    int m_alivePortId = 0;
    QString m_rootpath;
    QRegularExpression m_fileRegex;
    TIS_Info::FileSystemData m_heartData;
    std::atomic<int> sendCount = 0;

    std::atomic_bool m_bHolder = true;
    const std::string m_tcpName = "filesystem";
    std::weak_ptr<_Kits::TcpClient> m_tcpClient;

    std::deque<QString> m_sendQueue;              // 发送队列
    std::mutex m_queueMutex;                      // 互斥锁保护发送队列
    std::condition_variable m_queueCondVar;       // 条件变量用于通知发送线程
    std::thread m_sendThread;                     // 发送线程
    std::atomic_bool m_bSendThreadRunning{false}; // 发送线程运行标志

    std::thread m_aliveThread;

    std::shared_ptr<_Kits::ObjectPool<QByteArray>> m_objectPool; // 对象池，用于管理QByteArray对象
};
} // namespace _Controllers