set(CTL_NAME "ctl_shanghai_4c_filesystemsend")
message("---------- Building ${CTL_NAME}  ----------")



file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_asio_tcp_client>
)  

target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_asio_tcp_client
)

     
target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CTL_NAME}>
)   

  
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})


