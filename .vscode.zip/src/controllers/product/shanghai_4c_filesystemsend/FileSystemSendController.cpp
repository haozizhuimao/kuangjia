#include "FileSystemSendController.h"
#include "service/AppFramework.h"
// #include "tis_global/Field.h"
// //#include "tis_global/Function.h"

#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {

using namespace _Kits;
using namespace _Service;

FileSystemSendController::FileSystemSendController()
    : m_sendThread(std::thread(&FileSystemSendController::threadSendData, this)),
      m_aliveThread(std::thread(&FileSystemSendController::watchDirectory, this))
{

    // m_sendThread = std::thread(&FileSystemSendController::threadSendData, this);
    // m_objectPool = std::make_shared<_Kits::ObjectPool<QByteArray>>(1000); // 初始化对象池，最大容量为10

    // m_aliveThread = std::thread(&FileSystemSendController::watchDirectory, this);
}
FileSystemSendController::~FileSystemSendController()
{
    m_bSendThreadRunning.store(true);
    if (m_sendThread.joinable())
    {
        m_sendThread.join();
    }
    if (m_aliveThread.joinable())
    {
        m_aliveThread.join();
    }
}
void FileSystemSendController::reciveRootPath(const QString &path, const QString &pattern)
{
    m_rootpath = path;

    setFileRegex(pattern);
}

// QByteArray payload;
// // 发送文件数据
// QByteArray pathBytes = filePath.toUtf8();
// qint32 imageLength = fileData->size();
// qint32 pathLength = pathBytes.size();
// payload.append(TCP_HEADER);
// payload.append(reinterpret_cast<const char*>(&imageLength), sizeof(qint32));
// payload.append(fileData->data());
// payload.append(reinterpret_cast<const char*>(&pathLength), sizeof(qint32));
// payload.append(pathBytes);
// payload.append(TCP_TAIL);

void FileSystemSendController::setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find(m_tcpName);
    if (finder != clients.end())
    {
        m_tcpClient = finder->second;
    }
}
void FileSystemSendController::onRefreshWatchDirs()
{
    // QRegularExpression regex("^capture[0-4].*\\.jpg$", QRegularExpression::CaseInsensitiveOption);

    QDirIterator fileIt(m_rootpath, QStringList() << "*.jpg", QDir::Files, QDirIterator::Subdirectories);

    while (fileIt.hasNext())
    {
        QString fullPath = fileIt.next();
        QFileInfo fi(fullPath);
        if (fi.lastModified().msecsTo(QDateTime::currentDateTime()) < 500)
            continue;

        if (!m_fileRegex.match(fi.fileName()).hasMatch())
            continue;
        {
            std::lock_guard<std::mutex> lock(m_queueMutex);
            m_sendQueue.push_back(fullPath);
            m_queueCondVar.notify_one(); // 通知发送线程有新数据
        }
    }
}

void FileSystemSendController::watchDirectory()
{
    while (!m_bSendThreadRunning.load())
    {
        onRefreshWatchDirs();
        std::this_thread::sleep_for(std::chrono::seconds(1)); // 每1秒刷新一次
    }
}
void FileSystemSendController::setFileRegex(const QString &pattern)
{
    // QString fullPattern = QString("^%1\\d+.*\\.jpg$").arg(pattern);
    m_fileRegex.setPattern(pattern);
    m_fileRegex.setPatternOptions(QRegularExpression::CaseInsensitiveOption);
}

void FileSystemSendController::threadSendData()
{

    const static QByteArray TCP_HEADER = "{[(tcp_header)]}";
    const static QByteArray TCP_TAIL = "{[(tcp_tail)]}";
    // fileData.clear(); // 清空之前的内容
    while (!m_bSendThreadRunning.load())
    {
        std::unique_lock<std::mutex> lock(m_queueMutex);
        m_queueCondVar.wait(lock, [this] { return !m_sendQueue.empty() || m_bSendThreadRunning.load(); });

        if (m_bSendThreadRunning.load())
        {
            break; // 线程结束
        }

        auto filePath = std::move(m_sendQueue.front());
        m_sendQueue.pop_front();

        lock.unlock();

        QFile file(filePath);
        try
        {

            if (!file.open(QIODevice::ReadOnly))
            {
                LogError("Failed to open file: {}", filePath.toStdString());
                continue;
            }
        }
        catch (const std::exception &e)
        {
            return;
        }
        auto imgdata = file.readAll();
        file.close();
        QByteArray pathBytes = filePath.toUtf8();
        qint32 fileSize = imgdata.size();
        qint32 pathSize = pathBytes.size();
        // auto fileData = m_objectPool->getObject(1024 * 1024 * 1024, '\0');
        QByteArray fileData;
        // fileData->clear(); // 清空之前的内容
        fileData.append(TCP_HEADER);
        fileData.append(reinterpret_cast<const char *>(&fileSize), sizeof(qint32));
        fileData.append(imgdata);
        fileData.append(reinterpret_cast<const char *>(&pathSize), sizeof(qint32));
        fileData.append(pathBytes);
        fileData.append(TCP_TAIL);

        if (auto ptr = m_tcpClient.lock())
        {
            if (ptr->isConnected())
            {
                ptr->sendDataAsync(std::vector<uint8_t>(fileData.begin(), fileData.end()));
                sendCount++;
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                LogDebug(" tcp client send count: {},size:{}", sendCount.load(), fileData.size());
            }
        }

        // QFile file(filePath);
        // try
        // {

        //     if (!file.open(QIODevice::ReadOnly))
        //     {
        //         LogError("Failed to open file: {}", filePath.toStdString());
        //         continue;
        //     }
        // }
        // catch (const std::exception &e)
        // {
        //     return;
        // }

        // QByteArray pathBytes = filePath.toUtf8();
        // auto imgdata = file.readAll();
        // file.close();
        // qint32 fileSize = imgdata.size();
        // qint32 pathSize = pathBytes.size();

        // QByteArray fileData;
        // fileData->clear(); // 清空之前的内容

        // fileData->append(TCP_HEADER, TCP_HEADER.size());
        // fileData->append(reinterpret_cast<const char *>(&fileSize), sizeof(qint32));
        // // QByteArray array = file.readAll();
        // fileData->append(imgdata.data(), fileSize);
        // fileData->append(reinterpret_cast<const char *>(&pathSize), sizeof(qint32));
        // fileData->append(pathBytes, pathBytes.size());
        // fileData->append(TCP_TAIL, TCP_TAIL.size());
        // LogError("------------------------file.readAll().data().size:{}", imgdata.size());
        //  LogError("------------------------fileData:{}", fileData->toStdString());

        // // QByteArray pathBytes = filePath.toUtf8();
        // qint32 imageLength = fileData->size();
        // qint32 pathLength = pathBytes.size();
        // payload.append(TCP_HEADER);
        // payload.append(reinterpret_cast<const char*>(&imageLength), sizeof(qint32));
        // payload.append(fileData->data());
        // payload.append(reinterpret_cast<const char*>(&pathLength), sizeof(qint32));
        // payload.append(pathBytes);
        // payload.append(TCP_TAIL);

        // int iSzie = fileData->size();

        // _Kits::LogInfo(" tcp client send count: {}",sendCount);
        // if (m_tcpClient && m_tcpClient->getConnect())
        // {
        //     std::this_thread::sleep_for(std::chrono::milliseconds(10));
        //     if (m_tcpClient->sendData(*fileData))
        //     {
        //         ++sendCount;
        //         QFile::remove(filePath);
        //         _Kits::LogInfo(" tcp client send count: {},size:{}", sendCount, iSzie);
        //     }
        //     else
        //     {
        //         LogError("{} tcp client send failed.", m_tcpName);
        //     }

        //     // _Kits::LogInfo(" send file path:{}", filePath);
        // }
        // else
        // {
        //     LogError("{} tcp client disconnected.", m_tcpName);
        // }
    }
}
} // namespace _Controllers