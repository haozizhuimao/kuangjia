#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>
#include "tis_global/struct_details/sql_struct.h"
#include "tis_global/struct_details/mvb_struct.h"
#include "kits/database/postgresql_interface/PgMvbInfo.h"
#include <vector>
#include <thread>
#include <condition_variable>
#include <json/value.h>
#include <QVariantMap>
namespace _Kits {
class UdpClient;
}
namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;

    void onStart();
    void setConfigSwitch(const TIS_Info::MVBConfig &, const std::string &protocolPath);
    void onRecvSimuteMvbData(const Json::Value &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, MVBController::onStart);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::MVBSimluteHeartData, MVBController::onRecvSimuteMvbData);
    TASK_LIST_END

  private:
    void onUdpDataReceived(std::vector<uint8_t> &&);
    void sendTcmsData(const Json::Value &);
    void onUdpAlarmReceived(std::vector<uint8_t> &&);

  private:
    void udpClientInit();

    using ReceiveCallback = std::function<void(std::vector<uint8_t> &&)>;
    void recvUdpClientBind(const std::string &, const ReceiveCallback &);
    void sendUdpClientBind(const std::string &);
    void heartFunc();
    void sendAliveData();
    uint16_t getConfVersion(const std::string &);
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, Json::Value &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, Json::Value &);
    // 解析trdp协议头
    void parseTrdpHeader(const std::vector<uint8_t> &, TIS_Info::TrdpHeader &);
    // 生成trdp协议头
    void generateTrdpHeader(unsigned int);
    // 界面展示接收数据
    void displayRecvPortData(Json::Value &);
    // 界面展示心跳数据
    void displayHeartData();
    // 解析告警数据
    void parseAmifData(const Json::Value &);
    // 解析故障数据
    void setAmifAlarm(const int, const int, const int, const int, const int);

    void updateCommonInfo(const Json::Value &);
    _Kits::AwaitTask<void> sendMvbCommInfoLoop();
    _Kits::AwaitTask<void> writeMvbInfoToDB();
    std::vector<uint8_t> serializeMVBInfo(const TIS_Info::MVBCommunicationInfo &info);

    void retryStartUdp(std::string_view udpName, std::shared_ptr<_Kits::UdpClient> udpClient);

  private:
    std::atomic_bool m_bHolder = true;
    const std::string m_heartUdpName_netA = "mvb_heart_A"; // A网
    const std::string m_heartUdpName_netB = "mvb_heart_B"; // B网
    const std::string m_mvbTcmsName = "mvb";
    const std::string m_mvbAmifName = "mvb_amif";
    const std::string m_mvbTaskUdpName = "mvb_task";
    const std::string m_mvbTaskRecvName = "mvb_task_recv";
    std::weak_ptr<_Kits::UdpClient> m_heartUdpClient_netA;
    std::weak_ptr<_Kits::UdpClient> m_heartUdpClient_netB;
    std::weak_ptr<_Kits::UdpClient> m_tcmsUdpClient;
    std::weak_ptr<_Kits::UdpClient> m_taskSendUdp;
    std::vector<uint8_t> m_heartData;

    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    int m_headLength = 0;   // trdp协议头长度

    int m_startStation = -1;
    int m_endStation = -1;
    int m_lineDir = -1;
    float m_speed = 0;

    std::vector<TIS_Info::mvb_info> m_mvbInfoSqlvec;
    TIS_Info::mvb_info m_currentMvbInfo;
    TIS_Info::MVBCommunicationInfo m_mvbInfoTcms;
    std::mutex m_mutex;
    std::mutex m_dbMtx;

    TIS_Info::MVBConfig m_mvbConfig;
    uint16_t m_version = 0;

    std::once_flag m_onceFlag;
    std::atomic_bool m_start = false;
    std::shared_ptr<_Kits::database::PgMvbInfo> m_pgMvbInfo;
};
} // namespace _Controllers
