#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "tis_global/enum_public/uc_enum.h"
#include "kits/common/orm_user/MvbInfoSql.h"
#include <QDateTime>
#include <regex>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_heartData.resize(m_headLength + 32, 0);
}
MVBController::~MVBController() noexcept
{
    m_bHolder.store(false, std::memory_order_release);
    if (m_thHeart.joinable())
        m_thHeart.join();
}

void MVBController::onStart()
{
    auto pgClientPtr =
        _Service::DatabaseManager::getPgClient<_Kits::database::DbClientPtr>(_Kits::database::PgClientNames::pg_client_default);
    if (pgClientPtr && !m_pgMvbInfo)
    {
        m_pgMvbInfo = std::make_shared<_Kits::database::PgMvbInfo>(pgClientPtr);
    }
    bool excepted = false;
    if (!m_start.compare_exchange_strong(excepted, true))
    {
        // 防止重复启动
        return;
    }
    // 开始db记录定时器（mvb会接收大量重复数据，定时器刷新频率设置为3s）
    auto io_cortex = _Kits::io_manager::get_executor(_Kits::executor_names::io_database);
    asio::co_spawn(io_cortex, [this]() -> _Kits::AwaitTask<void> { co_await writeMvbInfoToDB(); }, asio::detached);

    auto timer_cortex = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    asio::co_spawn(timer_cortex, [this]() -> _Kits::AwaitTask<void> { co_await sendMvbCommInfoLoop(); }, asio::detached);
}

void MVBController::recvUdpClientBind(const std::string &udpName, const ReceiveCallback &callback)
{
    auto udpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(udpName);
    if (udpClient == nullptr)
    {
        _Kits::LogError("[MVBController] UDP客户端={} 获取失败", udpName);
        return;
    }
    udpClient->subscribe([this, callback](_Kits::UdpClient::SharedDataBuffer data) {
        if (!data)
        {
            return;
        }
        callback(std::vector<uint8_t>(data->begin(), data->end()));
    });

    // tcms启动失败需要重试
    if (udpName == m_mvbTcmsName)
    {
        if (!udpClient->start())
        {
            retryStartUdp(m_mvbTcmsName, udpClient);
        }
        m_tcmsUdpClient = udpClient;
    }
}

void MVBController::udpClientInit()
{
    // MVB tcms公共数据接收
    recvUdpClientBind(m_mvbTcmsName, [this](std::vector<uint8_t> &&data) { onUdpDataReceived(std::move(data)); });
    // MVB告警数据接收
    recvUdpClientBind(m_mvbAmifName, [this](std::vector<uint8_t> &&data) { onUdpAlarmReceived(std::move(data)); });
    // 绑定A网
    sendUdpClientBind(m_heartUdpName_netA);
    // 绑定B网
    sendUdpClientBind(m_heartUdpName_netB);

    // 开启心跳发送
    if (!m_thHeart.joinable())
    {
        m_thHeart = std::thread(&MVBController::heartFunc, this);
    }

    // 绑定任务发送udp
    // auto taskUdp = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_mvbTaskUdpName);
    // if (taskUdp == nullptr)
    // {
    //     _Kits::LogError("[MVBController] UDP客户端={} 获取失败", m_mvbTaskUdpName);
    //     return;
    // }
    // taskUdp->start();
    // m_taskSendUdp = taskUdp;
}

void MVBController::sendUdpClientBind(const std::string &udpName)
{
    // 发送A网数据
    auto heartUdpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(udpName);
    if (heartUdpClient == nullptr)
    {
        _Kits::LogError("[MVBController] UDP客户端={} 获取失败", udpName);
        return;
    }
    if (!heartUdpClient->start())
    {
        retryStartUdp(udpName, heartUdpClient);
    }
    if (udpName == m_heartUdpName_netA)
    {
        m_heartUdpClient_netA = heartUdpClient;
    }
    else if (udpName == m_heartUdpName_netB)
    {
        m_heartUdpClient_netB = heartUdpClient;
    }
}

void MVBController::retryStartUdp(std::string_view udpName, std::shared_ptr<_Kits::UdpClient> udpClient)
{
    // 初始化失败必须重试保证设备能发出生命信号
    auto io_context = _Kits::io_manager::get_executor(executor_names::io_timer);
    asio::co_spawn(
        io_context,
        [this, udpName, udpClient]() -> asio::awaitable<void> {
            constexpr int maxRetryCount = 15;
            int retryCount = 1;
            auto timer = asio::steady_timer(co_await asio::this_coro::executor);
            while (retryCount <= maxRetryCount)
            {
                timer.expires_after(std::chrono::seconds(5));
                co_await timer.async_wait(asio::use_awaitable);
                if (udpClient->start())
                {
                    if (m_heartUdpName_netA == udpName)
                    {
                        m_heartUdpClient_netA = udpClient;
                    }
                    else if (m_heartUdpName_netB == udpName)
                    {
                        m_heartUdpClient_netB = udpClient;
                    }
                    else if (m_mvbTcmsName == udpName)
                    {
                        m_tcmsUdpClient = udpClient;
                    }
                    co_return;
                }
                retryCount++;
                LogError("[MVBController] 网络设置失败重试次数={}", udpName, retryCount);
            }
        },
        asio::detached);
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);

    uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    std::bitset<8> bit(modeData);
    // 1车司机室激活
    outputData["xCab1Occupied"] = static_cast<bool>(bit[0]);
    // 4车司机室激活
    outputData["xCab2Occupied"] = static_cast<bool>(bit[1]);
    // AM模式
    outputData["xAMMode"] = static_cast<bool>(bit[2]);
    // ATP模式
    outputData["xATPMode"] = static_cast<bool>(bit[3]);
    // RM模式
    outputData["xRMMode"] = static_cast<bool>(bit[4]);
    // NRM模式
    outputData["xNRMMode"] = static_cast<bool>(bit[5]);
    // 列车上行
    outputData["xTrainUpLine"] = static_cast<bool>(bit[6]);
    // 列车下行
    outputData["xTrainDownLine"] = static_cast<bool>(bit[7]);

    uint8_t panData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    std::bitset<8> bit1(panData);
    // 时间设置有效位
    outputData["xTimeSetValid"] = static_cast<bool>(bit1[0]);
    // 2车受电弓升起
    outputData["xPanto1UpSt"] = static_cast<bool>(bit1[5]);
    // 3车受电弓升起
    outputData["xPanto2UpSt"] = static_cast<bool>(bit1[6]);

    uint8_t doorData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    std::bitset<8> bit2(doorData);
    // 列车开门信号
    outputData["xALLDoorOpen"] = static_cast<bool>(bit2[0]);
    // 列车关门信号
    outputData["xALLDoorCLoseLock"] = static_cast<bool>(bit2[1]);
    // 时间
    outputData["bYear"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["bMonth"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["bDay"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    outputData["bHour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 8);
    outputData["bMinute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
    outputData["bSecond"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 10);
    // 线路区域
    outputData["usLocation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 11);
    // 列车参考速度
    outputData["uiSpd"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    // 站点信息-起始站
    outputData["uiStartStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
    // 站点信息-当前站
    outputData["uiCurrentStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 16);
    // 站点信息-下一站
    outputData["uiNextStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 18);
    // 站点信息-终点站
    outputData["uiEndStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 20);
    // 离下一站距离
    outputData["uiNextStopDis"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 22);
    // 列车车次号
    outputData["uiTrainNumber"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 24);
    // 网压
    outputData["uiLineVoltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 26);
    // 网流
    outputData["wLineCurrent"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 28);
    // 线ID
    outputData["usLineID"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 30);
}

void MVBController::displayRecvPortData(Json::Value &portData)
{
    // 给页面传递数据展示
    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt.toStdString();

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

void MVBController::onUdpAlarmReceived(std::vector<uint8_t> &&data)
{
    auto alarmData = std::move(data);
    std::string jsonStr(reinterpret_cast<const char *>(alarmData.data()), alarmData.size());
    Json::Value jsonValue = stringToJson(jsonStr);
    if (jsonValue["msgType"].asString() == "amif")
    {
        parseAmifData(jsonValue["data"]);
    }
    LogInfo("[MVBController] 接收告警数据 = {}", jsonStr);
}

void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConf, const std::string &protocolPath)
{
    m_mvbConfig = std::move(mvbConf);
    m_version = getConfVersion(m_mvbConfig.mvbPublicCfg.version);
    udpClientInit();
}

void MVBController::parseAmifData(const Json::Value &jsonObj)
{
    TIS_Info::AmifAlarmType amifType = static_cast<TIS_Info::AmifAlarmType>(jsonObj["alarmType"].asInt());
    TIS_Info::AmifAlarmLevel amifLevel = static_cast<TIS_Info::AmifAlarmLevel>(jsonObj["alarmLevel"].asInt());
    int alarmValue = jsonObj["alarmValue"].asInt();
    // int targetOffset = amifLevel - 1; // 目标位偏移

    switch (amifType)
    {
    case TIS_Info::AmifAlarmType::AmifAlarmType_PanAttitude: {
        // 受电弓姿态
        if (!m_mvbConfig.amifCfg.panAttitude)
        {
            break;
        }
        setAmifAlarm(m_headLength + 2, 0, 0, 0, 1);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    std::bitset<8> amifBit = m_heartData.at(offset);
    // 该类型超限所有的状态复位
    for (int i = startBit; i <= endBit; i++)
    {
        amifBit.set(i, 0);
    }
    // 设置目标位超限值
    amifBit.set(targetBit, alarmValue);
    m_heartData.at(offset) = static_cast<uint8_t>(amifBit.to_ulong());
}

void MVBController::onUdpDataReceived(std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        LogError("[MVBController] 接收数据长度错误,长度={}", data.size());
        return;
    }
    TIS_Info::TrdpHeader header;
    parseTrdpHeader(data, header);
    LogInfo("recv all udp comId={},data={}", header.comId, ByteArrayTools::hexString(data.data(), data.size()));

    Json::Value jsonValue;
    std::vector<uint8_t> processData(data.begin() + m_headLength, data.end());
    if (header.comId == m_mvbConfig.netPortCfg.commonPortNetB)
    {
        parseCommonData(processData, jsonValue);
        sendTcmsData(jsonValue);
        updateCommonInfo(jsonValue);
        jsonValue["dataSource"] = "ningxiang_common_data";
    }
    displayRecvPortData(jsonValue);
}

void MVBController::sendTcmsData(const Json::Value &recvData)
{
    int curStartStation = recvData["uiStartStation"].asInt();
    int curEndStation = recvData["uiEndStation"].asInt();
    // 行别切换
    TIS_Info::MVBCommunicationInfo mvbCommInfo;
    mvbCommInfo.startStation = curStartStation;
    mvbCommInfo.endStation = curEndStation;
    mvbCommInfo.currentStationId = recvData["uiCurrentStation"].asInt();
    mvbCommInfo.strLineName = m_mvbConfig.mvbPublicCfg.lineName;
    mvbCommInfo.dSpeed = recvData["uiSpd"].asDouble() / 10;
    if (m_startStation != curStartStation && m_endStation != curEndStation && curStartStation != 0 && curEndStation != 0)
    {
        m_lineDir = curStartStation < curEndStation ? 0 : 1;
        m_startStation = curStartStation;
        m_endStation = curEndStation;
        LogInfo("[MVBController] 行别切换，当前行别={},开始站={}，结束站={}，当前站={}，当前速度={}",
                m_lineDir,
                m_startStation,
                m_endStation,
                mvbCommInfo.currentStationId,
                mvbCommInfo.dSpeed);
    }
    mvbCommInfo.nLineDirection = m_lineDir;
    // mvbCommInfo.nDirection = 0;
    mvbCommInfo.strTrainNum = recvData["uiTrainNumber"].asString();
    if (recvData.isMember("usLocation"))
    {
        mvbCommInfo.trainPosition = recvData["usLocation"].asInt();
    }
    if (recvData.isMember("uiLineVoltage"))
    {
        mvbCommInfo.voltage = recvData["uiLineVoltage"].asUInt();
    }
    if (recvData.isMember("wLineCurrent"))
    {
        mvbCommInfo.electric = recvData["wLineCurrent"].asInt();
    }
    mvbCommInfo.useVolEle = m_mvbConfig.mvbPublicCfg.sendVolEle;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_mvbInfoTcms = mvbCommInfo;
    }
    //_Service::MVBCommunication::sendMVBComInfo(mvbCommInfo);
}

void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
{
    if (data.size() < m_headLength)
    {
        return;
    }
    header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
    header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
    header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
    header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
    header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
    header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
}

void MVBController::generateTrdpHeader(unsigned int comId)
{
    TIS_Info::TrdpHeader header;
    header.comId = comId;
    header.sequenceCounter = m_aliveId;
    header.datasetLength = 32;
    header.protocolVersion = 0x0100;
    header.msgType = 0x5064;
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, m_aliveId, 0);
    ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.protocolVersion, 4);
    ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.msgType, 6);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comId, 8);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.etbTopoCnt, 12);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.opTrnTopoCnt, 16);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.datasetLength, 20);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.reserved01, 24);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyComId, 28);
    ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyIpAddress, 32);
    // 生成校验码
    header.headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, 36);
    LogInfo("sheader.headerFcs={}", header.headerFcs);
    // 协议里面定义的是大端，但是四方所是按小端来的
    ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, header.headerFcs, 36);
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(500);
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::sendAliveData()
{
    ++m_aliveId; // 心跳id自增
    // 应用数据
    ByteArrayTools::writeToVectorBE(m_heartData, m_aliveId, m_headLength + 0);
    std::call_once(m_onceFlag, [this]() {
        // 软件版本
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_version, m_headLength + 2);
        // 自检结果
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, 1, m_headLength + 6);
        // 受电弓严重异常
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 7, 0, false);
    });
    // 发送A网数据
    generateTrdpHeader(m_mvbConfig.netPortCfg.heartPortNetA);
    if (auto strongPtr = m_heartUdpClient_netA.lock())
    {
        auto headvector = m_heartData;
        strongPtr->post(m_heartUdpName_netA, std::move(headvector));
    }
    // 发送B网的数据
    generateTrdpHeader(m_mvbConfig.netPortCfg.heartPortNetB);
    if (auto strongPtr = m_heartUdpClient_netB.lock())
    {
        auto headvector = m_heartData;
        strongPtr->post(m_heartUdpName_netB, std::move(headvector));
    }
    std::vector<uint8_t> processData(m_heartData.begin() + m_headLength, m_heartData.end());
    LogInfo("[MVBController] 发送的心跳数据={}", ByteArrayTools::hexString(processData.data(), processData.size()));
    displayHeartData();
}

uint16_t MVBController::getConfVersion(const std::string &versionStr)
{
    if (versionStr.empty())
    {
        return 0;
    }

    int majorVersion = 0;
    int minorVersion = 0;
    int patchVersion = 0;

    std::smatch m;
    static const std::regex whole(R"(\b(\d+)\.(\d+)\.(\d+)\b)");
    if (!std::regex_search(versionStr, m, whole))
    {
        return 0;
    }
    majorVersion = std::stoi(m[1]);
    minorVersion = std::stoi(m[2]);
    patchVersion = std::stoi(m[3]);
    return (majorVersion << 8) | (minorVersion << 4) | (patchVersion & 0x0F);
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 软件版本High
    outputData["versionHigh"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    // 软件版本Low
    outputData["versionLow"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    // 自检结果
    outputData["selfCheckStat"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    // 受电弓严重异常
    uint8_t panData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    std::bitset<8> bit(panData);
    outputData["flt"] = static_cast<bool>(bit[0]);
}

void MVBController::onRecvSimuteMvbData(const Json::Value &simulateHeart)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    // 软件版本High
    if (simulateHeart.isMember("versionHigh"))
    {
        uint8_t versionHigh = static_cast<uint8_t>(simulateHeart["versionHigh"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, versionHigh, m_headLength + 2);
    }
    // 软件版本Low
    if (simulateHeart.isMember("versionLow"))
    {
        uint8_t versionLow = static_cast<uint8_t>(simulateHeart["versionLow"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, versionLow, m_headLength + 3);
    }
    // 自检结果
    if (simulateHeart.isMember("selfCheckStat"))
    {
        uint8_t checkStatus = static_cast<uint8_t>(simulateHeart["selfCheckStat"].asUInt());
        ByteArrayTools::writeToVectorBE<uint8_t>(m_heartData, checkStatus, m_headLength + 6);
    }
    // 受电弓严重异常
    if (simulateHeart.isMember("flt"))
    {
        uint8_t fltVal = static_cast<uint8_t>(simulateHeart["flt"].asUInt());
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 7, 0, fltVal);
    }
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    Json::Value heartData;
    std::vector<uint8_t> data(m_heartData.begin() + m_headLength, m_heartData.end());
    parseHeartData(data, heartData);

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    heartData["sendTime"] = timeFmt.toStdString();
    heartData["dataSource"] = "ningxiang_heart";

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, heartData);
}

void MVBController::updateCommonInfo(const Json::Value &commonData)
{
    std::lock_guard<std::mutex> mtx(m_dbMtx);
    m_currentMvbInfo.cur_station_id = commonData["uiCurrentStation"].asInt();
    m_currentMvbInfo.next_station_id = commonData["uiNextStation"].asInt();
    m_currentMvbInfo.start_station_id = commonData["uiStartStation"].asInt();
    m_currentMvbInfo.end_station_id = commonData["uiEndStation"].asInt();
    m_currentMvbInfo.line_id = -1;
    m_currentMvbInfo.train_id = commonData["uiTrainNumber"].asInt();
    m_currentMvbInfo.iyear = commonData["bYear"].asInt();
    m_currentMvbInfo.imonth = commonData["bMonth"].asInt();
    m_currentMvbInfo.iday = commonData["bDay"].asInt();
    m_currentMvbInfo.ihour = commonData["bHour"].asInt();
    m_currentMvbInfo.iminute = commonData["bMinute"].asInt();
    m_currentMvbInfo.isecond = commonData["bSecond"].asInt();
    m_currentMvbInfo.speed = commonData["uiSpd"].asFloat();
    m_currentMvbInfo.voltage = commonData["uiLineVoltage"].asFloat();
    m_currentMvbInfo.elec = commonData["wLineCurrent"].asFloat();
    m_currentMvbInfo.atb_mode = commonData["xATPMode"].asInt();
    m_currentMvbInfo.panto_up = commonData["xPanto1UpSt"].asInt();
}

_Kits::AwaitTask<void> MVBController::sendMvbCommInfoLoop()
{
    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    while (m_bHolder.load(std::memory_order_acquire))
    {
        asio::steady_timer timer(io_timer, std::chrono::milliseconds(512));
        co_await timer.async_wait(asio::use_awaitable);

        TIS_Info::MVBCommunicationInfo info;
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            info = m_mvbInfoTcms;
        }
        if (info.startStation != -1 && info.currentStationId != -1 && info.endStation != -1)
        {
            _Service::MVBCommunication::sendMVBComInfo(info);
            // if (auto taskUdp = m_taskSendUdp.lock())
            // {
            //     std::vector<uint8_t> mvbVec = serializeMVBInfo(info);
            //     taskUdp->post(m_mvbTaskRecvName, std::move(mvbVec));
            // }
        }
    }
    co_return;
}

// 发送端
std::vector<uint8_t> MVBController::serializeMVBInfo(const TIS_Info::MVBCommunicationInfo &info)
{
    Json::Value json;
    json["strTrainNum"] = info.strTrainNum;
    json["strLineName"] = info.strLineName;
    json["trainPosition"] = info.trainPosition;
    json["startStation"] = info.startStation;
    json["endStation"] = info.endStation;
    json["currentStationId"] = info.currentStationId;
    json["nextStation"] = info.nextStation;
    json["dSpeed"] = info.dSpeed;
    json["nLineDirection"] = info.nLineDirection;
    json["nDirection"] = info.nDirection;
    json["useVolEle"] = info.useVolEle;
    json["voltage"] = info.voltage;
    json["electric"] = info.electric;

    std::string jsonStr = json.toStyledString();
    return std::vector<uint8_t>(jsonStr.begin(), jsonStr.end());
}

_Kits::AwaitTask<void> MVBController::writeMvbInfoToDB()
{
    auto io_timer = _Kits::io_manager::get_executor(_Kits::executor_names::io_timer);
    while (m_bHolder.load(std::memory_order_acquire))
    {
        TIS_Info::mvb_info mvbInfo;
        {
            std::lock_guard<std::mutex> dbMtx(m_dbMtx);
            mvbInfo = m_currentMvbInfo;
        }
        // 只保存有效数据
        if (m_pgMvbInfo && mvbInfo.end_station_id > 0 && mvbInfo.cur_station_id > 0 && mvbInfo.next_station_id > 0)
        {
            if (m_pgMvbInfo->insert(std::move(mvbInfo)) < 0)
            {
                LogError("[MVBController] 保存mvb_info到数据库失败!");
            }
        }
        asio::steady_timer timer(io_timer, std::chrono::seconds(3));
        co_await timer.async_wait(asio::use_awaitable);
    }
}
} // namespace _Controllers
