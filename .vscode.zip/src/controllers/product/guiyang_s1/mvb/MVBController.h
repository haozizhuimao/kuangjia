#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <atomic>
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/json.h>

namespace _Kits {
class UdpClient;
class TcpSession;
} // namespace _Kits

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;

    void onStart();
    void afterMVBData(const int, const std::vector<uint8_t> &);
    // 使用阻塞方式初始化配置信息，防止异步导致未配置完成其他接口已经使用
    void setConfigHeart(const TIS_Info::DuagonCardData &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, MVBController::onStart);
    SYNC_TASK_ADD(_Service::MVBDistribution::setConfigHeart, MVBController::setConfigHeart);
    SYNC_TASK_ADD(_Service::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    ASYNC_TASK_ADD(_Service::MVBDistribution::duagonData, MVBController::afterMVBData);
    TASK_LIST_END

  private:
    void setConfigSwitch(const TIS_Info::MVBConfig &);

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&data);
    void heartFunc();
    void sendAliveData();
    // 解析车辆数据
    void parseCarInfo(const std::vector<uint8_t> &, Json::Value &);
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, Json::Value &);
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, Json::Value &);
    // 界面展示接收数据
    void displayRecvPortData(const int, Json::Value &);
    // 界面展示心跳数据
    void displayHeartData();
    // 解析处理超限数据
    void parseAmifData(const Json::Value &);
    // 解析处理模块数据
    void parseAsatData(const Json::Value &);

    void setAsatStatus(const int, const int, const int);
    void setAmifAlarm(const int, const int, const int, const int, const int);

    uint16_t getConfVersion(const std::string &versionStr);

    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全
    std::thread m_thHeart;
    std::atomic_bool m_bHolder = true;
    const std::string m_tcpName = "mvb";
    const std::string m_udpName = "mvb";
    std::weak_ptr<_Kits::TcpSession> m_tcpClient;
    TIS_Info::DuagonCardData m_heartData;
    std::vector<uint8_t> m_recvData;
    TIS_Info::MVBConfig m_mvbConfig;
    std::once_flag m_onceflag;
    uint16_t m_version = 0;
};
} // namespace _Controllers
