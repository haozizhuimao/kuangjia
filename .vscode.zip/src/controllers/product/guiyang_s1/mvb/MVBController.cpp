﻿#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/communication/asio/tcp_client/TcpSession.h"
#include "tis_global/enum_public/mvb_enum.h"
#include "service/AppInterface.h"
#include <regex>
#include "kits/utility/datetime/datetime.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

MVBController::MVBController()
{
    m_recvData.resize(50, 0);
}
MVBController::~MVBController() noexcept
{
    m_bHolder = false;
    if (m_thHeart.joinable())
        m_thHeart.join();
}
void MVBController::afterMVBData(const int portId, const std::vector<uint8_t> &data)
{
    Json::Value mapData;
    constexpr int offset = 16;
    if (portId == m_mvbConfig.netPortCfg.commonPortNetA)
    {
        // VCU向所有设备发送的公共数据 长度16字节固定
        std::copy(data.begin(), data.end(), m_recvData.begin());
        parseCommonData(data, mapData);
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        // VCU发送给弓网的数据 偏移16字节存放
        std::copy(data.begin(), data.end(), m_recvData.begin() + offset);
        parseCarInfo(data, mapData);
    }

    displayRecvPortData(portId, mapData);
    LogInfo("[MVBController] 端口={},数据={}", portId, ByteArrayTools::hexString(data.data(), data.size()));

    auto client = m_tcpClient.lock();
    if (!client)
    {
        LogError("[MVBController] 客户端={},断开连接", m_tcpName);
        return;
    }
    std::vector<uint8_t> tmpData = m_recvData;
    client->post(std::move(tmpData));
}
void MVBController::setConfigHeart(const TIS_Info::DuagonCardData &config)
{
    m_heartData = config;
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&datas)
{
    auto recvData = std::move(datas);
    std::string jsonStr(reinterpret_cast<const char *>(recvData.data()), recvData.size());
    Json::Value jsonValue = stringToJson(jsonStr);
    LogInfo("[MVBController] 接收告警数据= {}", jsonStr);
    if (jsonValue["msgType"].asString() == "amif")
    {
        parseAmifData(jsonValue["data"]);
    }
    else if (jsonValue["msgType"].asString() == "asat")
    {
        parseAsatData(jsonValue["data"]);
    }
}

uint16_t MVBController::getConfVersion(const std::string &versionStr)
{
    if (versionStr.empty())
        return 0;

    static const std::regex verRegex(R"(\b(\d+)\.(\d+)\.(\d+)\b)");
    std::smatch m;
    if (!std::regex_search(versionStr, m, verRegex))
        return 0;

    unsigned major = static_cast<unsigned>(std::stoi(m[1]));
    unsigned minor = static_cast<unsigned>(std::stoi(m[2]));
    unsigned patch = static_cast<unsigned>(std::stoi(m[3]));

    major = std::clamp(major, 0u, 15u);  // 4 bit
    minor = std::clamp(minor, 0u, 15u);  // 4 bit
    patch = std::clamp(patch, 0u, 255u); // 8 bit（整个低字节）

    uint16_t hiByte = static_cast<uint16_t>((major << 4) | minor);
    return static_cast<uint16_t>((hiByte << 8) | patch);
}

void MVBController::setConfigSwitch(const TIS_Info::MVBConfig &mvbConf)
{
    m_mvbConfig = mvbConf;
    m_version = getConfVersion(m_mvbConfig.mvbPublicCfg.version);
}

void MVBController::sendAliveData()
{
    ++m_aliveId; // 心跳id自增
    ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData.m_portData, m_aliveId, 0);
    // 初始化模块状态为异常，模块连接成功后模块状态切换为正常状态
    std::call_once(m_onceflag, [this]() {
        // 弓网燃弧测量模块
        if (m_mvbConfig.asatCfg.arcMode)
        {
            setAsatStatus(10, 1, 1);
        }
        // 拉出值导高测量模块
        if (m_mvbConfig.asatCfg.geoparMode)
        {
            setAsatStatus(9, 7, 1);
        }
        // 接触线温度测量模块
        if (m_mvbConfig.asatCfg.temperatureMode)
        {
            setAsatStatus(10, 0, 1);
        }
        // 受电弓结构故障监测模块
        if (m_mvbConfig.asatCfg.pantoMode)
        {
            setAsatStatus(10, 2, 1);
        }
        // 系统通信模块
        if (m_mvbConfig.asatCfg.sysCommunicationMode)
        {
            setAsatStatus(10, 3, 1);
        }
        // 接触线磨耗检测模块
        if (m_mvbConfig.asatCfg.abrvalMode)
        {
            setAsatStatus(11, 3, 1);
        }
    });
    // 软件版本
    ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData.m_portData, m_version, 12);
    _Service::MVBDistribution::dataToDuagonCard(m_heartData);
    displayHeartData();

    // TODO 测试
    // if (auto client = m_tcpClient.lock())
    // {
    //     std::vector<uint8_t> tmpData = {0x7B, 0x00, 0x19, 0x0C, 0x16, 0x08, 0x27, 0x00, 0x00, 0x00, 0x00, 0x07, 0x0B,
    //                                     0x00, 0x00, 0x00, 0x80, 0x01, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,
    //                                     0xFF, 0xFF, 0x03, 0x46, 0x03, 0x46, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    //                                     0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xCC, 0xCC};
    //     client->post(std::move(tmpData));
    // }
}

void MVBController::heartFunc()
{
    while (m_bHolder)
    {
        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= m_heartData.m_nextClock)
        {
            m_heartData.m_nextClock = now + m_heartData.portConfig.m_interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, m_heartData.m_nextClock);

        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

void MVBController::parseCarInfo(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    std::bitset<8> byte0(data[0]);
    // 运维模式
    outputData["panrun"] = static_cast<bool>(byte0[0]);
    // 维护模式
    outputData["panmnt"] = static_cast<bool>(byte0[1]);
    // 全自动报站
    outputData["autosign"] = static_cast<bool>(byte0[6]);
    // 2车受电弓升弓标志位
    outputData["panrise2"] = static_cast<bool>(byte0[7]);

    std::bitset<8> byte1(data.at(1));
    // 5车受电弓升弓标志位
    outputData["panrise5"] = static_cast<bool>(byte1[0]);
    // 自动折返
    outputData["atbsign"] = static_cast<bool>(byte1[1]);
    // 休眠指令
    outputData["sleepmode"] = static_cast<bool>(byte1[2]);

    // 离站及预到站信息
    outputData["tardis"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 2);
    // 终点站
    outputData["endstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    // 当前站
    outputData["currtstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    // 下一站
    outputData["nextstationid"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);
    // Tc1轮径（来自于DDU）；车轮直径770-840mm，1mm/bit（0x00=0mm，0x348=840mm）
    outputData["wd1"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    // Tc2轮径（来自于DDU）；车轮直径770-840mm，1mm/bit（0x00=0mm，0x348=840mm）
    outputData["wd2"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 14);
}
void MVBController::parseCommonData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // VCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);
    // 速度
    outputData["realspeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 8);
    // 列车编号
    outputData["trainset"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 10);

    std::bitset<8> bits(data[12]);
    // 时间有效
    outputData["timevalid"] = static_cast<bool>(bits[0]);
    // 速度有效
    outputData["speedvalid"] = static_cast<bool>(bits[1]);
    // 1车司机室激活
    outputData["cabact_1"] = static_cast<bool>(bits[2]);
    // 6车司机室激活
    outputData["cabact_6"] = static_cast<bool>(bits[3]);
    // ATO模式激活
    outputData["ATOmode"] = static_cast<bool>(bits[4]);
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    // VCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);

    std::bitset<8> bits8(data[8]);
    // 拉出值严重超限
    outputData["catOffGraveALarm"] = static_cast<bool>(bits8[0]);
    // 拉出值中等超限
    outputData["catOffMiddlingALarm"] = static_cast<bool>(bits8[1]);
    // 拉出值轻微超限
    outputData["catOffSlightALarm"] = static_cast<bool>(bits8[2]);
    // 导高严重超限
    outputData["catHeiGraveALarm"] = static_cast<bool>(bits8[3]);
    // 导高中等超限
    outputData["catHeiMiddlingALarm"] = static_cast<bool>(bits8[4]);
    // 导高轻微超限
    outputData["catHeiSlightALarm"] = static_cast<bool>(bits8[5]);
    // 弓网接触线温度严重超限
    outputData["tempGraveALarm"] = static_cast<bool>(bits8[6]);
    // 弓网接触线温度中等超限
    outputData["tempMiddlingALarm"] = static_cast<bool>(bits8[7]);

    std::bitset<8> bits9(data[9]);
    // 弓网接触线温度轻微超限
    outputData["tempSlightALarm"] = static_cast<bool>(bits9[0]);
    // 弓网燃弧严重超限
    outputData["arcGraveALarm"] = static_cast<bool>(bits9[1]);
    // 弓网燃弧中等超限
    outputData["arcMiddlingALarm"] = static_cast<bool>(bits9[2]);
    // 弓网燃弧轻微超限
    outputData["arcSlightALarm"] = static_cast<bool>(bits9[3]);
    // 受电弓结构严重故障
    outputData["strGraveALarm"] = static_cast<bool>(bits9[4]);
    // 受电弓结构中等故障
    outputData["strMiddlingALarm"] = static_cast<bool>(bits9[5]);
    // 受电弓结构轻微故障
    outputData["strSlightALarm"] = static_cast<bool>(bits9[6]);
    // 拉出值导高测量模块故障
    outputData["catHeiModeFault"] = static_cast<bool>(bits9[7]);

    std::bitset<8> bits10(data[10]);
    // 接触线温度测量模块故障
    outputData["tmpModFault"] = static_cast<bool>(bits10[0]);
    // 弓网燃弧测量模块故障
    outputData["arcModFault"] = static_cast<bool>(bits10[1]);
    // 受电弓结构故障监测模型故障
    outputData["iPanModStatus"] = static_cast<bool>(bits10[2]);
    // 系统通信模块故障
    outputData["sysNetModStatus"] = static_cast<bool>(bits10[3]);
    // 准备休眠信号
    outputData["readyToSleep"] = static_cast<bool>(bits10[4]);
    // 弓网系统严重故障
    outputData["bowNetGraveALarm"] = static_cast<bool>(bits10[5]);
    // 弓网系统中等故障
    outputData["bowNetMiddlingALarm"] = static_cast<bool>(bits10[6]);
    // 弓网系统轻微故障
    outputData["bowNetSlightALarm"] = static_cast<bool>(bits10[7]);

    std::bitset<8> bits11(data[11]);
    // 接触线磨耗值严重超限
    outputData["abrValGraveALarm"] = static_cast<bool>(bits11[0]);
    // 接触线磨耗值中等超限
    outputData["abrValMiddlingALarm"] = static_cast<bool>(bits11[1]);
    // 接触线磨耗值轻微超限
    outputData["abrValSlightALarm"] = static_cast<bool>(bits11[2]);
    // 接触线磨耗检测模块故障
    outputData["abrValOModStatus"] = static_cast<bool>(bits11[3]);
    // 运行模式
    outputData["panrun"] = static_cast<bool>(bits11[4]);
    // 维护模式
    outputData["panmnt"] = static_cast<bool>(bits11[5]);

    // 弓网版本
    // outputData["version"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    outputData["versionHigh"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 12);
    outputData["versionLow"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 13);
}

void MVBController::displayRecvPortData(const int portId, Json::Value &portData)
{
    Json::Value mapData;
    portData["recvTime"] = _Kits::datetime::current_string(_Kits::datetime::Formats::STANDARD_WITH_MSEC);

    if (portId == m_mvbConfig.netPortCfg.commonPortNetA)
    {
        portData["dataSource"] = "guiyangs1_common_data";
    }
    else if (portId == m_mvbConfig.netPortCfg.tcmsPortNetA)
    {
        portData["dataSource"] = "guiyangs1_ccu_data";
    }
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

void MVBController::displayHeartData()
{
    Json::Value heartData;
    parseHeartData(m_heartData.m_portData, heartData);
    heartData["sendTime"] = _Kits::datetime::current_string(_Kits::datetime::Formats::STANDARD_WITH_MSEC);
    heartData["dataSource"] = "guiyangs1_heart";

    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, heartData);
}

void MVBController::parseAmifData(const Json::Value &jsonObj)
{
    TIS_Info::AmifAlarmType_GuiYang amifType = static_cast<TIS_Info::AmifAlarmType_GuiYang>(jsonObj["alarmType"].asInt());
    TIS_Info::AmifAlarmLevel amifLevel = static_cast<TIS_Info::AmifAlarmLevel>(jsonObj["alarmLevel"].asInt());
    int alarmValue = jsonObj["alarmValue"].asInt();
    int targetOffset = amifLevel - 1; // 目标位偏移

    switch (amifType)
    {
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_Temp: {
        if (!m_mvbConfig.amifCfg.temperature)
        {
            break;
        }
        // 接触线温度超限跨字节处理
        if (amifLevel == TIS_Info::AmifAlarmLevel::AmifAlarmLevel_Level3)
        {
            setAmifAlarm(9, 0, 0, 0, alarmValue);
            // 清理其它位
            setAmifAlarm(8, 6, 7, 6, 0);
            setAmifAlarm(8, 6, 7, 7, 0);
        }
        else
        {
            setAmifAlarm(8, 6, 7, 6 + targetOffset, alarmValue);
            setAmifAlarm(9, 0, 0, 0, 0);
        }
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_AbrValOutlimit: {
        // 弓网接触线磨耗值超限
        if (!m_mvbConfig.amifCfg.abrval)
        {
            break;
        }
        setAmifAlarm(11, 0, 2, targetOffset, alarmValue);
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_Arc: {
        // 燃弧超限
        if (!m_mvbConfig.amifCfg.arc)
        {
            break;
        }
        setAmifAlarm(9, 1, 3, 1 + targetOffset, alarmValue);
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_BowSystem: {
        // 弓网系统超限
        if (!m_mvbConfig.amifCfg.bowSystem)
        {
            break;
        }
        setAmifAlarm(10, 5, 7, 5 + targetOffset, alarmValue);
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_CatHei: {
        // 导高超限
        if (!m_mvbConfig.amifCfg.catHei)
        {
            break;
        }
        setAmifAlarm(8, 3, 5, 3 + targetOffset, alarmValue);
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_CatOff: {
        // 拉出值超限
        if (!m_mvbConfig.amifCfg.catOff)
        {
            break;
        }
        setAmifAlarm(8, 0, 2, targetOffset, alarmValue);
        break;
    }
    case TIS_Info::AmifAlarmType_GuiYang::AmifAlarmType_GuiYang_Str: {
        // 受电弓结构超限
        if (!m_mvbConfig.amifCfg.panStructure)
        {
            break;
        }
        setAmifAlarm(9, 4, 6, 4 + targetOffset, alarmValue);
        break;
    }
    default:
        break;
    }
}

void MVBController::onStart()
{
    auto tcpClientPtr = _Service::TcpClientCenter::getClient<std::shared_ptr<_Kits::TcpSession>>(m_tcpName);
    if (nullptr == tcpClientPtr)
    {
        _Kits::LogError("[MVBController] 客户端={}, 获取TCP会话失败", m_tcpName);
        return;
    }
    tcpClientPtr->start();
    m_tcpClient = tcpClientPtr;

    auto udpClientPtr = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_udpName);
    if (nullptr == udpClientPtr)
    {
        _Kits::LogError("[MVBController] 客户端={}, 获取UDP会话失败", m_udpName);
        return;
    }
    udpClientPtr->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) {
        if (!datas)
        {
            return;
        }
        onUdpDataReceived(std::vector<uint8_t>(datas->begin(), datas->end()));
    });
}

void MVBController::parseAsatData(const Json::Value &jsonObj)
{
    TIS_Info::AsatModuleType_GuiYang moduleType = static_cast<TIS_Info::AsatModuleType_GuiYang>(jsonObj["moduleType"].asInt());
    int moduleStatus = jsonObj["moduleState"].asInt();

    switch (moduleType)
    {
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_ArcMod: {
        // 弓网燃弧测量模块
        if (!m_mvbConfig.asatCfg.arcMode)
        {
            break;
        }
        setAsatStatus(10, 1, moduleStatus);
        break;
    }
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_GeoParMon: {
        // 拉出值导高测量模块
        if (!m_mvbConfig.asatCfg.geoparMode)
        {
            break;
        }
        setAsatStatus(9, 7, moduleStatus);
        break;
    }
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_InfMod: {
        // 接触线温度测量模块
        if (!m_mvbConfig.asatCfg.temperatureMode)
        {
            break;
        }
        setAsatStatus(10, 0, moduleStatus);
        break;
    }
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_PantoMod: {
        // 受电弓结构故障监测模块
        if (!m_mvbConfig.asatCfg.pantoMode)
        {
            break;
        }
        setAsatStatus(10, 2, moduleStatus);
        break;
    }
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_SysCommunicationMode: {
        // 系统通信模块
        if (!m_mvbConfig.asatCfg.sysCommunicationMode)
        {
            break;
        }
        setAsatStatus(10, 3, moduleStatus);
        break;
    }
    case TIS_Info::AsatModuleType_GuiYang::AsatModuleType_GuiYang_AbrValMod: {
        // 接触线磨耗检测模块
        if (!m_mvbConfig.asatCfg.abrvalMode)
        {
            break;
        }
        setAsatStatus(11, 3, moduleStatus);
        break;
    }
    default:
        break;
    }
}

void MVBController::setAsatStatus(const int offset, const int targetBit, const int moduleState)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    // 设置目标位模块状态
    std::bitset<8> asatBit = m_heartData.m_portData.at(offset);
    asatBit.set(targetBit, moduleState);
    m_heartData.m_portData.at(offset) = static_cast<uint8_t>(asatBit.to_ulong());
}

void MVBController::setAmifAlarm(const int offset, const int startBit, const int endBit, const int targetBit, const int alarmValue)
{
    if (targetBit < 0 || targetBit > 7)
    {
        return;
    }
    std::bitset<8> amifBit = m_heartData.m_portData.at(offset);
    // 该类型超限所有的状态复位
    for (int i = startBit; i <= endBit; i++)
    {
        amifBit.set(i, 0);
    }
    // 设置目标位超限值
    amifBit.set(targetBit, alarmValue);
    m_heartData.m_portData.at(offset) = static_cast<uint8_t>(amifBit.to_ulong());
}

} // namespace _Controllers
