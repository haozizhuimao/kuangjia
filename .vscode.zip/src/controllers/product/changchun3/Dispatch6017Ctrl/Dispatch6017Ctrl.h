#pragma once

#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/primary/controller_base/ControllerBase.h"
////#include "tis_global/Function.h"
#include "kits/third_devices/udp_6017/Udp6017.h"
#include "tis_global/Struct.h"

#include <unordered_map>
#include <thread>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#endif // emit
#endif // Q_MOC_RUN

#include <utility>
#include <memory>

#include "tis_global/struct_details/press_acc_collect_struct.h"

namespace _Controllers {
class Dispatch6017Ctrl : public ControllerBase<Dispatch6017Ctrl>
{
  public:
    explicit Dispatch6017Ctrl();
    virtual ~Dispatch6017Ctrl() noexcept;

    void onInitChannelInfo(const std::vector<TIS_Info::Info6017>);
    void onStop6017Ctrl();
    void onRecvTaskInfo(const TIS_Info::TaskInfo &taskInfo);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::Dispatch6017::sendConfigToCtrl, Dispatch6017Ctrl::onInitChannelInfo);
    SYNC_TASK_ADD(TIS_Info::Dispatch6017::stop6017Ctrl, Dispatch6017Ctrl::onStop6017Ctrl);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, Dispatch6017Ctrl::onRecvTaskInfo);
    SYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, Dispatch6017Ctrl::onRecvTaskInfo);
    TASK_LIST_END

  private:
    std::unordered_map<QString, std::shared_ptr<_Kits::Udp6017>> mmap_dispatchUdp6017_;
    std::unordered_map<QString, TIS_Info::Info6017> mmap_channelInfo_;
    std::unordered_map<QString, tbb::concurrent_queue<std::vector<double>>> mvec_dispatch6017Ctrl_;

    std::unordered_map<QString, std::vector<TIS_Info::NeturalData6017>> mvec_dispatch6017_naturalData_;
    std::mutex m_mutex_naturalData;
    void writeNaturalData(QString index);

    std::thread _m_thread_process;
    std::atomic_bool _mb_thread_process_run = false;
    std::vector<std::string> _m_6017udp_names;

    void processDataThread();

    void createDataBase(QString taskName, QString index);

    TIS_Info::PressAndSpot _m_pressAndSpot;
    TIS_Info::VoltageAndElectric _m_voltageAndElectric;
    QString m_sTaskName;
};
} // namespace _Controllers