#include "Recv6017DataController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/primary/thread_pool/thread_pool.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

Recv6017DataController::Recv6017DataController() {}

Recv6017DataController::~Recv6017DataController() noexcept
{
    checkWriteCollectData(true);
    checkWritePressData(true);

    _mb_thread_process_run.store(false, std::memory_order_release);

    if (_m_thread_process.joinable())
    {
        _m_thread_process.join();
    }
}

// # 加速度硬点 spot_0y spot_0x
// # 压力 press0 press1 press2 press3 press4 press5 press6 press7
// # 电流 electric
// # 电压 voltage

void Recv6017DataController::getVolAndElc(TIS_Info::VoltageAndElectric vol_and_elc)
{
    _md_volData = vol_and_elc.md_voltage0;

    if (vol_and_elc.md_voltage0 != 8000)
    {
        _md_volData_qml = operateData("voltage", _md_volData);
    }
}

void Recv6017DataController::getPressAndSpot(TIS_Info::PressAndSpot press_and_spot)
{
    _md_spotData_0x.store(press_and_spot.md_spot0x, std::memory_order_release);
    _md_spotData_0y.store(press_and_spot.md_spot0y, std::memory_order_release);

    _md_pressData0.store(press_and_spot.md_press0, std::memory_order_release);
    _md_pressData1.store(press_and_spot.md_press1, std::memory_order_release);
    _md_pressData2.store(press_and_spot.md_press2, std::memory_order_release);
    _md_pressData3.store(press_and_spot.md_press3, std::memory_order_release);

    if (press_and_spot.md_spot0x != 8000)
    {
        _md_spotData_0x_qml.store(operateData("spot_0x", press_and_spot.md_spot0x), std::memory_order_release);
    }

    if (press_and_spot.md_spot0y != 8000)
    {
        _md_spotData_0y_qml.store(operateData("spot_0y", press_and_spot.md_spot0y), std::memory_order_release);
    }

    if (press_and_spot.md_press0 != 8000)
    {
        _md_pressData0_qml.store(operateData("press0", press_and_spot.md_press0), std::memory_order_release);
    }

    if (press_and_spot.md_press1 != 8000)
    {
        _md_pressData1_qml.store(operateData("press1", press_and_spot.md_press1), std::memory_order_release);
    }
    if (press_and_spot.md_press2 != 8000)
    {
        _md_pressData2_qml.store(operateData("press2", press_and_spot.md_press2), std::memory_order_release);
    }

    if (press_and_spot.md_press3 != 8000)
    {
        _md_pressData3_qml.store(operateData("press3", press_and_spot.md_press3), std::memory_order_release);
    }
}

void _Controllers::Recv6017DataController::recvTaskData(const TIS_Info::TaskInfo &taskInfo)
{
    if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        _mi_task_id.store(-1, std::memory_order_release);
        return;
    }

    _mi_task_id.store(taskInfo.nTaskID, std::memory_order_release);

    if (!_m_thread_process.joinable())
    {
        _mb_thread_process_run.store(true, std::memory_order_release);
        _m_thread_process = std::thread(&Recv6017DataController::processDataThread, this);
    }
}

void _Controllers::Recv6017DataController::processDataThread()
{
    static uint16_t nCount = 0;

    while (_mb_thread_process_run.load(std::memory_order_acquire))
    {
        if (_mi_task_id.load(std::memory_order_acquire) == -1)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        _mdeq_pressData.push_back(initPressData());

        _mdeq_collectData.push_back(initCollectData());

        checkWriteCollectData();
        checkWritePressData();

        if (++nCount % 100 == 0) // 前端控制显示频率
        {
            sendPressSpotToQml();
            sendVolEleDataToQml();
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void _Controllers::Recv6017DataController::checkWritePressData(bool force)
{
    if (_mdeq_pressData.size() >= 1000 || force)
    {
        std::deque<_Kits::_Orm::press_data> pressDataQue;
        pressDataQue.swap(_mdeq_pressData);

        _Kits::thread_pool::runTask([pressDataQue = std::move(pressDataQue)] {
            // qDebug() << "insert press data" << pressDataQue.size();
            _Kits::SqlInsert<_Kits::_Orm::press_data> sqlInsert;
            sqlInsert.insert(pressDataQue);
            if (!sqlInsert.exec())
            {
                _Kits::LogError("sql insert error");
            }
        });
    }
}

void _Controllers::Recv6017DataController::checkWriteCollectData(bool force)
{
    if (_mdeq_collectData.size() >= 1000 || force)
    {
        std::deque<_Kits::_Orm::collect_data> collectDataQue;
        collectDataQue.swap(_mdeq_collectData);

        _Kits::thread_pool::runTask([collectDataQue = std::move(collectDataQue)] {
            // qDebug() << "insert collect data" << collectDataQue.size();
            _Kits::SqlInsert<_Kits::_Orm::collect_data> sqlInsert;
            sqlInsert.insert(collectDataQue);
            if (!sqlInsert.exec())
            {
                _Kits::LogError("sql insert error");
            }
        });
    }
}

void _Controllers::Recv6017DataController::sendPressSpotToQml()
{
    TIS_Info::PressAndSpot PressAndSpot;
    PressAndSpot.md_press0 = _md_pressData0_qml.load(std::memory_order_acquire);
    PressAndSpot.md_press1 = _md_pressData1_qml.load(std::memory_order_acquire);
    PressAndSpot.md_press2 = _md_pressData2_qml.load(std::memory_order_acquire);
    PressAndSpot.md_press3 = _md_pressData3_qml.load(std::memory_order_acquire);

    PressAndSpot.md_spot0x = _md_spotData_0x_qml.load(std::memory_order_acquire);
    PressAndSpot.md_spot0y = _md_spotData_0y_qml.load(std::memory_order_acquire);

    _Service::senderPressSpotVolElecEtcDatasendPressSpotOut(PressAndSpot);
}

void _Controllers::Recv6017DataController::sendVolEleDataToQml()
{
    TIS_Info::VoltageAndElectric VoltageAndElectric;
    VoltageAndElectric.md_voltage0 = _md_volData_qml.load(std::memory_order_acquire);
    VoltageAndElectric.md_electric0 = 8000;

    _Service::senderPressSpotVolElecEtcDatasendVolElecOut(VoltageAndElectric);
}

double Recv6017DataController::operateData(QString data_name, double data)
{
    auto it = _mvec_equationCoefficients.find(data_name.toStdString());
    if (it != _mvec_equationCoefficients.end()) // 通道  等于  0
    {
        return (data + it->second.md_constant) * it->second.md_coefficient;
    }

    return 8000.0;
}

_Kits::_Orm::press_data _Controllers::Recv6017DataController::initPressData()
{

    _Kits::_Orm::press_data pressData;

    pressData.acc0_x = _md_spotData_0x.load(std::memory_order_acquire);
    pressData.acc0_y = _md_spotData_0y.load(std::memory_order_acquire);
    pressData.press0 = _md_pressData0.load(std::memory_order_acquire);
    pressData.press1 = _md_pressData1.load(std::memory_order_acquire);
    pressData.press2 = _md_pressData2.load(std::memory_order_acquire);
    pressData.press3 = _md_pressData3.load(std::memory_order_acquire);
    pressData.task_id = _mi_task_id.load(std::memory_order_acquire);

    pressData.press4 = 8000;
    pressData.press5 = 8000;
    pressData.press6 = 8000;
    pressData.press7 = 8000;

    pressData.acc0_z = 8000;
    pressData.acc1_x = 8000;
    pressData.acc1_y = 8000;
    pressData.acc1_z = 8000;

    return pressData;
}

_Kits::_Orm::collect_data _Controllers::Recv6017DataController::initCollectData()
{
    _Kits::_Orm::collect_data collectData;
    collectData.vol = _md_volData_qml.load(std::memory_order_acquire);
    collectData.task_id = _mi_task_id.load(std::memory_order_acquire);
    collectData.cur = 8000;
    collectData.tem = 8000;
    collectData.hum = 8000;

    return collectData;
}

void Recv6017DataController::recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017> EquationCoefficients)
{
    _mvec_equationCoefficients = EquationCoefficients;
}
} // namespace _Controllers