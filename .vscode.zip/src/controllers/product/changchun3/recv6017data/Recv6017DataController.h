#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <thread>
#include <deque>
#include "kits/common/database/CppBatis.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/press_acc_collect_struct.h"

namespace _Controllers {
class Recv6017DataController : public ControllerBase<Recv6017DataController>
{
  public:
    explicit Recv6017DataController();
    virtual ~Recv6017DataController() noexcept;

    void getVolAndElc(TIS_Info::VoltageAndElectric);
    void getPressAndSpot(TIS_Info::PressAndSpot);
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017>);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::Dispatch6017::sendVolAndElecNatrualDataOut, Recv6017DataController::getVolAndElc);
    ASYNC_TASK_ADD(TIS_Info::Dispatch6017::sendPressAndSpotNatrualOut, Recv6017DataController::getPressAndSpot);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, Recv6017DataController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, Recv6017DataController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::initController, Recv6017DataController::recvEquationCoefficients);
    TASK_LIST_END

  private:
    std::atomic<double> _md_spotData_0x = 8000; // 振动  x
    std::atomic<double> _md_spotData_0y = 8000; // 冲击  y
    std::atomic<double> _md_volData = 8000;     // 网压
    std::atomic<double> _md_pressData0 = 8000;  // 压力0
    std::atomic<double> _md_pressData1 = 8000;  // 压力1
    std::atomic<double> _md_pressData2 = 8000;  // 压力2
    std::atomic<double> _md_pressData3 = 8000;  // 压力3

    std::atomic<double> _md_spotData_0x_qml = 8000; // 振动  x  以下用于发qml 用于调试压力公式
    std::atomic<double> _md_spotData_0y_qml = 8000; // 冲击  y
    std::atomic<double> _md_volData_qml = 8000;     // 网压
    std::atomic<double> _md_pressData0_qml = 8000;  // 压力0
    std::atomic<double> _md_pressData1_qml = 8000;  // 压力1
    std::atomic<double> _md_pressData2_qml = 8000;  // 压力2
    std::atomic<double> _md_pressData3_qml = 8000;  // 压力3

    std::unordered_map<std::string, TIS_Info::Equation6017> _mvec_equationCoefficients;

    std::thread _m_thread_process;
    std::atomic_bool _mb_thread_process_run = false;
    std::deque<_Kits::_Orm::press_data> _mdeq_pressData;
    std::deque<_Kits::_Orm::collect_data> _mdeq_collectData;
    void processDataThread();

    _Kits::_Orm::press_data initPressData();
    _Kits::_Orm::collect_data initCollectData();

    void checkWritePressData(bool force = false);
    void checkWriteCollectData(bool force = false);

    void sendPressSpotToQml();
    void sendVolEleDataToQml();

    /// @brief 处理数据，计算因子
    /// @param data_name 数据名称
    double operateData(QString data_name, double data);

    std::atomic_int32_t _mi_task_id;
};
} // namespace _Controllers