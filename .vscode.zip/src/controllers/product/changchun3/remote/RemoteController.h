
#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
namespace _Controllers {
class RemoteController final : public ControllerBase<RemoteController>
{
  public:
    RemoteController() = default;
    ~RemoteController() noexcept = default;
    void publishTaskInfo(const TIS_Info::TaskInfo &);
    void publishLocationInfo(const TIS_Info::LocationData &);
    void publishPressSpotInfo(const TIS_Info::PressAndSpot &);
    void publishVolElecInfo(const TIS_Info::VoltageAndElectric &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskRunning, RemoteController::publishTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, RemoteController::publishLocationInfo);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, RemoteController::publishPressSpotInfo);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, RemoteController::publishVolElecInfo);
    TASK_LIST_END
};
} // namespace _Controllers