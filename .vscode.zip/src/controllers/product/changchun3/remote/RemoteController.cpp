#include "RemoteController.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
//#include "tis_global/Function.h"
#include <atomic>

namespace _Controllers {
void RemoteController::publishTaskInfo(const TIS_Info::TaskInfo &data)
{
    static std::atomic_int32_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);

    if (data.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        mes.topic = TIS_Info::TaskService::taskBegin;
    }
    else if (data.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        mes.topic = TIS_Info::TaskService::taskEnd;
    }
    else if (data.nTaskstate == TIS_Info::TaskState::TASK_RUNNING)
    {
        mes.topic = TIS_Info::TaskService::taskRunning;
    }

    Json::Value json;
    json["strTaskName"] = data.strTaskName;
    json["strTrainNumber"] = data.strTrainNumber;
    json["strLineName"] = data.strLineName;
    json["strstartstation"] = data.strStartStation;
    json["strEndstation"] = data.strEndStation;
    json["strstartPole"] = data.strStartPole;
    json["nStationId"] = data.nStationId;
    json["strRfid"] = data.strRfid;
    json["strTaskSavePath"] = data.strTaskSavePath;
    json["nLineDirection"] = data.nLineDirection;
    json["nDirection"] = data.nDirection;

    json["nTaskstate"] = static_cast<int>(data.nTaskstate);

    json["timestamp"] = data.timestamp;

    /*

      TaskType taskType = TaskType::TYPE_NONE;
    std::string strTaskName = "";     // 任务名称
    std::string strTrainNumber = "";  // 列车编号
    std::string strLineName = "";     // 线路名称
    std::string strStartStation = ""; // 起始站
    std::string strEndStation = "";   // 终点站
    std::string strStartPole = "";    // 起始杆号
    int nStationId = -1;              // 站区id
    std::string strRfid = "";         // rfid标签
    std::string strTaskSavePath = ""; // 任务路径
    int nLineDirection = 0;           // 0:上行 1:下行 EnumPublic::TaskLineDir::TASK_UP_LINE
    int nDirection = 0;               // 0:正向 1:反向 EnumPublic::TaskTrainDir::TASK_FORWARD_TRAIN
    TaskState nTaskstate = TaskState::TASK_NONE;
    int64_t timestamp = 0;

    */

    // 新加一段

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishLocationInfo(const TIS_Info::LocationData &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::LocationService::LocationRadio;
    Json::Value json;
    json["station_name"] = data.station_name.toStdString();
    json["maoduan_name"] = data.maoduan_name.toStdString();
    json["pole_name"] = data.pole_name.toStdString();
    json["mileage_adjust"] = data.mileage_adjust;
    json["speed"] = data.speed;
    json["task_id"] = data.task_id;
    json["location_type"] = static_cast<int>(data.location_type);
    json["mileage_normal"] = data.mileage_normal;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut;
    Json::Value json;
    json["press0"] = data.md_press0;
    json["press1"] = data.md_press1;
    json["press2"] = data.md_press2;
    json["press3"] = data.md_press3;
    json["press4"] = data.md_press4;
    json["press5"] = data.md_press5;
    json["press6"] = data.md_press6;
    json["press7"] = data.md_press7;
    json["spot0x"] = data.md_spot0x;
    json["spot0y"] = data.md_spot0y;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

void RemoteController::publishVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    static uint64_t id = 0;
    TIS_Info::RemoteMessage mes;
    mes.message_id = std::to_string(++id);
    mes.topic = TIS_Info::PressSpotVolElecEtcData::sendVolElecOut;
    Json::Value json;
    json["voltage"] = data.md_voltage0;
    json["electric"] = data.md_electric0;

    mes.json_data = _Kits::jsonToString(json);
    _Service::receiverRemoteAccesspublish(mes);
}

} // namespace _Controllers