#include "TemperatureController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "kits/common/utils/TimeToString.h"
#include "kits/product_kits/orm_user/InfraredSql.h"
#include <QPainter>
#include <iostream>
#include <filesystem>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void TemperatureController::recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
{
    m_IRImageQueue.pushItemNoBlocking(std::move(IRimagebuffer));
}
void TemperatureController::init(const QVariant &data)
{
    if (nullptr == m_infraredGeneral)
    {
        m_infraredGeneral = std::make_unique<_Kits::InfraredGeneral>();
    }

    auto configpath = data.toMap().value("configpath").toByteArray().toStdString();
    auto config = YAML::LoadFile(configpath);

    m_strSavePicRoot = config["rootpath"].as<std::string>();

    auto irconfig = config["irdata"];
    float fAlarmTemp1 = irconfig["alarmtemp1"].as<double>();
    float fAlarmTemp2 = irconfig["alarmtemp2"].as<double>();
    float fAlarmTemp3 = irconfig["alarmtemp3"].as<double>();

    m_infraredGeneral->updataAlarmTemp(fAlarmTemp1, fAlarmTemp2, fAlarmTemp3);

    m_fmaxTemperature_calibration = irconfig["maxtemperatrue"].as<double>();
    m_favgTemperature_coefficient = irconfig["avgtemperatrue_coeff"].as<double>();
    m_savepicflag = irconfig["savepicflag"].as<uint32_t>();
    m_startFalg.store(true);
    // m_yuvConverter = std::make_unique<_Kits::YuvConverter>();
    m_IRImageThread = std::thread(&TemperatureController::handleIRImageThread, this);
}
TemperatureController::~TemperatureController()
{
    exitthread();
    if (m_tempDataVec.size() > 0)
    {
        InfraredSql::insertAllInfraredData(m_tempDataVec);
    }
}
void TemperatureController::onTaskStart(const TIS_Info::TaskInfo &taskInfo)
{
    m_iSaveImgCount = 0;
    m_taskID.store(taskInfo.nTaskID);
    createSaveDiretory(taskInfo.strTaskName);
}
void TemperatureController::onTaskEnd(const TIS_Info::TaskInfo &taskInfo)
{
    m_iSaveImgCount = 0;
    if (m_tempDataVec.size() > 0)
    {
        InfraredSql::insertAllInfraredData(m_tempDataVec);
    }
    m_taskID.store(-1);
}
void TemperatureController::sendDisplayLog(const QString &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::displaylog_send, QVariant::fromValue(data));
}
void TemperatureController::handleIRImageThread()
{
    std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer = nullptr;
    while (m_startFalg.load())
    {
        {
            IRimagebuffer = m_IRImageQueue.popItem();
        }
        if (nullptr == IRimagebuffer)
        {
            break;
        }
        if (nullptr == m_yuvConverter)
        {
            m_yuvConverter = std::make_unique<_Kits::YuvConverter>();
            m_yuvConverter->init(IRimagebuffer->width, IRimagebuffer->height);
        }

        QImage image = QImage(IRimagebuffer->width, IRimagebuffer->height, QImage::Format_RGB888);
        m_yuvConverter->yuv420pTorgb_cuda(IRimagebuffer->data.data(), image.bits());

        dealSendToQmlData(image);

        QPoint tempPoint;
        if (0 != updateTempValue(IRimagebuffer, tempPoint))
        {
            continue;
        }
        QImage imageSave = image.copy();
        sendMaxTempToQml(QVariant::fromValue(m_maxtemp.load()));

        dealIRImageData(imageSave, tempPoint);

        sendMaxTempToQml(QVariant::fromValue(m_maxtemp.load()));
    }
}

int TemperatureController::updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, QPoint &maxTempPoint)
{
    if (nullptr == IRimagebuffer)
    {
        return 1;
    }

    m_maxtemp.store(IRimagebuffer->maxtemp);
    m_mintemp.store(IRimagebuffer->mintemp);
    maxTempPoint.setX(IRimagebuffer->maxpointx);
    maxTempPoint.setY(IRimagebuffer->maxpointy);

    auto maxTemp = m_favgTemperature_coefficient * m_maxtemp.load() + m_fmaxTemperature_calibration;
    m_maxtemp.store(maxTemp);

    return 0;
}
void TemperatureController::dealSendToQmlData(QImage &image)
{
    QVariantMap imgMap;
    imgMap["img"] = image;
    imgMap["camera_name"] = QString::fromStdString("");
    sendImage(QVariant::fromValue(imgMap));
}
void TemperatureController::dealIRImageData(QImage &image, const QPoint &maxTempPoint)
{
    if (!m_taskFlag.load() || -1 == m_taskID.load())
    {
        return;
    }

    bool bLimitByTime = true;
    auto now = std::chrono::high_resolution_clock::now();
    auto durationtime = std::chrono::duration_cast<std::chrono::seconds>(now - m_saveImageTime);

    if (m_saveImageTime != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_iAlarmTimeInterval)
    {
        bLimitByTime = false;
    }

    // int alarmLevel = isAlarm(m_maxtemp.load());
    int alarmLevel = m_infraredGeneral->isAlarm(m_maxtemp.load());
    std::string picname = "";
    if (alarmLevel > 0)
    {
        if (bLimitByTime)
        {
            m_saveImageTime = now;

            if (alarmLevel <= m_savepicflag)
            {
                picname = generatePictureName();
                saveIRImage(image, picname, maxTempPoint);
            }
        }
        QString strShowMaxTemp = "最高温度:" + QString::number(m_maxtemp.load()) + "警告等级:" + QString::number(alarmLevel);
        sendDisplayLog(strShowMaxTemp);

        // 发送数据库
    }
    if (!bLimitByTime)
    {
        alarmLevel = 0;
    }

    float avgtemp = (m_mintemp + m_maxtemp) / 2;
    dealIRAlarmData(alarmLevel, m_mintemp.load(), m_maxtemp.load(), avgtemp, picname);
}

void TemperatureController::saveIRImage(QImage &image, const std::string &picname, const QPoint &maxTempPoint)
{
    QPainter paintermax(&image);

    QPoint topleft = maxTempPoint - QPoint(20, 20);
    QPoint bottomRight = maxTempPoint + QPoint(20, 20);
    QRect rect(topleft, bottomRight);

    paintermax.setPen(Qt::black);
    paintermax.setBrush(Qt::NoBrush); // 不填充
    paintermax.drawRect(rect);        // 绘制矩形
    paintermax.setFont(QFont("Arial", 10));
    paintermax.drawText(maxTempPoint.x(), maxTempPoint.y() + 15, QString::number(m_maxtemp.load()));

    image.save((QString::fromLocal8Bit(picname.data())));
}
void TemperatureController::createSaveDiretory(const std::string &taskName)
{
    LogInfo("ArcDataDeal::startTask:{}", taskName);
    QString strPath = QString::fromStdString(m_strSavePicRoot);
    // std::filesystem::path path(strPath.toStdWString());
    std::filesystem::path path(strPath.toStdWString());
    path.append(TimeToString::getYearMonthDayStr());
    path.append(taskName);
    path.append(L"红外超限");

    m_taskSvaePath = path.string();

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            m_iSaveImgCount = 0;
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    LogInfo("start success:{}", m_taskSvaePath);

    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    m_taskFlag.store(true);
}
std::string TemperatureController::generatePictureName()
{
    std::string strPicName = std::to_string(m_iSaveImgCount++) + "_" + TimeToString::getHourMinSecStr() + ".jpg";

    std::string picname = m_taskSvaePath + "\\" + strPicName;
    return picname;
}
void TemperatureController::dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname)
{
    _Kits::_Orm::temperature_data tempData;
    tempData.alarm_level = level;
    tempData.max = maxtemp;
    tempData.min = mintemp;
    tempData.avg = avgtemp;
    if (level > 0)
    {
        tempData.alarm_temp = maxtemp;
    }
    else
    {
        tempData.alarm_temp = 0;
    }
    tempData.task_id = m_taskID;
    tempData.pic_path = QString::fromLocal8Bit(picname);
    tempData.created_time = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
    m_tempDataVec.push_back(tempData);

    if (m_tempDataVec.size() > 50)
    {
        auto ret = InfraredSql::insertAllInfraredData(m_tempDataVec);
        if (ret)
        {
            m_tempDataVec.clear();
        }
    }
}
void TemperatureController::sendImage(const QVariant &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page, data);
}
void TemperatureController::sendMaxTempToQml(const QVariant &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::maxtemp_recv, data);
}
void TemperatureController::exitthread()
{
    m_startFalg.store(false);
    recvIRImageData(nullptr);
    if (m_IRImageThread.joinable())
    {
        m_IRImageThread.join();
    }
}
} // namespace _Controllers