#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
//#include "tis_global/Function.h"
#include "kits/common/utils/BlockingQueue.h"
#include "kits/cuda/YuvConverter.h"
#include "kits/product_kits/infrared_general/InfraredGeneral.h"
#include "kits/common/database/orm/TableStructs.h"
#include <thread>
#include <atomic>
#include <string>
#include <QPoint>

namespace _Controllers {
class TemperatureController : public ControllerBase<TemperatureController>
{
  public:
    void recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer>);
    void init(const QVariant &);
    void sendDisplayLog(const QString &);
    void onTaskStart(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::IRayIRCameraService::IRImageReady, TemperatureController::recvIRImageData);
    SYNC_TASK_ADD(TIS_Info::IRayIRCameraService::initSignal, TemperatureController::init);
    ASYNC_TASK_ADD(TIS_Info::IRayIRCameraService::displayLogSignal, TemperatureController::sendDisplayLog);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, TemperatureController::onTaskStart);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, TemperatureController::onTaskEnd);
    TASK_LIST_END

  private:
    _Kits::BlockingQueue<std::shared_ptr<TIS_Info::IRImageBuffer>> m_IRImageQueue{10};
    std::thread m_IRImageThread;
    std::atomic_bool m_startFalg = false;
    int m_normalwidth = 0;
    int m_normalheight = 0;
    int m_iAlarmTimeInterval = 10; // 报警时间间隔，人为干预
    int m_iSaveImgCount = 0;
    double m_fmaxTemperature_calibration = 0; // 最大温度校准
    double m_favgTemperature_coefficient = 0; // 系数
    // std::atomic<float> m_avgtemp = 0.0;
    std::atomic<float> m_mintemp = 0.0;
    std::atomic<float> m_maxtemp = 0.0;
    std::atomic_bool m_taskFlag = false;
    std::string m_taskSvaePath = "";
    std::string m_strSavePicRoot = "";
    std::chrono::steady_clock::time_point m_saveImageTime = std::chrono::steady_clock::time_point(std::chrono::seconds(0));
    int m_savepicflag = 0;
    std::vector<_Kits::_Orm::temperature_data> m_tempDataVec;
    std::atomic<int> m_taskID = -1;
    std::unique_ptr<_Kits::YuvConverter> m_yuvConverter = nullptr;
    std::unique_ptr<_Kits::InfraredGeneral> m_infraredGeneral = nullptr;

  public:
    ~TemperatureController();

  private:
    void handleIRImageThread();
    void dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname);
    void sendImage(const QVariant &data);
    void sendMaxTempToQml(const QVariant &data);
    void createSaveDiretory(const std::string &taskName);
    void exitthread();
    void dealIRImageData(QImage &image, const QPoint &maxTempPoint);
    void dealSendToQmlData(QImage &image);
    void saveIRImage(QImage &image, const std::string &picname, const QPoint &maxTempPoint);
    int updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, QPoint &maxTempPoint);
    std::string generatePictureName();
};
} // namespace _Controllers
