
set(CTL_NAME "ctl_changchun3")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
      
target_sources(${LIB_CONTROLLERS} PUBLIC 
    $<TARGET_OBJECTS:${CTL_NAME}>
    $<TARGET_OBJECTS:kit_orm_user>
    $<TARGET_OBJECTS:kit_infrared_general>
    $<TARGET_OBJECTS:kit_save_video_by_ffmpeg>
)     

target_link_libraries(${CTL_NAME} PUBLIC 
        shared_dependencies 
        kit_log
        kit_orm_user
        kit_infrared_general
        kit_save_video_by_ffmpeg
)

find_package(OpenCV REQUIRED COMPONENTS core imgproc)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
) 

target_include_directories(${CTL_NAME} PUBLIC
    ${THIRD_PARTY_INCLUDE}/JCWLib/
)  

target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

# 用于选择加载的资源和界面文件 begin
set(RES_QML
    #res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
    res/qml/engineering_vehicle_qml/egv_task_page/egv_task_page.qml
    res/qml/engineering_vehicle_qml/rfid_page/rfid_page.qml
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Table.qml
    res/qml/public_controls/Modules.qml
    res/qml/engineering_vehicle_qml/egv_location_page/egv_location_page.qml
   # res/qml/engineering_vehicle_qml/main.qml
    #res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/public_controls/HighFrequencyChart.qml
    res/qml/public_controls/YunTai.qml
    res/qml/public_controls/Magnifier.qml
    res/qml/public_controls/ConfigEditorMain.qml
    res/qml/public_controls/DtConfigEditor.qml
    res/qml/public_controls/MvbConfigEditor.qml
    res/qml/public_controls/RfidConfigEditor.qml
    res/qml/public_controls/Speed6051Config.qml
    res/qml/public_controls/PressSpotEquation.qml
    res/qml/public_controls/TcpClientCenter.qml
    res/qml/public_controls/UdpCenter.qml
    res/qml/public_controls/HikCameraConfigEditor.qml
    res/qml/public_controls/QmlConfigEditor.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end