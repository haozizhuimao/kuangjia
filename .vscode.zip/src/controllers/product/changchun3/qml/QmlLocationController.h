#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <mutex>
namespace _Controllers {
class QmlLocationController : public ControllerBase<QmlLocationController>
{
  public:
    void sendPositToPage(const TIS_Info::LocationData &);
    void sendJiHeToQml(const TIS_Info::JiHeData &);
    void sendTaskNameToQml(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, QmlLocationController::sendPositToPage);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::JiHeDataBroadcast, QmlLocationController::sendJiHeToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlLocationController::sendTaskNameToQml);
    TASK_LIST_END

  private:
    std::vector<TIS_Info::LocationData> mv_locationData;
    std::thread m_locationDataSendThread;
    std::mutex m_locationDataMutex;
    std::atomic<TIS_Info::LocationType> m_locationType;
    std::atomic<float> mf_lastZig1;
};
} // namespace _Controllers