#include "QmlLocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include <qvariant.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlLocationController::sendPositToPage(const TIS_Info::LocationData &data)
{

    QVariantMap locationData = {{"stationname", data.station_name},
                                {"maoduan_name", data.maoduan_name},
                                {"pole_name", data.pole_name},
                                {"kilometer", data.mileage_adjust / 1000000.0},
                                {"moveDistance", data.mileage_normal / 1000000.0},
                                {"lineDirection", data.line_direction}};

    m_locationType.store(data.location_type, std::memory_order_release);

    // 发送所有数据到QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvlocation_page, QVariant::fromValue(locationData));
}

void QmlLocationController::sendJiHeToQml(const TIS_Info::JiHeData &data)
{
    QVariantMap jiHeData = {{"zig0", data.fZig[0]},
                            {"hei0", data.fHei[0]},
                            {"mohaoweidth0", data.fMoHaoWidth[0]},
                            {"positionType", static_cast<int>(m_locationType.load())},
                            {"isBreakPoint", false}};

    static bool zig1Jumped = false;
    float lastZig1 = mf_lastZig1.load(std::memory_order_acquire);

    if (data.fZig[1] == 8000)
    {
        // 遇到8000，重置状态
        zig1Jumped = false;
        mf_lastZig1.store(0.0f, std::memory_order_release);
    }
    else if (!zig1Jumped)
    {
        if (lastZig1 == 0.0f)
        {
            // 第一次有效值
            jiHeData["zig1"] = data.fZig[1];
            mf_lastZig1.store(data.fZig[1], std::memory_order_release);
        }
        else if (std::abs(data.fZig[1] - lastZig1) > 100)
        {
            // 跳变发生，只发送跳变前的数据
            jiHeData["isBreakPoint"] = true;
            zig1Jumped = true;
        }
        else
        {
            // 正常值
            jiHeData["zig1"] = data.fZig[1];
            mf_lastZig1.store(data.fZig[1], std::memory_order_release);
        }
    }

    // 发送数据到 QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::jihedata_recv, QVariant::fromValue(jiHeData));
    m_locationType.store(TIS_Info::LocationType::PT_LINE, std::memory_order_release);
}

void QmlLocationController::sendTaskNameToQml(const TIS_Info::TaskInfo &taskInfo)
{
    auto taskName = taskInfo.strTaskName;

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv, QVariant::fromValue(taskName));
}

} // namespace _Controllers
