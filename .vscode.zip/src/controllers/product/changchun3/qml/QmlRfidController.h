#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlRfidController : public ControllerBase<QmlRfidController>
{
  public:
    void onSendRfidCountToQml(int);
    void onSendRfidDataToQml(QString);
    void onClearRfidData(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::LocationService::sendRfidCount, QmlRfidController::onSendRfidCountToQml);
    ASYNC_TASK_ADD(TIS_Info::RfidService::sendRfidToQml, QmlRfidController::onSendRfidDataToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlRfidController::onClearRfidData);
    TASK_LIST_END

  private:
};
} // namespace _Controllers
