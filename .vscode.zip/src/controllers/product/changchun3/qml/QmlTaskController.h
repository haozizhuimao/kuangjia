#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
namespace _Controllers {
class QmlTaskController : public ControllerBase<QmlTaskController>
{
  public:
    void displayTask(const TIS_Info::TaskInfo &);
    void onLineBtnChoose(QVariant);
    void onLineNameSended(QVariant);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlTaskController::displayTask);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::LineBtnChoose, QmlTaskController::onLineBtnChoose);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::LineNameSend, QmlTaskController::onLineNameSended);
    TASK_LIST_END
};
} // namespace _Controllers