#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include <string>
namespace _Controllers {
class QmlHardwareInfo : public ControllerBase<QmlHardwareInfo>
{
  public:
    void onResourceInfo(TIS_Info::QmlCommunication::ForQmlSignals, const QVariant &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HardwareManager::resourceInfo, QmlHardwareInfo::onResourceInfo);
    TASK_LIST_END
};
} // namespace _Controllers
