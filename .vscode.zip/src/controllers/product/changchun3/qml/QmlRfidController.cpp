#include "QmlRfidController.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlRfidController::onSendRfidCountToQml(int data)
{
    // 发送rfid数据到QML
    qDebug() << "Sending RFID count to QML:" << data;
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_count_send, QVariant::fromValue(data));
}

void QmlRfidController::onSendRfidDataToQml(QString data)
{
    // LogInfo("Sending RFID data to QML: {}", data.toStdString().c_str());
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_recv, QVariant::fromValue(data));
}

void QmlRfidController::onClearRfidData(const TIS_Info::TaskInfo &)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_count_send, QVariant::fromValue(0));
}

} // namespace _Controllers
