#include "QmlSpeedController.h"
#include <qvariant.h>
#include <sys/stat.h>
#include <chrono>

namespace _Controllers
{
    using namespace _Service;

    void QmlSpeedController::onSendToQml(double speed)
    {
        receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::speed_data_send, QVariant::fromValue(speed));
    }

} // namespace _Controllers