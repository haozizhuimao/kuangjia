#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
namespace _Controllers {
class QmlVideoDisplay : public ControllerBase<QmlVideoDisplay>
{
  public:
    void displayVideo(std::shared_ptr<TIS_Info::ImageBuffer>);
    void sendImagePathToQml(QString, QString);
    void sendTaskNameToQml(const TIS_Info::TaskInfo &);
    void onSendRecordStateToQml(bool);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendImageToQml, QmlVideoDisplay::displayVideo);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendSavePathOut, QmlVideoDisplay::sendImagePathToQml);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendRecordState, QmlVideoDisplay::onSendRecordStateToQml);
    ASYNC_TASK_ADD(TIS_Info::UsbCameraManager::sendImageToQml, QmlVideoDisplay::displayVideo);
    ASYNC_TASK_ADD(TIS_Info::UsbCameraManager::sendSavePathOut, QmlVideoDisplay::sendImagePathToQml);
    ASYNC_TASK_ADD(TIS_Info::UsbCameraManager::sendRecordState, QmlVideoDisplay::onSendRecordStateToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlVideoDisplay::sendTaskNameToQml);
    TASK_LIST_END
};
} // namespace _Controllers