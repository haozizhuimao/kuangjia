#include "TaskController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/product_kits/task_helper/TaskSql.h"
#include "service/AppInterface.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/product_kits/line_helper/LineHelper.h"
#include "kits/common/database/CppBatis.h"
#include <QJsonDocument>
#include "kits/utility/datetime/datetime.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TaskController::initFromMoudle(const std::string &trainNum, const std::string &savePath)
{
    m_trainNum = trainNum;
    m_savePath = savePath;
}

// void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &mvb_info)
// {
//     if (m_taskHelper == nullptr)
//     {
//         LogError("任务服务初始化失败!");
//         return;
//     }
// }

void TaskController::onTaskSended(QVariant data)
{

    auto taskInfo = qmlTaskInfo(data);
    if (taskInfo.nTaskID == -1)
    {
        return;
    }
    m_currentTask = taskInfo;
    if (TIS_Info::TaskState::TASK_START == taskInfo.nTaskstate)
    {
        if (taskInfo.nTaskID != -1)
        {
            if (LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
            {
                senderTaskServicetaskBegin(taskInfo);
            }
            else
            {
                LogError("[任务线路表]: 任务线路表信息初始化失败。");
            }
        }
    }
    else if (TIS_Info::TaskState::TASK_STOPPED == taskInfo.nTaskstate)
    {
        TaskSql::updateStopTask(taskInfo.nTaskID);
        if (taskInfo.nTaskID != -1)
        {
            senderTaskServicetaskEnd(taskInfo);
        }
    }
}
void TaskController::onRfidTaskSended(const std::string &rfid, int64_t timet)
{
    auto [is_last, line_data] = _Kits::LineHelper::isLastRFID(rfid);
    if (is_last && m_currentTask.nTaskstate == TIS_Info::TaskState::TASK_START && m_currentTask.taskType == TIS_Info::TaskType::TYPE_RFID)
    {
        m_currentTask.nTaskstate = TIS_Info::TaskState::TASK_STOPPED;
        _Service::senderTaskServicetaskEnd(m_currentTask);
    }

    if (!is_last && m_currentTask.nTaskstate != TIS_Info::TaskState::TASK_START)
    {
        auto taskInfo = rfidTaskInfo(line_data, timet);
        if (taskInfo.nTaskID != -1)
        {
            taskInfo.nTaskstate = TIS_Info::TaskState::TASK_START;
            m_currentTask = taskInfo;
            if (LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
            {
                senderTaskServicetaskBegin(taskInfo);
            }
            else
            {
                LogError("[任务线路表]: 任务线路表信息初始化失败。");
            }
        }
    }
}
TIS_Info::TaskInfo TaskController::rfidTaskInfo(const _Kits::_Orm::line_data &first, int64_t timet)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_RFID;
    task.nLineDirection = first.line_direction;
    task.strLineName = first.line_name.toStdString();
    task.strStartStation = first.station_name.toStdString();
    task.strTaskSavePath = m_savePath;
    task.strTrainNumber = m_trainNum;
    auto strCreateTime = _Kits::datetime::timepoint_to_string(timet, "%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::timepoint_to_string(timet);
    task.timestamp = timet;
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;
    TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}

bool TaskController::isLastRfid(QString rfid)
{
    // 查询该线路上的所有非空rfid记录
    SqlSelect<_Orm::line_data> lineSelector;
    if (!lineSelector.select().where("rfid_id", _Kits::OperatorComparison::NotEqual, "").exec())
    {
        LogError("Failed to query all RFID data ");
        return {};
    }

    m_vecRfid = lineSelector.getResults();
    if (m_vecRfid.empty())
    {
        LogError("No RFID data found");
        return {};
    }

    // 查找最后一个rfid记录
    _Orm::line_data lastRfidData = m_vecRfid.back();

    // 判断给定的rfid是否等于最后一个rfid
    return lastRfidData.rfid_id == rfid;
}

QVariantMap TaskController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}
TIS_Info::TaskInfo TaskController::qmlTaskInfo(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        LogError("下发任务数据错误!");
        return {};
    }

    auto json = _Kits::stringToJson(data.toString().toStdString());
    if (!json.isMember("taskState"))
    {
        LogError("下发任务数据错误!");
        return {};
    }
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_MANUAL;
    task.nLineDirection = json["lineDirection"].asString() == "上行" ? 0 : 1;
    task.strLineName = json["lineName"].asString();
    task.strStartStation = json["startStation"].asString();
    task.strStartPole = json["startPole"].asString();
    task.strEndStation = json["endStation"].asString();
    task.strTrainNumber = m_trainNum;
    task.strTaskSavePath = m_savePath;
    task.nDirection = json["runDirection"].asInt();
    task.nTaskstate = static_cast<TIS_Info::TaskState>(json["taskState"].asInt());
    auto strCreateTime = _Kits::datetime::current_string("%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::current_string();
    task.timestamp = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;
    TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}

} // namespace _Controllers
