#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <json/json.h>
#include "kits/product_kits/task_helper/TaskHelper.h"
#include "kits/common/database/orm/TableStructs.h"
#include <json/value.h>
//#include "tis_global/Function.h"
#include "tis_global/struct_details/mvb_struct.h"
#include "tis_global/struct_details/task_struct.h"

namespace _Controllers {
class TaskController final : public ControllerBase<TaskController>
{
  public:
    TaskController() = default;
    ~TaskController() noexcept = default;
    void initFromMoudle(const std::string &, const std::string &); // 配置初始化
    void onTaskSended(QVariant);
    // void onRfidTaskSended(QString);
    void onRfidTaskSended(const std::string &, int64_t);
    bool isLastRfid(QString rfid);
    QVariantMap convertDataToJsonOrMap(const QVariant &data);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::TaskService::initTaskController, TaskController::initFromMoudle);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::TaskSend, TaskController::onTaskSended);
    ASYNC_TASK_ADD(TIS_Info::RfidService::rfidDeduplicated, TaskController::onRfidTaskSended);
    TASK_LIST_END
  private:
    TIS_Info::TaskInfo qmlTaskInfo(const QVariant &data);
    TIS_Info::TaskInfo m_currentTask;
    TIS_Info::TaskInfo rfidTaskInfo(const _Kits::_Orm::line_data &, int64_t timet);

    std::unique_ptr<_Kits::TaskHelper> m_taskHelper = nullptr;
    std::string m_trainNum;
    std::string m_savePath;
    // static std::vector<_Kits::_Orm::line_data> m_vecRfid;
    std::vector<_Kits::_Orm::line_data> m_vecRfid;
    bool m_isRfidTaskSended = false;
};
} // namespace _Controllers
