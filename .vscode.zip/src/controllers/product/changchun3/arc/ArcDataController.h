#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
//#include "tis_global/Function.h"
#include "kits/common/database/CppBatis.h"
#include "kits/common/database/orm/TableStructs.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
namespace _Controllers {
class ArcDataController : public ControllerBase<ArcDataController>
{
  public:
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    void onTaskStart(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);
    void init(QVariant);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, ArcDataController::setUdpClient);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, ArcDataController::onTaskStart);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, ArcDataController::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::ArcUVService::initSignal, ArcDataController::init);
    TASK_LIST_END

  private:
    void recvUdpArcData(std::vector<uint8_t> &&datas);
    void dealArcData(const std::vector<uint8_t> &&datas);
    void saveArcData(const TIS_Info::arcData &arcdata);
    void packageArcData(const int index, const int arcTime, const int arcCount);

  private:
    const std::string client_title = "arc";
    std::atomic<int> m_taskID = -1;
    int m_iIndexArc = -1; // 燃弧序号
    int m_minTime = 5;    //
};

} // namespace _Controllers