﻿#include "ArcDataController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"
#include "tis_global/EnumClass.h"
// #include "tis_global/Field.h"
// #include "tis_global/EnumPublic.h"
#include "kits/product_kits/orm_user/ArcSaveSql.h"
#include <qvariant.h>

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

void ArcDataController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto it = clients.find(client_title);
    if (it != clients.end())
    {
        auto udpArcClient = it->second;
        udpArcClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } recvUdpArcData(std::vector<uint8_t>(datas->begin(), datas->end())); });
    }
    else
    {
        _Kits::LogError("[rfid] UdpClient not found for name: {}", client_title);
    }
}

void ArcDataController::init(QVariant data)
{
    auto configpath = data.toMap().value("configpath").toByteArray().toStdString();
    auto config = YAML::LoadFile(configpath);

    if (config["arcmintime"])
    {
        m_minTime = config["arcmintime"].as<int>();
    }
    else
    {
        m_minTime = 5;
    }
}
void ArcDataController::onTaskStart(const TIS_Info::TaskInfo &taskInfo)
{
    m_taskID.store(taskInfo.nTaskID);
}
void ArcDataController::onTaskEnd(const TIS_Info::TaskInfo &taskInfo)
{
    m_taskID.store(-1);
}
void ArcDataController::recvUdpArcData(std::vector<uint8_t> &&datas)
{

    dealArcData(std::move(datas));
}

void ArcDataController::dealArcData(const std::vector<uint8_t> &&data)
{
    if (-1 == m_taskID)
    {
        return;
    }
    auto len = data.size();
    if (len >= 10)
    {
        for (int i = 0; i <= len - 10;)
        {
            if (0x5A == data.at(i) && 0xFF == data.at(i + 9))
            {
                bool arcing = (bool)data.at(i + 8);
                int daraIndex = (int)data.at(i + 1);
                int arcIndex = (int)data.at(i + 2);
                if (!arcing)
                {
                    i += 10;
                    continue;
                }
                if (arcIndex == m_iIndexArc)
                {
                    // 之前的燃弧
                    i += 10;
                    continue;
                }

                m_iIndexArc = arcIndex;

                int iA = data.at(i + 3);
                int iB = data.at(i + 4);

                int usArcTime = iB * 256 + iA;                          // 本次燃弧结束测得的时长
                int usArcCount = data.at(i + 6) * 256 + data.at(i + 5); // 本次燃弧结束时脉冲计数
                if (usArcTime <= m_minTime)
                {
                    i += 10;
                    LogInfo("arstime is litter:{}", usArcTime);
                    continue;
                }
                i += 10;
                packageArcData(m_iIndexArc, usArcTime, usArcCount);
            }
        }
    }
}

void ArcDataController::packageArcData(const int index, const int arcTime, const int arcCount)
{
    TIS_Info::arcData arcData;
    arcData.arcId = index;
    arcData.arctime = arcTime;
    arcData.arccount = arcCount;
    arcData.task_id = m_taskID.load();
    arcData.occurtime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toStdString();

    saveArcData(arcData);
}

void ArcDataController::saveArcData(const TIS_Info::arcData &arcdata)
{
    _Kits::_Orm::arc_data sql_arc;

    sql_arc.task_id = arcdata.task_id;
    sql_arc.created_time = QString::fromStdString(arcdata.occurtime);          // 创建时间
    sql_arc.updated_time = QString::fromStdString(arcdata.occurtime);          // 更新时间
    sql_arc.arc_count = arcdata.arccount;                                      // 燃弧总数
    sql_arc.arc_time = arcdata.arctime;                                        // 燃弧持续时间
    sql_arc.arc_pulse = arcdata.arcpulse;                                      // 燃弧脉冲个数
    sql_arc.arcvideo_path = arcdata.fileName;                                  // 视频路径
    sql_arc.camera_name = QString::fromStdString(arcdata.cameraName);          // 相机名称
    sql_arc.arc_device_index = QString::fromStdString(arcdata.arcDeviceIndex); // 燃弧传感器编号

    ArcSaveSql::insertArcData(sql_arc);
}
