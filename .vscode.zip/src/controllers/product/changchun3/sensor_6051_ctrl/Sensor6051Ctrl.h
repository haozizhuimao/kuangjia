#pragma once

#include "kits/third_devices/sensor_6051_kit/Sensor6051.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/struct_details/speed_struct.h"

namespace _Controllers {
class Sensor6051Ctrl : public ControllerBase<Sensor6051Ctrl>
{

  public:
    void onInit6051Ctrl(const TIS_Info::SpeedLogInfo &);
    void onTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    void onStop6051Ctrl();
    void onTaskBegin(const TIS_Info::TaskInfo &taskInfo);
    void onTaskEnd(const TIS_Info::TaskInfo &taskInfo);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::init6051Ctrl, Sensor6051Ctrl::onInit6051Ctrl);
    SYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, Sensor6051Ctrl::onTcpClient);
    SYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::stop6051Ctrl, Sensor6051Ctrl::onStop6051Ctrl);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, Sensor6051Ctrl::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, Sensor6051Ctrl::onTaskEnd);
    TASK_LIST_END

  private:
    std::shared_ptr<_Kits::Sensor6051> m_6051connectivity;
    TIS_Info::SpeedLogInfo m_logInfo;
    const std::string TCP_NAME = "tcp_6051";
};
} // namespace _Controllers