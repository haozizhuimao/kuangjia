#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include "kits/utility/log/CRossLogger.h"
#include <QJsonValue>
#include <opencv2/opencv.hpp>
#include <QDir>
#include "tis_global/enum_public/video_enum.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/camera/tools/RemoteParser.h"
#include <QJsonDocument>
#include <QVariantMap>
#include <QJsonObject>
#include "tis_global/enum_public/task_enum.h"

namespace _Controllers {
using namespace _Service;

_Controllers::VideoMaker::VideoMaker()
    : m_ImageBufferPools(std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>()),
      m_locationCtrl(std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); })), m_taskInfo({}),
      m_bSaveVideo(true), m_qStrSavePath({"d:/gwkj/video_Notask"}), m_threadSaveVideo{}, m_threadSendToQml{}, m_threadProcessImage{},
      m_threadSendTitle{}
{}

_Controllers::VideoMaker::~VideoMaker()
{
    onStopVideoMaker();
}

void VideoMaker::onStopVideoMaker()
{
    for (auto &[name, cam] : (*m_udmcam))
    {
        cam->closeCamera();
    }
    m_bSaveVideo.store(false);

    onStopRecord();
    stopAllThread();

    m_locationCtrl->stop();
}

// 辅助函数：创建目录
bool VideoMaker::createDirectory(const QString &dirPath)
{
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            _Kits::LogError("Failed to create directory: {}", dirPath.toStdString());
            return false;
        }
    }
    return true;
}

void _Controllers::VideoMaker::saveVideoThread()
{
    while (m_bSaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : m_mapImgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> yuv420p;
            while (queue.try_pop(yuv420p))
            {
                if (!yuv420p)
                    continue;

                // 查找对应的保存器
                auto it = m_mapSaveVideo.find(name);
                if (it != m_mapSaveVideo.end())
                {
                    it->second->pushOriginalImage(yuv420p);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::onStartRecord(QString fileName)
{
    QString dirPath, filePath;
    std::vector<std::pair<QString, QString>> savePaths;

    for (const auto &[name, saveVideo] : m_mapSaveVideo)
    {
        // 构建完整路径
        dirPath = m_qStrSavePath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";

        // 创建目录结构
        if (!createDirectory(dirPath))
        {
            continue; // 跳过当前摄像头
        }

        // 开始录像
        saveVideo->startRecord(filePath);
        savePaths.push_back({QString::fromStdString(name), dirPath});
    }

    // 批量发送保存路径
    for (const auto &[name, path] : savePaths)
    {
        senderHikManagersendSavePathOut(name, path);
    }
    senderHikManagersendRecordState(true);
}

void _Controllers::VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : m_mapSaveVideo)
    {
        saveVideo->stopRecord();
    }
}

void _Controllers::VideoMaker::onInitSaveVideo(
    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>> cameraMap,
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>> cameraInfo,
    std::shared_ptr<std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>>> algorithmInfo)
{
    m_udmcam = cameraMap;
    m_udmcamInfo = cameraInfo;

    for (const auto &[name, info] : (*m_udmcamInfo))
    {
        if (m_mapSaveVideo.find(info.mstr_deviceName) == m_mapSaveVideo.end())
        {
            m_mapSaveVideo[info.mstr_deviceName] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            m_mapSaveVideo[info.mstr_deviceName]->initSaveVideo(1); // 初始化录像kit
        }

        if (m_mapIsDisplay.find(info.mstr_deviceName) == m_mapIsDisplay.end())
        {
            m_mapIsDisplay[info.mstr_deviceName] = true;
        }
    }

    for (const auto &[name, cam] : (*m_udmcam))
    {
        cam->setSendImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) {
            if (!img)
                return;

            static uint32_t count = 0;

            if (count++ % 500 == 0)
                _Kits::LogInfo("Receive image:{}", img->name);

            m_mapImgQueueForProcess[img->name].push(img);
        });
    }

    startAllThread();

    _Kits::LogInfo("VideoMaker initialized successfully.");
}

void _Controllers::VideoMaker::processImageThread()
{
    static int i = 0;

    while (m_bSaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : m_mapImgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */

                /* 发送图像 */
                if (m_mapIsDisplay[name])
                {
                    m_mapImgQueueForQml[name].push(img);
                }

                m_mapImgQueue[name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::sendToQmlThread()
{
    while (m_bSaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : m_mapImgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img || queue.unsafe_size() > 5)
                    continue;

                auto img_rgb = YUV420ptoRGB(img);

                QImage qimg(img_rgb->data.data(), img_rgb->width, img_rgb->height, QImage::Format_RGB888);
                if (!qimg.isNull())
                {
                    qimg = qimg.rgbSwapped();

                    QImage qimg_copy = qimg.copy(); // 避免内存被回收

                    if (img_rgb->camera_type == (int)TIS_Info::CameraType::CameraType_HIK)
                    {
                        senderHikManagersendImageToQml(QVariantMap{{"img", qimg}, {"camera_name", QString::fromStdString(img_rgb->name)}});
                    }
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}
void _Controllers::VideoMaker::sendTitleThread()
{
    std::vector<QString> subtitles;
    subtitles.reserve(16);

    std::vector<QString> empty_subtitle = {""};

    while (m_bSaveVideo.load())
    {
        if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE)
        {
            for (const auto &name_cam : (*m_udmcam))
            {
                name_cam.second->onWriteSubTitle(empty_subtitle);
            }
        }
        else if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_RUNNING || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
        {

            // 使用tbb::concurrent_unordered_map的安全访问方式
            auto station_it = m_mapSubTitle.find("站区名");
            if (station_it != m_mapSubTitle.end())
            {
                subtitles.push_back("站区名:" + station_it->second.toString());
            }

            auto anchor_it = m_mapSubTitle.find("锚段名");
            if (anchor_it != m_mapSubTitle.end())
            {
                subtitles.push_back("锚段名:" + anchor_it->second.toString());
            }

            auto pole_it = m_mapSubTitle.find("杆号名");
            if (pole_it != m_mapSubTitle.end())
            {
                subtitles.push_back("杆号名:" + pole_it->second.toString());
            }

            auto km_it = m_mapSubTitle.find("公里标");
            if (km_it != m_mapSubTitle.end())
            {
                subtitles.push_back("公里标:" + QString::number(km_it->second.toDouble() / 1000 / 1000, 'f', 3));
            }

            auto speed_it = m_mapSubTitle.find("速度");
            if (speed_it != m_mapSubTitle.end())
            {
                subtitles.push_back("速度:" + QString::number(speed_it->second.toDouble(), 'f', 3));
            }

            auto press_it = m_mapSubTitle.find("压力");
            if (press_it != m_mapSubTitle.end())
            {
                subtitles.push_back("压力:" + QString::number(press_it->second.toDouble(), 'f', 3));
            }

            auto temp_it = m_mapSubTitle.find("硬点");
            if (temp_it != m_mapSubTitle.end())
            {
                subtitles.push_back("硬点:" + QString::number(temp_it->second.toDouble(), 'f', 3));
            }

            auto vol_it = m_mapSubTitle.find("电压");
            if (vol_it != m_mapSubTitle.end())
            {
                subtitles.push_back("电压:" + QString::number(vol_it->second.toDouble(), 'f', 3));
            }

            auto height_it = m_mapSubTitle.find("导高");
            if (height_it != m_mapSubTitle.end())
            {
                subtitles.push_back("导高:" + QString::number(height_it->second.toDouble(), 'f', 3));
            }

            auto zig_it = m_mapSubTitle.find("拉出值");
            if (zig_it != m_mapSubTitle.end())
            {
                subtitles.push_back("拉出值:" + QString::number(zig_it->second.toDouble(), 'f', 3));
            }

            for (const auto &name_cam : (*m_udmcam))
            {
                name_cam.second->onWriteSubTitle(subtitles);
            }

            subtitles.clear();
            std::this_thread::sleep_for(std::chrono::milliseconds(50)); // 发送一次标题
        }
    }
}

void VideoMaker::onJiheInfo(const TIS_Info::JiHeData &data)
{

    m_mapSubTitle["导高"] = data.fHeiBc[0];
    m_mapSubTitle["拉出值"] = data.fZigBc[0];
}

void VideoMaker::onPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    auto ret = (data.md_press0 == 8000 ? 0 : data.md_press0) + (data.md_press1 == 8000 ? 0 : data.md_press1) +
               (data.md_press2 == 8000 ? 0 : data.md_press2) + (data.md_press3 == 8000 ? 0 : data.md_press3);

    m_mapSubTitle["压力"] = (ret == 0 ? 8000 : ret);
    m_mapSubTitle["硬点"] = data.md_spot0x;
}

void VideoMaker::onVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    m_mapSubTitle["电压"] = data.md_voltage0;
    m_mapSubTitle["电流"] = data.md_electric0;
}

void _Controllers::VideoMaker::onDisplayImgOption(QVariant data)
{
    QVariantMap map = data.toMap();
    QString camera_name = map.value("camera_name").toString();
    bool isDisplay = map.value("isDisplay").toBool();

    m_mapIsDisplay[camera_name.toStdString()] = isDisplay;
}

void _Controllers::VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    m_mapSubTitle["站区名"] = location_data.station_name;
    m_mapSubTitle["杆号名"] = location_data.pole_name;
    m_mapSubTitle["公里标"] = location_data.mileage_adjust;
    m_mapSubTitle["速度"] = location_data.speed;

    // _Kits::LogError("[VideoMaker::onGetLocation] : 从定位处收到速度{}", location_data.speed);

    m_locationCtrl->updateLocation(location_data.station_name);
}

void _Controllers::VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    handleTaskBegin(task_info);
}

void _Controllers::VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    handleTaskEnd(task_info);
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = m_ImageBufferPools->getObject(w, h, 3); // RGB24

    cv::Mat yuv_mat(h * 3 / 2, w, CV_8UC1, img_yuv420p->data.data());
    cv::Mat rgb_mat(h, w, CV_8UC3, img_rgb->data.data());
    cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}

void _Controllers::VideoMaker::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskBegin: Task start");

    std::lock_guard<std::mutex> lock(m_mutex);
    m_taskInfo = task_info;
    m_locationCtrl->updateLocation("");
    // 更新保存路径
    if (!task_info.strTaskSavePath.empty())
    {
        m_qStrSavePath = task_info.strTaskSavePath.c_str();
        createDirectory(m_qStrSavePath);
    }
    // if (!task_info.strTaskSavePath.isEmpty())
    // {
    //     m_qStrSavePath = task_info.strTaskSavePath;
    //     createDirectory(m_qStrSavePath);
    // }
}

void _Controllers::VideoMaker::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskEnd: Task end");

    std::lock_guard<std::mutex> lock(m_mutex);
    m_taskInfo = task_info;

    // 停止所有录像
    onStopRecord();
    senderHikManagersendRecordState(false);
}

void VideoMaker::startAllThread()
{
    if (!m_threadProcessImage.joinable())
    {
        m_threadProcessImage = std::thread(&VideoMaker::processImageThread, this);
    }
    if (!m_threadSaveVideo.joinable())
    {
        m_threadSaveVideo = std::thread(&VideoMaker::saveVideoThread, this);
    }
    if (!m_threadSendToQml.joinable())
    {
        m_threadSendToQml = std::thread(&VideoMaker::sendToQmlThread, this);
    }
    if (!m_threadSendTitle.joinable())
    {
        m_threadSendTitle = std::thread(&VideoMaker::sendTitleThread, this);
    }
}

void VideoMaker::stopAllThread()
{
    if (m_threadSaveVideo.joinable())
    {
        m_threadSaveVideo.join();
    }
    if (m_threadProcessImage.joinable())
    {
        m_threadProcessImage.join();
    }
    if (m_threadSendToQml.joinable())
    {
        m_threadSendToQml.join();
    }
    if (m_threadSendTitle.joinable())
    {
        m_threadSendTitle.join();
    }
}
} // namespace _Controllers
