#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <mutex>
#include <json/json.h>
#include <mutex>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#include "kits/camera/tools/LocationCtrl.h"
#include "kits/camera/hik/base/HikBase.h"

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();
    void onStopVideoMaker();
    void onStartRecord(QString);
    void onStopRecord();

    /// @brief 单个相机录像
    /// @param camera_name 相机名
    /// @param file_name 录像名
    void onStartRecordOneCame(QString, QString);
    /// @brief 单个相机录像结束
    /// @param camera_name 相机名
    void onStopRecordOneCame(QString);

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraMap(std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>> &&) 录像kit的名称列表
    /// @param cameraInfo(std::vector<TIS_Info::HikLogInfo> &&) 相机信息
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>>,
                         std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>>,
                         std::shared_ptr<std::unordered_map<std::string, std::vector<TIS_Info::AlgorithmInfo>>>);

    void onDisplayImgOption(QVariant);

    void onGetLocation(const TIS_Info::LocationData &);
    void onTaskBegin(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);
    void onPressSpotInfo(const TIS_Info::PressAndSpot &);
    void onVolElecInfo(const TIS_Info::VoltageAndElectric &);
    void onJiheInfo(const TIS_Info::JiHeData &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HikManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, VideoMaker::onGetLocation);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, VideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, VideoMaker::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::HikManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, VideoMaker::onPressSpotInfo);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, VideoMaker::onVolElecInfo);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::JiHeDataBroadcast, VideoMaker::onJiheInfo);

    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::onDisplayImgOption);

    TASK_LIST_END

  private:
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> m_mapImgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> m_mapSaveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> m_mapImgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> m_mapImgQueueForQml;
    std::unordered_map<std::string, bool> m_mapIsDisplay;

    std::thread m_threadSaveVideo;
    std::atomic_bool m_bSaveVideo{true};
    std::atomic_bool m_bStop{false};

    std::thread m_threadProcessImage;
    std::thread m_threadSendToQml;

    std::thread m_threadSendTitle;

    QString m_qStrSavePath{""}; // 保存路径

    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> m_ImageBufferPools{nullptr};

    tbb::concurrent_unordered_map<std::string, QVariant> m_mapSubTitle; // 用于存储字幕信息

    std::unique_ptr<_Kits::LocationCtrl> m_locationCtrl{nullptr};

    TIS_Info::TaskInfo m_taskInfo;
    std::mutex m_mutex;

    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>> m_udmcam{nullptr};
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>> m_udmcamInfo{nullptr};

  private:
    void saveVideoThread();
    void processImageThread();
    void sendToQmlThread();
    void sendTitleThread();
    void startAllThread();
    void stopAllThread();

    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yv12);
    void handleTaskBegin(const TIS_Info::TaskInfo &task_info);
    void handleTaskEnd(const TIS_Info::TaskInfo &task_info);
    bool createDirectory(const QString &dirPath);
};
} // namespace _Controllers