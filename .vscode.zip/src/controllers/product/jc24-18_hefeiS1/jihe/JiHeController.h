#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/struct_details/jihe_struct.h"
#include "kits/product_kits/save_rawdata/SaveRawdata.h"
#include <atomic>
#include <memory>
#include "JiheSql.h"

namespace _Controllers {
class JiHeController : public ControllerBase<JiHeController>
{

  public:
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvYanYanData(std::shared_ptr<TIS_Info::RawData>);
    void recvJiheData(const std::shared_ptr<TIS_Info::RawData> &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::YanYanDataCollect::rawDataReady, JiHeController::recvYanYanData);
    ASYNC_TASK_ADD(TIS_Info::SimulationService::distributeJiheData, JiHeController::recvJiheData);
    TASK_LIST_END

  private:
    void broadcastJiHeData(const std::shared_ptr<TIS_Info::JiHeData> &JiHeData);

  private:
    std::atomic_int m_taskID = -1;
    std::unique_ptr<_Kits::SaveRawdata> m_saveRawdataptr{nullptr};
    std::atomic_int64_t m_lastBroadcast{0};
    std::unique_ptr<JiheSql> m_sqlOp = std::make_unique<JiheSql>();
};
} // namespace _Controllers
