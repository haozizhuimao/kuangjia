#include "JiheSql.h"
#include "kits/common/database/SqlInsert.h"
#include "kits/common/database/orm/TableStructs.h"
#include "kits/utility/datetime/datetime.h"
#include <mutex>
#include <utility>
#include "kits/primary/thread_pool/thread_pool.h"
namespace _Controllers {
void JiheSql::insertJiheData(const std::shared_ptr<TIS_Info::JiHeData> &data)
{
    if (m_lastSaveTime == 0)
    {
        m_lastSaveTime = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    }
    auto currentTime = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    if (currentTime - m_lastSaveTime < 1000)
    {
        std::lock_guard lk(m_mtxData);
        m_vJiheDatas.push_back(data);
    }
    else
    {
        m_lastSaveTime = currentTime;
        fluash();
    }
}

void JiheSql::fluash()
{
    _Kits::thread_pool::runTask([this] {
        std::vector<std::shared_ptr<TIS_Info::JiHeData>> vJihes;
        {
            std::lock_guard lk(m_mtxData);
            std::swap(vJihes, m_vJiheDatas);
        }
        if (!vJihes.empty())
        {
            std::vector<_Kits::_Orm::jihe_data> res;
            for (const auto &item : vJihes)
            {
                _Kits::_Orm::jihe_data dbItem;
                dbItem.task_id = item->task_id;
                dbItem.frame_number = item->frame_number;
                dbItem.line_number = item->line_number;
                dbItem.pos_type = item->position_type;
                dbItem.zig0 = item->fZig[0];
                dbItem.hei0 = item->fHei[0];
                dbItem.zig_bc0 = item->fZigBc[0];
                dbItem.hei_bc0 = item->fHeiBc[0];
                dbItem.mohao_width0 = item->fMoHaoWidth[0];
                dbItem.mohao_height0 = item->fMoHaoHeight[0];

                dbItem.zig1 = item->fZig[1];
                dbItem.hei1 = item->fHei[1];
                dbItem.zig_bc1 = item->fZigBc[1];
                dbItem.hei_bc1 = item->fHeiBc[1];
                dbItem.mohao_width1 = item->fMoHaoWidth[1];
                dbItem.mohao_height1 = item->fMoHaoHeight[1];

                dbItem.zig2 = item->fZig[2];
                dbItem.hei2 = item->fHei[2];
                dbItem.zig_bc2 = item->fZigBc[2];
                dbItem.hei_bc2 = item->fHeiBc[2];
                dbItem.mohao_width2 = item->fMoHaoWidth[2];
                dbItem.mohao_height2 = item->fMoHaoHeight[2];

                dbItem.zig3 = item->fZig[3];
                dbItem.hei3 = item->fHei[3];
                dbItem.zig_bc3 = item->fZigBc[3];
                dbItem.hei_bc3 = item->fHeiBc[3];
                dbItem.mohao_width3 = item->fMoHaoWidth[3];
                dbItem.mohao_height3 = item->fMoHaoHeight[3];

                dbItem.left_bc_x = item->fLeftBCX;
                dbItem.left_bc_y = item->fLeftBCY;
                dbItem.right_bc_x = item->fRightBCX;
                dbItem.right_bc_y = item->fRightBCY;

                dbItem.diameter0 = item->Diameter[0];
                dbItem.diameter1 = item->Diameter[1];
                dbItem.diameter2 = item->Diameter[2];
                dbItem.diameter3 = item->Diameter[3];

                QString time = QString().fromStdString(_Kits::datetime::timepoint_to_string(item->timestamp));
                dbItem.created_time = time;
                dbItem.updated_time = time;
                res.push_back(std::move(dbItem));
            }

            _Kits::SqlInsert<_Kits::_Orm::jihe_data> insert;
            insert.insert(res).exec();
        }
    });
}
} // namespace _Controllers
