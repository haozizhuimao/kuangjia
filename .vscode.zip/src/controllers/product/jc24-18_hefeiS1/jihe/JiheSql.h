#include "tis_global/struct_details/jihe_struct.h"
#include <atomic>
#include <memory>
#include <mutex>
#include <vector>
namespace _Controllers
{
    class JiheSql
    {
      public:
        void insertJiheData(const std::shared_ptr<TIS_Info::JiHeData> &vecData);
        void fluash();

      private:
        std::atomic_int64_t m_lastSaveTime;
        std::mutex m_mtxData;
        std::vector<std::shared_ptr<TIS_Info::JiHeData>> m_vJiheDatas;
    };

} // namespace _Controllers