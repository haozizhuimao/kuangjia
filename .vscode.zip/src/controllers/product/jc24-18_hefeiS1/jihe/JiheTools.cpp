#include "JiheTools.h"
#include "JCWDataDef.h"
#include <memory>
namespace _Controllers
{
    std::shared_ptr<TIS_Info::JiHeData> JiheTools::convertToJiheData(const std::shared_ptr<JCWD> &jcwjh)
    {
        std::shared_ptr<TIS_Info::JiHeData> jiheData = std::make_shared<TIS_Info::JiHeData>();
        jiheData->frame_number = jcwjh->uiFrameNo;
        jiheData->line_number = jcwjh->uiLineNum;
        jiheData->position_type = jcwjh->GetPosiflag();
        jiheData->jcx_type = jcwjh->jcx[0].lt;
        for (int i = 0; i < jiheData->line_number; i++)
        {
            jiheData->fZig[i] =
                (jcwjh->jcx[i].pntLinePos.x > 8000 || jcwjh->jcx[i].pntLinePos.x <= -8000) ? 8000 : jcwjh->jcx[i].pntLinePos.x;

            jiheData->fHei[i] =
                (jcwjh->jcx[i].pntLinePos.y >= 8000 || jcwjh->jcx[i].pntLinePos.y <= -8000) ? 8000 : jcwjh->jcx[i].pntLinePos.y;

            jiheData->fZigBc[i] =
                (jcwjh->jcx[i].pntCompPos.x >= 8000 || jcwjh->jcx[i].pntCompPos.x <= -8000) ? 8000 : jcwjh->jcx[i].pntCompPos.x;

            jiheData->fHeiBc[i] =
                (jcwjh->jcx[i].pntCompPos.y >= 8000 || jcwjh->jcx[i].pntCompPos.y <= -8000) ? 8000 : jcwjh->jcx[i].pntCompPos.y;
            /**************************磨耗*********************************/
            jiheData->fMoHaoWidth[i] = jcwjh->jcx[i].fMhBotLen;
            jiheData->fMoHaoHeight[i] = jcwjh->jcx[i].fMohaoH;
            jiheData->Diameter[i] = jcwjh->jcx[i].fLineRidus;
        }

        jiheData->fLeftBCX = (fabs(jcwjh->pntCompLeft.x) < 100 && fabs(jcwjh->pntCompLeft.y) < 100) ? jcwjh->pntCompLeft.x : 8000;
        jiheData->fLeftBCY = (fabs(jcwjh->pntCompLeft.x) < 100 && fabs(jcwjh->pntCompLeft.y) < 100) ? jcwjh->pntCompLeft.y : 8000;
        jiheData->fRightBCX = (fabs(jcwjh->pntCompRight.x) < 100 && fabs(jcwjh->pntCompRight.y) < 100) ? jcwjh->pntCompRight.x : 8000;
        jiheData->fRightBCY = (fabs(jcwjh->pntCompRight.x) < 100 && fabs(jcwjh->pntCompRight.y) < 100) ? jcwjh->pntCompRight.y : 8000;

        return jiheData;
    }

} // namespace _Controllers