#include "JiHeController.h"
#include "JCWDataDef.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "JiheTools.h"
#include "service/AppInterface.h"
#include <array>
#include <atomic>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void JiHeController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    if (nullptr == m_saveRawdataptr)
    {
        m_saveRawdataptr = std::make_unique<_Kits::SaveRawdata>(1000);
    }

    if (TIS_Info::TaskState::TASK_STOPPED == task.nTaskstate || TIS_Info::TaskState::TASK_NONE == task.nTaskstate)
    {
        m_taskID.store(-1, std::memory_order_release);
        m_saveRawdataptr->finshCollectData();
        m_sqlOp->fluash();
    }
    else if (TIS_Info::TaskState::TASK_START == task.nTaskstate)
    {
        std::string dbname = std::format("{}_{}_{}", std::to_string(task.nTaskID), std::to_string(task.timestamp), "yanyan");
        m_saveRawdataptr->createDBFile(dbname, "rawdata");
    }

    m_taskID.store(task.nTaskID, std::memory_order_release);
}

void JiHeController::broadcastJiHeData(const std::shared_ptr<TIS_Info::JiHeData> &JiHeData)
{
    _Service::senderJiHeServicefull(JiHeData);
    auto currentTime = datetime::current_timestamp(datetime::TimestampUnit::Milliseconds);
    constexpr int interval = 50; // 间隔50ms
    auto lastTime = m_lastBroadcast.load(std::memory_order_acquire);
    if (currentTime - lastTime >= interval)
    {
        _Service::senderJiHeServicebroadcast(JiHeData); // 部分数据--巡检等使用
        m_lastBroadcast.store(currentTime, std::memory_order_release);
    }
}

void JiHeController::recvYanYanData(std::shared_ptr<TIS_Info::RawData> data)
{
    recvJiheData(data);
}
void JiHeController::recvJiheData(const std::shared_ptr<TIS_Info::RawData> &rawData)
{
    if (m_taskID == -1)
    {
        return;
    }
    std::shared_ptr<JCWD> jcwjh = std::make_shared<JCWD>();
    std::memcpy(jcwjh.get(), rawData->data.data(), sizeof(JCWD));
    // 1 结构解析
    auto jiheData = JiheTools::convertToJiheData(jcwjh);
    jiheData->timestamp = rawData->timestamp / 1000;
    jiheData->task_id = m_taskID.load(std::memory_order_acquire);
    broadcastJiHeData(jiheData);                                      // 几何广播
    m_saveRawdataptr->collectData(rawData->data, rawData->timestamp); // 采集原始数据，sqlite
    m_sqlOp->insertJiheData(jiheData);                                // 存储几何数据，pg
}

} // namespace _Controllers