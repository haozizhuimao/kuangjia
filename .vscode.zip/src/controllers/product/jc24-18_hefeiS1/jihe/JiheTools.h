

#include "tis_global/struct_details/jihe_struct.h"
#include "JCWDataDef.h"
#include <memory>
namespace _Controllers
{
    class JiheTools
    {

      public:
        static std::shared_ptr<TIS_Info::JiHeData> convertToJiheData(const std::shared_ptr<JCWD> &jcwjh);
    };
} // namespace _Controllers