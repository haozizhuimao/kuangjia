#include "Sensor6051Ctrl.h"
#include "service/AppInterface.h"
#include "kits/utility/log/CRossLogger.h"
#include <cstdint>
namespace _Controllers {

void Sensor6051Ctrl::onInit6051Ctrl(const TIS_Info::SpeedLogInfo &logInfo)
{
    m_logInfo = logInfo;

    if (m_6051connectivity == nullptr)
    {
        m_6051connectivity = std::make_shared<_Kits::Sensor6051>();
    }
    m_6051connectivity->setInfo(logInfo);
    m_6051connectivity->setDataCallback(
        [this](const TIS_Info::SpeedData &speed_data) { _Service::senderSensor6051DataOutsendSpeedDataOut(speed_data); });
    m_6051connectivity->setSpeedCallback(
        [this](double speed, int64_t timet) { _Service::senderSensor6051DataOutsendSpeedValue(speed, timet); });
    m_6051connectivity->start();
}

void Sensor6051Ctrl::onTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    if (m_6051connectivity == nullptr)
    {
        m_6051connectivity = std::make_shared<_Kits::Sensor6051>();
    }

    auto it = clients.find(TCP_NAME);
    if (it == clients.end())
    {
        return;
    }

    m_6051connectivity->setTcpClient(it->second);
    m_6051connectivity->start();
}

void Sensor6051Ctrl::onStop6051Ctrl()
{
    if (m_6051connectivity != nullptr)
    {
        m_6051connectivity->stop();
    }
}

void Sensor6051Ctrl::onTaskBegin(const TIS_Info::TaskInfo &taskInfo)
{
    if (m_6051connectivity != nullptr)
    {
        auto taskID = taskInfo.nTaskID;
        auto taskCreateTime = taskInfo.timestamp;
        auto taskName = std::to_string(taskID) + "_ " + std::to_string(taskCreateTime);
        m_6051connectivity->setTaskInfo(taskName);
    }
}

void Sensor6051Ctrl::onReceiveSimulationData(const std::shared_ptr<TIS_Info::RawData> &iData)
{
    // _Kits::LogInfo("iData.speed--------------- :{}",iData.size());
    if (m_6051connectivity)
    {
        m_6051connectivity->setSimulationData(iData);
    }
}

} // namespace _Controllers