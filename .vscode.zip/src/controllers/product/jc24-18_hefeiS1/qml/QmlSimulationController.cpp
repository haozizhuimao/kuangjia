#include "QmlSimulationController.h"
#include "kits/utility/log/CRossLogger.h"

#include <filesystem>
#include <string>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void QmlSimulationController::onRcvTaskBegin(const TIS_Info::TaskInfo &taskInfo)
{
    m_taskName = taskInfo.strTaskName;
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv, QVariant::fromValue(m_taskName));

    if (m_isRun)
    {
        startRun();
    }
    return;
}

void QmlSimulationController::onRcvTaskEnd(const TIS_Info::TaskInfo &taskInfo)
{
    m_taskName = taskInfo.strTaskName;
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskend_recv, QVariant::fromValue(m_taskName));

    endRun();
    return;
}

void QmlSimulationController::onSimulationSelectDb(QVariant path)
{
    const auto dbPath = path.toString();
    const std::filesystem::path fullPath = std::filesystem::path(dbPath.toStdString()) / m_dbName;

    // 检查文件是否存在
    if (std::filesystem::exists(fullPath) && std::filesystem::is_regular_file(fullPath))
    {
        LogInfo("[仿真]找到 test.db 文件: {}", fullPath.string());
        m_isRun = true;
        receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::simulation_dbname_recv,
                                            QVariant::fromValue(m_dbName));

        try
        {
            senderSimulationServiceinitDbData(fullPath.string());
        }
        catch (...)
        {
            LogError("[仿真]调用 SimulationService 失败");
        }
    }
    else
    {
        m_isRun = false;
        LogWarn("[仿真]未找到 test.db 文件: {}", fullPath.string());
    }
}

void QmlSimulationController::startRun()
{
    LogInfo("[仿真]开始运行");
    try
    {
        senderSimulationServicestartRun();
    }
    catch (...)
    {
        LogError("[仿真]调用 SimulationService 失败");
    }
}

void QmlSimulationController::endRun()
{
    LogInfo("[仿真]结束运行");
    try
    {
        senderSimulationServicestopRun();
    }
    catch (...)
    {
        LogError("[仿真]调用 SimulationService 失败");
    }
}
} // namespace _Controllers
