#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include <memory>
#include <mutex>
namespace _Controllers {
class QmlLocationController : public ControllerBase<QmlLocationController>
{
  public:
    void sendPositToPage(const TIS_Info::LocationData &);
    void sendJiHeToQml(std::shared_ptr<TIS_Info::JiHeData>);
    void sendTaskNameToQml(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, QmlLocationController::sendPositToPage);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::broadcast, QmlLocationController::sendJiHeToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlLocationController::sendTaskNameToQml);
    TASK_LIST_END

    template <typename T>
    std::pair<T, size_t> findClosestValueWithIndexSorted(const std::vector<T> &sortedArray, T target);

  private:
    void getJiheTimestamp(int64_t timestamp);

  private:
    std::vector<TIS_Info::LocationData> mv_locationData;
    std::thread m_locationDataSendThread;
    std::mutex m_timeStampMuxtex;
    std::mutex m_locationDataMutex;
    std::atomic<TIS_Info::LocationType> m_locationType;
    std::atomic<float> mf_lastZig1;
    int64_t m_jiheLatestTimestamp = 0;
    std::vector<int64_t> timeStamps;
    int maxTimeStampConut = 300;
};
} // namespace _Controllers