#include "QmlRfidController.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlRfidController::onSendRfidCountToQml(int data)
{
    // 发送rfid数据到QML
    qDebug() << "Sending RFID count to QML:" << data;
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_count_send, QVariant::fromValue(data));
}

void QmlRfidController::onSendRfidDataToQml(const std::string &data)
{
    if (!data.empty())
    {
        // 计数自增
        m_rfidCountMap[data]++;
        int count = m_rfidCountMap[data];

        LogInfo("RFID data received: {}, count: {}", data.c_str(), count);

        // 创建包含rfid和计数值的QVariantMap
        QVariantMap rfidData;
        rfidData["rfid"] = QString::fromStdString(data);
        rfidData["count"] = count;

        // 发送rfid和计数值到QML
        receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_recv, QVariant::fromValue(rfidData));
    }
    else
    {
        LogWarn("Received invalid RFID data");
    }
}

void QmlRfidController::onClearRfidData(const TIS_Info::TaskInfo &)
{
    // 清空RFID计数映射
    m_rfidCountMap.clear();
    LogInfo("RFID count map cleared");
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::rfid_count_send, QVariant::fromValue(0));
}

} // namespace _Controllers
