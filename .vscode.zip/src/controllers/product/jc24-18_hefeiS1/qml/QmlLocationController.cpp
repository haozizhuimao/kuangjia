#include "QmlLocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include <qvariant.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlLocationController::sendPositToPage(const TIS_Info::LocationData &data)
{
    // 数据点
    QVariantMap locationData = {{"station_name", data.station_name.c_str()},
                                {"maoduan_name", data.maoduan_name.c_str()},
                                {"speed", data.speed},
                                {"pole_name", data.pole_name.c_str()},
                                {"kilometer", data.mileage_adjust / 1000000.0},
                                {"distance", data.mileage_normal / 1000000.0},
                                {"location_type", (int)data.location_type},
                                {"timestamp", data.timestamp},
                                {"line_direction", data.line_direction}};

    std::lock_guard<std::mutex> lock(m_timeStampMuxtex);
    if (m_jiheLatestTimestamp > 0)
    {
        locationData["timestamp"] = m_jiheLatestTimestamp;
    }

    // 发送所有数据到QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvlocation_page, QVariant::fromValue(locationData));

    // //
    // if (!timeStamps.empty())
    // {
    //     // 近值匹配
    //     std::pair<int64_t, size_t> colser = findClosestValueWithIndexSorted(timeStamps, data.timestamp);

    //     if (colser.first != -1)
    //     {
    //         locationData["timestamp"] = colser.first;
    //     }

    //     // 发送所有数据到QML
    //     receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvlocation_page,
    //     QVariant::fromValue(locationData));
    // }
}

void QmlLocationController::sendJiHeToQml(std::shared_ptr<TIS_Info::JiHeData> data)
{

    // 曲线
    QVariantMap jiHeData = {{"line_number", data->line_number},
                            {"zig0", data->fZig[0]},
                            {"zig1", data->fZig[1]},
                            {"zig2", data->fZig[2]},
                            {"zig3", data->fZig[3]},
                            {"hei0", data->fHei[0]},
                            {"hei1", data->fHei[1]},
                            {"hei2", data->fHei[2]},
                            {"hei3", data->fHei[3]},
                            {"mohao0", data->fMoHaoWidth[0]},
                            {"mohao1", data->fMoHaoWidth[1]},
                            {"mohao2", data->fMoHaoWidth[2]},
                            {"mohao3", data->fMoHaoWidth[3]},
                            {"timestamp", data->timestamp}};

    getJiheTimestamp(jiHeData["timestamp"].toLongLong());

    static bool zig1Jumped = false;
    float lastZig1 = mf_lastZig1.load(std::memory_order_acquire);

    if (data->fZig[1] == 8000)
    {
        // 遇到8000，重置状态
        zig1Jumped = false;
        mf_lastZig1.store(0.0f, std::memory_order_release);
    }
    else if (!zig1Jumped)
    {
        if (lastZig1 == 0.0f)
        {
            // 第一次有效值
            jiHeData["zig1"] = data->fZig[1];
            mf_lastZig1.store(data->fZig[1], std::memory_order_release);
        }
        else if (std::abs(data->fZig[1] - lastZig1) > 100)
        {
            // 跳变发生，只发送跳变前的数据
            jiHeData["isBreakPoint"] = true;
            zig1Jumped = true;
        }
        else
        {
            // 正常值
            jiHeData["zig1"] = data->fZig[1];
            mf_lastZig1.store(data->fZig[1], std::memory_order_release);
        }
    }

    // 发送数据到 QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::jihedata_recv, QVariant::fromValue(jiHeData));
}

void QmlLocationController::sendTaskNameToQml(const TIS_Info::TaskInfo &taskInfo)
{
    QString taskName = taskInfo.strTaskName.c_str();

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv, QVariant::fromValue(taskName));
}

void QmlLocationController::getJiheTimestamp(int64_t timestamp)
{
    std::lock_guard<std::mutex> lock(m_timeStampMuxtex);
    // 记录几何最新点时间戳
    m_jiheLatestTimestamp = timestamp;

    // if (timeStamps.size() < maxTimeStampConut)
    // {
    //     timeStamps.push_back(timestamp);
    // }
    // else
    // {
    //     timeStamps.erase(timeStamps.begin());
    //     timeStamps.push_back(timestamp);
    // }
}

template <typename T>
std::pair<T, size_t> QmlLocationController::findClosestValueWithIndexSorted(const std::vector<T> &sortedArray, T target)
{
    if (sortedArray.empty())
    {
        throw std::invalid_argument("Array is empty");
    }

    auto it = std::lower_bound(sortedArray.begin(), sortedArray.end(), target);

    if (it == sortedArray.begin())
    {
        return std::make_pair(*it, 0);
    }

    if (it == sortedArray.end())
    {
        return std::make_pair(*(it - 1), sortedArray.size() - 1);
    }

    T after = *it;
    auto beforeIt = it - 1;
    T before = *beforeIt;

    if ((target - before) < (after - target))
    {
        return std::make_pair(before, std::distance(sortedArray.begin(), beforeIt));
    }
    else
    {
        return std::make_pair(after, std::distance(sortedArray.begin(), it));
    }
}
} // namespace _Controllers
