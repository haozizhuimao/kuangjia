#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <QString>
#include "kits/ui/qml_kits/ImagePainter.h"
namespace _Controllers {
class QmlVideoDisplay : public ControllerBase<QmlVideoDisplay>
{
  public:
    void displayVideo(std::shared_ptr<TIS_Info::ImageBuffer>);
    void sendImagePathToQml(QString, QString);
    void sendTaskNameToQml(const TIS_Info::TaskInfo &);
    void onSendRecordStateToQml(bool);
    void recvImagePainter(QVariant);
    void onDisplayImgOption(QVariant);
    void onExposureAndGain(int exposure, int gain, const std::string &camera_name);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendImageToQml, QmlVideoDisplay::displayVideo);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendSavePathOut, QmlVideoDisplay::sendImagePathToQml);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendRecordState, QmlVideoDisplay::onSendRecordStateToQml);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendExposureAndGain, QmlVideoDisplay::onExposureAndGain);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlVideoDisplay::sendTaskNameToQml);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::sendImagePainter, QmlVideoDisplay::recvImagePainter);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, QmlVideoDisplay::onDisplayImgOption);
    TASK_LIST_END
  private:
    const QString cameraName = "camera1";
    _Kits::ImagePainter *m_imagePainter = nullptr;
    bool m_isDisplay = true;
    bool m_firstFPS = true;
};
} // namespace _Controllers