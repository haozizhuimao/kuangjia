#include "LocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/common/location_general/LocationGeneral.h"
#include "tis_global/enum_public/location_enum.h"
#include <QJsonDocument>
#include <cstdint>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void LocationController::moduleStarted(TIS_Info::LocationConfigs config, std::shared_ptr<_Kits::LocationBase> ptrTools)
{
    m_kitLocation = ptrTools;
}

void LocationController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_curTaskInfo = task;
    if (task.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto data = locationTools->startTask(task);
        if (!data.pole_name.empty())
        {
            _Service::senderLocationServiceLocationRadio(data);
            LogInfo("[定位开始] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
        }
    }
    else if (task.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        auto data = locationTools->stopTask();
        if (!data.pole_name.empty())
        {
            _Service::senderLocationServiceLocationRadio(data);
        }
        LogInfo("[定位结束] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
    }
}

void LocationController::recvSpeedValue(double speed, int64_t timestamp)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    // LogInfo("recvSpeedValue.timestamp--------------- :{}",timestamp);

    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto locationPtr = static_cast<LocationGeneral *>(locationTools.get());
        locationPtr->updateSpeed(speed);
    }
}

void LocationController::recvSpeedData(const TIS_Info::SpeedData &data)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    auto locationPtr = static_cast<LocationGeneral *>(locationTools.get());
    auto locationData = locationPtr->updateMillimeter(data.mull_millimeter, data.timestamp);
    if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
    {
        lastSendMM = locationData.milimeter;
        _Service::senderLocationServiceLocationRadio(locationData);
    }
    else
    {
        if (locationData.milimeter - lastSendMM >= 1000)
        {
            _Service::senderLocationServiceLocationRadio(locationData);
            lastSendMM = locationData.milimeter;
        }
    }
}

void LocationController::recvRfidDataFromQml(QVariant data)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid rfid data!");
        return;
    }
}

void LocationController::recvRfidDataFromModule(const std::string &data, int64_t timet)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.empty())
    {
        LogError("Invalid rfid data!");
        return;
    }
}

void LocationController::recvHandData(QVariant data)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid data!");
        return;
    }
    QVariantMap variant = convertDataToJsonOrMap(data);
    QString str = variant.value("pole_name").toString();
    // m_kitLocation->handAdjust(str);

    // auto locationData = m_kitLocation->getCurrentData();
    // locationData.location_type = TIS_Info::LocationType::PT_HAND;
    // _Service::senderLocationServiceLocationRadio(locationData);
}

void LocationController::recvJiheData(std::shared_ptr<TIS_Info::JiHeData> data)
{
    auto locationTools = m_kitLocation.lock();

    if (locationTools == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(locationTools.get());
    auto locationData = locationPtr->updateJiheData(data);
    if (locationData.timestamp > 0)
    {
        if (locationData.milimeter - lastSendImgMM_ > 1000)
        {
            lastSendImgMM_ = locationData.milimeter;
            _Service::senderLocationServiceLocationRadio(locationData);
        }
    }
}

QVariantMap LocationController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}

} // namespace _Controllers