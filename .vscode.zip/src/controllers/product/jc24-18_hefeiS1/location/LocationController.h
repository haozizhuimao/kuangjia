#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <atomic>
#include <cstdint>
#include <memory>
#include "kits/common/location_general/LocationBase.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/jihe_struct.h"
#include "tis_global/struct_details/location_struct.h"
namespace _Controllers {
class LocationController : public ControllerBase<LocationController>
{
  public:
    void moduleStarted(TIS_Info::LocationConfigs, std::shared_ptr<_Kits::LocationBase>);
    void recvTaskData(const TIS_Info::TaskInfo &);

    void recvJiheData(std::shared_ptr<TIS_Info::JiHeData>);
    void recvRfidDataFromQml(QVariant);
    void recvRfidDataFromModule(const std::string &, int64_t);
    void recvHandData(QVariant);
    QVariantMap convertDataToJsonOrMap(const QVariant &);
    void recvSpeedData(const TIS_Info::SpeedData &);
    void recvSpeedValue(double, int64_t);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::LocationService::moduleStarted, LocationController::moduleStarted);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::sendSpeedDataOut, LocationController::recvSpeedData);
    ASYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::sendSpeedValue, LocationController::recvSpeedValue);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::RfidSimulate, LocationController::recvRfidDataFromQml);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ULPoleCalibration, LocationController::recvHandData);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::PoleCalibration, LocationController::recvHandData);
    ASYNC_TASK_ADD(TIS_Info::RfidService::rfidDeduplicated, LocationController::recvRfidDataFromModule);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::full, LocationController::recvJiheData);
    TASK_LIST_END
  private:
    std::weak_ptr<_Kits::LocationBase> m_kitLocation;
    TIS_Info::TaskInfo m_curTaskInfo;
    std::atomic_uint64_t lastSendMM = 0;
    std::atomic_int64_t lastSendImgMM_ = 0;
};

} // namespace _Controllers
