#include "PressSpotDataController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/primary/thread_pool/thread_pool.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

PressSpotDataController::PressSpotDataController() {}

PressSpotDataController::~PressSpotDataController() noexcept
{
    checkWritePressData(true);

    _mb_thread_process_run.store(false, std::memory_order_release);

    if (_m_thread_process.joinable())
    {
        _m_thread_process.join();
    }
}

void PressSpotDataController::getPressAndSpot(TIS_Info::PressAndSpot press_and_spot)
{
    if (press_and_spot.md_spot0x != 8000)
    {
        m_pressAndSpot.md_spot0x = operateData("spot_0x", press_and_spot.md_spot0x);
    }
    if (press_and_spot.md_spot0y != 8000)
    {
        m_pressAndSpot.md_spot0y = operateData("spot_0y", press_and_spot.md_spot0y);
    }
    if (press_and_spot.md_press0 != 8000)
    {
        m_pressAndSpot.md_press0 = operateData("press0", press_and_spot.md_press0);
    }
    if (press_and_spot.md_press1 != 8000)
    {
        m_pressAndSpot.md_press1 = operateData("press1", press_and_spot.md_press1);
    }
    if (press_and_spot.md_press2 != 8000)
    {
        m_pressAndSpot.md_press2 = operateData("press2", press_and_spot.md_press2);
    }
    if (press_and_spot.md_press3 != 8000)
    {
        m_pressAndSpot.md_press3 = operateData("press3", press_and_spot.md_press3);
    }
    if (press_and_spot.md_press4 != 8000)
    {
        m_pressAndSpot.md_press4 = operateData("press4", press_and_spot.md_press4);
    }
    if (press_and_spot.md_press5 != 8000)
    {
        m_pressAndSpot.md_press5 = operateData("press5", press_and_spot.md_press5);
    }
    if (press_and_spot.md_press6 != 8000)
    {
        m_pressAndSpot.md_press6 = operateData("press6", press_and_spot.md_press6);
    }
    if (press_and_spot.md_press7 != 8000)
    {
        m_pressAndSpot.md_press7 = operateData("press7", press_and_spot.md_press7);
    }

    _m_cond_process.notify_one();
}

void _Controllers::PressSpotDataController::recvTaskData(const TIS_Info::TaskInfo &taskInfo)
{
    if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        checkWritePressData(true);
        _mi_task_id.store(-1, std::memory_order_release);
        return;
    }

    _mi_task_id.store(taskInfo.nTaskID, std::memory_order_release);

    if (!_m_thread_process.joinable())
    {
        _mb_thread_process_run.store(true, std::memory_order_release);
        _m_thread_process = std::thread(&PressSpotDataController::processDataThread, this);
    }
}

void _Controllers::PressSpotDataController::processDataThread()
{
    static uint16_t nCount = 0;

    while (_mb_thread_process_run.load(std::memory_order_acquire))
    {
        std::unique_lock<std::mutex> lock(_m_mutex_process);
        _m_cond_process.wait(lock, [this] { return _mi_task_id != -1 || !_mb_thread_process_run.load(std::memory_order_acquire); });

        if (!_mb_thread_process_run.load(std::memory_order_acquire))
        {
            continue;
        }

        _mdeq_pressData.push_back(initPressData());

        checkWritePressData();

        if (++nCount % 100 == 0) // 前端控制显示频率
        {
            sendPressSpotToQml();
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void _Controllers::PressSpotDataController::checkWritePressData(bool force)
{
    if (_mdeq_pressData.size() >= 1000 || force)
    {
        std::deque<_Kits::_Orm::press_data> pressDataQue;
        pressDataQue.swap(_mdeq_pressData);

        _Kits::thread_pool::runTask([pressDataQue = std::move(pressDataQue)] {
            // qDebug() << "insert press data" << pressDataQue.size();
            _Kits::SqlInsert<_Kits::_Orm::press_data> sqlInsert;
            sqlInsert.insert(pressDataQue);
            if (!sqlInsert.exec())
            {
                _Kits::LogError("sql insert error");
            }
        });
    }
}

void _Controllers::PressSpotDataController::sendPressSpotToQml()
{
    _Service::senderPressSpotVolElecEtcDatasendPressSpotOut(m_pressAndSpot);
}

double PressSpotDataController::operateData(QString data_name, double data)
{
    auto it = _mvec_equationCoefficients.find(data_name.toStdString());
    if (it != _mvec_equationCoefficients.end()) // 通道  等于  0
    {
        return (data + it->second.md_constant) * it->second.md_coefficient;
    }

    return 8000.0;
}

_Kits::_Orm::press_data _Controllers::PressSpotDataController::initPressData()
{

    _Kits::_Orm::press_data pressData;

    pressData.acc0_x = m_pressAndSpot.md_spot0x;
    pressData.acc0_y = m_pressAndSpot.md_spot0y;
    pressData.press0 = m_pressAndSpot.md_press0;
    pressData.press1 = m_pressAndSpot.md_press1;
    pressData.press2 = m_pressAndSpot.md_press2;
    pressData.press3 = m_pressAndSpot.md_press3;
    pressData.task_id = _mi_task_id.load(std::memory_order_acquire);

    pressData.press4 = m_pressAndSpot.md_press4;
    pressData.press5 = m_pressAndSpot.md_press5;
    pressData.press6 = m_pressAndSpot.md_press6;
    pressData.press7 = m_pressAndSpot.md_press7;

    pressData.acc0_z = 8000;
    pressData.acc1_x = 8000;
    pressData.acc1_y = 8000;
    pressData.acc1_z = 8000;

    return pressData;
}
void PressSpotDataController::recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017> EquationCoefficients)
{
    _mvec_equationCoefficients = EquationCoefficients;
}
} // namespace _Controllers