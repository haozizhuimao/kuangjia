#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <thread>
#include <deque>
#include "kits/common/database/CppBatis.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/press_acc_collect_struct.h"
#include <condition_variable>
#include <mutex>

namespace _Controllers {
class PressSpotDataController : public ControllerBase<PressSpotDataController>
{
  public:
    explicit PressSpotDataController();
    virtual ~PressSpotDataController() noexcept;

    void getPressAndSpot(TIS_Info::PressAndSpot);
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017>);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::Dispatch6017::sendPressAndSpotNatrualOut, PressSpotDataController::getPressAndSpot);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, PressSpotDataController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, PressSpotDataController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::initController, PressSpotDataController::recvEquationCoefficients);
    TASK_LIST_END

  private:
    TIS_Info::PressAndSpot m_pressAndSpot;
    TIS_Info::VoltageAndElectric m_volAndElec;

    std::unordered_map<std::string, TIS_Info::Equation6017> _mvec_equationCoefficients;

    std::thread _m_thread_process;
    std::mutex _m_mutex_process;
    std::condition_variable _m_cond_process;

    std::atomic_bool _mb_thread_process_run = false;
    std::deque<_Kits::_Orm::press_data> _mdeq_pressData;
    void processDataThread();

    _Kits::_Orm::press_data initPressData();

    void checkWritePressData(bool force = false);

    void sendPressSpotToQml();

    /// @brief 处理数据，计算因子
    /// @param data_name 数据名称
    double operateData(QString data_name, double data);

    std::atomic_int32_t _mi_task_id;
};
} // namespace _Controllers
