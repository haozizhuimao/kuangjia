#include "RfidController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include <qvariant.h>
#include "kits/common/database/CppBatis.h"
#include "kits/common/database/connections/DatabaseConnections.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

RfidController::RfidController() {}

void RfidController::onRecvTask(const TIS_Info::TaskInfo &taskInfo)
{
    if (m_rfidInfo.isSaveNatural && nullptr != m_saveRawdata)
    {
        std::string dbname = std::format("{}_{}_{}", std::to_string(taskInfo.nTaskID), std::to_string(taskInfo.timestamp), "rfid");
        m_saveRawdata->createDBFile(dbname, "rawdata");
    }
    m_taskInfo = taskInfo;
}
void RfidController::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find("RFID");
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", "RFID");
        return;
    }
    auto client = finder->second;
    if (nullptr == m_rfidKPCID)
    {
        m_rfidKPCID = std::make_unique<RfidKPCID1>();
    }
    m_rfidKPCID->setTcpClient(client);
    m_rfidKPCID->setSendRfidCallback([this](const std::string &rfid, int64_t timet) {
        if (rfid.empty())
        {
            return;
        }

        if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE)
        {
            return;
        }

        senderRfidServicesendRfidToQml(rfid);

        senderRfidServicerfidDeduplicated(rfid, timet);
    });

    if (!m_rfidKPCID->start())
    {
        LogError("RFID KPCID1 failed to start");
    }
}

void RfidController::onInitConfig(const TIS_Info::RfidInfo &info)
{
    m_rfidInfo = info;
    if (nullptr == m_rfidKPCID)
    {
        m_rfidKPCID = std::make_shared<RfidKPCID1>();
    }
    if (m_rfidInfo.isSaveNatural)
    {
        m_saveRawdata = std::make_unique<SaveRawdata>(1);
        m_rfidKPCID->setSendRawdataCallback(
            [this](const std::vector<uint8_t> &data, int64_t timet) { m_saveRawdata->collectData(data, timet); });
    }

    m_rfidKPCID->setInfo(info);
    m_rfidKPCID->start();
}

} // namespace _Controllers