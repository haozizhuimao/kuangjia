#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/rfid_kpc_kits/RfidKPCID1.h"
#include "kits/product_kits/save_rawdata/SaveRawdata.h"
#include <memory>

namespace _Controllers {
class RfidController : public ControllerBase<RfidController>
{
  public:
    explicit RfidController();

    void initNaturalDataBase(bool);
    void onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    void onInitConfig(const TIS_Info::RfidInfo &);
    void processDataThread();
    void onRecvTask(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::RfidService::rfidConfigInit, RfidController::onInitConfig);
    ASYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, RfidController::onSetTcpClient);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, RfidController::onRecvTask);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, RfidController::onRecvTask);

    TASK_LIST_END

  private:
    std::shared_ptr<_Kits::RfidKPCID1> m_rfidKPCID = nullptr;
    std::unique_ptr<_Kits::SaveRawdata> m_saveRawdata = nullptr;
    TIS_Info::TaskInfo m_taskInfo;
    TIS_Info::RfidInfo m_rfidInfo;
};
} // namespace _Controllers