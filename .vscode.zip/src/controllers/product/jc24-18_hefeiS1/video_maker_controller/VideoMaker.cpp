#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include "kits/utility/log/CRossLogger.h"
#include <QJsonValue>
#include <opencv2/opencv.hpp>
#include <QDir>
#include "tis_global/enum_public/video_enum.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/camera/tools/RemoteParser.h"
#include <QJsonDocument>
#include <QVariantMap>
#include <QJsonObject>
#include <QPainter>
#include <QFont>

namespace _Controllers {
using namespace _Service;

_Controllers::VideoMaker::VideoMaker()
    : _m_ImageBufferPools(std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>()),
      _m_locationCtrl(std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); })),
      _m_task_info({}), _mb_SaveVideo(true), _mqstr_SavePath({"d:/gwkj/video_Notask"}), _m_thread_saveVideo{}, _m_thread_sendToQml{},
      _m_thread_processImage{}, _m_thread_sendTitle{}
{}

_Controllers::VideoMaker::~VideoMaker()
{
    onStopVideoMaker();
}

void VideoMaker::onStopVideoMaker()
{
    _mb_SaveVideo.store(false);

    for (auto &[name, cam] : (m_udm_cam))
    {
        cam->closeCamera();
    }

    onStopRecord();

    stopAllThread();

    _m_locationCtrl->stop();
}

// 辅助函数：创建目录
bool VideoMaker::createDirectory(const QString &dirPath)
{
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            _Kits::LogError("Failed to create directory: {}", dirPath.toStdString());
            return false;
        }
    }
    return true;
}

void _Controllers::VideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> yuv420p;
            while (queue.try_pop(yuv420p))
            {
                if (!yuv420p)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(yuv420p);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::onStartRecord(QString fileName)
{
    QString dirPath, filePath;
    std::vector<std::pair<QString, QString>> savePaths;

    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        // 构建完整路径
        dirPath = _mqstr_SavePath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";

        // 创建目录结构
        if (!createDirectory(dirPath))
        {
            continue; // 跳过当前摄像头
        }

        // 开始录像
        saveVideo->startRecord(filePath);
        savePaths.push_back({QString::fromStdString(name), dirPath});
    }

    // 批量发送保存路径
    for (const auto &[name, path] : savePaths)
    {
        senderHikManagersendSavePathOut(name, path);
    }
    senderHikManagersendRecordState(true);
}

void _Controllers::VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
}

void _Controllers::VideoMaker::onInitSaveVideo(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> &cameraMap)
{
    m_udm_cam = cameraMap;

    for (const auto &[name, cam] : (cameraMap))
    {
        if (_mmap_saveVideo.find(name) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[name] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[name]->initSaveVideo(1); // 初始化录像kit
        }

        if (_mmap_isDisplay.find(name) == _mmap_isDisplay.end())
        {
            _mmap_isDisplay[name] = true;
        }
    }

    for (const auto &[name, cam] : (cameraMap))
    {
        cam->setSendImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) {
            if (!img)
                return;

            static uint32_t count = 0;

            if (count++ % 500 == 0)
                _Kits::LogInfo("Receive image:{}", img->name);

            if (_mmap_imgQueueForProcess[img->name].unsafe_size() < 10)
            {
                _mmap_imgQueueForProcess[img->name].push(img);
            }
        });
    }

    startAllThread();

    _Kits::LogInfo("VideoMaker initialized successfully.");
}

void _Controllers::VideoMaker::writeSubTitle(int pointSize,
                                             const QString &family,
                                             Qt::GlobalColor color,
                                             std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    QImage qimg(img->data.data(), img->width, img->height, QImage::Format_RGB888);
    QPainter painter(&qimg);
    painter.setPen(color);
    painter.setFont(QFont(family, pointSize));

    int y = 30;
    // 加锁读取字幕，避免并发访问导致的闪烁
    std::vector<QString> current_subtitles;
    {
        std::lock_guard<std::mutex> lock(_m_subMutex);
        current_subtitles = m_subtitles;
    }

    for (auto &subtitle : current_subtitles)
    {
        painter.drawText(QRect(20, y, qimg.width(), 70), Qt::AlignLeft | Qt::AlignTop, subtitle);
        y += 70;
    }
}

void _Controllers::VideoMaker::processImageThread()
{
    static int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */
                if (img->pixFormat == (int)TIS_Info::AVPixelFormat::AV_PIX_FMT_YUV420P)
                {
                    img = YUV420ptoRGB(img);
                }

                writeSubTitle(42, "SimHei", Qt::white, img);
                /* 发送图像 */
                if (_mmap_isDisplay[name] && queue.unsafe_size() < 5)
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                try
                {
                    if (img->camera_type == (int)TIS_Info::CameraType::CameraType_HIK && _mb_SaveVideo.load())
                    {
                        senderHikManagersendImageToQml(img);
                    }
                }
                catch (const std::exception &e)
                {
                    break;
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::SetExposureTimeAndGain(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    QString type = dataMap.value("type").toString();

    if (type == "setExposureAndGain")
    {
        std::string cameraName = dataMap.value("camera_name").toString().toStdString();
        DWORD exposureTime = static_cast<DWORD>(dataMap.value("exposure").toUInt());
        BYTE gainValue = static_cast<BYTE>(dataMap.value("gain").toUInt());

        auto it = m_udm_cam.find(cameraName);
        if (it != m_udm_cam.end())
        {
            it->second->onSetExposureTimeAndGain(exposureTime, gainValue);
        }
    }
}

void _Controllers::VideoMaker::SetFocusZoom(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    QString type = dataMap.value("type").toString();
    if (type == "focus")
    {
        std::string cameraName = dataMap.value("camera_name").toString().toStdString();
        std::string command = dataMap.value("command").toString().toStdString();
        std::string status = dataMap.value("status").toString().toStdString();
        bool isStop = (status == "STOP");

        auto it = m_udm_cam.find(cameraName);
        if (it != m_udm_cam.end())
        {
            if (command == "focus-plus")
            {
                it->second->onFocusPlus(isStop);
            }
            else if (command == "focus-minus")
            {
                it->second->onFocusMinus(isStop);
            }
            else if (command == "zoom-plus")
            {
                it->second->onZoomPlus(isStop);
            }
            else if (command == "zoom-minus")
            {
                it->second->onZoomMinus(isStop);
            }
            else if (command == "auto-focus")
            {
                it->second->onAutoFocus();
            }
        }
    }
}

void _Controllers::VideoMaker::PTZControl(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string type = dataMap.value("type").toString().toStdString();
    if (type == "PTZControl")
    {
        std::string cameraName = dataMap.value("camera_name").toString().toStdString();
        std::string dir = dataMap.value("dir").toString().toStdString();
        std::string command = dataMap.value("command").toString().toStdString();

        auto it = m_udm_cam.find(cameraName);
        if (it != m_udm_cam.end())
        {
            it->second->onPTZControl(dir, command);
        }
    }
}

void _Controllers::VideoMaker::SetPTZSpeed(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    QString type = dataMap.value("type").toString();
    if (type == "SetPTZSpeed")
    {
        std::string cameraName = dataMap.value("camera_name").toString().toStdString();
        DWORD speed = static_cast<DWORD>(dataMap.value("speed").toUInt());

        auto it = m_udm_cam.find(cameraName);
        if (it != m_udm_cam.end())
        {
            it->second->onSetPTZSpeed(speed);
        }
    }
}

QVariantMap _Controllers::VideoMaker::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: data is not a string");
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: invalid JSON object");
        return {};
    }

    return doc.object().toVariantMap();
}

void _Controllers::VideoMaker::sendTitleThread()
{
    std::vector<QString> subtitles;
    subtitles.reserve(128);

    std::vector<QString> empty_subtitle = {};

    while (_mb_SaveVideo.load(std::memory_order_acquire))
    {
        if (_m_task_info.nTaskstate == TIS_Info::TaskState::TASK_STOPPED || _m_task_info.nTaskstate == TIS_Info::TaskState::TASK_NONE)
        {
            m_subtitles = empty_subtitle;
        }
        else if (_m_task_info.nTaskstate == TIS_Info::TaskState::TASK_RUNNING || _m_task_info.nTaskstate == TIS_Info::TaskState::TASK_START)
        {
            subtitles.clear();

            {
                std::lock_guard<std::mutex> lock(_m_subTitleMutex);
                subtitles.push_back("站区名:" + m_subTitle_send.stationName);
                subtitles.push_back("杆号名:" + m_subTitle_send.poleName);
            }

            subtitles.push_back("公里标:" +
                                QString::number(m_subTitle_send.kilometerMark.load(std::memory_order_acquire) / 1000 / 1000, 'f', 3));
            subtitles.push_back("速度:" + QString::number(m_subTitle_send.speed.load(std::memory_order_acquire), 'f', 3));
            subtitles.push_back("压力:" + QString::number(m_subTitle_send.pressure.load(std::memory_order_acquire), 'f', 3));
            subtitles.push_back("硬点:" + QString::number(m_subTitle_send.hardPoint.load(std::memory_order_acquire), 'f', 3));
            subtitles.push_back("网压:" + QString::number(m_subTitle_send.voltage.load(std::memory_order_acquire), 'f', 3));
            subtitles.push_back("导高:" + QString::number(m_subTitle_send.height.load(std::memory_order_acquire), 'f', 3));
            subtitles.push_back("拉出值:" + QString::number(m_subTitle_send.zig.load(std::memory_order_acquire), 'f', 3));

            {
                std::lock_guard<std::mutex> lock(_m_subMutex);
                if (!subtitles.empty())
                    m_subtitles.swap(subtitles);
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

void VideoMaker::onJiheInfo(std::shared_ptr<TIS_Info::JiHeData> data)
{
    if (data->fZigBc[0] < 7990)
    {
        m_subTitle_send.zig.store(data->fZigBc[0], std::memory_order_release);
    }
    if (data->fHeiBc[0] < 7990)
    {
        m_subTitle_send.height.store(data->fHeiBc[0], std::memory_order_release);
    }
}

void VideoMaker::onPressSpotInfo(const TIS_Info::PressAndSpot &data)
{
    auto ret = (data.md_press0 == 8000 ? 0 : data.md_press0) + (data.md_press1 == 8000 ? 0 : data.md_press1) +
               (data.md_press2 == 8000 ? 0 : data.md_press2) + (data.md_press3 == 8000 ? 0 : data.md_press3);
    ret = (ret == 0 ? 8000 : ret);

    if (ret < 7990)
    {
        m_subTitle_send.pressure.store(ret, std::memory_order_release);
    }
    if (data.md_spot0x < 7990)
    {
        m_subTitle_send.hardPoint.store(data.md_spot0x, std::memory_order_release);
    }
}

void VideoMaker::onVolElecInfo(const TIS_Info::VoltageAndElectric &data)
{
    if (data.md_voltage0 < 7990)
    {
        m_subTitle_send.voltage.store(data.md_voltage0, std::memory_order_release);
    }

    if (data.md_electric0 < 7990)
    {
        m_subTitle_send.current.store(data.md_electric0, std::memory_order_release);
    }
}

void _Controllers::VideoMaker::onQmlRecordSignal(QVariant data)
{
    QVariantMap map = convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    bool isCheck = map.value("isCheck").toBool();

    if (isCheck)
    {
        onStartRecordOneCame(camera_name, "");
    }
    else
    {
        // onStopRecordOneCame(camera_name);
    }
}

void VideoMaker::onStartRecordOneCame(QString camera_name, QString file_name)
{
    QString dirPath = _mqstr_SavePath + "/" + QDateTime::currentDateTime().toString("yyyyMMdd") + "/" + camera_name;
    QString filePath = dirPath + "/" + file_name + ".mp4";

    // 创建目录结构
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            qWarning() << "Failed to create directory:" << dirPath;
            _Kits::LogError("[HikCamera::onStartRecordOneCame] 创建文件夹失败，录像失败");
            return;
        }
    }

    _mmap_saveVideo[camera_name.toStdString()]->startRecord(filePath);
}

void VideoMaker::onStopRecordOneCame(QString camera_name)
{
    _mmap_saveVideo[camera_name.toStdString()]->stopRecord();
}

void _Controllers::VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    if (location_data.station_name.empty() || location_data.pole_name.empty())
    {
        return;
    }

    {
        std::lock_guard<std::mutex> lock(_m_subTitleMutex);
        m_subTitle_send.stationName = QString::fromStdString(location_data.station_name);
        m_subTitle_send.poleName = QString::fromStdString(location_data.pole_name);
    }

    m_subTitle_send.kilometerMark.store(location_data.mileage_adjust, std::memory_order_release);
    m_subTitle_send.speed.store(location_data.speed, std::memory_order_release);

    //_Kits::LogError("[VideoMaker::onGetLocation] : 从定位处收到速度{}", location_data.speed);

    _m_locationCtrl->updateLocation(location_data.station_name.c_str());
}

void _Controllers::VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    handleTaskBegin(task_info);
}

void _Controllers::VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    handleTaskEnd(task_info);
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    if (!m_p_yuv420pToRgb24)
    {
        m_p_yuv420pToRgb24 = std::make_shared<_Kits::SwsImagePixelConverter>();
    }

    auto img_rgb = m_p_yuv420pToRgb24->convertYUV420PToRGB24(img_yuv420p);
    if (!img_rgb)
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] conversion failed");
        return nullptr;
    }

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}

void _Controllers::VideoMaker::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskBegin: Task start");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;
    _m_locationCtrl->updateLocation("");
    // 更新保存路径
    if (!task_info.strTaskSavePath.empty())
    {

        _mqstr_SavePath = QString::fromStdString(task_info.strTaskSavePath);
        //_Kits::LogInfo("VideoMaker::handleTaskBegin: Task start path:{}",_mqstr_SavePath.toStdString());
        createDirectory(_mqstr_SavePath);
    }
    else
    {
        _Kits::LogError("VideoMaker::handleTaskBegin: Task error:path is empty");
    }
}

void _Controllers::VideoMaker::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskEnd: Task end");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;

    // 停止所有录像
    onStopRecord();
    senderHikManagersendRecordState(false);
}

void VideoMaker::startAllThread()
{
    if (!_m_thread_processImage.joinable())
    {
        _m_thread_processImage = std::thread(&VideoMaker::processImageThread, this);
    }
    if (!_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo = std::thread(&VideoMaker::saveVideoThread, this);
    }
    if (!_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml = std::thread(&VideoMaker::sendToQmlThread, this);
    }
    if (!_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle = std::thread(&VideoMaker::sendTitleThread, this);
    }
}

void VideoMaker::stopAllThread()
{
    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }
    if (_m_thread_processImage.joinable())
    {
        _m_thread_processImage.join();
    }
    if (_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml.join();
    }
    if (_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle.join();
    }
}
} // namespace _Controllers
