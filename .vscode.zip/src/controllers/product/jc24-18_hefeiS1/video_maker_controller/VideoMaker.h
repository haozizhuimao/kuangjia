#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <mutex>
#include <json/json.h>
#include <mutex>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#include "kits/camera/tools/LocationCtrl.h"
#include "kits/camera/hik/base/HikBase.h"

#include "kits/third_devices/sws_imgpix_by_ffmpeg/SwsImagePixelConverter.h"

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();
    void onStopVideoMaker();
    void onStartRecord(QString);
    void onStopRecord();

    /// @brief 单个相机录像
    /// @param camera_name 相机名
    /// @param file_name 录像名
    void onStartRecordOneCame(QString, QString);
    /// @brief 单个相机录像结束
    /// @param camera_name 相机名
    void onStopRecordOneCame(QString);
    /// @brief 录像结束，用于QML触发录像结束
    /// @param camera_name 相机名
    /// @param ischeck 录像开启或结束
    void onQmlRecordSignal(QVariant);

    /// @brief 用作初始化录像kit，由模块触发
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(const std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> &);

    void SetFocusZoom(QVariant);
    void SetExposureTimeAndGain(QVariant);
    void PTZControl(QVariant);
    void SetPTZSpeed(QVariant);

    void onGetLocation(const TIS_Info::LocationData &);
    void onTaskBegin(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);
    void onPressSpotInfo(const TIS_Info::PressAndSpot &);
    void onVolElecInfo(const TIS_Info::VoltageAndElectric &);
    void onJiheInfo(std::shared_ptr<TIS_Info::JiHeData>);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HikManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, VideoMaker::onGetLocation);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, VideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, VideoMaker::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::HikManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, VideoMaker::onPressSpotInfo);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, VideoMaker::onVolElecInfo);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::broadcast, VideoMaker::onJiheInfo);

    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetExposureTimeAndGain);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::PTZControl);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetPTZSpeed);
    // QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::onDisplayImgOption);
    //  QML_ADD(TIS_Info::QmlCommunication::QmlActions::VideoRecordButton, VideoMaker::onQmlRecordSignal);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetFocusZoom);

    TASK_LIST_END

  private:
    // 字幕信息结构体，替代原来的map容器
    struct SubTitleInfo
    {
        QString stationName = "";                // 站区名
        QString anchorName = "";                 // 锚段名
        QString poleName = "";                   // 杆号名
        std::atomic<double> kilometerMark = 0.0; // 公里标
        std::atomic<double> speed = 0.0;         // 速度
        std::atomic<double> pressure = 8000.0;   // 压力
        std::atomic<double> hardPoint = 8000.0;  // 硬点
        std::atomic<double> voltage = 8000.0;    // 电压
        std::atomic<double> current = 8000.0;    // 电流
        std::atomic<double> height = 8000.0;     // 导高
        std::atomic<double> zig = 8000.0;        // 拉出值
    };

    SubTitleInfo m_subTitle_change; // 用于存储字幕信息
    SubTitleInfo m_subTitle_send;   // 用于发送字幕信息
    std::mutex _m_subTitleMutex;    // 保护字幕信息的互斥锁

    std::vector<QString> m_subtitles = {}; // 用于存储字幕串
    std::mutex _m_subMutex;                // 保护字幕串的互斥锁
    std::shared_ptr<_Kits::SwsImagePixelConverter> m_p_yuv420pToRgb24;

    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> _mmap_saveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForQml;
    std::unordered_map<std::string, bool> _mmap_isDisplay;

    std::thread _m_thread_saveVideo;
    std::atomic_bool _mb_SaveVideo;
    std::atomic_bool _mb_stop;

    std::thread _m_thread_processImage;
    std::thread _m_thread_sendToQml;

    std::thread _m_thread_sendTitle;

    QString _mqstr_SavePath; // 保存路径

    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> _m_ImageBufferPools;

    std::unique_ptr<_Kits::LocationCtrl> _m_locationCtrl;

    TIS_Info::TaskInfo _m_task_info;
    std::mutex m_mutex;

    std::unordered_map<std::string, std::shared_ptr<_Kits::HikBase>> m_udm_cam;

  private:
    void saveVideoThread();
    void processImageThread();
    void sendToQmlThread();
    void sendTitleThread();
    void startAllThread();
    void stopAllThread();
    void writeSubTitle(int pointSize, const QString &family, Qt::GlobalColor color, std::shared_ptr<TIS_Info::ImageBuffer> img);

    QVariantMap convertDataToJsonOrMap(const QVariant &);

    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yv12);
    void handleTaskBegin(const TIS_Info::TaskInfo &task_info);
    void handleTaskEnd(const TIS_Info::TaskInfo &task_info);
    bool createDirectory(const QString &dirPath);
};
} // namespace _Controllers