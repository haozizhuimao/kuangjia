#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <memory>
#include <qcontainerfwd.h>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    void setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, MVBController::setUdpClient);
    SYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, MVBController::setTcpClient);
    TASK_LIST_END

  private slots:
    void onUdpDataReceived(const std::shared_ptr<std::vector<QByteArray>> &);

  private:
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // 解析trdp协议头
    void parseTrdpHeader(const std::vector<uint8_t> &, TIS_Info::TrdpHeader &);
    // 界面展示接收数据
    void displayRecvPortData(QVariantMap &);

    const std::string m_udpName = "mvb";
    const std::string m_tcpName = "mvb";
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    std::weak_ptr<_Kits::TcpClient> m_tcpClient;
    std::vector<uint8_t> m_recvData;
    int m_headeLength = 0; // trdp协议头长度
};
} // namespace _Controllers
