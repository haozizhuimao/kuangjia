#include "MVBController.h"
#include "kits/third_devices/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "service/AppInterface.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <qobject.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headeLength = sizeof(TIS_Info::TrdpHeader);
    m_recvData.resize(m_headeLength + 100, 0);
}
MVBController::~MVBController() noexcept {}

void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto finder = clients.find(m_udpName);
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", m_udpName);
        return;
    }
    m_udpClient = finder->second;

    finder->second->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) {
        if (!data)
        {
            return;
        }

        auto packets = std::make_shared<std::vector<QByteArray>>();
        packets->emplace_back(reinterpret_cast<const char *>(data->data()), static_cast<int>(data->size()));
        onUdpDataReceived(packets);
    });
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);

    uint8_t speedData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    std::bitset<8> bit(speedData);
    // 列车参考速度有效
    outputData["trainSpeedVld"] = static_cast<bool>(bit[4]);
    // 列车参考速度
    outputData["trainSpeed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 12);
    // CRC32
    outputData["crc32"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 97);
}

void MVBController::displayRecvPortData(QVariantMap &portData)
{
    // 给页面传递数据展示
    QVariantMap mapData;

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt;

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(portData));
}

void MVBController::setTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find(m_tcpName);
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", m_tcpName);
        return;
    }
    m_tcpClient = finder->second;
}

void MVBController::onUdpDataReceived(const std::shared_ptr<std::vector<QByteArray>> &vecData)
{
    for (const auto &data : *vecData)
    {
        if (data.size() < m_headeLength)
        {
            continue;
        }
        std::vector<uint8_t> commonData(data.begin() + m_headeLength, data.end());
        std::vector<uint8_t> headerData(data.begin(), data.begin() + m_headeLength);
        LogInfo("recv data={}", data.toHex(',').toStdString());
        // 解析trdp头
        TIS_Info::TrdpHeader header;
        parseTrdpHeader(headerData, header);
        // 解析数据内容
        QVariantMap dataMap;
        parseCommonData(commonData, dataMap);
        dataMap["dataSource"] = "shanghai4c_common_data";
        displayRecvPortData(dataMap);
        // 转发给mvb
        QByteArray byteArray(reinterpret_cast<const char *>(commonData.data()), commonData.size());
        auto client = m_tcpClient.lock();
        if (!client || !client->getConnect())
        {
            return;
        }
        client->sendData(byteArray);
    }
}

void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
{
    if (data.size() == 0)
    {
        return;
    }
    header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
    header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
    header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
    header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
    header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
    header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
}
} // namespace _Controllers
