#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

namespace _Controllers {

class JiHeTriggerController : public ControllerBase<JiHeTriggerController>
{
  public:
    void sendTirggerToConnectivityService();

    // 定义任务列表
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::JiHeTriggerService::sendJiHeTriggerSignal, JiHeTriggerController::sendTirggerToConnectivityService);
    TASK_LIST_END
};
} // namespace _Controllers