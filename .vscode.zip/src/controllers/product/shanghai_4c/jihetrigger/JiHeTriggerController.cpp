#include "JiHeTriggerController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"
#include <qvariant.h>

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

void JiHeTriggerController::sendTirggerToConnectivityService()
{
    invokeConnectivityServiceJiHeTrigger_A();
}