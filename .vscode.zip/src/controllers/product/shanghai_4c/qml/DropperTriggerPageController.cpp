#include "DropperTriggerPageController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
#include <qvariant.h>

namespace _Controllers {
void DropperTriggerPageController::onSimulateTriggerSended(const QVariant &)
{
    // 触发吊弦触发service中的模拟触发
    invokeDropTriggerServeronTrigger_V();
}

void DropperTriggerPageController::onDropperVideoRecordSended(const QVariant &data)
{
    // 发送录像数据到QML
    auto temp = data.toString();
    invokeDropTriggerServeronRecvRecordByQml_V(data);
}

} // namespace _Controllers
// namespace _Controllers