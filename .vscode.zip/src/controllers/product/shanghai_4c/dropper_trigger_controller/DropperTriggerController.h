#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/save_video_by_ffmpeg/SaveVideoQImage.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include "drop_trigger_reco/svm_classifier.h"
#include <json/json.h>

#include <atomic>
#include <memory>

namespace _Controllers {
class DropperTriggerController : public ControllerBase<DropperTriggerController>
{
  public:
    DropperTriggerController();
    ~DropperTriggerController();
    void sendImageToQml(TIS_Info::ImageInfo);                                    // 发送图像数据到QML
    void getImageByCamera(TIS_Info::ImageInfo);                                  // 获取图像，跑算法
    void recordImage(TIS_Info::ImageInfo);                                       // 录像推送图片
    void isRecord(TIS_Info::RecordInfo);                                         // 是否录像，由qml触发
    void initVideosave();                                                        // 初始化录像
    void initSVM(const std::string &, const std::string &, const std::string &); // 初始化算法
    void onSimulateTriggerSended(const QVariant &);
    void onDropperVideoRecordSended(const QVariant &);
    // void sendTriggerToBasler(const QVariant &); // 发送触发信号到Basler相机
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::DropTriggerServer::imgoutqml, DropperTriggerController::sendImageToQml);
    ASYNC_TASK_ADD(TIS_Info::DropTriggerServer::imgout, DropperTriggerController::getImageByCamera);
    ASYNC_TASK_ADD(TIS_Info::DropTriggerServer::imgout, DropperTriggerController::recordImage);
    ASYNC_TASK_ADD(TIS_Info::DropTriggerServer::isRecord, DropperTriggerController::isRecord);
    SYNC_TASK_ADD(TIS_Info::DropTriggerServer::initVideosave, DropperTriggerController::initVideosave);
    SYNC_TASK_ADD(TIS_Info::DropTriggerServer::initSVM, DropperTriggerController::initSVM);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::SimulateTrigger, DropperTriggerController::onSimulateTriggerSended);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::DropperVideoRecord, DropperTriggerController::onDropperVideoRecordSended);
    TASK_LIST_END

  private:
    std::atomic_bool mb_isRecord = false; // 是否录像
    QString m_strRecordPath;              // 录像路径
    QString m_strCameraName;              // 相机名称
    std::unique_ptr<_Kits::SaveVideoNew::SaveVideoQImage> m_saveVideo = std::make_unique<_Kits::SaveVideoNew::SaveVideoQImage>();
    TIS_Info::RecordInfo m_recordInfo; // 录像信息

  private:
    QString createPath();
    bool createFile(const QString &filePath);

#ifdef _RELEASE

    HOGSVMClassifier m_svm;

#endif
};
} // namespace _Controllers