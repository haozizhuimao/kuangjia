#include "DropperTriggerController.h"
#include "service/AppFramework.h"
#include "tis_global/Field.h"
#include <qimage.h>
#include <qvariant.h>
#include <sys/stat.h>

using namespace _Controllers;
using namespace _Kits;
using namespace _Kits::SaveVideoNew;
using namespace _Service;

_Controllers::DropperTriggerController::DropperTriggerController()
{
}

_Controllers::DropperTriggerController::~DropperTriggerController()
{
    m_saveVideo->stopRecord();
    m_saveVideo->destroyed();
}

void DropperTriggerController::initVideosave()
{
    m_saveVideo->initSaveVideo(1);
}

void DropperTriggerController::initSVM(const std::string &modelFile, const std::string &labelMapFile, const std::string &hogParamsFile)
{

#ifdef _RELEASE
    m_svm.load(modelFile, labelMapFile, hogParamsFile);
#endif
}

// 发送图像数据到QML
void DropperTriggerController::sendImageToQml(TIS_Info::ImageInfo data)
{

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvdropper_trigger_page,
                                        QVariant::fromValue(data.image));
}

void _Controllers::DropperTriggerController::getImageByCamera(TIS_Info::ImageInfo data)
{

#ifdef _RELEASE
    // 跑算法
    std::string json;
    QSize size = data.image.size();

    bool ret = m_svm.predict(data.image.bits(), data.image.size().width() * data.image.size().height(), json);

    Json::Value jsonValue;
    std::string err;
    Json::CharReaderBuilder builder;
    std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
    if (!reader->parse(json.c_str(), json.c_str() + json.size(), &jsonValue, &err))
    {
        LogError("JSON {} parse failed: {}", json, err.c_str());
        return; // 或错误处理
    }

    if (jsonValue.isMember("value") && jsonValue["value"].isNumeric() && jsonValue["value"].asInt() == 0)
    {
        App().invokeModuleAsync(TIS_Info::DropTriggerServer::onTrigger);
    }

#endif
}

void _Controllers::DropperTriggerController::recordImage(TIS_Info::ImageInfo data)
{
    if (mb_isRecord.load())
    {
        m_saveVideo->pushImage(data.image);
    }
}

void _Controllers::DropperTriggerController::isRecord(TIS_Info::RecordInfo data)
{
    if (mb_isRecord.load() != data.mb_is_record)
    {
        mb_isRecord.store(data.mb_is_record);
        m_strRecordPath = data.mstr_record_path;
        m_strCameraName = data.mstr_camera_name;
        if (mb_isRecord.load())
        {
            if (m_saveVideo == nullptr)
            {
                m_saveVideo = std::make_unique<SaveVideoQImage>();
            }

            QString filePath = createPath();
            if (createFile(filePath))
            {
                m_saveVideo->startRecord(filePath);
            }
        }
        else
        {
            if (m_saveVideo != nullptr)
            {
                m_saveVideo->stopRecord();
            }
        }
    }
}

QString _Controllers::DropperTriggerController::createPath()
{
    if (m_strRecordPath.isEmpty() || m_strCameraName.isEmpty())
    { // 增加摄像头名称判空
        return QString();
    }

    QDateTime current = QDateTime::currentDateTime();

    // 构建层次化路径：根路径/摄像头名/日期/时间.mp4
    QDir baseDir(m_strRecordPath);
    QString cameraDatePath = baseDir.filePath(QString("%1/%2").arg(m_strCameraName).arg(current.toString("yyyyMMdd")));

    // 递归创建目录（一次性创建所有不存在的父目录）
    if (!QDir().mkpath(cameraDatePath))
    {
        qWarning() << "Failed to create path:" << cameraDatePath;
        return QString();
    }

    return QDir(cameraDatePath).filePath(current.toString("HHmmss") + ".mp4");
}
bool DropperTriggerController::createFile(const QString &filePath)
{
    if (filePath.isEmpty())
    {
        qWarning() << "Invalid empty file path";
        return false;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly))
    {
        qWarning() << "File creation failed:" << file.errorString();
        return false;
    }
    file.close(); // 立即关闭文件以完成创建

    return QFile::exists(filePath); // 二次验证
}
void DropperTriggerController::onSimulateTriggerSended(const QVariant &)
{
    // 触发吊弦触发service中的模拟触发
    invokeDropTriggerServeronTrigger_A();
}

void DropperTriggerController::onDropperVideoRecordSended(const QVariant &data)
{
    // 发送录像数据到QML
    invokeDropTriggerServeronRecvRecordByQml_A(data);
}
