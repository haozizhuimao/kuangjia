#include "JiHeController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "service/AppInterface.h"
#include "tis_global/EnumClass.h"
#include "tis_global/Field.h"
#include <qvariant.h>

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
void JiHeController::sendJiHeInfoToQml(const QVariant &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::jihedata_recv, data);
}

void JiHeController::sendJiHeTOJiHeTriggerService(const QVariant &data)
{
    invokeJiHeTriggerServiceonJiHeDataReceived_V(data);
}

void JiHeController::doDisplay(const QVariant &data)
{
    QVariantMap JiHeData = data.toMap();
    double zig0 = JiHeData.value("zig0", -1.0f).toDouble();
    double hei0 = JiHeData.value("hei0", -1.0f).toDouble();
    _Kits::LogInfo("[jihe] zig0:{},hei0:{}", zig0, hei0);
}
