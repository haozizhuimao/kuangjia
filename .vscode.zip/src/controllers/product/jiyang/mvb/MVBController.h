#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include <memory>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>
#include <json/value.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    struct PISHeader
    {
        uint8_t frameHeader = 0;
        uint8_t frameTail = 0;
        uint16_t srcAddr = 0;
        uint16_t dstAddr = 0;
        uint8_t functionCode = 0;
        uint16_t dataSize = 0;
    };

    explicit MVBController();
    ~MVBController() noexcept;

    void onStart();

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, MVBController::onStart);
    TASK_LIST_END

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&data);

  private:
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, Json::Value &);
    // 解析trdp协议头
    void parsePISHeader(const std::vector<uint8_t> &, PISHeader &);
    // 界面展示接收数据
    void displayRecvPortData(Json::Value &);

    const std::string m_udpName = "mvb";
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    std::vector<uint8_t> m_recvData;
    int m_headeLength = 0; // trdp协议头长度
};
} // namespace _Controllers
