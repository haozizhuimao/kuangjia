﻿#include "MVBController.h"
#include "kits/common/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "service/AppInterface.h"
#include <json/value.h>
#include <qcontainerfwd.h>
#include <QDateTime>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headeLength = 10;
    m_recvData.resize(m_headeLength + 200, 0);
}
MVBController::~MVBController() noexcept {}

void MVBController::onStart()
{
    // mvb common数据接收
    auto udpClient = _Service::UdpCenter::getUdpClient<std::shared_ptr<_Kits::UdpClient>>(m_udpName);
    if (udpClient == nullptr)
    {
        LogError("can not find udp client.name = {}", m_udpName);
        return;
    }
    m_udpClient = udpClient;
    udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) {
        if (!datas)
        {
            return;
        }
        onUdpDataReceived(std::vector<uint8_t>(datas->begin(), datas->end()));
    });
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, Json::Value &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 时间
    outputData["year"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 2);
    outputData["month"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 3);
    outputData["day"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 4);
    outputData["hour"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 5);
    outputData["minute"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    outputData["second"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 7);

    std::bitset<8> byte8(ByteArrayTools::readFromVectorBE<uint8_t>(data, 8));
    // MC1车司机室激活
    outputData["mc1Active"] = static_cast<bool>(byte8[7]);
    // MC2车司机室激活
    outputData["mc2Active"] = static_cast<bool>(byte8[6]);
    // 列车参考速度有效标志位
    outputData["speedValid"] = static_cast<bool>(byte8[3]);
    // 轮径有效标志位
    outputData["wheelValid"] = static_cast<bool>(byte8[2]);
    // 时间设置标志位
    outputData["timeSet"] = static_cast<bool>(byte8[1]);
    // 时间有效标志位
    outputData["timeValid"] = static_cast<bool>(byte8[0]);

    // 线路号
    outputData["lineNum"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 9);
    // 列车号
    outputData["trainNum"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 10);
    // 列车参考速度
    outputData["speed"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 11);

    std::bitset<8> byte13(ByteArrayTools::readFromVectorBE<uint8_t>(data, 13));
    // 储能投入指令
    outputData["energyInput"] = static_cast<bool>(byte13[7]);
    // 储能退出指令
    outputData["energyOuput"] = static_cast<bool>(byte13[6]);
    // 有网进无网转换指令
    outputData["toDisconnect"] = static_cast<bool>(byte13[5]);
    // 无网进有网转换指令
    outputData["toConnect"] = static_cast<bool>(byte13[4]);

    std::bitset<8> byte14(ByteArrayTools::readFromVectorBE<uint8_t>(data, 14));
    // Mp1车受电弓升起
    outputData["panRiseMp1"] = static_cast<bool>(byte14[7]);
    // 零速信号
    outputData["noSpeed"] = static_cast<bool>(byte14[6]);
    // PA信息有效
    outputData["paVaild"] = static_cast<bool>(byte14[5]);
    // ATC报站信息有效
    outputData["atcVaild"] = static_cast<bool>(byte14[4]);
    // 列车下行
    outputData["down"] = static_cast<bool>(byte14[3]);
    // 列车上行
    outputData["up"] = static_cast<bool>(byte14[2]);

    // 网压
    outputData["voltage"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 15);
    // 网流
    outputData["electricity"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 17);

    // 站点信息反馈-起始站
    outputData["startStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 19);
    // 站点信息反馈-当前站
    outputData["currentStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 21);
    // 站点信息反馈-下一站
    outputData["nextStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 23);
    // 站点信息反馈-终点站
    outputData["endStation"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 25);
    // 列车总行驶里程
    outputData["accumulatedKM"] = ByteArrayTools::readFromVectorBE<uint32_t>(data, 27);
}

void MVBController::displayRecvPortData(Json::Value &portData)
{
    // 给页面传递数据展示
    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt.toStdString();
    _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::displayMVBData, portData);
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headeLength)
    {
        return;
    }
    //  解析协议头
    PISHeader header;
    parsePISHeader(data, header);
    // 解析数据内容
    Json::Value dataMap;
    int offsetLen = m_headeLength + header.dataSize;
    if (offsetLen > data.size())
    {
        LogError("udp recv data len error,len={}", offsetLen);
        return;
    }
    std::vector<uint8_t> commonData(data.begin() + m_headeLength, data.begin() + offsetLen);
    parseCommonData(commonData, dataMap);
    LogInfo(
        "recv udp all data, srcaddr={},size={},data={}", header.srcAddr, data.size(), ByteArrayTools::hexString(data.data(), data.size()));
    dataMap["dataSource"] = "jiyang_common_data";
    if (header.srcAddr == 0x0b01 || header.srcAddr == 0x0d01)
    {
        displayRecvPortData(dataMap);
        LogInfo("recv udp srcaddr={},size={},data={}",
                header.srcAddr,
                data.size(),
                ByteArrayTools::hexString(commonData.data(), commonData.size()));
        if (auto strongPtr = m_udpClient.lock())
        {
            // strongPtr->post("forward_common", std::move(commonData));
        }
    }
}

void MVBController::parsePISHeader(const std::vector<uint8_t> &data, PISHeader &header)
{
    if (data.size() == 0)
    {
        return;
    }
    header.frameHeader = ByteArrayTools::readFromVectorBE<uint8_t>(data, 0);
    header.srcAddr = ByteArrayTools::readFromVectorLE<uint16_t>(data, 2);
    header.dstAddr = ByteArrayTools::readFromVectorLE<uint16_t>(data, 4);
    header.functionCode = ByteArrayTools::readFromVectorBE<uint8_t>(data, 6);
    header.dataSize = ByteArrayTools::readFromVectorLE<uint16_t>(data, 7);
    int len = m_headeLength + header.dataSize;
    if (len > data.size())
    {
        LogError("data len error: len={}", len);
        return;
    }
    header.frameTail = ByteArrayTools::readFromVectorBE<uint8_t>(data, len);
    _Kits::LogInfo("parsePISHeader,header.frameHeader={},header.srcAddr={}, "
                   "header.dstAddr={},header.functionCode={},header.dataSize={}, header.frameTail ={}",
                   header.frameHeader,
                   header.srcAddr,
                   header.dstAddr,
                   header.functionCode,
                   header.dataSize,
                   header.frameTail);
}
} // namespace _Controllers
