#include "TemperatureController.h"
#include "kits/utility/log/CRossLogger.h"
#include <QPainter>
#include "kits/common/utils/TimeToString.h"
#include <iostream>
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include <QDateTime>
#include <QFileInfo>
#include <QJsonObject>
#include <QJsonDocument>
namespace _Controllers {

using namespace _Kits;
using namespace _Service;
void TemperatureController::recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
{
    m_IRImageQueue.pushItemNoBlocking(std::move(IRimagebuffer));
}
void TemperatureController::recvKafaMessage(const std::string strMsg)
{

    Json::CharReaderBuilder readerBuilder;
    Json::Value root;
    std::string errs;
    qDebug() << "recive json" << strMsg.c_str();
    std::istringstream ss(strMsg);
    if (!Json::parseFromStream(readerBuilder, ss, &root, &errs))
    {
        LogDebug("recive json error");
        return;
    }

    if (m_image.isNull())
    {
        return;
    }

    int level = isAlarm(m_maxtemp.load());

    std::string picname = "";
    {
        std::lock_guard<std::mutex> lock(m_mutex_rev);
        picname = generatePictureName(); // 获得保存图像路径

        dealSendImage(m_image, m_image.width(), m_image.height());

        m_image.save((QString::fromLocal8Bit(picname.data())));
    }
    std::string remote = dealFtpPath(picname);
    UploadData task;
    task.transType = 1;
    task.alarmType = 1; // 数据类型
    task.alarmLevel = level;
    task.avgtemp = m_avgtemp.load();
    task.maxtemp = m_maxtemp.load();
    task.mintemp = m_mintemp.load();
    task.localPath = picname;
    task.remotePath = remote;

    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_ftp_kafka_deque.push_back(std::move(task));
        m_condition.notify_one();
    }
}
void TemperatureController::recvTempRect(const int startx, const int starty, const int endx, const int endy, const int w, const int h)
{
    m_startx = startx;
    m_starty = starty;
    m_endx = endx;
    m_endy = endy;
    m_normalwidth = w;
    m_normalheight = h;
}
void TemperatureController::initKafka(const std::string configPath)
{

    auto yamlConfig = YAML::LoadFile(configPath);

    if (yamlConfig["kafka_producer"])
    {
        for (const auto &item : yamlConfig["kafka_producer"])
        {
            std::string broker_produce = item["broker"].as<std::string>();
            std::string topic_produce = item["topic"].as<std::string>();
            if (m_kafkaProducer == nullptr)
            {
                m_kafkaProducer = std::make_shared<_Kits::KafkaProducer>(broker_produce, topic_produce);
            }
        }
    }
}
void TemperatureController::startFtp(bool)
{

    if (!m_ftpClient.lock())
    {
        m_ftpClient = invokeFtpClientCentergetClient_R<std::shared_ptr<_Kits::FtpClient>>(Q_ARG(std::string, client_title));
    }
}

void TemperatureController::init(const QVariant &data)
{

    auto configpath = data.toMap().value("configpath").toByteArray().toStdString();
    auto config = YAML::LoadFile(configpath);

    m_strSavePicRoot = config["rootpath"].as<std::string>();

    auto irconfig = config["irdata"];
    m_fAlarmTemp1 = irconfig["alarmtemp1"].as<double>();
    m_fAlarmTemp2 = irconfig["alarmtemp2"].as<double>();
    m_fAlarmTemp3 = irconfig["alarmtemp3"].as<double>();

    m_fmaxTemperature_calibration = irconfig["maxtemperatrue"].as<double>();
    m_favgTemperature_coefficient = irconfig["avgtemperatrue_coeff"].as<double>();
    m_iAlarmTimeInterval = irconfig["limittime"].as<uint32_t>();
    m_getTemperatrueType = irconfig["irtype"].as<uint32_t>();

    m_startFalg.store(true);
    m_running.store(true); // 发送ftp
    // todo
    createSaveDiretory("temp");
    m_IRImageThread = std::thread(&TemperatureController::handleIRImageThread, this);
    m_sendFTP = std::thread(&TemperatureController::sendFTPThread, this);
}

void TemperatureController::setFtpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::FtpClient>> &clients)
{
    auto iter = clients.find(client_title);

    if (iter != clients.end())
    {
        m_ftpClient = iter->second;
    }
    else
    {
        LogError("TemperatureController::setFTPClient: {} not found", client_title);
    }
}

void TemperatureController::notifyTaskfunc(const QVariant &data) // todo
{
    // auto taskinfomap = data.toMap();
    // auto taskname = taskinfomap.value("taskname").toByteArray().toStdString();

    // auto taskstate = taskinfomap.value("taskstate").toInt();
    // if (0 == taskstate)
    // {
    //     createSaveDiretory(taskname);
    //     // m_taskFlag.store(true);
    // }
    // else if (1 == taskstate)
    // {
    //     m_taskFlag.store(false);
    // }
}

void TemperatureController::stop()
{
    exitthread();
}

void TemperatureController::sendDisplayLog(const QString &data)
{
    // App().invokeModuleAsync(
    //     TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::displaylog_send,
    //     QVariant::fromValue(data));
}
void TemperatureController::removeFile(std::string path)
{
    QFile file(QString::fromStdString(path));
    if (file.exists())
    {
        file.remove();
        qDebug() << "删除文件" << path;
    }
}
void TemperatureController::handleIRImageThread()
{
    std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer = nullptr;
    while (m_startFalg.load())
    {
        {
            IRimagebuffer = m_IRImageQueue.popItem();
        }
        if (nullptr == IRimagebuffer)
        {
            break;
        }

        QByteArray byteArray(reinterpret_cast<const char *>(IRimagebuffer->data.data()), IRimagebuffer->iamgesize);
        QImage image = QImage::fromData(byteArray, "JPG");
        // 当前图像
        {
            std::lock_guard<std::mutex> lock(m_mutex_rev);
            m_image = image;
        }

        // dealSendToQmlData(image, IRimagebuffer->width, IRimagebuffer->height);

        QImage imagesave = image.copy();

        if (1 == m_getTemperatrueType)
        {
            analysisHotPicData(IRimagebuffer->tempdata.data(), IRimagebuffer->width, IRimagebuffer->height);
        }
        else
        {
            m_avgtemp.store(IRimagebuffer->avgtemp);
            m_maxtemp.store(IRimagebuffer->maxtemp);
            m_mintemp.store(IRimagebuffer->mintemp);
            m_tempPoint.setX(IRimagebuffer->maxpointx * IRimagebuffer->width);
            m_tempPoint.setY(IRimagebuffer->maxpointy * IRimagebuffer->height);
        }

        auto maxTemp = m_favgTemperature_coefficient * m_maxtemp.load() + m_fmaxTemperature_calibration;
        m_maxtemp.store(maxTemp);
        // 发送最大温度给QML
        // sendMaxTempToQml(QVariant::fromValue(m_maxtemp.load()));

        dealIRImageData(imagesave, IRimagebuffer->width, IRimagebuffer->height);
    }
}

void TemperatureController::dealSendToQmlRectData(QImage &image, std::unordered_map<int, QRect> &rects)
{
    QVariantMap imgMap;
    for (auto &[index, rect] : rects)
    {
        if (rect.isValid())
        {
            QPainter painter(&image);
            painter.setPen(Qt::green);
            painter.setBrush(Qt::NoBrush); // 不填充
            painter.drawRect(rect);        // 绘制矩形
        }
        // image.save("./test222.jpg");
    }
    imgMap["img"] = image.convertToFormat(QImage::Format_BGR888);
    imgMap["camera_name"] = QString::fromStdString("");
    sendImage(QVariant::fromValue(imgMap));
}

void TemperatureController::dealSendImage(QImage &image, int width, int height)
{
    int offsetx = m_startx * width / m_normalwidth;
    int offsety = m_starty * height / m_normalheight;
    int endoffsetx = m_endx * width / m_normalwidth;
    int endoffsety = m_endy * height / m_normalheight;

    QPainter painter(&image);
    QPoint topleft(offsetx, height - endoffsety);
    QPoint bottomRight(endoffsetx, height - offsety);
    QRect rect(topleft, bottomRight);
    painter.setPen(Qt::green);
    painter.setBrush(Qt::NoBrush); // 不填充
    painter.drawRect(rect);        // 绘制矩形
    painter.setFont(QFont("Arial", 10));
    painter.drawText(m_tempPoint.x(), m_tempPoint.y() + 15, QString::number(m_maxtemp.load()));
}

void TemperatureController::dealSendToQmlData(QImage &image, int width, int height)
{
    QVariantMap imgMap;
    int offsetx = m_startx * width / m_normalwidth;
    int offsety = m_starty * height / m_normalheight;
    int endoffsetx = m_endx * width / m_normalwidth;
    int endoffsety = m_endy * height / m_normalheight;

    QPainter painter(&image);
    QPoint topleft(offsetx, height - endoffsety);
    QPoint bottomRight(endoffsetx, height - offsety);
    QRect rect(topleft, bottomRight);
    painter.setPen(Qt::green);
    painter.setBrush(Qt::NoBrush); // 不填充
    painter.drawRect(rect);        // 绘制矩形

    imgMap["img"] = image.convertToFormat(QImage::Format_BGR888);
    imgMap["camera_name"] = QString::fromStdString("");
    sendImage(QVariant::fromValue(imgMap));
}

void TemperatureController::dealIRImageData(QImage &image, int width, int height)
{
    // if (!m_taskFlag.load()) //判断是否开启任务
    // {
    //     return;
    // }
    m_avgtemp.store((m_mintemp + m_maxtemp) / 2);
    bool bLimitByTime = true;
    bool saveTimeflag = false;
    auto now = std::chrono::high_resolution_clock::now();
    auto durationtime = std::chrono::duration_cast<std::chrono::seconds>(now - m_saveImageTime);

    if (m_saveImageTime != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_iAlarmTimeInterval)
    {
        bLimitByTime = false;
    }

    if (m_saveImageTime != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_sendTimeInterval)
    {
        saveTimeflag = true;
    }

    int alarmLevel = isAlarm(m_maxtemp.load());
    std::string picname = "";
    int alarmType = 0; // 普通数据
    if (alarmLevel > 0)
    {
        // if (bLimitByTime)
        // {
        m_saveImageTime = now;

        // if(alarmLevel <= m_savepicflag)
        if (m_savepicflag)
        {

            int offsetx = m_startx * width / m_normalwidth;
            int offsety = m_starty * height / m_normalheight;
            int endoffsetx = m_endx * width / m_normalwidth;
            int endoffsety = m_endy * height / m_normalheight;

            QPainter painter(&image);
            QPoint topleft(offsetx, height - endoffsety);
            QPoint bottomRight(endoffsetx, height - offsety);
            QRect rect(topleft, bottomRight);
            painter.setPen(Qt::green);
            painter.setBrush(Qt::NoBrush); // 不填充
            painter.drawRect(rect);        // 绘制矩形
            painter.setFont(QFont("Arial", 10));
            painter.drawText(m_tempPoint.x(), m_tempPoint.y() + 15, QString::number(m_maxtemp.load()));

            picname = generatePictureName(); // 获得保存图像路径
            image.save((QString::fromLocal8Bit(picname.data())));

            alarmType = 1; // 告警数据

            // 发送 kafka 根据需要上传ftp

            std::string remote_Path = dealFtpPath(picname);
            UploadData task;
            task.alarmLevel = alarmLevel;
            task.alarmType = alarmType; // 告警数据  普通数据
            task.avgtemp = m_avgtemp.load();
            task.localPath = picname;
            task.maxtemp = m_maxtemp.load();
            task.mintemp = m_mintemp.load();
            task.remotePath = remote_Path; // 目标路径
            task.transType = 0;            // 0主动发送，1 被动发送 通过点击页面
            {
                std::lock_guard<std::mutex> lock(m_mutex);
                m_ftp_kafka_deque.push_back(task);
                m_condition.notify_one();
            }
        }

        QString strShowMaxTemp = "最高温度:" + QString::number(m_maxtemp.load()) + "警告等级:" + QString::number(alarmLevel);
        sendDisplayLog(strShowMaxTemp);
    }
    else
    {

        // m_saveImageTime = now;
        dealKafkaData(m_mintemp.load(), m_maxtemp.load(), m_avgtemp.load(), "", 0, alarmLevel, 0);
    }

    // if (!bLimitByTime)
    // {
    //     alarmLevel = 0;
    // }

    // dealIRAlarmData(alarmLevel, m_mintemp.load(), m_maxtemp.load(), m_avgtemp.load(),picname); //写数据库
}

void TemperatureController::createSaveDiretory(const std::string &taskName)
{
    LogInfo("ArcDataDeal::startTask:{}", taskName);
    QString strPath = QString::fromStdString(m_strSavePicRoot);
    // std::filesystem::path path(strPath.toStdWString());
    std::filesystem::path path(strPath.toStdWString());
    path.append(TimeToString::getYearMonthDayStr());
    path.append(taskName);
    // path.append(L"红外超限");

    m_taskSvaePath = path.string();

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            m_iSaveImgCount = 0;
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    LogInfo("start success:{}", m_taskSvaePath);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    m_taskFlag.store(true);
}

std::string TemperatureController::generatePictureName()
{
    // std::string strPicName = std::to_string(m_iSaveImgCount++) + "_" + TimeToString::getHourMinSecStr() + "_" +
    //                          std::to_string(m_fgpsx) + "_" + std::to_string(m_fgpsy) + ".jpg";
    std::string strPicName =
        TimeToString::getYearMonthDayStr() + "_" + TimeToString::getHourMinSecStr() + "_" + std::to_string(m_iSaveImgCount++) + ".jpg";

    std::string picname = m_taskSvaePath + "\\" + strPicName;
    return picname;
}

void TemperatureController::calculateTempRect(int &offsetx, int &offsety, int &endx, int &endy, const int width, const int height)
{
    if (0 != m_normalheight && 0 != m_normalwidth)
    {
        offsetx = m_startx * width / m_normalwidth;
        offsety = height - m_endy * height / m_normalheight;

        int endoffsetx = m_endx * width / m_normalwidth;
        endx = endoffsetx > width ? width : endoffsetx;

        int endoffsety = height - m_starty * height / m_normalheight;
        endy = endoffsety > height ? height : endoffsety;
    }
    else
    {
        offsetx = 0;
        offsety = 0;
        endx = width;
        endy = height;
    }
}

void TemperatureController::analysisHotPicData(const uint8_t *buf, int width, int height)
{
    int iIndex = 0;
    char temp[10] = {0};
    float minTemp = 10000.0;
    float maxTemp = -10000.0;

    int offsetx = 0;
    int offsety = 0;
    int endoffsetx = width;
    int endoffsety = height;
    calculateTempRect(offsetx, offsety, endoffsetx, endoffsety, width, height);

    int dataoffset = offsety * width * 4 + offsetx * 4;
    // 根据宽高遍历所有数据
    for (int iWriteHeight = offsety; iWriteHeight < endoffsety; ++iWriteHeight)
    {
        iIndex = 0;
        for (int iWriteWidth = offsetx; iWriteWidth < endoffsetx; ++iWriteWidth)
        {
            // 解析数据
            float fTemp = *((float *)(buf + dataoffset + iIndex));

            // 判断fTemp是否是一个正常值，不是则赋值最大或最小，防止设备崩溃
            fTemp = (9999 < fTemp) ? 9999 : ((-9999 > fTemp) ? -9999 : fTemp);

            minTemp = (minTemp > fTemp) ? fTemp : minTemp;
            if (maxTemp < fTemp)
            {
                maxTemp = fTemp;
                m_tempPoint.setX(iWriteWidth);
                m_tempPoint.setY(iWriteHeight);
            }

            memset(temp, 0, sizeof(temp));
            sprintf(temp, "%.2f,", fTemp);
            iIndex += 4;
        }
        dataoffset += width * 4;
    }

    m_mintemp.store(minTemp);
    m_maxtemp.store(maxTemp);
    LogTrace("************************ minTemp: {}, maxTemp: {}", m_mintemp.load(), m_maxtemp.load());
    return;
}

int TemperatureController::isAlarm(const float tempValue)
{
    int alarmLeve = 0;

    if (tempValue >= m_fAlarmTemp1)
    {
        alarmLeve = 1;
    }
    if (tempValue >= m_fAlarmTemp2 && tempValue < m_fAlarmTemp1)
    {
        alarmLeve = 2;
    }
    if (tempValue >= m_fAlarmTemp3 && tempValue < m_fAlarmTemp2)
    {
        alarmLeve = 3;
    }

    return alarmLeve;
}

void TemperatureController::dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname)
{
    size_t last_backslash = picname.find_last_of('\\');
    size_t second_last_backslash = std::string::npos;
    if (last_backslash != std::string::npos && last_backslash > 0)
    {
        second_last_backslash = picname.find_last_of('\\', last_backslash - 1);
    }
    std::string irPicpath = picname;
    if (second_last_backslash != std::string::npos)
    {
        irPicpath = picname.substr(second_last_backslash);
    }

    long long lFileTime = 0;
    double dtimeStamp = 0;
    // HistoryUniqueIDRecviever::Instance().getFileTimeAndTimeStamp(lFileTime, dtimeStamp);
    QVariantMap irDatamap;
    irDatamap.insert("irlevel", level);
    irDatamap.insert("mintemperature", mintemp);
    irDatamap.insert("maxtemperature", maxtemp);

    irDatamap.insert("lltimestamp", lFileTime);
    irDatamap.insert("dtimestamp", dtimeStamp);
    irDatamap.insert("avgtemperature", avgtemp);
    QByteArray picpath = QByteArray::fromRawData(irPicpath.data(), irPicpath.size());
    irDatamap.insert("picpath", QByteArray(picpath.constData(), picpath.size()));
    // emit sendIRData(irDatamap);
    // App().invokeModuleAsync(TIS_Info::HistroyProgramComm::writeIRData, QVariant::fromValue(irDatamap));

    if (level > 0)
    {
        QVariantMap IRamifDatamap;
        IRamifDatamap.insert("amiflevel", level);
        IRamifDatamap.insert("amiftype", 1);
        IRamifDatamap.insert("lltimestamp", lFileTime);
        IRamifDatamap.insert("dtimestamp", dtimeStamp);

        // App().invokeModuleAsync(TIS_Info::HistroyProgramComm::sendAmifData, QVariant::fromValue(IRamifDatamap));
    }
}
void TemperatureController::sendImage(const QVariant &data)
{
    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page, data);
}
void TemperatureController::sendMaxTempToQml(const QVariant &data)
{
    // App().invokeModuleAsync(TIS_Info::QmlPrivateEngine::callFromCpp, TIS_Info::QmlCommunication::ForQmlSignals::maxtemp_recv, data);
}
void TemperatureController::exitthread()
{
    m_startFalg.store(false);
    m_running.store(false);
    recvIRImageData(nullptr);
    recvKafaMessage("");

    if (m_IRImageThread.joinable())
    {
        m_IRImageThread.join();
    }
    if (m_sendFTP.joinable())
    {
        m_sendFTP.join();
    }
}

void TemperatureController::recvUploadSuccess(QVariant data)
{
    if (data.canConvert<QVariantMap>())
    {
        QVariantMap map = data.toMap();

        float mintemp = map["mintemp"].toFloat();
        float maxtemp = map["maxtemp"].toFloat();
        float avgtemp = map["avgtemp"].toFloat();
        std::string picpath = map["imagePath"].toString().toStdString();
        std::string localPath = map["localPath"].toString().toStdString(); // 本地图像保存路径
        int alarmLevel = map["alarmLevel"].toInt();
        int alarmType = map["alarmType"].toInt();
        int transmissionType = map["transmissionType"].toInt();
        dealKafkaData(mintemp, maxtemp, avgtemp, picpath, alarmType, alarmLevel, transmissionType);
        removeFile(localPath);
    }
}

void TemperatureController::dealKafkaData(
    float mintemp, float maxtemp, float avgtemp, std::string picPath, int alarmType, int alarmLevel, int transmissionTpye)
{

    QDateTime current = QDateTime::currentDateTime();
    std::string time = current.toString("yyyy-MM-dd hh:mm:ss").toUtf8().toStdString();
    qDebug() << "time:" << time.c_str();

    QJsonObject kafka_json;
    kafka_json["deviceId"] = 1; // 设备ID
    kafka_json["transmissionType"] = transmissionTpye;
    kafka_json["alarmType"] = alarmType;                          // 数据类型：0=普通温度数据，1=告警数据
    kafka_json["alarmLevel"] = alarmLevel;                        // 根据温度设置告警等级
    kafka_json["time"] = current.toString("yyyy-MM-dd hh:mm:ss"); // 当前时间
    kafka_json["avg"] = avgtemp;
    kafka_json["max"] = maxtemp;
    kafka_json["min"] = mintemp;
    kafka_json["imagePath"] = QString::fromStdString(picPath);

    QJsonDocument doc(kafka_json);
    QString str = QString::fromUtf8(doc.toJson(QJsonDocument::Compact));
    std::string strKafka = str.toStdString();

    qDebug() << "kafka json" << str;
    if (m_kafkaProducer != nullptr)
    {
        if (!m_kafkaProducer->sendMessage(strKafka, "op_dcwd_data"))
        {
            LogDebug("send kafka error");
        }
    }
    else
    {
        LogDebug("kafka is null");
    }
}

void TemperatureController::sendFTPThread()
{
    while (m_running)
    {

        UploadData task;
        {

            std::unique_lock<std::mutex> lock(m_mutex);
            m_condition.wait(lock, [this] { return !m_running || !m_ftp_kafka_deque.empty(); });
            if (!m_running)
            {
                break;
            }
            task = std::move(m_ftp_kafka_deque.front());
            m_ftp_kafka_deque.pop_front();
        }

        if (auto ftp = m_ftpClient.lock())
        {

            QVariantMap data;
            data["mintemp"] = task.mintemp;
            data["maxtemp"] = task.maxtemp;
            data["avgtemp"] = task.avgtemp;
            data["alarmType"] = task.alarmType;
            data["alarmLevel"] = task.alarmLevel;
            data["transmissionType"] = task.transType;
            data["imagePath"] = QString::fromStdString(task.remotePath);
            data["localPath"] = QString::fromStdString(task.localPath);

            ftp->uploadFile(QString::fromStdString(task.localPath), QString::fromStdString(task.remotePath), QVariant::fromValue(data));
        }
        else
        {
            LogDebug("ftp client not available");
        }
    }
}

std::string TemperatureController::dealFtpPath(std::string &localpath)
{
    QString path = QString::fromStdString(localpath);
    QFileInfo fileInfo(path);
    // std::string root = m_ftp_upRoot;
    std::string root = "/test";
    if (!root.empty() && root.back() != '/' && root.back() != '\\')
    {
        root += '/';
    }
    return root + fileInfo.fileName().toStdString();
}

} // namespace _Controllers