#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include "kits/common/utils/BlockingQueue.h"
#include <thread>
#include <atomic>
#include <string>
#include <QPoint>
#include "kits/communication/ftp/FtpClient.h"
#include "kits/communication/kafka_consumer/KafkaConsumer.h"
#include "kits/communication/kafka/KafkaProducer.h"
#include <unordered_map>
#include <string>
#include <deque>
#include <condition_variable>
#include <mutex>

namespace _Controllers {

struct UploadData
{
    std::string localPath;
    std::string remotePath;
    float mintemp;
    float maxtemp;
    float avgtemp;
    int alarmType;
    int alarmLevel;
    int transType;
};
class TemperatureController : public ControllerBase<TemperatureController>
{
  public:
    void recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer>);
    void recvTempRect(const int, const int, const int, const int, const int, const int);

    void notifyTaskfunc(const QVariant &);
    void init(const QVariant &);
    void initKafka(const std::string);
    void stop();
    void sendDisplayLog(const QString &);
    void setFtpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::FtpClient>> &);
    void recvKafaMessage(const std::string);
    void startFtp(bool);
    void recvUploadSuccess(QVariant);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRImageReady, TemperatureController::recvIRImageData);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRTempRect, TemperatureController::recvTempRect);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::initSignal, TemperatureController::init);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::stopSignal, TemperatureController::stop);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::displayLogSignal, TemperatureController::sendDisplayLog);
    SYNC_TASK_ADD(TIS_Info::FtpClientCenter::dispatchClient, TemperatureController::setFtpClient);
    SYNC_TASK_ADD(TIS_Info::FtpClientCenter::startFTP, TemperatureController::startFtp);
    SYNC_TASK_ADD(TIS_Info::KafkaManager::initSignal, TemperatureController::initKafka);
    ASYNC_TASK_ADD(TIS_Info::KafkaManager::sendMesg, TemperatureController::recvKafaMessage);
    ASYNC_TASK_ADD(TIS_Info::FtpClientCenter::uploadData, TemperatureController::recvUploadSuccess);
    TASK_LIST_END

  private:
    std::weak_ptr<_Kits::FtpClient> m_ftpClient;
    std::shared_ptr<_Kits::KafkaConsumer> m_kafkaConsumer = nullptr; // kafka
    std::shared_ptr<_Kits::KafkaProducer> m_kafkaProducer = nullptr;
    const std::string client_title = "ftp";
    const QString m_ftpName = "temperature_dev";
    _Kits::BlockingQueue<std::shared_ptr<TIS_Info::IRImageBuffer>> m_IRImageQueue{10};
    std::deque<UploadData> m_ftp_kafka_deque; // 用于ftpkafka数据 上传
    std::thread m_IRImageThread;
    std::thread m_sendFTP; // 报警ftp kafka 上传线程
    std::mutex m_mutex;
    std::condition_variable m_condition;
    int m_savepicflag = 1;

    std::atomic_bool m_startFalg = false;
    int m_startx = 0;
    int m_starty = 0;
    int m_endx = 0;
    int m_endy = 0;
    int m_normalwidth = 0;
    int m_normalheight = 0;
    float m_fAlarmTemp1 = 0;      // 温度超限报警1级
    float m_fAlarmTemp2 = 0;      // 温度超限报警2级
    float m_fAlarmTemp3 = 0;      // 温度超限报警3级
    int m_iAlarmTimeInterval = 1; // 报警时间间隔，人为干预
    int m_sendTimeInterval = 100; // 正常数据发送 间隔
    std::string m_taskName = "";
    std::string m_strSavePicRoot = "";
    std::string m_ftp_upRoot = "";
    int m_iSaveImgCount = 0;
    float m_fgpsx = 0.0;
    float m_fgpsy = 0.0;
    int m_getTemperatrueType = 0;
    double m_fmaxTemperature_calibration = 0; // 最大温度校准
    double m_favgTemperature_coefficient = 0; // 系数
    std::atomic<float> m_avgtemp = 0.0;
    std::atomic<float> m_mintemp = 0.0;
    std::atomic<float> m_maxtemp = 0.0;
    std::atomic_bool m_taskFlag = false;
    std::atomic_bool m_running = false; // 报警ftp kafka 上传线程
    std::string m_taskSvaePath = "";
    std::chrono::steady_clock::time_point m_saveImageTime = std::chrono::steady_clock::time_point(std::chrono::seconds(0));
    QPoint m_tempPoint;
    QImage m_image;         // 用于保存当前热力图像
    std::mutex m_mutex_rev; // 当前图像锁

  private:
    void parseJsonSendData();
    void sendState(QByteArray &data);
    void sendFTPThread();
    void handleIRImageThread();
    void analysisHotPicData(const uint8_t *buf, int width, int height);
    void analysisHotPicData(const uint8_t *buf, std::unordered_map<int, QRect> &rects, int width, int height);
    void calculateTempRect(int &offsetx, int &offsety, int &endx, int &endy, const int width, const int height);
    int isAlarm(const float tempValue);
    std::string generatePictureName();
    void dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname);
    void sendImage(const QVariant &data);
    void sendMaxTempToQml(const QVariant &data);
    void createSaveDiretory(const std::string &taskName);
    void exitthread();

    void dealIRImageData(QImage &image, int width, int height);
    void dealSendToQmlData(QImage &image, int width, int height);
    void dealSendToQmlRectData(QImage &image, std::unordered_map<int, QRect> &rects);
    void dealKafkaData(float mintemp,
                       float maxtemp,
                       float avgtemp,
                       std::string picPath,
                       int alarmType,
                       int alarmLevel,
                       int transmissionTpye);        // 组装kafka消息
    std::string dealFtpPath(std::string &localpath); // 处理ftp目标路径
    void removeFile(std::string path);
    void dealSendImage(QImage &image, int width, int height);
};

} // namespace _Controllers
