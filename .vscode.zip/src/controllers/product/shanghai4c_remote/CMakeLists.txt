
set(CTL_NAME "ctl_jc22-12shanghai4c_remote")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})

target_sources(${CTL_NAME} PUBLIC
$<TARGET_OBJECTS:kit_asio_tcp_client>
$<TARGET_OBJECTS:kit_asio_udp>
$<TARGET_OBJECTS:kit_camera_basler_base>
)
target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_asio_tcp_client
kit_asio_udp
kit_camera_basler_base
)



target_include_directories(${CTL_NAME} PUBLIC
    ${THIRD_PARTY_INCLUDE}/JCWLib/
)

target_include_directories(${CTL_NAME} PUBLIC
    ${THIRD_PARTY_INCLUDE}/include/basler_camera
)


find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})



# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/engineering_vehicle_qml/main.qml
    res/qml/engineering_vehicle_qml/egv_video_page/egv_video_page.qml
    res/qml/public_controls/CustomTitleBar.qml
    res/qml/public_controls/Table.qml
    res/qml/public_controls/Modules.qml
    res/qml/public_controls/VideoDisplay.qml
    res/qml/public_controls/HighFrequencyChart.qml
    res/qml/public_controls/Magnifier.qml
    res/qml/engineering_vehicle_qml/egv_inspectionimage_page/egv_inspectionimage_page.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end