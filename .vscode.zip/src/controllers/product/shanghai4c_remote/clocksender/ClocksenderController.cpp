#include "ClocksenderController.h"
#include "service/AppFramework.h"
#include <chrono>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#else
#include <ctime>
#endif

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

ClocksenderController::ClocksenderController() : mp_pool(std::make_shared<_Kits::ObjectPool<QByteArray>>(50))
{
    m_thread_dealData = std::thread(&ClocksenderController::_dealtimeData, this);
}

ClocksenderController::~ClocksenderController()
{
    mb_thread_dealData_stop.store(true);
    if (m_thread_dealData.joinable())
    {
        m_thread_dealData.join();
    }
}

uint64_t ClocksenderController::GetLocalFileTimeEX()
{
#if defined(_WIN32) || defined(_WIN64)
    FILETIME ft;
    GetSystemTimePreciseAsFileTime(&ft);
    uint64_t fileTime = (static_cast<uint64_t>(ft.dwHighDateTime) << 32) | static_cast<uint64_t>(ft.dwLowDateTime);
    return fileTime;
#else
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    const uint64_t EPOCH_DIFFERENCE = 11644473600LL * 10000000LL;
    uint64_t unixTimeIn100ns = (uint64_t)ts.tv_sec * 10000000LL + (uint64_t)ts.tv_nsec / 100;
    return unixTimeIn100ns + EPOCH_DIFFERENCE;
#endif
}

void ClocksenderController::getClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &s_map)
{
    myClient = s_map.find("TIMESTAMP")->second;
}

void ClocksenderController::_dealtimeData()
{
    while (!mb_thread_dealData_stop.load())
    {
        auto lockptr = myClient.lock();
        if (lockptr)
        {
            uint64_t timestamp = GetLocalFileTimeEX();
            // 格式化时间戳消息
            std::ostringstream oss;
            oss << "TIMESTAMP:" << timestamp;
            std::string message = oss.str();
            std::vector<uint8_t> vec(message.begin(), message.end());
            std::vector<uint8_t> vecsend;
            vecsend = vec;
            lockptr->sendDataAsync("time1", std::move(vecsend));
            vecsend = vec;
            lockptr->sendDataAsync("time2", std::move(vecsend));
            vecsend = vec;
            lockptr->sendDataAsync("time3", std::move(vecsend));
            vecsend = vec;
            lockptr->sendDataAsync("time4", std::move(vecsend));
            vecsend = vec;
            lockptr->sendDataAsync("time5", std::move(vecsend));
            vecsend = vec;
            lockptr->sendDataAsync("time6", std::move(vecsend));

            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
    }
}
