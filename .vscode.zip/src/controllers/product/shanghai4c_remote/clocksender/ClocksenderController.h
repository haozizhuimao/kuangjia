#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include <unordered_map>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <condition_variable>
#include "kits/utility/object_pool/ObjectPool.h"
//#include "tis_global/Function.h"
#include "tis_global/Field.h"
#include "tis_global/Struct.h"
#include <time.h>
#include <stdint.h>
#include <QByteArray>
namespace _Controllers {
class ClocksenderController : public ControllerBase<ClocksenderController>
{
  public:
    ClocksenderController();
    ~ClocksenderController();
    void getClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, ClocksenderController::getClient);
    TASK_LIST_END
  private:
    std::shared_ptr<_Kits::ObjectPool<QByteArray>> mp_pool;
    std::atomic_bool mb_thread_dealData_stop = false;
    std::thread m_thread_dealData;
    void _dealtimeData();
    uint64_t GetLocalFileTimeEX();
    std::weak_ptr<_Kits::UdpClient> myClient;
};
} // namespace _Controllers