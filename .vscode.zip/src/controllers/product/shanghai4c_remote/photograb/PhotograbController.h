#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
#include "kits/camera/basler/base/BaslerBase.h"
#include <unordered_map>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <condition_variable>
#include "kits/utility/object_pool/ObjectPool.h"
//#include "tis_global/Function.h"
#include "tis_global/Field.h"
#include "tis_global/Struct.h"
#include <QMap>
#include <QReadWriteLock>
#include <QString>
#include <json/json.h>
struct ImageData
{
    QByteArray image;
    qint64 timestamp;
    QString camera;
};

class TimestampMap
{
  public:
    void insert(qint64 timestamp, const QString &value)
    {
        std::lock_guard<std::mutex> lock(m_locker);
        if (map.size() > 1000)
        {
            QList<qint64> keyList = map.keys();
            map.remove(keyList[0]);
        }
        map.insert(timestamp, value);
    }
    QString findClosest(qint64 target) const
    {
        if (map.isEmpty())
        {
            return QString();
        }

        auto it = map.lowerBound(target);

        if (it == map.end())
        {
            --it;
            return it.value();
        }

        if (it == map.begin())
        {
            return it.value();
        }

        auto prev = it;
        --prev;
        const qint64 diffPrev = target - prev.key();
        const qint64 diffCurrent = it.key() - target;

        return (diffPrev <= diffCurrent) ? prev.value() : it.value();
    }

  private:
    std::mutex m_locker;
    QMap<qint64, QString> map;
};

namespace _Controllers {
class PhotograbController : public ControllerBase<PhotograbController>
{
  public:
    PhotograbController();
    ~PhotograbController();
    void getcaminfoString(QVariant);
    void savePictureInFile(const ImageData &, const QString &);
    void refreshTask(const QString &);
    void savePictureInFileNetcam(std::shared_ptr<TIS_Info::ImageBuffer>);
    void refreshInitinfo(const QVariantMap &);
    void refreshInitinfoNet(const QVariantMap &);
    void RefreshLocation(const TIS_Info::RemoteMessage &);

    void onNewClient(const std::string &, std::shared_ptr<_Kits::TcpClient>);
    void onClientDisconnect(qintptr);
    void onRecvData(const QByteArray &, const QString &);
    void onRecvClientdata_0(const std::vector<uint8_t> &&);
    void onRecvClientdata_1(const std::vector<uint8_t> &&);
    void onRecvClientdata_2(const std::vector<uint8_t> &&);
    void onRecvClientdata_3(const std::vector<uint8_t> &&);
    void onRecvClientdata_4(const std::vector<uint8_t> &&);
    void onRecvClientdata_5(const std::vector<uint8_t> &&);

    void onReleaseClient_0();
    void onReleaseClient_1();
    void onReleaseClient_2();
    void onReleaseClient_3();
    void onReleaseClient_4();
    void onReleaseClient_5();
    void praseData(std::shared_ptr<QByteArray> data);

    void initNetCamera(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>,
                       std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>>);

    void onTaskBegin(const TIS_Info::RemoteMessage &);
    void onTaskEnd(const TIS_Info::RemoteMessage &);
    void onReleaseCamera(int);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::initPatrolCtrls, PhotograbController::initNetCamera);
    ASYNC_TASK_ADD(TIS_Info::BaslerManager::initinfo, PhotograbController::refreshInitinfoNet);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::initinfosend, PhotograbController::refreshInitinfo);
    ASYNC_TASK_ADD(TIS_Info::RossekSeverService::sendinitinfoTopage, PhotograbController::getcaminfoString);
    REMOTE_TASK_ADD(TIS_Info::LocationService::OffsetLocationRadio, PhotograbController::RefreshLocation);
    REMOTE_TASK_ADD(TIS_Info::TaskService::taskBegin, PhotograbController::onTaskBegin);
    REMOTE_TASK_ADD(TIS_Info::TaskService::taskEnd, PhotograbController::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::BaslerManager::sendStopsignal, PhotograbController::onReleaseCamera);
    SYNC_TASK_ADD(TIS_Info::TcpServerCenter::newClient, PhotograbController::onNewClient);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::camera_button_clicked, PhotograbController::getcaminfoString);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::SimulateTrigger, PhotograbController::softTriger);

    TASK_LIST_END
  private:
    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>> m_udm_cam =
        std::make_shared<std::unordered_map<std::string, std::unique_ptr<_Kits::BaslerBase>>>();
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> m_udm_camInfo =
        std::make_shared<std::unordered_map<std::string, TIS_Info::CameraInfo>>();
    QVariantMap m_initinfo;
    QStringList ipandsnlist;
    QStringList m_iplist;
    TimestampMap timestampMap;
    QString mytaskdir;
    QString basedir;
    QMap<QString, int> countmap;
    QMap<QString, QString> sametrigger_map = {
        {"柔性1", "柔性2"}, {"柔性2", "柔性1"}, {"柔性3", "柔性4"}, {"柔性4", "柔性3"}, {"吊弦1", "吊弦2"}, {"吊弦2", "吊弦1"}};
    ImageData rouxing1, rouxing2, rouxing3, rouxing4, diaoxian1, diaoxian2;
    QMap<QString, ImageData> nameTostore_map = {
        {"柔性1", rouxing1}, {"柔性2", rouxing2}, {"柔性3", rouxing3}, {"柔性4", rouxing4}, {"吊弦1", diaoxian1}, {"吊弦2", diaoxian2}};
    std::mutex tasklocker;
    void softTriger(QVariant);

    std::atomic_bool mb_thread_recvData_stop = false;
    std::thread m_thread_processData;
    QString poleNow;
    void _dealprocessData();
    size_t findNearestIndex(qint64, size_t);
    std::shared_ptr<_Kits::ObjectPool<QByteArray>> mp_pool;

    int clientcount = 0;
    QMap<int, QString> m_client_count_map;
    QList<QByteArray> m_client_buffer_list;
    inline const static QByteArray TCP_HEADER = "{[(tcp_header)]}";
    inline const static QByteArray TCP_TAIL = "{[(tcp_tail)]}";
    void processImage(const QByteArray &, const QString &);

    // 数据包格式常量
    static constexpr int TIMESTAMP_SIZE = 8;
    static constexpr int IMG_SIZE_SIZE = 4;
};
} // namespace _Controllers
