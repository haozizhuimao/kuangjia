
set(CTL_NAME "ctl_shanghai_4ctemp")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
   
target_sources(${CTL_NAME} PUBLIC 
    $<TARGET_OBJECTS:kit_uniqueid_recv_kits>
    $<TARGET_OBJECTS:kit_infrared_general>
)         
target_link_libraries(${CTL_NAME} PUBLIC 
        shared_dependencies 
        kit_log
        kit_uniqueid_recv_kits
        kit_infrared_general
)

target_sources(${LIB_CONTROLLERS} PUBLIC
$<TARGET_OBJECTS:${CTL_NAME}>
)

target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/temperature/CustomLabel.qml
    res/qml/temperature/CustomState.qml
    res/qml/temperature/main.qml
    res/qml/temperature/irvideo_page.qml
    res/qml/temperature/CustomTitleBar.qml
)

file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)
# 用于选择加载的资源和界面文件 end
