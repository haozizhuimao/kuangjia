#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
//#include "tis_global/Function.h"
#include "kits/common/utils/BlockingQueue.h"
#include "kits/product_kits/infrared_general/InfraredGeneral.h"
#include <thread>
#include <atomic>
#include <string>
#include <QPoint>

namespace _Controllers {
class TemperatureController : public ControllerBase<TemperatureController>
{
  public:
    void recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer>);
    void recvTempRect(const int, const int, const int, const int, const int, const int);
    void notifyTaskfunc(const QVariant &);
    void init(const QVariant &);
    void stop();
    void sendDisplayLog(const QString &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRImageReady, TemperatureController::recvIRImageData);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::IRTempRect, TemperatureController::recvTempRect);
    ASYNC_TASK_ADD(TIS_Info::HistroyProgramComm::notifyTaskInfo, TemperatureController::notifyTaskfunc);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::initSignal, TemperatureController::init);
    SYNC_TASK_ADD(TIS_Info::TemperatureService::stopSignal, TemperatureController::stop);
    ASYNC_TASK_ADD(TIS_Info::TemperatureService::displayLogSignal, TemperatureController::sendDisplayLog);
    TASK_LIST_END

  private:
    _Kits::BlockingQueue<std::shared_ptr<TIS_Info::IRImageBuffer>> m_IRImageQueue{10};
    std::thread m_IRImageThread;
    std::atomic_bool m_startFalg = false;
    _Kits::IRRuleRect m_rawRect;
    int m_normalwidth = 0;
    int m_normalheight = 0;
    int m_iAlarmTimeInterval = 10; // 报警时间间隔，人为干预
    int m_savepicflag = 0;
    int m_isshowarea = 0;
    int m_iSaveImgCount = 0;
    int m_getTemperatrueType = 0;
    double m_fmaxTemperature_calibration = 0; // 最大温度校准
    double m_favgTemperature_coefficient = 0; // 系数
    // std::atomic<float> m_avgtemp = 0.0;
    std::atomic<float> m_mintemp = 0.0;
    std::atomic<float> m_maxtemp = 0.0;
    std::atomic_bool m_taskFlag = false;
    std::string m_taskSvaePath = "";
    std::string m_strSavePicRoot = "";
    std::chrono::steady_clock::time_point m_saveImageTime = std::chrono::steady_clock::time_point(std::chrono::seconds(0));
    std::unique_ptr<_Kits::InfraredGeneral> m_infraredGeneral = nullptr;

  private:
    void handleIRImageThread();
    void dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname);
    void sendImage(const QVariant &data);
    void sendMaxTempToQml(const QVariant &data);
    void createSaveDiretory(const std::string &taskName);
    void exitthread();
    void dealIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const QPoint &maxTempPoint);
    void dealSendToQmlData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, _Kits::IRRuleRect &rawRect);
    void saveIRImage(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const std::string &picname, const QPoint &maxTempPoint);
    int updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, QPoint &maxTempPoint);
    std::string generatePictureName();
    void drwaCrossPoint(QImage &image, const QPoint &center, int size); // 绘制十字
    void dealSendToQmlData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, _Kits::IRRuleRect &rawRect, const QPoint &maxTempPoint);
};
} // namespace _Controllers
