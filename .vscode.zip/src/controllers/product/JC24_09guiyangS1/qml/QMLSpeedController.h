#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <cstdint>
namespace _Controllers {
class QmlSpeedController : public ControllerBase<QmlSpeedController>
{
  public:
    void onSendToQml(double, int64_t);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::sendSpeedValue, QmlSpeedController::onSendToQml);
    TASK_LIST_END
};

} // namespace _Controllers