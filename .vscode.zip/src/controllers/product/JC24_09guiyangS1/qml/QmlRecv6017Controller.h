#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlRecv6017Controller : public ControllerBase<QmlRecv6017Controller>
{
  public:
    void onSendPressSpotToQml(const TIS_Info::PressAndSpot &);
    void onSendVolEleDataToQml(const TIS_Info::VoltageAndElectric &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, QmlRecv6017Controller::onSendPressSpotToQml);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, QmlRecv6017Controller::onSendVolEleDataToQml);
    TASK_LIST_END

  private:
    double md_totalPress = 0.0;
};
} // namespace _Controllers
