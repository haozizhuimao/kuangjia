#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlSimulationController : public ControllerBase<QmlSimulationController>
{
  public:
    void onRcvTaskBegin(const TIS_Info::TaskInfo &taskInfo);
    void onRcvTaskEnd(const TIS_Info::TaskInfo &taskInfo);
    void onSimulationSelectDb(QVariant);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlSimulationController::onRcvTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, QmlSimulationController::onRcvTaskEnd);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::SimulationSelectDb, QmlSimulationController::onSimulationSelectDb);
    TASK_LIST_END
  private:
    void startRun();
    void endRun();
    std::string m_dbName = "test.db";
    std::string m_taskName = "";
    bool m_isRun = false;
};
} // namespace _Controllers
