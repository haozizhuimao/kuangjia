#include "QmlHardwareInfo.h"
#include "service/AppInterface.h"
namespace _Controllers
{
    void QmlHardwareInfo::onResourceInfo(TIS_Info::QmlCommunication::ForQmlSignals action, const QVariant &value)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(action, value);
    }
} // namespace _Controllers