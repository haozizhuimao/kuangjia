#include "QmlDatabaseManager.h"
#include "service/AppInterface.h"
namespace _Controllers
{
    void QmlDatabaseManager::onDatabaseConnect(TIS_Info::QmlCommunication::ForQmlSignals action, const QVariant &value)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(action, value);
    }
} // namespace _Controllers