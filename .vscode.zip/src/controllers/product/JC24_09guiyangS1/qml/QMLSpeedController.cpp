#include "QmlSpeedController.h"
#include <qvariant.h>
#include <sys/stat.h>
#include <chrono>

namespace _Controllers
{
    using namespace _Service;

    void QmlSpeedController::onSendToQml(double speed, int64_t time)
    {
        QVariantMap mapSpeed = {{"timestamp", time}, {"speed", speed}};
        receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::speed_data_send, QVariant::fromValue(mapSpeed));
    }

} // namespace _Controllers