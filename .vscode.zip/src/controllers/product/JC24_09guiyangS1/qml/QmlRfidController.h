#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlRfidController : public ControllerBase<QmlRfidController>
{
  public:
    void onSendRfidCountToQml(int);
    void onSendRfidDataToQml(const std::string &);
    void onClearRfidData(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::LocationService::sendRfidCount, QmlRfidController::onSendRfidCountToQml);
    ASYNC_TASK_ADD(TIS_Info::RfidService::sendRfidToQml, QmlRfidController::onSendRfidDataToQml);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, QmlRfidController::onClearRfidData);
    TASK_LIST_END

  private:
    std::unordered_map<std::string, int> m_rfidCountMap; // 存储RFID计数
};
} // namespace _Controllers
