#include "WriteCollecDatatController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/primary/thread_pool/thread_pool.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

WriteCollecDatatController::WriteCollecDatatController() {}

WriteCollecDatatController::~WriteCollecDatatController() noexcept
{
    checkWriteCollectData(true);

    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    m_threadRunFlag.store(false, std::memory_order_release);

    if (m_threadProcess.joinable())
    {
        m_threadProcess.join();
    }
}

// # 加速度硬点 spot_0y spot_0x
// # 压力 press0 press1 press2 press3 press4 press5 press6 press7
// # 电流 electric
// # 电压 voltage

void WriteCollecDatatController::getVolAndElc(TIS_Info::VoltageAndElectric vol_and_elc)
{
    m_volData = vol_and_elc.md_voltage0;
}

void WriteCollecDatatController::getTemperatureHumidity(const TIS_Info::TemperatureHumidity &THdata)
{
    m_temperatureData = THdata.temperature;
    m_HumidityData = THdata.humidity;
}

void _Controllers::WriteCollecDatatController::recvTaskData(const TIS_Info::TaskInfo &taskInfo)
{
    if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        m_taskid.store(-1, std::memory_order_release);
        return;
    }

    m_taskid.store(taskInfo.nTaskID, std::memory_order_release);

    if (!m_threadProcess.joinable())
    {
        m_threadRunFlag.store(true, std::memory_order_release);
        m_threadProcess = std::thread(&WriteCollecDatatController::processDataThread, this);
    }
}

void _Controllers::WriteCollecDatatController::processDataThread()
{
    static uint16_t nCount = 0;
    while (m_threadRunFlag.load(std::memory_order_acquire))
    {
        if (m_taskid.load(std::memory_order_acquire) == -1)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        m_collectData.push_back(initCollectData());

        checkWriteCollectData();

        if (++nCount % 100 == 0) // 前端控制显示频率
        {
            sendVolEleDataToQml();
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
void _Controllers::WriteCollecDatatController::checkWriteCollectData(bool force)
{
    if (m_collectData.size() >= 1000 || force)
    {
        std::deque<_Kits::_Orm::collect_data> collectDataQue;
        collectDataQue.swap(m_collectData);
        _Kits::SqlInsert<_Kits::_Orm::collect_data> sqlInsert;
        sqlInsert.insert(collectDataQue);
        if (!sqlInsert.exec())
        {
            _Kits::LogError("sql insert error");
        }
    }
}

void _Controllers::WriteCollecDatatController::sendVolEleDataToQml()
{
    TIS_Info::VoltageAndElectric VoltageAndElectric;
    VoltageAndElectric.md_voltage0 = operateData("voltage", m_volData.load(std::memory_order_acquire));
    VoltageAndElectric.md_electric0 = 8000;

    _Service::senderPressSpotVolElecEtcDatasendVolElecOut(VoltageAndElectric);
}

double WriteCollecDatatController::operateData(const std::string &data_name, double data)
{
    auto it = m_equationCoefficients.find(data_name);
    if (it != m_equationCoefficients.end()) // 通道  等于  0
    {
        return (data + it->second.md_constant) * it->second.md_coefficient;
    }
    return 8000.0;
}
_Kits::_Orm::collect_data _Controllers::WriteCollecDatatController::initCollectData()
{
    _Kits::_Orm::collect_data collectData;
    collectData.vol = operateData("voltage", m_volData.load(std::memory_order_acquire));
    collectData.task_id = m_taskid.load(std::memory_order_acquire);
    collectData.cur = 8000.0;
    collectData.tem = m_temperatureData.load(std::memory_order_acquire);
    collectData.hum = m_HumidityData.load(std::memory_order_acquire);

    return collectData;
}

void WriteCollecDatatController::recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017> EquationCoefficients)
{
    m_equationCoefficients = EquationCoefficients;
}
} // namespace _Controllers