#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <thread>
#include <deque>
#include "kits/common/database/CppBatis.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/press_acc_collect_struct.h"

namespace _Controllers {
class WriteCollecDatatController : public ControllerBase<WriteCollecDatatController>
{
  public:
    explicit WriteCollecDatatController();
    virtual ~WriteCollecDatatController() noexcept;

    void getVolAndElc(TIS_Info::VoltageAndElectric);
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvEquationCoefficients(std::unordered_map<std::string, TIS_Info::Equation6017>);
    void getTemperatureHumidity(const TIS_Info::TemperatureHumidity &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::TemperatureHumidityService::sendTemperatureHumidity, WriteCollecDatatController::getTemperatureHumidity);
    ASYNC_TASK_ADD(TIS_Info::Dispatch6017::sendVolAndElecNatrualDataOut, WriteCollecDatatController::getVolAndElc);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, WriteCollecDatatController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, WriteCollecDatatController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::initController, WriteCollecDatatController::recvEquationCoefficients);
    TASK_LIST_END

  private:
    void processDataThread();

    _Kits::_Orm::collect_data initCollectData();

    void checkWriteCollectData(bool force = false);

    void sendVolEleDataToQml();

    /// @brief 处理数据，计算因子
    /// @param data_name 数据名称
    double operateData(const std::string &data_name, double data);

  private:
    std::atomic<double> m_volData{8000}; // 网压
    std::atomic<float> m_temperatureData{8000};
    std::atomic<float> m_HumidityData{8000};
    // std::atomic<double> m_volData_qml = 8000;     // 网压
    std::unordered_map<std::string, TIS_Info::Equation6017> m_equationCoefficients;
    std::thread m_threadProcess;
    std::atomic_bool m_threadRunFlag{false};
    std::deque<_Kits::_Orm::collect_data> m_collectData;
    std::atomic_int32_t m_taskid{-1};
};
} // namespace _Controllers