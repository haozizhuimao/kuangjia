#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "Kits/Communication/asio/serial_port/SerialPortClient.h"
#include <memory>
#include "kits/third_devices/sensor_huakong_kit/SensorHuakong.h"

namespace _Controllers {
class TemperatureHumidityController : public ControllerBase<TemperatureHumidityController>
{
  public:
    TemperatureHumidityController();
    ~TemperatureHumidityController();

    void onSetSerialPortClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::SerialPortClient>> &);
    void onInitConfig(const TIS_Info::TemperatureHumidityConfig &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::TemperatureHumidityService::temperatureHumidityConfigInit, TemperatureHumidityController::onInitConfig);
    ASYNC_TASK_ADD(TIS_Info::SerialPortCenter::dispatchClient, TemperatureHumidityController::onSetSerialPortClient);
    TASK_LIST_END
  private:
    std::shared_ptr<_Kits::SensorHuakong> m_sensorHuakong = nullptr;
    int m_iFrequency{0};
    bool m_bRunning{false};
};
} // namespace _Controllers