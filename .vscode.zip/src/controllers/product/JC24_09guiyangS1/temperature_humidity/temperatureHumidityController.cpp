#include "TemperatureHumidityController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include "kits/common/database/CppBatis.h"
#include "kits/common/database/connections/DatabaseConnections.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include <chrono>
#include <vector>
#include <thread>
#include <deque>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

TemperatureHumidityController::TemperatureHumidityController() {}
TemperatureHumidityController::~TemperatureHumidityController()
{
    m_bRunning = false;
}

void TemperatureHumidityController::onSetSerialPortClient(
    const std::unordered_map<std::string, std::shared_ptr<_Kits::SerialPortClient>> &clients)
{
    auto finder = clients.find("temperature_humidity");
    if (finder == clients.end())
    {
        LogError("can not find serial port client.name = {}", "temperature_humidity");
        return;
    }
    auto m_serialPortClient = finder->second;

    if (nullptr == m_sensorHuakong)
    {
        m_sensorHuakong = std::make_unique<_Kits::SensorHuakong>();
    }
    m_sensorHuakong->setTcpClient(m_serialPortClient);
    m_sensorHuakong->setSendTHCallback([this](const float temperature, const float humidity, int64_t timet) {
        // senderRfidServicesendRfidToQml(QString::fromStdString(rfid));
        TIS_Info::TemperatureHumidity th;
        th.temperature = temperature;
        th.humidity = humidity;
        senderTemperatureHumidityServicesendTemperatureHumidity(th);
        // senderRfidServicerfidDeduplicated(rfid, timet);
    });

    if (!m_sensorHuakong->start())
    {
        LogError("sensor hua kong failed to start");
    }
}

void TemperatureHumidityController::onInitConfig(const TIS_Info::TemperatureHumidityConfig &config)
{
    if (nullptr == m_sensorHuakong)
    {
        m_sensorHuakong = std::make_shared<_Kits::SensorHuakong>();
    }
    m_sensorHuakong->setInfo(config);

    if (!m_sensorHuakong->start())
    {
        LogError("sensor hua kong failed to start");
    }
}

} // namespace _Controllers