#include "RfidController.h"
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumClass.h"
#include <qvariant.h>
#include "kits/common/database/CppBatis.h"
#include "kits/common/database/connections/DatabaseConnections.h"
#include "kits/third_devices/rfid_kits/SqliteRfidID.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

RfidController::RfidController() {}

void RfidController::onRecvTask(const TIS_Info::TaskInfo &taskInfo)
{
    m_taskInfo = taskInfo;
}

void RfidController::onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &clients)
{
    auto finder = clients.find("RFID");
    if (finder == clients.end())
    {
        LogError("can not find tcp client.name = {}", "RFID");
        return;
    }
    auto client = finder->second;
    if (m_rfid_VFR61M == nullptr)
    {
        m_rfid_VFR61M = std::make_shared<Rfid_VFR61M>();
    }
    m_rfid_VFR61M->setTcpClient(client);
    m_rfid_VFR61M->setSendRfidCallback([this](const std::string &rfid, int64_t timet) {
        if (rfid.empty())
            return;

        senderRfidServicesendRfidToQml(rfid);

        senderRfidServicerfidDeduplicated(rfid, timet);
    });

    if (!m_rfid_VFR61M->start())
    {
        LogError("RFID VFR61M failed to start");
    }
}

void RfidController::onInitConfig(const TIS_Info::RfidInfo &info)
{
    m_rfidInfo = info;
    if (m_rfid_VFR61M == nullptr)
    {
        m_rfid_VFR61M = std::make_shared<Rfid_VFR61M>();
    }

    m_rfid_VFR61M->setInfo(info);
    m_rfid_VFR61M->start();
}

} // namespace _Controllers