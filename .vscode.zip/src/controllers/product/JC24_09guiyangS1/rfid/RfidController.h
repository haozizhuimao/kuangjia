#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/rfid_kits/Rfid_VFR61M.h"
#include <memory>

namespace _Controllers {
class RfidController : public ControllerBase<RfidController>
{
  public:
    explicit RfidController();

    void initNaturalDataBase(bool);
    void onSetTcpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::TcpClient>> &);
    void onInitConfig(const TIS_Info::RfidInfo &);
    void processDataThread();
    void onRecvTask(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::RfidService::rfidConfigInit, RfidController::onInitConfig);
    ASYNC_TASK_ADD(TIS_Info::TcpClientCenter::dispatchClient, RfidController::onSetTcpClient);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, RfidController::onRecvTask);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, RfidController::onRecvTask);

    TASK_LIST_END

  private:
    std::mutex m_mutex;
    std::set<std::string> m_receiveRfids;
    std::shared_ptr<_Kits::Rfid_VFR61M> m_rfid_VFR61M = nullptr;
    std::string m_stask_name;
    TIS_Info::TaskInfo m_taskInfo;
    TIS_Info::RfidInfo m_rfidInfo;
    std::thread m_thSendCMD;
    std::atomic_bool m_bRunning{true};
};
} // namespace _Controllers