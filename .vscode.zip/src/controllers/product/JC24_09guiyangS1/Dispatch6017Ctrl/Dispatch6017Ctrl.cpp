#include "Dispatch6017Ctrl.h"
#include "kits/common/database/CppBatis.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/primary/thread_pool/thread_pool.h"
#include "tis_global/enum_public/task_enum.h"

namespace _Controllers {
using namespace _Service;
_Controllers::Dispatch6017Ctrl::Dispatch6017Ctrl() : _mb_thread_process_run{true}, _m_voltageAndElectric{}, _m_pressAndSpot{} {}
_Controllers::Dispatch6017Ctrl::~Dispatch6017Ctrl() noexcept {}

void _Controllers::Dispatch6017Ctrl::onInitChannelInfo(const std::vector<TIS_Info::Info6017> channel_info_map)
{
    for (const auto &config : channel_info_map)
    {
        auto &index = config.mstr_index;

        mmap_channelInfo_.insert({index, config});
        mvec_dispatch6017Ctrl_[index] = tbb::concurrent_queue<std::vector<double>>();

        if (mmap_dispatchUdp6017_.find(index) == mmap_dispatchUdp6017_.end())
        {
            mmap_dispatchUdp6017_[index] = std::make_shared<_Kits::Udp6017>();
        }

        auto &udp6017 = mmap_dispatchUdp6017_[index];
        auto client = _Service::receiverUdpCentergetUdpClient<std::shared_ptr<_Kits::UdpClient>>(index);

        if (client == nullptr)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(1000));
            client = _Service::receiverUdpCentergetUdpClient<std::shared_ptr<_Kits::UdpClient>>(index);
            if (client == nullptr)
            {
                _Kits::LogError("[Dispatch6017Ctrl::initChannelInfo] UdpClient for {} is not available", index);
                continue;
            }
        }
        udp6017->setUdpClient(client);
        _Kits::LogDebug("[Dispatch6017Ctrl::onInitChannelInfo] Udp6017 client set for index: {}", index);

        udp6017->setSendRetOut([this, index](std::vector<double> &&data) {
            if (mvec_dispatch6017Ctrl_[index].unsafe_size() < 5)
            {
                mvec_dispatch6017Ctrl_[index].push(std::move(data));
            }
        });
        _Kits::LogDebug("[Dispatch6017Ctrl::onInitChannelInfo] SendRetOut callback set for index: {}", index);

        udp6017->setSendTime(config.mui_interval);
        _Kits::LogDebug("[Dispatch6017Ctrl::onInitChannelInfo] SendTime set for index: {}", index);

        if (config.mb_is_save_natural_data)
        {
            udp6017->setSendNeturalDataOut([this, index](TIS_Info::NeturalData6017 &&data) {
                mvec_dispatch6017_naturalData_[index].push_back(std::move(data));

                if (mvec_dispatch6017_naturalData_[index].size() > 1000)
                {
                    writeNaturalData(index);
                }
            });

            _Kits::LogDebug("[Dispatch6017Ctrl::onInitChannelInfo] SendNeturalDataOut callback set for index: {}", index);
        }
    }

    _m_thread_process = std::thread(&Dispatch6017Ctrl::processDataThread, this);
}

void Dispatch6017Ctrl::onStop6017Ctrl()
{
    _mb_thread_process_run.store(false, std::memory_order_release);

    if (_m_thread_process.joinable())
    {
        _m_thread_process.join();
    }
}

void _Controllers::Dispatch6017Ctrl::writeNaturalData(std::string index)
{
    std::vector<TIS_Info::NeturalData6017> vec_data;
    {
        std::lock_guard<std::mutex> lock(m_mutex_naturalData);
        vec_data.swap(mvec_dispatch6017_naturalData_[index]);
    }

    _Kits::thread_pool::runTask([vec_data, index]() {
        std::unordered_map<QString, QSql::ParamType> bindtypes;
        bindtypes.insert(std::make_pair("timestamp", QSql::In));
        bindtypes.insert(std::make_pair("data", QSql::Binary));
        std::vector<QVariantMap> vec_mapdata;
        for (auto &data : vec_data)
        {
            QVariantMap data_map;
            data_map["timestamp"] = data.mll_timestamp;
            data_map["data"] = QByteArray(reinterpret_cast<const char *>(data.mqb_data.data()), data.mqb_data.size());
            vec_mapdata.push_back(std::move(data_map));
        }

        auto ret = _Kits::CppBatis<_Kits::SqliteTag>::insert(
            QString::fromStdString("6017Data_" + index), QString::fromStdString("_6017_data"), vec_mapdata, bindtypes);
        if (!ret)
        {
            qDebug() << "insert 6017Data_" + index + " failed";
        }
    });
}

void _Controllers::Dispatch6017Ctrl::processDataThread()
{
    std::unordered_map<std::string, double *> channelMap = {{"spot_0x", &_m_pressAndSpot.md_spot0x},
                                                            {"spot_0y", &_m_pressAndSpot.md_spot0y},
                                                            {"press0", &_m_pressAndSpot.md_press0},
                                                            {"press1", &_m_pressAndSpot.md_press1},
                                                            {"press2", &_m_pressAndSpot.md_press2},
                                                            {"press3", &_m_pressAndSpot.md_press3},
                                                            {"voltage", &_m_voltageAndElectric.md_voltage0},
                                                            {"electric", &_m_voltageAndElectric.md_electric0}};

    while (_mb_thread_process_run.load())
    {
        for (auto &[index, data] : mvec_dispatch6017Ctrl_)
        {

            std::vector<double> vec_data;
            if (!data.try_pop(vec_data))
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;
            }

            if (vec_data.size() < 8)
            {
                continue;
            }

            if (mmap_channelInfo_.find(index) == mmap_channelInfo_.end())
            {
                continue; // 如果没有找到对应的配置，跳过处理
            }

            const auto &config = mmap_channelInfo_[index];
            if (!config.mstr_index.empty())
            {
                for (const auto &config_oneChannel : config.mmap_Channel_info)
                {
                    // 可以考虑组成一个json包，包含所有状态一起上报。性能更好   做结构体优化
                    auto it = channelMap.find(config_oneChannel.first);
                    if (it != channelMap.end())
                    {
                        *(it->second) = vec_data[config_oneChannel.second];
                    }
                }

                senderDispatch6017sendPressAndSpotNatrualOut(_m_pressAndSpot);
                senderDispatch6017sendVolAndElecNatrualDataOut(_m_voltageAndElectric);
            }
        }
    }
}

void Dispatch6017Ctrl::onRecvTaskInfo(const TIS_Info::TaskInfo &taskInfo)
{
    auto taskID = taskInfo.nTaskID;
    auto taskCreateTime = taskInfo.timestamp;
    std::string taskName = std::to_string(taskID) + "_" + std::to_string(taskCreateTime);
    for (auto &[index, udp6017] : mmap_dispatchUdp6017_)
    {
        if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
        {
            createDataBase(QString::fromStdString(taskName), QString::fromStdString(index));
            udp6017->setTaskRun(true);
        }
        else if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
        {
            udp6017->setTaskRun(false);
        }
    }
}

void Dispatch6017Ctrl::createDataBase(QString taskName, QString index)
{

    auto db_name = QString("%1_%2.db").arg(taskName).arg("6017Data_" + index);
    _Kits::CppBatis<_Kits::SqliteTag>::execSql(db_name,
                                               "CREATE TABLE IF NOT EXISTS _6017_data ("
                                               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                               "data TEXT NOT NULL,"
                                               "timestamp TEXT NOT NULL)");
}

} // namespace _Controllers
