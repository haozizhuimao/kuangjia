#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <json/json.h>
#include <json/value.h>
#include "kits/common/database/orm/TableStructs.h"
//#include "tis_global/Function.h"
#include "tis_global/enum_public/task_enum.h"
#include "tis_global/struct_details/mvb_struct.h"
#include "tis_global/struct_details/task_struct.h"

namespace _Controllers {
class TaskController final : public ControllerBase<TaskController>
{
  public:
    TaskController() = default;
    ~TaskController() noexcept = default;
    void initFromMoudle(const int type, const std::string &, const std::string &); // 配置初始化
    void onQmlTask(QVariant);
    void onRfidTaskSended(const std::string &, int64_t);
    bool isLastRfid(QString rfid);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::TaskService::initTaskController, TaskController::initFromMoudle);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::TaskSend, TaskController::onQmlTask);
    ASYNC_TASK_ADD(TIS_Info::RfidService::rfidDeduplicated, TaskController::onRfidTaskSended);
    ASYNC_TASK_ADD(TIS_Info::MVBCommunication::sendMVBComInfo, TaskController::recvMVBInfo);
    TASK_LIST_END
  private:
    TIS_Info::TaskInfo jsonTaskInfo(const Json::Value &data);
    TIS_Info::TaskInfo rfidTaskInfo(const _Kits::_Orm::line_data &, int64_t timet);
    TIS_Info::TaskInfo mvbTaskInfo(const TIS_Info::MVBCommunicationInfo &);
    TIS_Info::TaskInfo m_currentTask;
    TIS_Info::TaskType m_task_type = TIS_Info::TaskType::TYPE_NONE;
    std::string m_trainNum;
    std::string m_savePath;
    int m_line_direction = -1;
};
} // namespace _Controllers
