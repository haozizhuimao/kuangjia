#include "TaskSql.h"
#include "kits/common/database/CppBatis.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Kits {

int TaskSql::insertTaskToDB(const std::string &time, const TIS_Info::TaskInfo &task)
{
    int taskId = -1;
    _Kits::_Orm::task_data sqlData;
    sqlData.task_type = (int)task.taskType;
    sqlData.task_name = task.strTaskName.c_str();
    sqlData.line_name = task.strLineName.c_str();
    sqlData.drive_direction = task.nDirection;
    sqlData.start_station = task.strStartStation.c_str();
    sqlData.start_pole = task.strStartPole.c_str();
    sqlData.end_station = task.strEndStation.c_str();
    sqlData.created_time = time.c_str();
    sqlData.updated_time = time.c_str();
    sqlData.line_direction = task.nLineDirection;

    auto insert = _Kits::SqlInsert<_Kits::_Orm::task_data>();
    if (!insert.insert(sqlData).exec())
    {
        LogError("数据库插入失败");
        return taskId;
    }

    SqlSelect<_Kits::_Orm::task_data> select;
    select.select({"id"}).where("task_name", _Kits::OperatorComparison::Equal, sqlData.task_name);

    if (!select.exec())
    {
        return taskId;
    }

    auto res = select.getResults();

    if (!res.size())
    {
        return taskId;
    }

    taskId = res[0].id;
    return taskId;
}
void TaskSql::updateStopTask(int taskId)
{
    auto task_time = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
    SqlUpdate<_Kits::_Orm::task_data> update;
    update.set("updated_time", task_time).set("end_time", task_time).where("id", _Kits::OperatorComparison::Equal, taskId);
    if (!update.exec())
    {
        LogError("更新任务结束时间失败。");
    }
}

} // namespace _Kits