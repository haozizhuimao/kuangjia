#pragma once

#include "tis_global/struct_details/task_struct.h"
#include <string>
namespace _Kits
{

    class TaskSql
    {
      public:
        static int insertTaskToDB(const std::string &time, const TIS_Info::TaskInfo &task);
        static void updateStopTask(int taskId);
    };

} // namespace _Kits