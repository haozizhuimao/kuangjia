#include "TaskController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/product_kits/line_helper/LineHelper.h"
#include "tis_global/enum_public/task_enum.h"
#include "TaskSql.h"
#include <filesystem>
#include <iostream>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void TaskController::initFromMoudle(const int type, const std::string &trainNum, const std::string &savePath)
{
    m_task_type = static_cast<TIS_Info::TaskType>(type);
    m_trainNum = trainNum;
    m_savePath = savePath;
}

void TaskController::onQmlTask(QVariant data)
{
    if (m_task_type != TIS_Info::TaskType::TYPE_MANUAL)
    {
        LogError("任务类型错误{}，不能手动创建任务", static_cast<int>(m_task_type));
        return;
    }
    // 前端发来的是 JSON 字符串

    if (!data.canConvert<QString>())
    {
        LogError("下发任务数据错误!");
        return;
    }

    auto json = _Kits::stringToJson(data.toString().toUtf8().constData());
    std::cout << json;
    if (!json.isMember("taskState"))
    {
        LogError("下发任务数据错误!");
        return;
    }
    auto state = static_cast<TIS_Info::TaskState>(std::stoi(json["taskState"].asString()));
    if (state == TIS_Info::TaskState::TASK_START)
    {
        auto taskInfo = jsonTaskInfo(json);

        if (taskInfo.nTaskID == -1)
        {
            return;
        }
        taskInfo.nTaskstate = state;
        m_currentTask = taskInfo;
        if (!LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
        {
            LogError("[任务线路表]: 任务线路表信息初始化失败。");
            return;
        }
        senderTaskServicetaskBegin(taskInfo);
    }
    else if (TIS_Info::TaskState::TASK_STOPPED == state)
    {
        m_currentTask.nTaskstate = state;
        TaskSql::updateStopTask(m_currentTask.nTaskID);
        if (m_currentTask.nTaskID != -1)
        {
            senderTaskServicetaskEnd(m_currentTask);
        }
    }
}

void TaskController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &mvb_info)
{
    // if (m_task_type != TIS_Info::TaskType::TYPE_STATION)
    // {
    //     LogError("任务类型错误{}，不能创建任务", static_cast<int>(m_task_type));
    //     return;
    // }
    // // 行别切换时创建站区id任务，其他消息用于更新速度
    // if (m_line_direction != mvb_info.nLineDirection)
    // {
    //     m_line_direction = mvb_info.nLineDirection;
    //     if (m_currentTask.nTaskID != -1 && m_currentTask.taskType == TIS_Info::TaskType::TYPE_STATION &&
    //         m_currentTask.nTaskstate == TIS_Info::TaskState::TASK_START)
    //     {
    //         m_currentTask.nTaskstate = TIS_Info::TaskState::TASK_STOPPED;
    //         senderTaskServicetaskEnd(m_currentTask);
    //     }

    //     auto taskInfo = mvbTaskInfo(mvb_info);
    //     if (taskInfo.nTaskID != -1)
    //     {
    //         taskInfo.nTaskstate = TIS_Info::TaskState::TASK_START;
    //         m_currentTask = taskInfo;
    //         if (LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
    //         {
    //             senderTaskServicetaskBegin(taskInfo);
    //         }
    //         else
    //         {
    //             LogError("[任务线路表]: 任务线路表信息初始化失败。");
    //         }
    //     }
    // }
}

void TaskController::onRfidTaskSended(const std::string &rfid, int64_t timet)
{
    // if (m_task_type != TIS_Info::TaskType::TYPE_RFID)
    // {
    //     LogError("任务类型错误{}，不能创建任务", static_cast<int>(m_task_type));
    //     return;
    // }
    // auto [is_last, line_data] = _Kits::LineHelper::isLastRFID(rfid);
    // if (is_last && m_currentTask.nTaskstate == TIS_Info::TaskState::TASK_START &&
    //     m_currentTask.taskType == TIS_Info::TaskType::TYPE_RFID)
    // {
    //     m_currentTask.nTaskstate = TIS_Info::TaskState::TASK_STOPPED;
    //     _Service::senderTaskServicetaskEnd(m_currentTask);
    // }

    // if (!is_last && m_currentTask.nTaskstate != TIS_Info::TaskState::TASK_START)
    // {
    //     auto taskInfo = rfidTaskInfo(line_data, timet);
    //     if (taskInfo.nTaskID != -1)
    //     {
    //         taskInfo.nTaskstate = TIS_Info::TaskState::TASK_START;
    //         m_currentTask = taskInfo;
    //         if (LineHelper::initTaskLineData(taskInfo.strLineName, taskInfo.nLineDirection))
    //         {
    //             senderTaskServicetaskBegin(taskInfo);
    //         }
    //         else
    //         {
    //             LogError("[任务线路表]: 任务线路表信息初始化失败。");
    //         }
    //     }
    // }
}

TIS_Info::TaskInfo TaskController::mvbTaskInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_STATION;
    task.nLineDirection = data.nLineDirection;
    task.strLineName = data.strLineName;
    task.strStartStation = LineHelper::getStationName(data.startStation, data.strLineName, data.nLineDirection);
    task.strEndStation = LineHelper::getStationName(data.endStation, data.strLineName, data.nLineDirection);
    task.strTaskSavePath = m_savePath;
    task.strTrainNumber = data.strTrainNum;
    auto strCreateTime = _Kits::datetime::current_string("%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::current_string();
    task.timestamp = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;
    TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}
TIS_Info::TaskInfo TaskController::jsonTaskInfo(const Json::Value &json)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_MANUAL;

    task.strTrainNumber = m_trainNum;

    task.nDirection = std::stoi(json["runDirection"].asString());
    task.nLineDirection = json["lineDirection"].asString() == "上行" ? 0 : 1;
    task.strLineName = json["lineName"].asString();
    task.strStartStation = json["startStation"].asString();
    task.strStartPole = json["startPole"].asString();
    task.strEndStation = json["endStation"].asString();

    auto strDateTime = _Kits::datetime::current_string("%Y%m%d");
    auto strCreateTime = _Kits::datetime::current_string("%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::current_string();
    task.timestamp = _Kits::datetime::current_timestamp(_Kits::datetime::TimestampUnit::Milliseconds);
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;

    task.strTaskSavePath = std::format("{}/tasks/{}/{}", m_savePath, strDateTime, task.strTaskName);

    std::filesystem::path savePath = std::filesystem::path(std::u8string(reinterpret_cast<const char8_t *>(task.strTaskSavePath.c_str())));

    if (!std::filesystem::exists(savePath))
    {
        if (std::filesystem::create_directories(savePath))
        {
            LogDebug("[任务开始]: 任务保存路径创建成功, {}", task.strTaskSavePath);
        }
        else
        {
            LogDebug("[任务开始]: 任务保存路径创建失败, {}", task.strTaskSavePath);
        }
    }

    task.nTaskID = TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}

TIS_Info::TaskInfo TaskController::rfidTaskInfo(const _Kits::_Orm::line_data &first, int64_t timet)
{
    TIS_Info::TaskInfo task;
    task.taskType = TIS_Info::TaskType::TYPE_RFID;
    task.nLineDirection = first.line_direction;
    task.strLineName = first.line_name.toStdString();
    task.strStartStation = first.station_name.toStdString();
    task.strTaskSavePath = m_savePath;
    task.strTrainNumber = m_trainNum;
    auto strCreateTime = _Kits::datetime::timepoint_to_string(timet, "%Y%m%d%H%M%S");
    auto strSqlTime = _Kits::datetime::timepoint_to_string(timet);
    task.timestamp = timet;
    task.strTaskName =
        task.strTrainNumber + "_" + strCreateTime + "_" + task.strLineName + "_" + task.strStartStation + "_" + task.strEndStation;
    TaskSql::insertTaskToDB(strSqlTime, task);
    return task;
}
} // namespace _Controllers
