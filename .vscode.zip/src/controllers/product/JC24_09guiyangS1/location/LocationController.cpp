#include "LocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/common/location_general/LocationGeneral.h"
#include "kits/common/location_general/LocationMVB.h"
#include "tis_global/enum_public/location_enum.h"
#include <QJsonDocument>
#include <cstdint>
#include <mutex>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void LocationController::initConfig(TIS_Info::LocationConfigs config)
{
    if (m_kitLocation == nullptr)
    {
        if (config.speed_type == 0)
        {
            m_kitLocation = std::make_unique<LocationGeneral>();
        }
        else
        {
            m_kitLocation = std::make_unique<LocationMVB>();
        }
    }
}

void LocationController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_curTaskInfo = task;
    if (task.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto data = m_kitLocation->startTask(task);
        if (!data.pole_name.empty())
        {
            _Service::senderLocationServiceLocationRadio(data);
            LogInfo("[定位开始] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
        }
    }
    else if (task.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        m_kitLocation->stopTask();
        LogInfo("[定位结束] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
    }
}
void LocationController::recvMVBInfo(const TIS_Info::MVBCommunicationInfo &data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto locationPtr = static_cast<LocationMVB *>(m_kitLocation.get());

        auto locationData = locationPtr->speedMVBUpdate(data.currentStationId, datetime::current_timestamp(datetime::TimestampUnit::Milliseconds), data.dSpeed);

        if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
        {
            _Service::senderLocationServiceLocationRadio(locationData);
        }
        else
        {

            static auto last_mm = locationData.mileage_normal;
            auto interval = locationData.mileage_normal - last_mm;
            constexpr double MAX_DISTANCE = 500; // 默认 500mm
            if (interval > MAX_DISTANCE)
            {
                _Service::senderLocationServiceLocationRadio(locationData);
                last_mm = locationData.mileage_normal;
            }
        }
    }
}

void LocationController::recvSpeedValue(double speed, int64_t timestamp)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    // LogInfo("recvSpeedValue.timestamp--------------- :{}",timestamp);

    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
    {
        auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
        locationPtr->updateSpeed(speed);
    }
}

void LocationController::recvSpeedData(const TIS_Info::SpeedData &data)
{

    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->updateMillimeter(data.mull_millimeter, data.timestamp);
    if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
    {
        lastSendMM = locationData.milimeter;
        _Service::senderLocationServiceLocationRadio(locationData);
    }
    else
    {
        if (locationData.milimeter - lastSendMM >= 500)
        {
            _Service::senderLocationServiceLocationRadio(locationData);
            lastSendMM = locationData.milimeter;
        }
    }
}

void LocationController::recvRfidDataFromQml(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid rfid data!");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->rfidAdjust(data.toString().toStdString(), datetime::current_timestamp(datetime::TimestampUnit::Milliseconds));
    if (!locationData.pole_name.empty())
    {
        _Service::senderLocationServiceLocationRadio(locationData);
    }
}

void LocationController::recvRfidDataFromModule(const std::string &data, int64_t timet)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.empty())
    {
        LogError("Invalid rfid data!");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->rfidAdjust(data, timet);
    if (!locationData.pole_name.empty())
    {
        _Service::senderLocationServiceLocationRadio(locationData);
    }
}

void LocationController::recvHandData(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid data!");
        return;
    }
    QVariantMap variant = convertDataToJsonOrMap(data);
    QString str = variant.value("pole_name").toString();
    // m_kitLocation->handAdjust(str);

    // auto locationData = m_kitLocation->getCurrentData();
    // locationData.location_type = TIS_Info::LocationType::PT_HAND;
    // _Service::senderLocationServiceLocationRadio(locationData);
}

void LocationController::recvImageData(int64_t timestamp)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->ImagePoleBind(timestamp);
    if (locationData.timestamp > 0)
    {
        _Service::senderLocationServiceLocationRadio(locationData);
    }
}
void LocationController::recvXianchaData(int64_t timestamp0, int64_t timestamp1, int64_t timeImage)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->xianchaAdjust(timestamp0, timestamp1, timeImage);
    if (locationData.size() != 3)
    {
        return;
    }
    _Service::senderLocationServiceLocationRadio(locationData[2]);
}
void LocationController::recvMaoduanData(int64_t timestamp0, int64_t timestamp1, int64_t timeImage)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    auto locationPtr = static_cast<LocationGeneral *>(m_kitLocation.get());
    auto locationData = locationPtr->maoduanAdjust(timestamp0, timestamp1, timeImage);
    if (locationData.size() != 3)
    {
        return;
    }
    _Service::senderLocationServiceLocationRadio(locationData[2]);
}

QVariantMap LocationController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}

} // namespace _Controllers