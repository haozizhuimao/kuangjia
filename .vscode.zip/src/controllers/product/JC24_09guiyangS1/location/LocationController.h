#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <cstdint>
#include <map>
#include <memory>
#include <mutex>
#include "kits/common/location_general/LocationBase.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/location_struct.h"
namespace _Controllers {
class LocationController : public ControllerBase<LocationController>
{
  public:
    void initConfig(TIS_Info::LocationConfigs);
    void recvTaskData(const TIS_Info::TaskInfo &);

    void recvImageData(int64_t);
    void recvXianchaData(int64_t, int64_t, int64_t);
    void recvMaoduanData(int64_t, int64_t, int64_t);
    void recvRfidDataFromQml(QVariant);
    void recvRfidDataFromModule(const std::string &, int64_t);
    void recvHandData(QVariant);
    QVariantMap convertDataToJsonOrMap(const QVariant &);
    void recvSpeedData(const TIS_Info::SpeedData &);
    void recvSpeedValue(double, int64_t);
    void recvMVBInfo(const TIS_Info::MVBCommunicationInfo &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::LocationService::initConfig, LocationController::initConfig);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, LocationController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::sendSpeedDataOut, LocationController::recvSpeedData);
    ASYNC_TASK_ADD(TIS_Info::Sensor6051DataOut::sendSpeedValue, LocationController::recvSpeedValue);
    ASYNC_TASK_ADD(TIS_Info::MVBCommunication::sendMVBComInfo, LocationController::recvMVBInfo);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::RfidSimulate, LocationController::recvRfidDataFromQml);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ULPoleCalibration, LocationController::recvHandData);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::PoleCalibration, LocationController::recvHandData);
    ASYNC_TASK_ADD(TIS_Info::RfidService::rfidDeduplicated, LocationController::recvRfidDataFromModule);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::JiHeImgToLocation, LocationController::recvImageData);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::JiHeMaoDuanToLocation, LocationController::recvMaoduanData);
    ASYNC_TASK_ADD(TIS_Info::JiHeService::JiHeXianChaToLocation, LocationController::recvMaoduanData);
    TASK_LIST_END
  private:
    std::unique_ptr<_Kits::LocationBase> m_kitLocation{nullptr};
    TIS_Info::TaskInfo m_curTaskInfo;
    uint64_t lastSendMM = 0;
};

} // namespace _Controllers
