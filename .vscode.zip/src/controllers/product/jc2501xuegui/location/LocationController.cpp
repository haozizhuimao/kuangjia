#include "LocationController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppInterface.h"
#include "tis_global/EnumClass.h"
#include "kits/common/database/orm/TableStructs.h"
#include "tis_global/EnumPublic.h"
#include "tis_global/enum_public/location_enum.h"
#include <chrono>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void LocationController::initConfig(TIS_Info::LocationConfigs config)
{
    if (m_kitLocation == nullptr)
    {
        m_kitLocation = std::make_unique<LocationGeneral>();
        m_kitLocation->init(config);
    }
}

void LocationController::recvTaskData(TIS_Info::TaskInfo task)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_curTaskInfo = task;
    LogInfo("[里程清零] 任务状态：{} task_id:{}", static_cast<int>(task.nTaskstate), task.nTaskID);
    m_kitLocation->clearAllMileages();
    m_kitLocation->setTaskInfo(task);
}
void LocationController::recvSpeedValue(double value)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    m_kitLocation->setSpeed(value);
}
void LocationController::recvSpeedData(TIS_Info::SpeedData data)
{
    static uint64_t last_mull_pulse = data.mull_pulse;
    static uint64_t last_mileage = data.mull_millimeter;
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    if (m_curTaskInfo.nTaskstate == TIS_Info::TaskState::TASK_START && data.mull_pulse > last_mull_pulse)
    {
        constexpr uint64_t MAX_SPACING = 1 * 1000 * 1000; // 1 km

        auto spacing = data.mull_millimeter - last_mileage;
        if (spacing < MAX_SPACING)
        {
            m_kitLocation->speedSensorUpdate(spacing);
            auto locationData = m_kitLocation->getCurrentData();
            if (locationData.location_type > TIS_Info::LocationType::PT_LINE)
            {
                _Service::senderLocationServiceLocationRadio(locationData);
            }
            else
            {
                using clock = std::chrono::steady_clock;
                static auto last_time = clock::now();
                auto cur_time = clock::now();
                auto interval = std::chrono::duration_cast<std::chrono::milliseconds>(cur_time - last_time).count();
                last_time = cur_time;
                constexpr double MAX_DISTANCE = 100; // 默认 100ms
                if (interval > MAX_DISTANCE)
                {
                    _Service::senderLocationServiceLocationRadio(locationData);
                }
            }
        }
    }

    last_mull_pulse = data.mull_pulse;
    last_mileage = data.mull_millimeter;
}

void LocationController::recvRfidDataFromQml(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid rfid data!");
        return;
    }
    m_kitLocation->rfidAdjust(data.toString());

    auto locationData = m_kitLocation->getCurrentData();
    locationData.location_type = TIS_Info::LocationType::PT_RFID;
    _Service::senderLocationServiceLocationRadio(locationData);

    int count = m_kitLocation->getRfidCount();
    _Service::senderLocationServicesendRfidCount(count);
}

void LocationController::recvRfidDataFromModule(const std::string &data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.empty())
    {
        LogError("Invalid rfid data!");
        return;
    }

    m_kitLocation->rfidAdjust(QString::fromStdString(data));

    auto locationData = m_kitLocation->getCurrentData();
    locationData.location_type = TIS_Info::LocationType::PT_RFID;
    _Service::senderLocationServiceLocationRadio(locationData);

    int count = m_kitLocation->getRfidCount();
    _Service::senderLocationServicesendRfidCount(count);
}

void LocationController::recvHandData(QVariant data)
{
    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }
    if (data.isNull())
    {
        LogError("Invalid data!");
        return;
    }
    QVariantMap variant = convertDataToJsonOrMap(data);
    QString str = variant.value("pole_name").toString();
    m_kitLocation->handAdjust(str);

    auto locationData = m_kitLocation->getCurrentData();
    locationData.location_type = TIS_Info::LocationType::PT_HAND;
    _Service::senderLocationServiceLocationRadio(locationData);
}

void LocationController::recvImageData(bool status)
{
    static uint64_t lastDis = 0;
    static std::atomic_bool isFirst{true};
    static int testCount = 0;

    if (m_kitLocation == nullptr)
    {
        LogError("定位工具对象没有初始化。");
        return;
    }

    if (status && isFirst.load(std::memory_order_acquire))
    {
        auto locationData = m_kitLocation->getCurrentData();
        lastDis = locationData.mileage_normal;
        isFirst = false;
        // LogDebug("recvImageData: testCount=={}",++testCount);
    }
    else if (!status && !isFirst.load(std::memory_order_acquire))
    {
        auto data = m_kitLocation->getCurrentData();
        auto diff = data.mileage_normal - lastDis;
        // LogDebug("recvImageData: diff:{}={}-{} speed:{},testCount=={}",
        //   diff, data.mileage_normal, lastDis,data.speed, ++testCount);
        testCount = 0;

        // 应用图像调整，传递当前位置、方向和偏移量
        m_kitLocation->ImageAdjust(data.mileage_after, data.line_direction, diff);

        isFirst.store(true, std::memory_order_release);

        auto locationData = m_kitLocation->getCurrentData();
        locationData.location_type = TIS_Info::LocationType::PT_IMG;
        _Service::senderLocationServiceLocationRadio(locationData);
    }
    else
    {
        isFirst = true;
    }
}
void LocationController::recvMaoduanData(bool status)
{
    static uint64_t lastDis = 0;
    static bool isFirst = true;
    if (status == true && isFirst)
    {
        auto locationData = m_kitLocation->getCurrentData();
        lastDis = locationData.mileage_normal;
        isFirst = false;
        LogInfo("maoduan adjust start");
    }
    else if (status == false && !isFirst)
    {
        auto data = m_kitLocation->getCurrentData();
        isFirst = true;
        LogInfo("maoduan adjust end");
        if (data.mileage_normal - lastDis > 50) // mm
        {
            LogInfo("maoduan adjust is success");
            m_kitLocation->maoduanAdjust(data.mileage_after, data.line_direction);
            auto locationData = m_kitLocation->getCurrentData();
            locationData.location_type = TIS_Info::LocationType::PT_MAODUAN;
            _Service::senderLocationServiceLocationRadio(locationData);
        }
    }
    else
    {
        isFirst = true;
    }
}

QVariantMap LocationController::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}
} // namespace _Controllers