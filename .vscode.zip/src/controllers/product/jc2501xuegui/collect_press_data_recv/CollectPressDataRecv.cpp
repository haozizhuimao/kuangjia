#include "CollectPressDataRecv.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "tis_global/EnumClass.h"
#include "tis_global/Field.h"
#include <qvariant.h>

#include "kits/primary/thread_pool/thread_pool.h"

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

_Controllers::CollectPressDataRecv::CollectPressDataRecv() {}

_Controllers::CollectPressDataRecv::~CollectPressDataRecv() noexcept
{
    checkWriteCollectData(true);
    checkWritePressData(true);

    _mb_thread_process_run.store(false, std::memory_order_release);

    if (_m_thread_process.joinable())
    {
        _m_thread_process.join();
    }
}

void _Controllers::CollectPressDataRecv::getElectriData(const float data)
{
    // auto tmp = (data - 0.4) * 625;
    _md_electriData.store(data, std::memory_order_release);
}

void _Controllers::CollectPressDataRecv::getVoltageData(const float data)
{
    // auto tmp = data * 400;
    _mf_volData.store(data, std::memory_order_release);
}

void CollectPressDataRecv::getPressData0(const float data)
{
    _md_pressData0.store(data, std::memory_order_release);
}

void CollectPressDataRecv::getSpotData0x(const float data)
{
    _md_spotData_0x.store(data, std::memory_order_release);
}

void _Controllers::CollectPressDataRecv::recvTaskData(TIS_Info::TaskInfo taskInfo)
{
    if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        _mi_task_id.store(-1, std::memory_order_release);
        return;
    }

    _mi_task_id.store(taskInfo.nTaskID, std::memory_order_release);

    if (!_m_thread_process.joinable())
    {
        _mb_thread_process_run.store(true, std::memory_order_release);
        _m_thread_process = std::thread(&CollectPressDataRecv::processDataThread, this);
    }
}

void _Controllers::CollectPressDataRecv::processDataThread()
{
    static uint16_t nCount = 0;

    while (_mb_thread_process_run.load(std::memory_order_acquire))
    {
        if (_mi_task_id.load(std::memory_order_acquire) == -1)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        _mdeq_pressData.push_back(initPressData());

        _mdeq_collectData.push_back(initCollectData());

        if (checkWriteCollectData())
        {
            /* code */
        }

        if (checkWritePressData())
        {
            /* code */
        }

        if (++nCount % 100 == 0) // 前端控制显示频率
        {
            sendPressSpot();
            sendVolEleData();
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

bool _Controllers::CollectPressDataRecv::checkWritePressData(bool force)
{
    if (_mdeq_pressData.size() > 1000 || force)
    {
        std::deque<_Kits::_Orm::press_data> pressDataQue;
        pressDataQue.swap(_mdeq_pressData);

        _Kits::thread_pool::runTask(
            [](std::deque<_Kits::_Orm::press_data> &&pressDataQue) {
                // qDebug() << "insert press data" << pressDataQue.size();
                _Kits::SqlInsert<_Kits::_Orm::press_data> sqlInsert;
                sqlInsert.insert(pressDataQue);
                if (!sqlInsert.exec())
                {
                    _Kits::LogError("sql insert error");
                }
            },
            std::move(pressDataQue));
    }

    return false;
}

bool _Controllers::CollectPressDataRecv::checkWriteCollectData(bool force)
{
    if (_mdeq_collectData.size() > 1000 || force)
    {
        std::deque<_Kits::_Orm::collect_data> collectDataQue;
        collectDataQue.swap(_mdeq_collectData);

        _Kits::thread_pool::runTask(
            [](std::deque<_Kits::_Orm::collect_data> &&collectDataQue) {
                // qDebug() << "insert collect data" << collectDataQue.size();
                _Kits::SqlInsert<_Kits::_Orm::collect_data> sqlInsert;
                sqlInsert.insert(collectDataQue);
                if (!sqlInsert.exec())
                {
                    _Kits::LogError("sql insert error");
                }
            },
            std::move(collectDataQue));
    }

    return false;
}

void _Controllers::CollectPressDataRecv::sendPressSpot()
{
    TIS_Info::PressAndSpot PressAndSpot;
    PressAndSpot.md_press0 = _md_pressData0.load(std::memory_order_acquire);
    PressAndSpot.md_press1 = _md_pressData1.load(std::memory_order_acquire);
    PressAndSpot.md_press2 = _md_pressData2.load(std::memory_order_acquire);
    PressAndSpot.md_press3 = _md_pressData3.load(std::memory_order_acquire);

    PressAndSpot.md_spot0x = _md_spotData_0x.load(std::memory_order_acquire);
    PressAndSpot.md_spot0y = _md_spotData_0y.load(std::memory_order_acquire);

    _Service::senderPressSpotVolElecEtcDatasendPressSpotOut(PressAndSpot);
}
void _Controllers::CollectPressDataRecv::sendVolEleData()
{
    TIS_Info::VoltageAndElectric VoltageAndElectric;
    VoltageAndElectric.md_voltage0 = _mf_volData.load(std::memory_order_acquire);
    VoltageAndElectric.md_electric0 = _md_electriData.load(std::memory_order_acquire);

    _Service::senderPressSpotVolElecEtcDatasendVolElecOut(VoltageAndElectric);
}

_Kits::_Orm::press_data _Controllers::CollectPressDataRecv::initPressData()
{

    _Kits::_Orm::press_data pressData;

    pressData.acc0_x = _md_spotData_0x.load(std::memory_order_acquire);
    pressData.acc0_y = _md_spotData_0y.load(std::memory_order_acquire);
    pressData.press0 = _md_pressData0.load(std::memory_order_acquire);
    pressData.press1 = _md_pressData1.load(std::memory_order_acquire);
    pressData.press2 = _md_pressData2.load(std::memory_order_acquire);
    pressData.press3 = _md_pressData3.load(std::memory_order_acquire);
    pressData.task_id = _mi_task_id.load(std::memory_order_acquire);

    pressData.press4 = 8000;
    pressData.press5 = 8000;
    pressData.press6 = 8000;
    pressData.press7 = 8000;

    pressData.acc0_z = 8000;
    pressData.acc1_x = 8000;
    pressData.acc1_y = 8000;
    pressData.acc1_z = 8000;

    return pressData;
}

_Kits::_Orm::collect_data _Controllers::CollectPressDataRecv::initCollectData()
{
    _Kits::_Orm::collect_data collectData;
    collectData.vol = _mf_volData.load(std::memory_order_acquire);
    collectData.task_id = _mi_task_id.load(std::memory_order_acquire);
    collectData.cur = _md_electriData.load(std::memory_order_acquire);
    collectData.tem = 8000;
    collectData.hum = 8000;

    return collectData;
}