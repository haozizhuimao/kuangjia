#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <memory>
#include <thread>

#include "kits/common/database/CppBatis.h"

namespace _Controllers {
class CollectPressDataRecv : public ControllerBase<CollectPressDataRecv>
{
  public:
    explicit CollectPressDataRecv();
    virtual ~CollectPressDataRecv() noexcept;

    void getElectriData(const float);
    void getVoltageData(const float);
    void getPressData0(const float);
    void getPressData1(const float);
    void getPressData2(const float);
    void getPressData3(const float);
    void getSpotData0x(const float);
    void getSpotData0y(const float);
    void recvTaskData(TIS_Info::TaskInfo);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendElectriDataOut, CollectPressDataRecv::getElectriData);
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendPressData0Out, CollectPressDataRecv::getPressData0);
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendVoltageDataOut, CollectPressDataRecv::getVoltageData);
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendAccData0xOut, CollectPressDataRecv::getSpotData0x);
    // ASYNC_TASK_ADD(TIS_Info::TaskService::notifyTaskData, CollectPressDataRecv::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, CollectPressDataRecv::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, CollectPressDataRecv::recvTaskData);
    TASK_LIST_END

  private:
    std::atomic<float> _md_spotData_0x = 8000; // 振动  x
    std::atomic<float> _md_spotData_0y = 8000; // 冲击  y
    std::atomic<float> _md_electriData = 8000; // 电流
    std::atomic<float> _mf_volData = 8000;     // 电压
    std::atomic<float> _md_pressData0 = 8000;  // 压力0
    std::atomic<float> _md_pressData1 = 8000;  // 压力1
    std::atomic<float> _md_pressData2 = 8000;  // 压力2
    std::atomic<float> _md_pressData3 = 8000;  // 压力3

    std::thread _m_thread_process;
    std::atomic_bool _mb_thread_process_run = false;
    std::deque<_Kits::_Orm::press_data> _mdeq_pressData;
    std::deque<_Kits::_Orm::collect_data> _mdeq_collectData;
    void processDataThread();

    _Kits::_Orm::press_data initPressData();
    _Kits::_Orm::collect_data initCollectData();

    bool checkWritePressData(bool force = false);
    bool checkWriteCollectData(bool force = false);

    void sendPressSpot();
    void sendVolEleData();

    std::atomic_int32_t _mi_task_id;
};
} // namespace _Controllers