#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/common/database/orm/TableStructs.h"
//#include "tis_global/Function.h"
#include "tis_global/struct_details/jihe_struct.h"
#include "JCWDataDef.h"
#include "kits/product_kits/save_rawdata/SaveRawdata.h"
#include <cstdint>
#include <unordered_map>
#include <thread>
#include <atomic>
#include <vector>
#include <mutex>
#include <chrono>

#include "kits/algorithm/location/locationRegression.h"
#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#endif // emit
#endif // Q_MOC_RUN
namespace _Controllers {
class JiHeController : public ControllerBase<JiHeController>
{
  public:
    struct LinearFitResult
    {
        double slope;     // 斜率
        double intercept; // 截距
        double r_squared; // 判定系数(R-square)
    };

  public:
    void initUdpRecvier(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    ~JiHeController();
    void recvTaskData(const TIS_Info::TaskInfo &);
    void recvYanYanData(std::shared_ptr<TIS_Info::RawData>);
    void recvInitSignal(int);
    void recvInitConfig(const TIS_Info::jiheConfig);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, JiHeController::initUdpRecvier);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, JiHeController::recvTaskData);
    ASYNC_TASK_ADD(TIS_Info::YanYanDataCollect::rawDataReady, JiHeController::recvYanYanData);
    SYNC_TASK_ADD(TIS_Info::YanYanDataCollect::initSignal, JiHeController::recvInitSignal);
    ASYNC_TASK_ADD(TIS_Info::RailJiHeCollect::rawDataReady, JiHeController::recvYanYanData);
    SYNC_TASK_ADD(TIS_Info::RailJiHeCollect::initSignal, JiHeController::recvInitSignal);
    SYNC_TASK_ADD(TIS_Info::JiHeService::initConfig, JiHeController::recvInitConfig);
    TASK_LIST_END

  private:
    void recvUdpJiheData(std::vector<uint8_t> &&data);
    void recvUdpBuchangData(std::vector<uint8_t> &&datas);
    void sendJiHeData(const TIS_Info::JiHeData &JiHeData);
    void sendJiHeToLocationService(const TIS_Info::JiHeData &data);
    void sendImgJiHeToLocation(const TIS_Info::JiHeData &data);

    void dealJiHeData();
    void handleData(std::shared_ptr<TIS_Info::RawData> rawData);
    int64_t milisecondsTimestamp(const std::vector<uint8_t> &vecData);
    int64_t getMilisecondsTimestamp(std::shared_ptr<JCWD> jcwjh, const int64_t timestamp);
    LinearFitResult linearLeastSquares(const std::vector<double> &x, const std::vector<double> &y);
    void writeJiHeDataToDB();
    std::vector<_Kits::_Orm::jihe_data> convertToDBData(const std::vector<TIS_Info::JiHeData> &vecData);
    bool DataBaseInsert(const std::vector<_Kits::_Orm::jihe_data> &);

  private:
    bool readSimple(int num, const std::string &filename, std::shared_ptr<std::multimap<int, std::vector<double>>> simleVecPtr);
    void initLocationRegression(std::shared_ptr<std::multimap<int, std::vector<double>>> simleVecPtr);

    inline static constexpr char m_udpJiheName[] = "jihe";       // 几何
    inline static constexpr char m_udpBuchangName[] = "buchang"; // 补偿
    std::thread m_dealJiHeThread;
    std::atomic_bool m_isDealJiHeThreadRun = false;
    tbb::concurrent_queue<std::vector<uint8_t>> m_jiheQueue;
    tbb::concurrent_queue<std::shared_ptr<TIS_Info::RawData>> m_jiherawQueue;
    std::thread m_writeDBThread;
    std::vector<TIS_Info::JiHeData> m_jiheData;
    std::mutex m_jiheMutex;
    std::atomic_int32_t m_taskID = -1;
    int64_t m_tpMaoduanlastTime;
    int64_t m_tpTuxianglastTime;
    std::atomic_bool m_bMaoduan = false;
    std::atomic_bool m_bImgType = false;
    std::atomic_bool m_saveRawData = false;
    std::unique_ptr<_Kits::SaveRawdata> m_saveRawdataptr{nullptr};

    std::unique_ptr<_Kits::locationRegression> m_kitLocationReg{nullptr};

    TIS_Info::BCData m_bcData;
    std::mutex m_bcMutex;
    std::atomic_bool m_bBCStatus = false;
};
} // namespace _Controllers
