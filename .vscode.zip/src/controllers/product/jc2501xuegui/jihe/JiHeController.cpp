﻿#include "JiHeController.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include <chrono>
#include <cstdint>
#include <qobject.h>
#include <qtpreprocessorsupport.h>
#include <qvariant.h>
#include <vector>

#include "kits/common/database/CppBatis.h"
#include <fstream>
#include <sstream>
#include <iostream>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void JiHeController::sendJiHeToLocationService(const TIS_Info::JiHeData &data)
{
    static std::vector<double> fVecZig0;
    static std::vector<double> fVecZig1;
    constexpr int maxSaveLen = 4000; // 10s的时间
    // 锚段校正
    if (data.lineNum == 2 && m_bMaoduan == false)
    {
        m_bMaoduan = true;
        m_tpMaoduanlastTime = data.timestamp;
    }
    if (data.lineNum == 2 && m_bMaoduan == true) // 在锚中或者线岔中
    {
        fVecZig0.push_back(data.fZig[0]);
        fVecZig1.push_back(data.fZig[1]);

        if (fVecZig0.size() > maxSaveLen) // 10s还在锚内，不做处理
        {
            fVecZig0.clear();
            fVecZig1.clear();
            m_bMaoduan = false;
        }
    }
    if (data.lineNum == 1 && m_bMaoduan == true)
    {
        m_bMaoduan = false;

        if (fVecZig0.size() >= 10 && fVecZig1.size() >= 10)
        {
            auto jiheData = m_kitLocationReg->preprocessData(fVecZig0, fVecZig1);
            int ret = m_kitLocationReg->detectExtremums(std::move(jiheData));

            if (ret == 1)
            {
                LogInfo("[定位分类]:锚段数据,原始数据长度:{}", fVecZig0.size());
                senderJiHeServiceJiHeMaoDuanToLocation(m_tpMaoduanlastTime, data.timestamp);
            }
            else if (ret == 0)
            {
                LogInfo("[定位分类]:线岔数据,原始数据长度:{}", fVecZig0.size());
                // senderJiHeServiceJiHeXianChaToLocation(m_tpMaoduanlastTime, data.timestamp);
            }
            else
            {
                LogInfo("[定位分类]:分类异常");
            }
            LogInfo("[定位分类],{},{},{},{},{},{},{},{},{},{}",
                    jiheData[0],
                    jiheData[1],
                    jiheData[2],
                    jiheData[3],
                    jiheData[4],
                    jiheData[5],
                    jiheData[6],
                    jiheData[7],
                    jiheData[8],
                    jiheData[9]);

            // senderJiHeServiceJiHeMaoDuanToLocation(m_tpMaoduanlastTime, data.timestamp);
        }
        else
        {
            LogWarn("[定位分类]:数据不足，无法进行分类判断,size={}", fVecZig0.size());
        }
        fVecZig0.clear();
        fVecZig1.clear();
    }

    // 图像校正
    if (data.iImgPosType == 4 && m_bImgType == false) // 支柱位置
    {
        m_bImgType = true;
    }
    if (data.iImgPosType != 4 && m_bImgType == true)
    {
        m_bImgType = false;
        // senderJiHeServiceJiHeImgToLocation(data.timestamp);
    }
}

void JiHeController::sendImgJiHeToLocation(const TIS_Info::JiHeData &data)
{
    // 图像校正
    if (data.iImgPosType == 4 && m_bImgType == false) // 支柱位置
    {
        m_bImgType = true;
    }
    if (data.iImgPosType != 4 && m_bImgType == true)
    {
        m_bImgType = false;
        // senderJiHeServiceJiHeImgToLocation(data.timestamp);
    }
}

JiHeController::~JiHeController()
{
    m_isDealJiHeThreadRun.store(false);
    if (m_dealJiHeThread.joinable())
    {
        m_dealJiHeThread.join();
    }
    if (m_writeDBThread.joinable())
    {
        m_writeDBThread.join();
    }
}

void JiHeController::recvTaskData(const TIS_Info::TaskInfo &task)
{
    if (TIS_Info::TaskState::TASK_STOPPED == task.nTaskstate || TIS_Info::TaskState::TASK_NONE == task.nTaskstate)
    {
        m_taskID.store(-1, std::memory_order_release);
        if (nullptr != m_saveRawdataptr)
        {
            m_saveRawdataptr->finshCollectData();
        }
        return;
    }
    if (1 == m_saveRawData.load() && nullptr != m_saveRawdataptr)
    {
        std::string dbname = std::format("{}_{}_{}", std::to_string(task.nTaskID), std::to_string(task.timestamp), "yanyan");
        m_saveRawdataptr->createDBFile(dbname, "rawdata");
    }

    m_taskID.store(task.nTaskID, std::memory_order_release);
}

void JiHeController::recvInitSignal(int flag)
{
    m_saveRawData.store(flag, std::memory_order_release);
    if (1 == m_saveRawData.load())
    {
        m_saveRawdataptr = std::make_unique<_Kits::SaveRawdata>(1000);
    }
}

bool JiHeController::readSimple(int typenum,
                                const std::string &filename,
                                std::shared_ptr<std::multimap<int, std::vector<double>>> simleVecPtr)
{

    std::ifstream file(filename);
    if (file.is_open())
    {
        std::string line;
        int num = 0;
        while (std::getline(file, line))
        {
            // 瑙ｆ瀽閫楀彿鍒嗛殧鐨勬暟鎹?
            std::vector<double> values;
            std::stringstream ss(line);
            std::string valueStr;
            if (line.empty() || line[0] == '#')
            {
                continue;
            }
            try
            {
                while (std::getline(ss, valueStr, ','))
                {
                    // 去除每个值前后的空格
                    valueStr.erase(0, valueStr.find_first_not_of(" \t"));
                    valueStr.erase(valueStr.find_last_not_of(" \t") + 1);

                    // 转换为double并添加到vector
                    if (!valueStr.empty())
                    {
                        double value = std::stod(valueStr);
                        values.push_back(value);
                    }
                }

                // 将解析后的数据存储到multimap中
                if (!values.empty())
                {
                    simleVecPtr->insert({typenum, values});
                    num++;
                }
            }
            catch (const std::exception &e)
            {
                LogWarn("解析样本数据失败: {}", e.what());
                continue;
            }
        }
        LogInfo("样本数据读取完成,数量为:{}", num);
    }
    else
    {
        LogWarn("无法打开样本文件: {}", filename);
        return false;
    }
    return true;
}

void JiHeController::recvInitConfig(const TIS_Info::jiheConfig config)
{
    std::shared_ptr<std::multimap<int, std::vector<double>>> simleVecPtr = std::make_shared<std::multimap<int, std::vector<double>>>();
    readSimple(1, config.positive_sample, simleVecPtr);
    readSimple(0, config.negative_sample, simleVecPtr);
    initLocationRegression(simleVecPtr);
}

void JiHeController::initLocationRegression(std::shared_ptr<std::multimap<int, std::vector<double>>> simleVecPtr)
{
    if (m_kitLocationReg == nullptr)
    {
        m_kitLocationReg = std::make_unique<_Kits::locationRegression>();
    }
    m_kitLocationReg->train(*simleVecPtr);
}
void JiHeController::sendJiHeData(const TIS_Info::JiHeData &JiHeData)
{
    static int sendNum = 0;
    if (sendNum++ < 20) // 20*2.5ms=50ms
    {
        return;
    }
    else
    {
        sendNum = 0;
    }
    _Service::senderJiHeServiceJiHeDataBroadcast(JiHeData);
}
void JiHeController::initUdpRecvier(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    auto finderJihe = clients.find(m_udpJiheName);
    if (finderJihe != clients.end())
    {
        auto udpJiheClient = finderJihe->second;
        udpJiheClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } recvUdpJiheData(std::vector<uint8_t>(datas->begin(), datas->end())); });
    }

    auto finderBuchang = clients.find(m_udpBuchangName);
    if (finderBuchang != clients.end())
    {
        auto udpBCClient = finderBuchang->second;
        udpBCClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } recvUdpBuchangData(std::vector<uint8_t>(datas->begin(), datas->end())); });
        m_bBCStatus = true;
    }

    m_isDealJiHeThreadRun.store(true);
    m_dealJiHeThread = std::thread(&JiHeController::dealJiHeData, this);
    m_writeDBThread = std::thread(&JiHeController::writeJiHeDataToDB, this);
}

void JiHeController::recvUdpJiheData(std::vector<uint8_t> &&datas)
{
    constexpr int data_size = sizeof(JCWD) + 8;
    if (datas.size() < 560)
    {
        LogError("[JiHeController::recvUdpJiheData]:数据长度异常{},{}", data_size, datas.size());
        return;
    }

    // datas的数据不定长 564-568，需要删除后8位，再统一长度为560
    std::vector<uint8_t> trimmed_data(datas.begin(), datas.end() - 8);
    std::shared_ptr<JCWD> jcwjh = std::make_shared<JCWD>();
    std::memset(jcwjh.get(), 0, sizeof(JCWD));
    std::memcpy(jcwjh.get(), trimmed_data.data(), sizeof(JCWD));

    // 将 JCWD 转换为 std::vector<uint8_t>
    std::vector<uint8_t> data_vector(reinterpret_cast<uint8_t *>(jcwjh.get()), reinterpret_cast<uint8_t *>(jcwjh.get()) + sizeof(JCWD));

    std::shared_ptr<TIS_Info::RawData> data_copy = std::make_shared<TIS_Info::RawData>(std::move(data_vector));
    data_copy->timestamp = datetime::currentTimestamp<std::chrono::microseconds>();
    m_jiherawQueue.push(std::move(data_copy));
}
void JiHeController::recvUdpBuchangData(std::vector<uint8_t> &&datas)
{
    if (datas.size() < sizeof(TIS_Info::BCData))
    {
        LogError("[JiHeController::recvUdpBuchangData]:数据长度小于{}", sizeof(TIS_Info::BCData));
        return;
    }
    TIS_Info::BCData bcData;
    std::memcpy(&bcData, datas.data(), sizeof(TIS_Info::BCData));

    std::lock_guard<std::mutex> lock(m_bcMutex);
    m_bcData = bcData;
}

void JiHeController::recvYanYanData(std::shared_ptr<TIS_Info::RawData> rawdata)
{
    auto data_copy = rawdata;
    m_jiherawQueue.push(std::move(data_copy));
    if (1 == m_saveRawData.load() && -1 != m_taskID.load())
    {
        auto data_copy_save = rawdata;
        m_saveRawdataptr->collectData(rawdata->data, rawdata->timestamp);
    }
}
void JiHeController::dealJiHeData()
{
    while (m_isDealJiHeThreadRun.load())
    {
        std::shared_ptr<TIS_Info::RawData> rawData;
        if (m_jiherawQueue.try_pop(rawData))
        {
            handleData(rawData);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}
void JiHeController::handleData(std::shared_ptr<TIS_Info::RawData> rawData)
{
    if (m_taskID == -1 || nullptr == rawData)
    {
        return;
    }
    std::shared_ptr<JCWD> jcwjh = std::make_shared<JCWD>();
    std::memset(jcwjh.get(), 0, sizeof(JCWD));
    std::memcpy(jcwjh.get(), rawData->data.data(), sizeof(JCWD));

    TIS_Info::JiHeData jiheData;
    auto lineNumber = jcwjh->uiLineNum < 4 ? jcwjh->uiLineNum : 4;
    for (int i = 0; i < lineNumber; i++)
    {
        if (jcwjh->jcx[i].pntLinePos.x > 8000 || jcwjh->jcx[i].pntLinePos.x <= -8000)
        {
            jiheData.fZig[i] = 8000;
        }
        else
        {
            jiheData.fZig[i] = jcwjh->jcx[i].pntLinePos.x;
        }

        if (jcwjh->jcx[i].pntLinePos.y >= 8000 || jcwjh->jcx[i].pntLinePos.y <= -8000)
        {
            jiheData.fHei[i] = 8000;
        }
        else
        {
            jiheData.fHei[i] = jcwjh->jcx[i].pntLinePos.y;
        }

        if (jcwjh->jcx[i].pntCompPos.x >= 8000 || jcwjh->jcx[i].pntCompPos.x <= -8000)
        {
            jiheData.fZigBc[i] = 8000;
        }
        else
        {
            jiheData.fZigBc[i] = jcwjh->jcx[i].pntCompPos.x;
        }

        if (jcwjh->jcx[i].pntCompPos.y >= 8000 || jcwjh->jcx[i].pntCompPos.y <= -8000)
        {
            jiheData.fHeiBc[i] = 8000;
        }
        else
        {
            jiheData.fHeiBc[i] = jcwjh->jcx[i].pntCompPos.y;
        }

        /**************************磨耗*********************************/
        jiheData.fMoHaoWidth[i] = jcwjh->jcx[i].fMhBotLen;
        jiheData.fMoHaoHeight[i] = jcwjh->jcx[i].fMohaoH;
        jiheData.Diameter[i] = jcwjh->jcx[i].fLineRidus;
        // LogDebug("jcwjh->jcx[i].pntCompPos.x
        // :{},jcwjh->jcx[i].pntCompPos.y:{},{}",jcwjh->jcx[i].pntCompPos.x,jcwjh->jcx[i].pntCompPos.y);
        // LogDebug("fzig:{},fhei:{},fmohaolen:{},jiheData.fZigBc:{} jiheData.fHeiBc:{}
        // i:{},lineNumber:{}",jiheData.fZig[i],jiheData.fHei[i],jiheData.fMoHaoWidth[i],jiheData.fZigBc[i],jiheData.fHeiBc[i],i,lineNumber);
    }

    auto postype = jcwjh->GetPosiflag();

    if (JCXP_POLE == postype)
    {
        jiheData.iImgPosType = 4;
    }
    else
    {
        jiheData.iImgPosType = 1;
    }
    jiheData.lineNum = lineNumber;

    if (m_bBCStatus)
    {
        std::lock_guard<std::mutex> lock(m_bcMutex);
        jcwjh->pntCompLeft.x = m_bcData.left_fvert;
        jcwjh->pntCompLeft.y = m_bcData.left_fhori;
        jcwjh->pntCompRight.x = m_bcData.right_fvert;
        jcwjh->pntCompRight.y = m_bcData.right_fhori;
    }

    if (fabs(jcwjh->pntCompLeft.x) < 100 && fabs(jcwjh->pntCompLeft.y) < 100)
    {
        jiheData.fLeftBCX = jcwjh->pntCompLeft.x;
        jiheData.fLeftBCY = jcwjh->pntCompLeft.y;
    }
    else
    {
        jiheData.fLeftBCX = 8000;
        jiheData.fLeftBCY = 8000;
    }
    if (fabs(jcwjh->pntCompRight.x) < 100 && fabs(jcwjh->pntCompRight.y) < 100)
    {
        jiheData.fRightBCX = jcwjh->pntCompRight.x;
        jiheData.fRightBCY = jcwjh->pntCompRight.y;
    }
    else
    {
        jiheData.fRightBCX = 8000;
        jiheData.fRightBCY = 8000;
    }

    jiheData.timestamp = jiheData.timestamp = getMilisecondsTimestamp(jcwjh, rawData->timestamp / 1000);
    // jiheData.timestamp = datetime::current_timestamp(datetime::TimestampUnit::Milliseconds); // 调试测试使用
    auto lineType = jcwjh->jcx[0].lt;
    if (lineType == JCXT_FLEX) // 柔性导线发送图像
    {
        sendImgJiHeToLocation(jiheData);
    }
    else // 刚性导线发送锚段和图像
    {
        sendJiHeToLocationService(jiheData);
    }
    // sendJiHeToLocationService(jiheData);
    sendJiHeData(jiheData);

    std::lock_guard<std::mutex> lock(m_jiheMutex);

    // 临时复用字段, 存储导线个数和图像类型
    jiheData.Diameter[2] = lineNumber;
    jiheData.Diameter[3] = jiheData.iImgPosType;
    //

    m_jiheData.push_back(jiheData);
}

int64_t JiHeController::getMilisecondsTimestamp(std::shared_ptr<JCWD> jcwjh, const int64_t timestamp)
{
    static std::atomic_bool stimeStampAdjust{false};
    static std::atomic_int64_t sfirstTime{0};
    static LinearFitResult slineResult{0};
    static std::vector<double> vec_x;
    static std::vector<double> vec_y;

    if (stimeStampAdjust.load())
    {
        int64_t time = static_cast<int64_t>(jcwjh.get()->uiFileTime * slineResult.slope + slineResult.intercept);
        return time;
    }

    // int64_t timestamp = milisecondsTimestamp(vecData);
    if (sfirstTime == 0) // 第一次初始化
    {
        sfirstTime = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        return timestamp;
    }

    auto curTime = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();

    if (curTime - static_cast<long long>(sfirstTime) < 3000) // 未校准
    {
        vec_x.push_back(static_cast<double>(jcwjh.get()->uiFileTime));
        vec_y.push_back(static_cast<double>(timestamp));
    }
    else
    {
        if (vec_x.size() > 2)
        {
            slineResult = linearLeastSquares(vec_x, vec_y);
            stimeStampAdjust.store(true);
        }
        vec_x.clear();
        vec_y.clear();
    }
    return timestamp;
}
// int64_t JiHeController::milisecondsTimestamp(const std::vector<uint8_t> &vecData)
// {
//     int64_t timestamp = 0;
//     auto len = vecData.size();
//     if (len >= 8)
//     {
//         const uint8_t *raw = reinterpret_cast<const uint8_t *>(vecData.data());
//         timestamp = static_cast<int64_t>((static_cast<uint64_t>(raw[len - 8]) << 56) | (static_cast<uint64_t>(raw[len - 7]) << 48) |
//                                          (static_cast<uint64_t>(raw[len - 6]) << 40) | (static_cast<uint64_t>(raw[len - 5]) << 32) |
//                                          (static_cast<uint64_t>(raw[len - 4]) << 24) | (static_cast<uint64_t>(raw[len - 3]) << 16) |
//                                          (static_cast<uint64_t>(raw[len - 2]) << 8) | (static_cast<uint64_t>(raw[len - 1])));
//     }

//     return timestamp / 1000;

//     // auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
//     // return ms;
// }

void JiHeController::writeJiHeDataToDB()
{
    while (m_isDealJiHeThreadRun.load())
    {
        if (!m_jiheData.empty())
        {
            std::vector<TIS_Info::JiHeData> vecjiheData;
            {
                std::lock_guard<std::mutex> lock(m_jiheMutex);
                vecjiheData = m_jiheData;
                m_jiheData.clear();
            }
            auto vecData = convertToDBData(vecjiheData);
            DataBaseInsert(vecData);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
    }
}

std::vector<_Kits::_Orm::jihe_data> JiHeController::convertToDBData(const std::vector<TIS_Info::JiHeData> &vecData)
{
    std::vector<_Kits::_Orm::jihe_data> res;
    for (const auto &item : vecData)
    {
        // const auto&data = item.data;
        _Kits::_Orm::jihe_data dbItem;
        dbItem.task_id = m_taskID;
        dbItem.zig0 = item.fZig[0];
        dbItem.hei0 = item.fHei[0];
        dbItem.zig_bc0 = item.fZigBc[0];
        dbItem.hei_bc0 = item.fHeiBc[0];
        dbItem.mohao_width0 = item.fMoHaoWidth[0];
        dbItem.mohao_height0 = item.fMoHaoHeight[0];

        dbItem.zig1 = item.fZig[1];
        dbItem.hei1 = item.fHei[1];
        dbItem.zig_bc1 = item.fZigBc[1];
        dbItem.hei_bc1 = item.fHeiBc[1];
        dbItem.mohao_width1 = item.fMoHaoWidth[1];
        dbItem.mohao_height1 = item.fMoHaoHeight[1];

        dbItem.zig2 = item.fZig[2];
        dbItem.hei2 = item.fHei[2];
        dbItem.zig_bc2 = item.fZigBc[2];
        dbItem.hei_bc2 = item.fHeiBc[2];
        dbItem.mohao_width2 = item.fMoHaoWidth[2];
        dbItem.mohao_height2 = item.fMoHaoHeight[2];

        dbItem.zig3 = item.fZig[3];
        dbItem.hei3 = item.fHei[3];
        dbItem.zig_bc3 = item.fZigBc[3];
        dbItem.hei_bc3 = item.fHeiBc[3];
        dbItem.mohao_width3 = item.fMoHaoWidth[3];
        dbItem.mohao_height3 = item.fMoHaoHeight[3];

        dbItem.left_bc_x = item.fLeftBCX;
        dbItem.left_bc_y = item.fLeftBCY;
        dbItem.right_bc_x = item.fRightBCX;
        dbItem.right_bc_y = item.fRightBCY;

        dbItem.diameter0 = item.Diameter[0];
        dbItem.diameter1 = item.Diameter[1];
        dbItem.diameter2 = item.Diameter[2];
        dbItem.diameter3 = item.Diameter[3];

        QString time = QDateTime::fromMSecsSinceEpoch(item.timestamp).toString("yyyy-MM-dd hh:mm:ss.zzz");
        dbItem.created_time = time;
        dbItem.updated_time = time;
        res.push_back(std::move(dbItem));
    }
    return res;
}

bool JiHeController::DataBaseInsert(const std::vector<_Kits::_Orm::jihe_data> &vecData)
{
    if (!vecData.empty())
    {
        _Kits::SqlInsert<_Kits::_Orm::jihe_data> insert;
        insert.insert(vecData).exec();

        int nums = insert.getNumAffected();
        // _Kits::LogDebug("JiHe data end nums={}", nums);
        return nums > 0;
    }
    return false;
}

JiHeController::LinearFitResult JiHeController::linearLeastSquares(const std::vector<double> &x, const std::vector<double> &y)
{
    if (x.size() != y.size() || x.size() < 2)
    {
        return {0.0, 0.0, 0.0};
    }

    size_t n = x.size();

    // 计算均值
    double mean_x = std::accumulate(x.begin(), x.end(), 0.0) / n;
    double mean_y = std::accumulate(y.begin(), y.end(), 0.0) / n;

    // 计算斜率和截距
    double numerator = 0.0;
    double denominator = 0.0;

    double ss_res = 0.0; // 娈嬪樊骞虫柟鍜?
    double ss_tot = 0.0; // 总平方和

    for (size_t i = 0; i < n; ++i)
    {
        double diff_x = x[i] - mean_x;
        numerator += diff_x * (y[i] - mean_y);
        denominator += diff_x * diff_x;
    }

    double slope = (denominator != 0) ? numerator / denominator : 0.0;
    double intercept = mean_y - slope * mean_x;

    for (size_t i = 0; i < n; ++i)
    {
        double y_pred = slope * x[i] + intercept;
        ss_res += (y[i] - y_pred) * (y[i] - y_pred);
        ss_tot += (y[i] - mean_y) * (y[i] - mean_y);
    }

    double r_squared = (ss_tot != 0) ? 1.0 - (ss_res / ss_tot) : 1.0;

    return {slope, intercept, r_squared};
}

} // namespace _Controllers
