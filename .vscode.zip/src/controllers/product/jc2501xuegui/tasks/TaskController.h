#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <json/json.h>
#include "kits/product_kits/task_helper/TaskHelper.h"
#include "tis_global/Struct.h"
namespace _Controllers {
class TaskController final : public ControllerBase<TaskController>
{
  public:
    TaskController() = default;
    ~TaskController() noexcept = default;
    void initFromMoudle(const std::string &, const std::string &); // 配置初始化
    void onTaskSended(QVariant);
    QVariantMap convertDataToJsonOrMap(const QVariant &data);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::TaskService::initTaskController, TaskController::initFromMoudle);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::TaskSend, TaskController::onTaskSended);
    TASK_LIST_END
  private:
    std::unique_ptr<_Kits::TaskHelper> m_taskHelper = nullptr;
    std::string m_trainNum;
};
} // namespace _Controllers
