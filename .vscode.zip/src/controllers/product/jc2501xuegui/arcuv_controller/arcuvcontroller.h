#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

namespace _Controllers {

class ArcuvController : public ControllerBase<ArcuvController>
{
  public:
    void sendArcStatisticsData(TIS_Info::arcData);
    QString arcFileNameSet(TIS_Info::arcData); // 组装视频保存路径
    void sendArcTest(QVariant);
    void sendDWCArcToModule(const float);

  public:
    // 定义任务列表
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::arcUvService::sendArcStatisticsToController,
                   ArcuvController::sendArcStatisticsData); // 开始录制  让其返回 视频路径
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendArcDataOut, ArcuvController::sendDWCArcToModule);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::TestButton, ArcuvController::sendArcTest);
    TASK_LIST_END
};
} // namespace _Controllers