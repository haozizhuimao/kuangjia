#include "arcuvcontroller.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include <qvariant.h>
#include <qdebug.h>

using namespace _Kits;
using namespace _Service;

namespace _Controllers {
void ArcuvController::sendArcStatisticsData(TIS_Info::arcData arc_statistics_data)
{
    auto filename = arcFileNameSet(arc_statistics_data);
    arc_statistics_data.fileName = filename;
    invokearcUvServicesendArcData_V(arc_statistics_data);
}

QString ArcuvController::arcFileNameSet(TIS_Info::arcData arcDataSet)
{
    // 处理时间字符串中的冒号替换为下划线
    std::string occurtime = arcDataSet.occurtime;
    std::replace(occurtime.begin(), occurtime.end(), ':', '_');

    // 组装文件名
    std::string filename = "cameraName_" + arcDataSet.cameraName + "_arcid_" + std::to_string(arcDataSet.arcId) + "_occurtime_" +
                           occurtime + "_count_" + std::to_string(arcDataSet.arccount) + "_arctime_" + std::to_string(arcDataSet.arctime) +
                           "_pulse_" + std::to_string(arcDataSet.arcpulse);

    return QString::fromStdString(filename);
}

void ArcuvController::sendArcTest(QVariant)
{
    TIS_Info::arcData arcDataSet;
    arcDataSet.cameraName = "test_baumer"; // 直接使用std::string
    arcDataSet.arcId = 1;                  // 前置递增保证ID唯一
    arcDataSet.arccount = 1;
    arcDataSet.arctime = 1;
    arcDataSet.arcpulse = 1;
    arcDataSet.occurtime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toStdString();
    arcDataSet.arcDeviceIndex = "1";

    arcDataSet.fileName = arcFileNameSet(arcDataSet);

    invokearcUvServicesendArcData_V(arcDataSet);
}

void ArcuvController::sendDWCArcToModule(const float voltage)
{
    invokearcUvServicesendDWCVoltage_V(voltage);
}

} // namespace _Controllers
