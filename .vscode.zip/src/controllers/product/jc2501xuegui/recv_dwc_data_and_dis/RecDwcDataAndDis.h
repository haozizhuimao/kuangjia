#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
#include <vector>
#include "tis_global/Struct.h"
#include <unordered_map>
#include "kits/communication/asio/udp_client/UdpClient.h"
#include <thread>
#include <atomic>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#endif // emit
#endif // Q_MOC_RUN

namespace _Controllers {
class RecvDwcData : public ControllerBase<RecvDwcData>
{
  public:
    void dealRecDwcData(std::vector<uint8_t> &&datas);
    void dealRcvDwcPressAndSpot(std::vector<uint8_t> &&datas);
    void afterRecDwcData(const float, int);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, RecvDwcData::getUdpClients);

    TASK_LIST_END

  private:
    void getUdpClients(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);

    std::unordered_map<uint16_t, std::shared_ptr<_Kits::UdpClient>> _m_udpClients;

    tbb::concurrent_queue<std::vector<uint8_t>> m_dwcQueue;
    std::thread m_thread_dealDwcData;
    std::atomic_bool m_b_thread_dealDwcData_run = false;
};
} // namespace _Controllers