﻿#include "RecDwcDataAndDis.h"
#include "service/AppFramework.h"
#include <QObject>

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

void RecvDwcData::dealRecDwcData(std::vector<uint8_t> &&data)
{
   


    if (data.empty())
    {
        LogError("Received empty dwc data");
        return;
    }

    // 检查内存对齐（可选，但更安全）
    if (reinterpret_cast<uintptr_t>(data.data()) % alignof(float) != 0)
    {
        LogError("DWC data is not properly aligned for float access");
        // 可以在这里进行内存拷贝到对齐的缓冲区
    }

    int requiredSize = sizeof(float) * 4;
    if (data.size() < requiredSize)
    {
        LogError("Insufficient DWC data size: {} < {}", data.size(), requiredSize);
        return;
    }

    // 安全地访问数据
    float value1, value2, value3;
    std::memcpy(&value1, data.data() + sizeof(float) * 1, sizeof(float));
    std::memcpy(&value2, data.data() + sizeof(float) * 2, sizeof(float));
    std::memcpy(&value3, data.data() + sizeof(float) * 3, sizeof(float));
    float elecV = value1 *400;

    float elec = (value2 - 0.4) * 625; // 电流 X-0.4）* 625

    afterRecDwcData(value1, 0); // 电压
    afterRecDwcData(elec, 1); // 电流
    afterRecDwcData(value3, 2); // 燃弧电压
    LogDebug("dwc rec data value1:{},value2:{},value3:{}", value1, value2, value3);



}
void RecvDwcData::afterRecDwcData(const float data, int index)
{
    switch (index)
    {
        case 0:
            invokeDwcDataDispatchsendVoltageDataOut_V(data);
            break;
        case 1:
            invokeDwcDataDispatchsendElectriDataOut_V(data);//电流
            break;
        case 2:
           //触发的
            invokeDwcDataDispatchsendArcDataOut_V(data);
            //显示
            invokeDwcDataDispatchsendAccData0xOut_V(data);
            break;
        case 3:
            invokeDwcDataDispatchsendAccData0xOut_V(data);//硬点
            break;
        case 4:
            invokeDwcDataDispatchsendPressData0Out_V(data);//压力
            break;

    default:
        break;
    }
}
void RecvDwcData::getUdpClients(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{

    auto udp_client_dwc = clients.find("dwc_data");
    if (udp_client_dwc != clients.end())
    {
        auto udp_client = udp_client_dwc->second;
        LogDebug("found dwc_data udp client");

        udp_client->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } dealRecDwcData(std::vector<uint8_t>(datas->begin(), datas->end())); });
    }
    auto udp_client_dwc_press_spot = clients.find("dwc_press_and_spot");
    if (udp_client_dwc_press_spot != clients.end())
    {
        auto udp_client = udp_client_dwc_press_spot->second;
        LogDebug("found dwc_press_and_spot udp client");
        udp_client->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } dealRcvDwcPressAndSpot(std::vector<uint8_t>(datas->begin(), datas->end())); });

           
    }
   
}
void RecvDwcData::dealRcvDwcPressAndSpot(std::vector<uint8_t> &&datas)
{

    if (datas.empty())
    {
        LogError("Received empty dwc press and spot data");
        return;
    }

    int requiredSize = sizeof(float) * 2;
    if (datas.size() < requiredSize)
    {
        LogError("Insufficient DWC press and spot data size: {} < {}", datas.size(), requiredSize);
        return;
    }
    unsigned templatevalue;
    float pressValue, spotValue;
    std::memcpy(&templatevalue, datas.data() +  0, sizeof(unsigned));

    std::memcpy(&pressValue, datas.data() + sizeof(unsigned), sizeof(float));
    std::memcpy(&spotValue, datas.data() + sizeof(unsigned) + sizeof(float), sizeof(float));
    float press = pressValue*196;
    afterRecDwcData(spotValue, 3); // 硬点
    afterRecDwcData(press, 4);  // 压力

    
  
    //LogDebug("dwc press and spot rec data pressValue:{}, spotValue:{}", pressValue, spotValue);

}





