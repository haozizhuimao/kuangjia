#pragma once
#include "kits/utility/object_pool/ObjectPool.h"
#include "kits/primary/controller_base/ControllerBase.h"

#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

#include "kits/third_devices/save_video_by_ffmpeg/SaveVideoCache.h"

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

namespace _Controllers {
class ArcVideoMaker : public ControllerBase<ArcVideoMaker>
{
  public:
    ArcVideoMaker();
    ~ArcVideoMaker();

    void sendArcImage(std::shared_ptr<TIS_Info::ImageBuffer>);

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraName(std::vector<std::string>) 录像kit的名称列表
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveArc(std::vector<std::string>);

    bool arcFileNameMK(const QString &fileFullName, const QString &filename); // 创建空文件
    void onDealArcData(TIS_Info::arcData);

    void onTaskBegin(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::sendArcImage, ArcVideoMaker::sendArcImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::sendArcImage, ArcVideoMaker::sendArcImage);
    ASYNC_TASK_ADD(TIS_Info::HikManager::initArcCtrl, ArcVideoMaker::onInitSaveArc);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::initArcCtrl, ArcVideoMaker::onInitSaveArc);
    ASYNC_TASK_ADD(TIS_Info::arcUvService::sendArcData, ArcVideoMaker::onDealArcData);

    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, ArcVideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, ArcVideoMaker::onTaskEnd);
    TASK_LIST_END

  private:
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideoCache>> _mmap_saveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForQml;

    std::thread _m_thread_saveVideo;
    std::condition_variable _m_cond_saveVideo;
    std::mutex _m_mutex_saveVideo;
    std::atomic_bool _mb_SaveVideo;

    std::thread _m_thread_processImage;
    std::thread _m_thread_sendToQml;

    QString _mqstr_SavePath; // 保存路径
    TIS_Info::TaskInfo _m_task_info;

  private:
    void onStartRecord(TIS_Info::arcData, QString);
    void onStopRecord();
    void saveVideoThread();

    void processImageThread();

    void sendToQmlThread();

  signals:
    void saveImage(std::shared_ptr<TIS_Info::ImageBuffer> img);
};
} // namespace _Controllers