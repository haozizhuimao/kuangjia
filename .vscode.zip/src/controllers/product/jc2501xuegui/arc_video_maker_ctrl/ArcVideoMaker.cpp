#include "ArcVideoMaker.h"
#include "service/AppFramework.h"
#include "tis_global/enum_public/video_enum.h"
using namespace _Controllers;
using namespace _Kits;
using namespace _Service;

_Controllers::ArcVideoMaker::ArcVideoMaker()
    : _m_thread_saveVideo(std::thread(&ArcVideoMaker::saveVideoThread, this)), _mb_SaveVideo(true),
      _m_thread_processImage(std::thread(&ArcVideoMaker::processImageThread, this)),
      _m_thread_sendToQml(std::thread(&ArcVideoMaker::sendToQmlThread, this))
{
}

_Controllers::ArcVideoMaker::~ArcVideoMaker()
{
    _mb_SaveVideo.store(false);

    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }

    if (_m_thread_processImage.joinable())
    {
        _m_thread_processImage.join();
    }

    if (_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml.join();
    }
}

void ArcVideoMaker::sendArcImage(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    auto &processQueue = _mmap_imgQueueForProcess[img->name];
    // int i = processQueue.unsafe_size();
    processQueue.push(img);
}

void _Controllers::ArcVideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(img);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::ArcVideoMaker::onStartRecord(TIS_Info::arcData arcdata, QString rootPath)
{
    const auto &cameraName = arcdata.cameraName;
    const auto &fileName = arcdata.fileName;

    QString saveVideoPath = rootPath + "/" + QString::fromStdString(cameraName) + "/" + fileName + "." + "mp4";
    QString fileRootPath = rootPath + "/" + QString::fromStdString(cameraName);

    qDebug() << "_mmap_saveVideo:" << _mmap_saveVideo.size();
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        if (name != cameraName) // 只处理特点相机的录像
        {
            continue;
        }
        if (arcFileNameMK(saveVideoPath, fileRootPath))
        {
            saveVideo->startRecord(saveVideoPath, [arcdata, saveVideoPath](int ret) mutable {
                if (ret == 0)
                {
                    arcdata.fileName = saveVideoPath;
                    invokearcUvServiceOnVideoPathReceived_V(arcdata);
                }
                else if (ret == 3)
                {
                    qDebug() << "Recording is already in progress for camera: " << saveVideoPath;
                    QFile::remove(saveVideoPath);
                }
                else
                {
                    LogError("[ArcVideoMaker::onStartRecord] 录像失败，错误码: {}", ret);
                }
            });
        }
        else
        {
            LogError("[ArcVideoMaker::onStartRecord] 燃弧路径错误: {}", saveVideoPath.toStdString());
        }

        // saveVideo->startRecord(fileName);
    }
}

void _Controllers::ArcVideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
}

void _Controllers::ArcVideoMaker::onInitSaveArc(std::vector<std::string> cameraName)
{
    for (const auto &name : cameraName)
    {
        if (_mmap_saveVideo.find(name) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[name] = std::make_unique<_Kits::SaveVideoNew::SaveVideoCache>();
            _mmap_saveVideo[name]->initSaveVideo(1); // 初始化录像kit
        }
    }
}
bool _Controllers::ArcVideoMaker::arcFileNameMK(const QString &fileFullName, const QString &filename)
{
    QDir dir;
    if (!dir.exists(filename))
    {
        if (!dir.mkpath(filename))
        {
            qDebug() << "Failed to create directory:" << filename;
            return false;
        }
    }

    return true;
}

void _Controllers::ArcVideoMaker::onDealArcData(TIS_Info::arcData arcdata)
{
    onStartRecord(arcdata, _mqstr_SavePath);
}

void _Controllers::ArcVideoMaker::processImageThread()
{
    static unsigned int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */

                /* 发送图像 */
                if (++i % 5 == 0)
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[img->name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::ArcVideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                // 发送图像到QML
                if(img->pixFormat == (int)TIS_Info::AVPixelFormat::AV_PIX_FMT_GRAY8)
                {
                    QImage qimg(img->data.data(), img->width, img->height, QImage::Format_Grayscale8);
                    if (!qimg.isNull())
                    {
                        invokeQmlPrivateEnginecallFromCpp_V(
                            TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page,
                            QVariant::fromValue(QVariantMap{{"img", qimg}, {"camera_name", QString::fromStdString(img->name)}}));
                    }

                }
                else
                {
                    LogError("相机发送图像格式错误");
                }
               
               
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::ArcVideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _mqstr_SavePath = task_info.strTaskSavePath;
    _m_task_info = task_info;
}

void _Controllers::ArcVideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _mqstr_SavePath = "";
    _m_task_info.clear();
    onStopRecord();
}