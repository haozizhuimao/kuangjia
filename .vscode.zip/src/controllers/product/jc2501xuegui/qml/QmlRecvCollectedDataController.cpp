#include "QmlRecvCollectedDataController.h"
#include "kits/utility/log/CRossLogger.h"

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlRecvCollectedDataController::onSendPressSpotToQml(TIS_Info::PressAndSpot data)
{
    md_totalPress = 0;
    if (data.md_press0 != 8000)
        md_totalPress += data.md_press0;
    if (data.md_press1 != 8000)
        md_totalPress += data.md_press1;
    if (data.md_press2 != 8000)
        md_totalPress += data.md_press2;
    if (data.md_press3 != 8000)
        md_totalPress += data.md_press3;

    QVariantMap pressSpotDataMap = {{"press", md_totalPress},
                                    {"press1", data.md_press0},
                                    {"press2", data.md_press1},
                                    {"press3", data.md_press2},
                                    {"press4", data.md_press3},
                                    {"spotx", data.md_spot0x},
                                    {"spoty", data.md_spot0y}};

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::press_data_send, QVariant::fromValue(pressSpotDataMap));
}

void QmlRecvCollectedDataController::onSendVolEleDataToQml(TIS_Info::VoltageAndElectric data)
{
    QVariantMap volEleDataMap = {{"electri0", data.md_electric0}, {"voltage0", data.md_voltage0}};

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::voltage_data_send, QVariant::fromValue(volEleDataMap));
}

} // namespace _Controllers
