#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <mutex>
namespace _Controllers {
class QmlArcController : public ControllerBase<QmlArcController>
{
  public:
    void sendArcDataToPage(const float);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::DwcDataDispatch::sendArcDataOut, QmlArcController::sendArcDataToPage);
    TASK_LIST_END
};
} // namespace _Controllers