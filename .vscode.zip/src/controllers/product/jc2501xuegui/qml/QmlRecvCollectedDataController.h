#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <qvariant.h>
#include <string>
namespace _Controllers {
class QmlRecvCollectedDataController : public ControllerBase<QmlRecvCollectedDataController>
{
  public:
    void onSendPressSpotToQml(TIS_Info::PressAndSpot);
    void onSendVolEleDataToQml(TIS_Info::VoltageAndElectric);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, QmlRecvCollectedDataController::onSendPressSpotToQml);
    ASYNC_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, QmlRecvCollectedDataController::onSendVolEleDataToQml);
    TASK_LIST_END

  private:
    double md_totalPress = 0.0;
};
} // namespace _Controllers
