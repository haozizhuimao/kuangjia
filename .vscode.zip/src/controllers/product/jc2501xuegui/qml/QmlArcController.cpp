#include "QmlArcController.h"
#include "kits/utility/log/CRossLogger.h"
#include <qvariant.h>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;

void QmlArcController::sendArcDataToPage(const float arcData)
{
    // 发送所有数据到QML
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::arc_page, QVariant::fromValue(arcData));
}

} // namespace _Controllers
