#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include "kits/utility/log/CRossLogger.h"
#include "tis_global/EnumPublic.h"
#include "tis_global/enum_public/video_enum.h"
#include <QJsonValue>
#include <opencv2/opencv.hpp>

namespace _Controllers {
using namespace _Service;

VideoMaker::VideoMaker()
    : _m_ImageBufferPools(std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>()),
      _m_locationCtrl(std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); })),
      _m_task_info({}), _mb_SaveVideo(true), _mqstr_SavePath({"d:/gwkj/video_Notask"}),

      _m_thread_saveVideo{}, _m_thread_sendToQml{}, _m_thread_processImage{}, _m_thread_sendTitle{}
{}

VideoMaker::~VideoMaker() {}

void VideoMaker::onStopVideoMaker()
{
    _mb_SaveVideo.store(false);

    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }

    if (_m_thread_processImage.joinable())
    {
        _m_thread_processImage.join();
    }

    if (_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml.join();
    }

    if (_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle.join();
    }

    onStopRecord();

    _m_locationCtrl->~LocationCtrl();
}

void VideoMaker::sendImage(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    auto &processQueue = _mmap_imgQueueForProcess[img->name];
    int i = processQueue.unsafe_size();
    processQueue.push(img);
}

void VideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> yuv420p;
            while (queue.try_pop(yuv420p))
            {
                if (!yuv420p)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(yuv420p);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void VideoMaker::onStartRecord(QString fileName)
{
    QString dirPath, filePath;

    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        // 构建完整路径
        dirPath = _mqstr_SavePath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";

        // 创建目录结构
        QDir dir;
        if (!dir.exists(dirPath))
        {
            if (!dir.mkpath(dirPath))
            {
                qWarning() << "Failed to create directory:" << dirPath;
                continue; // 跳过当前摄像头
            }
        }

        // 开始录像
        saveVideo->startRecord(filePath);
        invokeBaumerManagersendSavePathOut_V(QString::fromStdString(name), dirPath);
        // for循环里面更新界面这个好吗？ 频率低
        // 最好组成vector发过去
    }

    invokeBaumerManagersendRecordState_V(true);
}

void VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
    // senderHikManagersendRecordState(false);
    invokeBaumerManagersendRecordState_V(false);
}

void VideoMaker::onInitSaveVideo(std::vector<std::string> cameraName)
{
    for (const auto &name : cameraName)
    {
        if (_mmap_saveVideo.find(name) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[name] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[name]->initSaveVideo(1); // 初始化录像kit
        }

        if (_mmap_isDisplay.find(name) == _mmap_isDisplay.end())
        {
            _mmap_isDisplay[name] = true;
        }
    }

    _m_thread_saveVideo = std::thread(&VideoMaker::saveVideoThread, this);
    _m_thread_sendToQml = std::thread(&VideoMaker::sendToQmlThread, this);
    _m_thread_processImage = std::thread(&VideoMaker::processImageThread, this);
    _m_thread_sendTitle = std::thread(&VideoMaker::sendTitleThread, this);
}

void VideoMaker::processImageThread()
{
    static int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */

                /* 发送图像 */
                if (_mmap_isDisplay[name])
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void VideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img || queue.unsafe_size() > 5)
                    continue;

                // baumer 使用mono8 格式
                if (img->camera_type == (int)TIS_Info::EnumPublic::CameraType::CameraType_BAUMER &&
                    img->pixFormat == (int)TIS_Info::AVPixelFormat::AV_PIX_FMT_GRAY8)
                {
                    QImage qimg(img->data.data(), img->width, img->height, QImage::Format_Grayscale8);
                    if (!qimg.isNull())
                    {
                        QImage qimg_copy = qimg.copy();
                        invokeBaumerManagersendImageToQml_V(
                            QVariantMap{{"img", qimg_copy}, {"camera_name", QString::fromStdString(img->name)}});
                    }
                }

                // auto img_rgb = YUV420ptoRGB(img);

                // QImage qimg(img_rgb->data.data(), img_rgb->width, img_rgb->height, QImage::Format_RGB888);
                // if (!qimg.isNull())
                // {
                //     qimg = qimg.rgbSwapped();

                //     QImage qimg_copy = qimg.copy(); // 避免内存被回收

                //     if (img_rgb->camera_type == (int)TIS_Info::CameraType::CameraType_HIK)
                //     {
                //         senderHikManagersendImageToQml(
                //             QVariantMap{{"img", qimg}, {"camera_name", QString::fromStdString(img_rgb->name)}});
                //     }
                // }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void VideoMaker::SetExposureTimeAndGain(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD exposureTime = static_cast<DWORD>(dataMap.value("exposure").toUInt());
    BYTE gainValue = static_cast<BYTE>(dataMap.value("gain").toUInt());
    QString type = dataMap.value("type").toString();

    if (type == "setExposureAndGain")
    {
        // receiverHikManageronSetExposureTimeAndGain(exposureTime, gainValue, cameraName);
    }
    else
    {
        return;
    }
}

void VideoMaker::PTZControl(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    QString dir = dataMap.value("dir").toString();
    QString command = dataMap.value("command").toString();
    QString type = dataMap.value("type").toString();
    if (type == "PTZControl")
    {
        // receiverHikManageronPTZControl(dir, command, cameraName);
    }
    else
    {
        return;
    }
}

void VideoMaker::SetPTZSpeed(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD speed = static_cast<DWORD>(dataMap.value("speed").toUInt());
    QString type = dataMap.value("type").toString();
    if (type == "SetPTZSpeed")
    {
        // receiverHikManageronSetPTZSpeed(speed, cameraName);
    }
    else
    {
        return;
    }
}

QVariantMap VideoMaker::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        qWarning() << "convertDataToJsonOrMap: data is not a string";
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        qWarning() << "convertDataToJsonOrMap: invalid JSON object";
        return {};
    }

    return doc.object().toVariantMap();
}

void VideoMaker::sendTitleThread()
{
    std::vector<QString> subtitles;
    subtitles.reserve(16);

    while (_mb_SaveVideo.load())
    {
        // 使用tbb::concurrent_unordered_map的安全访问方式
        auto station_it = _m_map_subTitle.find("站区名");
        if (station_it != _m_map_subTitle.end())
        {
            subtitles.push_back("站区名:" + station_it->second.toString());
        }

        auto anchor_it = _m_map_subTitle.find("锚段名");
        if (anchor_it != _m_map_subTitle.end())
        {
            subtitles.push_back("锚段名:" + anchor_it->second.toString());
        }

        auto pole_it = _m_map_subTitle.find("杆号名");
        if (pole_it != _m_map_subTitle.end())
        {
            subtitles.push_back("杆号名:" + pole_it->second.toString());
        }

        auto km_it = _m_map_subTitle.find("公里标");
        if (km_it != _m_map_subTitle.end())
        {
            subtitles.push_back("公里标:" + QString::number(km_it->second.toDouble(), 'f', 3));
        }

        auto speed_it = _m_map_subTitle.find("速度");
        if (speed_it != _m_map_subTitle.end())
        {
            subtitles.push_back("速度:" + QString::number(speed_it->second.toDouble(), 'f', 3));
        }

        // senderHikManagersendSubTitle(subtitles);

        subtitles.clear();
        std::this_thread::sleep_for(std::chrono::milliseconds(1000)); // 每秒发送一次标题 待测试
    }
}

void VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    _m_map_subTitle["站区名"] = location_data.station_name;
    _m_map_subTitle["锚段名"] = location_data.maoduan_name;
    _m_map_subTitle["杆号名"] = location_data.pole_name;
    _m_map_subTitle["公里标"] = static_cast<float>(location_data.mileage_after) / 1000 / 1000;
    _m_map_subTitle["速度"] = location_data.speed;

    m_LastlocationData = location_data;
    _m_locationCtrl->updateLocation(location_data.station_name);
}
void VideoMaker::onGetLocation_(const TIS_Info::RemoteMessage &location_data)
{

    std::string data = location_data.json_data;

    Json::Value root;
    Json::CharReaderBuilder builder;
    std::string errs;
    std::istringstream iss(data);

    if (!Json::parseFromStream(builder, iss, &root, &errs))
    {
        qDebug() << "Failed to parse JSON: " << QString::fromStdString(errs);
        return;
    }

    if (!root.isMember("station_name") || !root.isMember("maoduan_name") || !root.isMember("pole_name") ||
        !root.isMember("mileage_after") || !root.isMember("speed"))
    {
        return;
    }

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_map_subTitle["站区名"] = QString::fromUtf8(root["station_name"].asCString());
    _m_map_subTitle["锚段名"] = QString::fromUtf8(root["maoduan_name"].asCString());
    _m_map_subTitle["杆号名"] = QString::fromUtf8(root["pole_name"].asCString());
    _m_map_subTitle["公里标"] = static_cast<float>(root["mileage_after"].asDouble()) / 1000 / 1000;
    _m_map_subTitle["速度"] = static_cast<float>(root["speed"].asDouble());
    _m_locationCtrl->updateLocation(QString::fromUtf8(root["station_name"].asCString()));
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[HikCamera::YV12toRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = _m_ImageBufferPools->getObject(w, h, 3); // RGB24

    cv::Mat yuv_mat(h * 3 / 2, w, CV_8UC1, img_yuv420p->data.data());
    cv::Mat rgb_mat(h, w, CV_8UC3, img_rgb->data.data());
    cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}

void VideoMaker::onStartRecordOneCame(QString camera_name, QString file_name)
{
    QString dirPath = _mqstr_SavePath + "/" + QDateTime::currentDateTime().toString("yyyyMMdd") + "/" + camera_name;
    QString filePath = dirPath + "/" + file_name + ".mp4";

    // 创建目录结构
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            qWarning() << "Failed to create directory:" << dirPath;
            _Kits::LogError("[HikCamera::onStartRecordOneCame] 创建文件夹失败，录像失败");
            return;
        }
    }

    _mmap_saveVideo[camera_name.toStdString()]->startRecord(filePath);
}

void VideoMaker::onStopRecordOneCame(QString camera_name)
{
    _mmap_saveVideo[camera_name.toStdString()]->stopRecord();
}

void VideoMaker::onQmlRecordSignal(QVariant data)
{
    if (_m_task_info.nTaskstate == TIS_Info::TaskState::TASK_START || _m_task_info.nTaskstate == TIS_Info::TaskState::TASK_RUNNING)
    {
        return;
    }

    auto dataMap = convertDataToJsonOrMap(data);
    auto camera_name = dataMap.value("camera_name").toString();
    auto ischeck = dataMap.value("state").toBool();

    auto cam_it = _mmap_saveVideo.find(camera_name.toStdString());
    if (cam_it == _mmap_saveVideo.end())
    {
        _Kits::LogError("[HikCamera::onQmlRecordSignal] 录像失败，没有此摄像机");
        return;
    }

    if (ischeck == true)
    {
        onStartRecordOneCame(camera_name, QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss"));
    }
    else if (ischeck == false)
    {
        onStopRecordOneCame(camera_name);
    }
}
void VideoMaker::onTaskBegin_(const TIS_Info::RemoteMessage &msg)
{

    std::string data = msg.json_data;

    Json::Value root;
    Json::CharReaderBuilder builder;
    std::string errs;
    std::istringstream iss(data);

    if (!Json::parseFromStream(builder, iss, &root, &errs))
    {
        qDebug() << "Failed to parse JSON: " << QString::fromStdString(errs);
        return;
    }

    _mqstr_SavePath = QString::fromStdString(root["strTaskSavePath"].asString());
    // 创建文件夹_mqstr_SavePath
    QDir dir;
    if (!dir.exists(_mqstr_SavePath))
    {
        dir.mkdir(_mqstr_SavePath);
    }

    TIS_Info::TaskInfo task_info;
    task_info.dKilometer = root["dkilometer"].asDouble();
    task_info.nDirection = root["nDirection"].asInt();
    task_info.nLineDirection = root["nLineDir"].asInt();
    task_info.nTaskID = root["nTaskID"].asInt();
    task_info.nTaskstate = static_cast<TIS_Info::TaskState>(root["nTaskstate"].asInt());
    task_info.strCreateTime = QString::fromStdString(root["strCreateTime"].asString());
    task_info.strEndStation = QString::fromUtf8(root["strEndstation"].asCString());
    task_info.strLineName = QString::fromUtf8(root["strLineName"].asCString());
    task_info.strStartPole = QString::fromStdString(root["strstartPole"].asString());
    task_info.strStartStation = QString::fromUtf8(root["strstartstation"].asCString());
    task_info.strSubWayNum = QString::fromStdString(root["strsubwayNum"].asString());
    task_info.strTaskSavePath = QString::fromStdString(root["strTaskSavePath"].asString());
    task_info.nTaskID = root["nTaskID"].asInt();

    _m_task_info = task_info;
    _m_locationCtrl->updateLocation("");
}
void VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _mqstr_SavePath = task_info.strTaskSavePath;
    _m_task_info = task_info;
    _m_locationCtrl->updateLocation("");
}

void VideoMaker::onTaskEnd_(const TIS_Info::RemoteMessage &msg)
{
    std::string data = msg.json_data;

    Json::Value root;
    Json::CharReaderBuilder builder;
    std::string errs;
    std::istringstream iss(data);

    if (!Json::parseFromStream(builder, iss, &root, &errs))
    {
        qDebug() << "Failed to parse JSON: " << QString::fromStdString(errs);
        return;
    }

    _mqstr_SavePath = QString::fromUtf8(root["strTaskSavePath"].asCString());

    TIS_Info::TaskInfo task_info;
    task_info.dKilometer = root["dkilometer"].asDouble();
    task_info.nDirection = root["nDirection"].asInt();
    task_info.nLineDirection = root["nLineDir"].asInt();
    task_info.nTaskID = root["nTaskID"].asInt();
    task_info.nTaskstate = static_cast<TIS_Info::TaskState>(root["nTaskstate"].asInt());
    task_info.strCreateTime = QString::fromStdString(root["strCreateTime"].asString());
    task_info.strEndStation = QString::fromStdString(root["strEndstation"].asString());
    task_info.strLineName = QString::fromUtf8(root["strLineName"].asCString());         // strLineName
    task_info.strStartPole = QString::fromUtf8(root["strstartPole"].asCString());       // strstartPole
    task_info.strStartStation = QString::fromUtf8(root["strstartstation"].asCString()); // strstartstation
    task_info.strSubWayNum = QString::fromStdString(root["strsubwayNum"].asString());
    task_info.strTaskSavePath = QString::fromUtf8(root["strTaskSavePath"].asCString()); // strTaskSavePath
    task_info.nTaskID = root["nTaskID"].asInt();

    _m_task_info = task_info;

    _mqstr_SavePath = "d:/gwkj/video_Notask"; // 重置保存路径

    _m_task_info.nTaskID = -1;
    onStopRecord();
}

void VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _mqstr_SavePath = "d:/gwkj/video_Notask";
    _m_task_info = task_info;
    _m_task_info.nTaskID = -1;
    onStopRecord();
}

void VideoMaker::onDisplayImgOption(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    auto state = static_cast<DWORD>(dataMap.value("state").toBool());
    QString type = dataMap.value("type").toString();

    if (type == "isDisplay")
    {
        auto cam_name_it = _mmap_isDisplay.find(cameraName);
        if (cam_name_it == _mmap_isDisplay.end())
        {
            _Kits::LogError("前端发送的相机名是空的: {}", cameraName);
            return;
        }

        cam_name_it->second = state;
    }
}

} // namespace _Controllers