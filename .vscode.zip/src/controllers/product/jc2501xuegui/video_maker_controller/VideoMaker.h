#pragma once
#include "kits/utility/object_pool/ObjectPool.h"
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Field.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <QImage>

#include <json/json.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QString>
#include <mutex>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#include "kits/camera/tools/LocationCtrl.h"

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();
    void onStopVideoMaker();

    void sendImage(std::shared_ptr<TIS_Info::ImageBuffer>);
    void onStartRecord(QString);
    void onStopRecord();

    /// @brief 单个相机录像
    /// @param camera_name 相机名
    /// @param file_name 录像名
    void onStartRecordOneCame(QString, QString);
    /// @brief 单个相机录像结束
    /// @param camera_name 相机名
    void onStopRecordOneCame(QString);
    /// @brief 录像结束，用于QML触发录像结束
    /// @param camera_name 相机名
    /// @param ischeck 录像开启或结束
    void onQmlRecordSignal(QVariant);

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraName(std::vector<std::string>) 录像kit的名称列表
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitSaveVideo(std::vector<std::string>);

    void onDisplayImgOption(QVariant);

    void SetExposureTimeAndGain(QVariant);
    void PTZControl(QVariant);
    void SetPTZSpeed(QVariant);

    void onGetLocation(const TIS_Info::LocationData &);

    void onTaskBegin(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);
    void onTaskBegin_(const TIS_Info::RemoteMessage &);
    void onTaskEnd_(const TIS_Info::RemoteMessage &);
    void onGetLocation_(const TIS_Info::RemoteMessage &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::sendImage, VideoMaker::sendImage);
    ASYNC_TASK_ADD(TIS_Info::BaumerManager::initVideoCtrl, VideoMaker::onInitSaveVideo);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, VideoMaker::onGetLocation);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, VideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, VideoMaker::onTaskEnd);
    SYNC_TASK_ADD(TIS_Info::BaumerManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);

    REMOTE_TASK_ADD(TIS_Info::TaskService::taskBegin, VideoMaker::onTaskBegin_);
    REMOTE_TASK_ADD(TIS_Info::TaskService::taskEnd, VideoMaker::onTaskEnd_);
    REMOTE_TASK_ADD(TIS_Info::LocationService::LocationRadio, VideoMaker::onGetLocation_);

    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetExposureTimeAndGain);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::PTZControl);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetPTZSpeed);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::VideoRecordButton, VideoMaker::onQmlRecordSignal);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::onDisplayImgOption);

    TASK_LIST_END

  private:
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> _mmap_saveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForQml;
    std::unordered_map<std::string, bool> _mmap_isDisplay;

    std::thread _m_thread_saveVideo;
    std::atomic_bool _mb_SaveVideo;
    std::atomic_bool _mb_stop;

    std::thread _m_thread_processImage;
    std::thread _m_thread_sendToQml;

    std::thread _m_thread_sendTitle;
    QString rootPath;

    QString _mqstr_SavePath; // 保存路径
    TIS_Info::TaskInfo _m_task_info;

    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> _m_ImageBufferPools;

    tbb::concurrent_unordered_map<std::string, QVariant> _m_map_subTitle; // 用于存储字幕信息

    std::unique_ptr<_Kits::LocationCtrl> _m_locationCtrl;
    std::mutex m_mutex;

  private:
    void saveVideoThread();

    void processImageThread();

    void sendToQmlThread();

    void sendTitleThread();

    QVariantMap convertDataToJsonOrMap(const QVariant &);

    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yv12);
};
} // namespace _Controllers