#include "TrackInspectionCollectController.h"
#include "kits/common/remote_message_parser/RemoteParser.h"
#include "kits/database/postgresql_interface/PgLineData.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/database/postgresql_interface/PgDetection.h"
#include "tis_global/struct_details/zongheng_remote_struct.h"
#include <atomic>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
TrackInspectionCollectController::TrackInspectionCollectController()
    : m_trackInspectionManager(std::make_unique<_Kits::TrackInspectionManager>())
{}
void TrackInspectionCollectController::onStart()
{
    // 数据库连接
    auto pgClientPtr = _Service::DatabaseManager::getPgClient<database::DbClientPtr>(database::PgClientNames::pg_client_default);
    _Kits::database::PgDetection::setClient(pgClientPtr);
}

void TrackInspectionCollectController::onStop() {}
void TrackInspectionCollectController::onTaskInfo(const TIS_Info::task_data &iTaskData)
{
    m_taskData = iTaskData;
    switch (static_cast<TIS_Info::TaskState>(iTaskData.task_state))
    {
    case TIS_Info::TaskState::TASK_START:
        m_trackInspectionManager->updateTaskInfo(iTaskData);
        m_trackInspectionManager->collectionEnable(true);
        break;
    case TIS_Info::TaskState::TASK_STOPPED:
        m_trackInspectionManager->collectionEnable(false);
        break;
    case TIS_Info::TaskState::TASK_PAUSED:
    case TIS_Info::TaskState::TASK_RUNNING:
    case TIS_Info::TaskState::TASK_NONE:
    default:
        break;
    }
}

void TrackInspectionCollectController::onLocationInfoFromRemote(const TIS_Info::RemoteMessage &msg)
{
    if (m_taskData.line_name.empty() || m_taskData.task_name.empty())
    {
        LogError("task has not been created");
        return;
    }
    TIS_Info::TrackLocationData trackPosition;
    _Kits::RemoteParser::parseTrackLocationInfo(msg, trackPosition);
    // 获取定位信息
    TIS_Info::LocationData locationData;
    locationData.milimeter = trackPosition.kilometer;
    locationData.line_direction = trackPosition.updown_id;
    locationData.speed = trackPosition.speed;
    locationData.line_name = m_taskData.line_name;
    auto lineData = _Kits::database::PgLineData::getLineById(trackPosition.line_id, trackPosition.updown_id, m_taskData.drive_direction, m_taskData.line_name);
    if (lineData.has_value())
    {
        locationData.maoduan_name = lineData->maoduan_name;
        locationData.pole_name = lineData->pole_name;
    }
    m_trackInspectionManager->updateLocation(locationData);
}

void TrackInspectionCollectController::onLocationInfo(const TIS_Info::LocationData &iPositon)
{
    m_trackInspectionManager->updateLocation(iPositon);
}

void TrackInspectionCollectController::onInitHikIndustrial(TIS_Info::HikIndustrialInfo config)
{
    if (m_trackInspectionManager)
    {
        m_trackInspectionManager->setCameraConfig(config);
    }
}

void TrackInspectionCollectController::onDetectInfoRequest(const Json::Value &iData)
{
    if (m_trackInspectionManager)
    {
        TIS_Info::track_detect_info info = m_trackInspectionManager->getCollectionInfo();
        Json::Value alInfo;
        Json::Value result;
        for (auto it = info.detect_result.begin(); it != info.detect_result.end(); ++it) {
            result[it->first] = it->second;
        }
        alInfo["detect_info"] = result;
        alInfo["detected_count"] = info.detected_count;
        alInfo["collect_count"] = info.collect_count;

        // _Service::AlgorithmService::algorithmProcess(alInfo);
        _Service::UIEngine::callFromCpp(TIS_Info::UI::ActionsCPP2UI::algorithmDataSend, alInfo);
    }
}

} // namespace _Controllers