
#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "tis_global/Struct.h"
#include "kits/common/track_inspection/TrackInspectionManager.h"
#include <memory>

namespace _Controllers {
class TrackInspectionCollectController final : public ControllerBase<TrackInspectionCollectController>
{
  public:
    TrackInspectionCollectController();
    ~TrackInspectionCollectController() noexcept = default;

    void onStart();
    void onStop();

    void onTaskInfo(const TIS_Info::task_data &);
    void onLocationInfo(const TIS_Info::LocationData &);
    void onInitHikIndustrial(TIS_Info::HikIndustrialInfo);
    void onLocationInfoFromRemote(const TIS_Info::RemoteMessage &);
    void onDetectInfoRequest(const Json::Value &);

    TASK_LIST_BEGIN
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_start, TrackInspectionCollectController::onStart);
    SYNC_TASK_ADD(_Service::ControllerManager::ctrl_stop, TrackInspectionCollectController::onStop);
    ASYNC_TASK_ADD(_Service::TaskService::taskInfo, TrackInspectionCollectController::onTaskInfo);
    ASYNC_TASK_ADD(_Service::LocationService::LocationRadio, TrackInspectionCollectController::onLocationInfo);
    ASYNC_TASK_ADD(_Service::HikManager::initHikIndustrial, TrackInspectionCollectController::onInitHikIndustrial);
    // SYNC_TASK_ADD(_Service::AlgorithmService::algorithmInfoRequest, TrackInspectionCollectController::onDetectInfoRequest);
    
    UI_TASK_ADD(TIS_Info::UI::ActionsUI2CPP::AlgorithmDataRequest, TrackInspectionCollectController::onDetectInfoRequest);
    REMOTE_TASK_ADD("kilo_mark", TrackInspectionCollectController::onLocationInfoFromRemote);
    TASK_LIST_END

  private:
    std::unique_ptr<_Kits::TrackInspectionManager> m_trackInspectionManager = nullptr;
    TIS_Info::task_data m_taskData;
};
} // namespace _Controllers