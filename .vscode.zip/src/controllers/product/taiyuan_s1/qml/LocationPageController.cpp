#include "LocationPageController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"

using namespace _Controllers;
using namespace _Kits;
using namespace _Service;
#include <qvariant.h>

namespace _Controllers {
// 上下杆号校准
void LocationPageController::onULPoleCalibrationSended(QVariant data)
{
    // 发送组合后的数据到其他模块
    invokeLocationServicerecvHandData_A(data);
}
// 站区杆号校准
void LocationPageController::onPoleCalibrationSended(QVariant data)
{
    // 发送组合后的数据到其他模块
    invokeLocationServicerecvHandData_A(data);
}

} // namespace _Controllers
// namespace _Controllers