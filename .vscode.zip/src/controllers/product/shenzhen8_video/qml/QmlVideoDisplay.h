#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include <QString>
#include "kits/ui/qml_kits/ImagePainter.h"
namespace _Controllers {
class QmlVideoDisplay : public ControllerBase<QmlVideoDisplay>
{
  public:
    void displayVideo(std::shared_ptr<TIS_Info::ImageBuffer>);
    void recvImagePainter(QVariant);
    void onDisplayImgOption(QVariant);
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::RoseekService::sendImageToQml, QmlVideoDisplay::displayVideo);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::sendImagePainter, QmlVideoDisplay::recvImagePainter);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, QmlVideoDisplay::onDisplayImgOption);
    TASK_LIST_END
  private:
    const QString cameraName = "roseek";
    _Kits::ImagePainter *m_imagePainter = nullptr;
    bool m_isDisplay = true;
    bool m_firstFPS = true;
};
} // namespace _Controllers