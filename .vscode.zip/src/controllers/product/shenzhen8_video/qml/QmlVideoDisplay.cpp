
#include "QmlVideoDisplay.h"
#include "kits/utility/log/CRossLogger.h"
#include <QVariantMap>
#include <QVariant>
#include <QImage>
#include "kits/qtcommon/jsontomap/QmlJsonToMap.h"
namespace _Controllers {
using namespace _Service;
using namespace _Kits;

void QmlVideoDisplay::recvImagePainter(QVariant data)
{
    _Kits::ImagePainter *ImagePainter = data.value<_Kits::ImagePainter *>();
    QString camera_name = ImagePainter->getObjectName();
    if (camera_name != cameraName)
    {
        return;
    }
    m_imagePainter = ImagePainter;
    LogInfo("QmlVideoDisplay {}", camera_name.toStdString());
}
void QmlVideoDisplay::displayVideo(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    if (img == nullptr || !m_isDisplay)
    {
        return;
    }
    if (m_firstFPS)
    {
        m_isDisplay = false;
    }
    QImage img_temp(img->data.data(), img->width, img->height, QImage::Format_RGB888);
    img_temp = img_temp.rgbSwapped();
    if (nullptr != m_imagePainter)
    {
        m_imagePainter->setImage(img_temp);
    }
}

void QmlVideoDisplay::onDisplayImgOption(QVariant data)
{
    QVariantMap map = QmlJsonToMap::convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    QString type = map.value("type").toString();
    if (type == "isDisplay" && camera_name == cameraName)
    {
        m_firstFPS = false;
        bool isDisplay = map.value("state").toBool();
        m_isDisplay = isDisplay;
    }
    else
    {
        return;
    }
}
} // namespace _Controllers