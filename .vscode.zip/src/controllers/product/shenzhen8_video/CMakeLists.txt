
set(CTL_NAME "shenzhen8_video")
message("---------- Building ${CTL_NAME}  ----------")

file(GLOB_RECURSE CURRENT_SRC ${CMAKE_CURRENT_SOURCE_DIR}/*.cpp 
                          ${CMAKE_CURRENT_SOURCE_DIR}/*.h)

add_library(${CTL_NAME} OBJECT ${CURRENT_SRC})
target_sources(${CTL_NAME} PUBLIC 
$<TARGET_OBJECTS:kit_asio_tcp_client>
$<TARGET_OBJECTS:kit_remote_message_parser>
$<TARGET_OBJECTS:kit_roseek_camera_base>
$<TARGET_OBJECTS:kit_subtitle_general>
$<TARGET_OBJECTS:kit_video_manage>
)       

find_package(TBB CONFIG REQUIRED)
target_link_libraries(${CTL_NAME} PRIVATE TBB::tbb)

target_link_libraries(${CTL_NAME} PUBLIC 
shared_dependencies 
kit_log
kit_asio_tcp_client
kit_remote_message_parser
kit_roseek_camera_base
kit_subtitle_general
kit_video_manage
)


target_sources(${LIB_CONTROLLERS} PUBLIC 
$<TARGET_OBJECTS:${CTL_NAME}>
)     
target_link_libraries(${LIB_CONTROLLERS} PUBLIC ${CTL_NAME})

find_package(OpenCV REQUIRED COMPONENTS core imgproc highgui)
target_link_libraries(${CTL_NAME} PUBLIC ${OpenCV_LIBS})
target_include_directories(${CTL_NAME} PUBLIC
    ${OpenCV_INCLUDE_DIRS}
)  



# 用于选择加载的资源和界面文件 begin
set(RES_QML
    res/qml/roseek_video_qml/main.qml
    res/qml/roseek_video_qml/CustomTitleBar.qml
    res/qml/roseek_video_qml/Modules.qml
    res/qml/roseek_video_qml/VideoDisplay.qml
    res/qml/roseek_video_qml/egv_video_page.qml
)


file(GLOB_RECURSE RES_FILES RELATIVE ${CMAKE_SOURCE_DIR}/ ${CMAKE_SOURCE_DIR}/res/icon/*)