#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include <asio/awaitable.hpp>
#include <cstdint>
#include "tis_global/Struct.h"
#include <thread>
#include <atomic>
#include <mutex>
#include "kits/product_kits/video_manage/VideoManage.h"
#include "kits/third_devices/roseek_kits/RoseekLiveStreamer.h"
#include "kits/third_devices/roseek_kits/RoseekNormalCamera.h"
#include "kits/product_kits/subtitle_general/SubtitleGeneral.h"
#include "kits/utility/object_pool/ObjectPool.h"
#include <mutex>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoController : public ControllerBase<VideoController>
{

  public:
    VideoController();
    ~VideoController();

    void recvRoseekImageptr(std::shared_ptr<_Kits::RoseekNormalCamera>);
    void onInitEncodeVideoInfo(const std::unordered_map<std::string, TIS_Info::EncoderInfo> &);

    void onTaskBegin(const TIS_Info::RemoteMessage &);
    void onTaskEnd(const TIS_Info::RemoteMessage &);
    void onGetLocation(const TIS_Info::RemoteMessage &);
    void onPressSpotInfo(const TIS_Info::RemoteMessage &);
    void onVolElecInfo(const TIS_Info::RemoteMessage &);
    void onJiheInfo(const TIS_Info::RemoteMessage &);

        TASK_LIST_BEGIN
        SYNC_TASK_ADD(TIS_Info::RoseekService::sendRoseekNormalptr, VideoController::recvRoseekImageptr);
        ASYNC_TASK_ADD(TIS_Info::VideoEncoderService::initVideoEncoderInfo, VideoController::onInitEncodeVideoInfo);
        
        REMOTE_TASK_ADD(TIS_Info::TaskService::taskBegin, VideoController::onTaskBegin);
        REMOTE_TASK_ADD(TIS_Info::TaskService::taskEnd, VideoController::onTaskEnd);
        REMOTE_TASK_ADD(TIS_Info::LocationService::LocationRadio, VideoController::onGetLocation);
        REMOTE_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendPressSpotOut, VideoController::onPressSpotInfo);
        REMOTE_TASK_ADD(TIS_Info::PressSpotVolElecEtcData::sendVolElecOut, VideoController::onVolElecInfo);
        REMOTE_TASK_ADD(TIS_Info::JiHeService::Broadcast, VideoController::onJiheInfo);
        TASK_LIST_END

  private:
    void dealImageBufferFunc();
    void handleTaskBegin(const TIS_Info::TaskInfo &task_info);
    void handleTaskEnd(const TIS_Info::TaskInfo &task_info);
    void onStartRecord(const std::string &savePath);
    void onStopRecord();
    std::shared_ptr<TIS_Info::ImageBuffer> graytoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p);
    std::string generateVideoName(const std::string &strStationName);
    void sendToQmlThread();
    void createVideoManage(const std::string &name);
    void startGrabFrame(std::shared_ptr<_Kits::RoseekNormalCamera> &roseekNormalCamera);

  private:
    std::unique_ptr<_Kits::SubtitleGeneral> m_subtitleGeneral = nullptr;
    TIS_Info::TaskInfo m_taskInfo;
    std::string m_currentStationName{""};
    ;
    std::mutex m_mutex;
    std::mutex m_createMutex;
    std::unordered_map<std::string, std::shared_ptr<_Kits::VideoManage>> m_videoManageMap;
    std::unordered_map<std::string, TIS_Info::EncoderInfo> m_encoderInfoMap;
    std::thread m_uiRenderThread;
    std::atomic_bool m_isRunning{false};
    tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>> m_imageBufferQueue;
    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> m_ImageBufferPools;
    std::string m_subtitleText = "";
};
} // namespace _Controllers
