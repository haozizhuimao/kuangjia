#include "VideoController.h"
#include "kits/primary/io_manager/io_manager.h"
#include "service/AppInterface.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/utility/datetime/datetime.h"
#include "kits/product_kits/remote_message_parser/RemoteParser.h"
#include "kits/utility/system_config/SystemConfig.h"
#include <format>
// #include <QFontDatabase>
// #include <opencv2/opencv.hpp>
#include <QImage>
#include <QPainter>
#ifdef _WIN32
#pragma comment(lib, "mpr.lib")
#endif

namespace _Controllers {
using namespace _Service;
using namespace _Kits;
VideoController::VideoController()
{
    m_ImageBufferPools = std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>(30);
    m_isRunning.store(true);
    m_subtitleGeneral = std::make_unique<_Kits::SubtitleGeneral>();
    m_uiRenderThread = std::thread(&VideoController::sendToQmlThread, this);
}

VideoController::~VideoController()
{
    onStopRecord();
    m_isRunning.store(false);
    m_imageBufferQueue.stop();  
    if (m_uiRenderThread.joinable())
    {
        m_uiRenderThread.join();
    }
}

void VideoController::onInitEncodeVideoInfo(const std::unordered_map<std::string, TIS_Info::EncoderInfo> &encoderInfomap)
{
    for (auto &[name, encoderInfo] : encoderInfomap)
    {
        createVideoManage(name);
        if (0 != encoderInfo.width && 0 != encoderInfo.height)
        {
            m_videoManageMap[name]->init(encoderInfo, encoderInfo.subtitleInputInfo);
        }
    }
}

void VideoController::recvRoseekImageptr(std::shared_ptr<_Kits::RoseekNormalCamera> roseekNormalCamera)
{
    createVideoManage("roseek");
    m_subtitleGeneral->setSendSubtitleCallback([this](const std::vector<std::string> &subtitleData) {
        if (nullptr != m_videoManageMap["roseek"])
        {
            std::string subtitle = "";
            for (auto it = subtitleData.begin(); it != subtitleData.end(); ++it)
            {
                subtitle += *it;
                if (std::next(it) != subtitleData.end())
                {
                    subtitle += "\n";
                }
            }
            m_subtitleText = subtitle;
            m_videoManageMap["roseek"]->updateSubtitles(subtitle);
        }
    });

    startGrabFrame(roseekNormalCamera);
}
void VideoController::startGrabFrame(std::shared_ptr<_Kits::RoseekNormalCamera> &roseekNormalCamera)
{
    auto ret = roseekNormalCamera->startGrab([this](std::shared_ptr<TIS_Info::ImageBuffer> imageBuffer) {
        if (nullptr == imageBuffer)
        {
            return;
        }
        auto it = m_encoderInfoMap.find("roseek");
        if (it == m_encoderInfoMap.end())
        {
            TIS_Info::EncoderInfo encoderInfo;
            encoderInfo.width = imageBuffer->width;
            encoderInfo.height = imageBuffer->height;
            m_encoderInfoMap["roseek"] = encoderInfo;
            if (nullptr != m_videoManageMap["roseek"])
            {
                m_videoManageMap["roseek"]->init(encoderInfo, encoderInfo.subtitleInputInfo);
            }
        }
        else
        {
            if (0 == it->second.width || 0 == it->second.height)
            {
                it->second.width = imageBuffer->width;
                it->second.height = imageBuffer->height;

                if (nullptr != m_videoManageMap["roseek"])
                {
                    m_videoManageMap["roseek"]->init(it->second, it->second.subtitleInputInfo);
                }
            }
        }

        imageBuffer->name = "roseek";
        imageBuffer->pixFormat = 8;
        if (nullptr != m_videoManageMap["roseek"])
        {
            m_videoManageMap["roseek"]->pushImage(imageBuffer);
        }
        m_imageBufferQueue.pushItemNoBlocking(imageBuffer);
    });
    if (0 != ret)
    {
        LogError("RoseekNormalCamera startGrab failed:{}", ret);
    }
}
void VideoController::onTaskBegin(const TIS_Info::RemoteMessage &msg)
{
    auto task_info = RemoteParser::parseTaskBeginMessage(msg);
    handleTaskBegin(task_info);
}
void VideoController::onTaskEnd(const TIS_Info::RemoteMessage &msg)
{
    auto task_info = RemoteParser::parseTaskEndMessage(msg);
    handleTaskEnd(task_info);
}
void VideoController::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    LogInfo("VideoController::handleTaskBegin: Task start");
    std::filesystem::path mappath = std::filesystem::u8path(SystemConfig::mapoutpath());
    wchar_t unc_buffer[MAX_PATH] = {0};
    DWORD buffer_size = MAX_PATH;
    std::wstring drive = std::wstring(1, SystemConfig::mapoutpath().at(0)) + L":";
    WNetGetConnectionW(drive.c_str(), unc_buffer, &buffer_size);
    std::filesystem::path rootpath = std::filesystem::path(unc_buffer);

    std::lock_guard<std::mutex> lock(m_mutex);
    auto strDateTime = _Kits::datetime::current_string("%Y%m%d");
    rootpath /= strDateTime;
    rootpath /= task_info.strTaskName;
    for (auto &[name, videomanageptr] : m_videoManageMap)
    {
        LogInfo("VideoController::setVideoSaveRootPath:{} ", rootpath.string());
        videomanageptr->setVideoSaveRootPath(rootpath.string());
    }
    // LogInfo("task_info:{} {}",task_info.strTaskSavePath,task_info.strTaskName);

    m_taskInfo = task_info;
    m_currentStationName = "";
}
void VideoController::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    LogInfo("VideoController:: End: Task end");
    std::lock_guard<std::mutex> lock(m_mutex);
    m_taskInfo = task_info;
    // 停止所有录像
    onStopRecord();
}
void VideoController::onStartRecord(const std::string &savePath)
{
    for (auto &videoManage : m_videoManageMap)
    {
        videoManage.second->updataVideoName(savePath);
    }
}
void VideoController::onStopRecord()
{
    for (auto &videoManage : m_videoManageMap)
    {
        videoManage.second->updataVideoName("");
    }
}
void VideoController::onGetLocation(const TIS_Info::RemoteMessage &msg)
{
    if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
    {
        return;
    }

    TIS_Info::LocationData loactionData;
    if (!_Kits::RemoteParser::parseLocationInfo(msg, loactionData))
    {
        _Kits::LogWarn("Failed to parse location info");
        return;
    }

    if (m_currentStationName != loactionData.station_name && !loactionData.station_name.empty())
    {
        auto videoName = generateVideoName(loactionData.station_name);
        onStartRecord(videoName);
    }

    m_currentStationName = loactionData.station_name;
    if (nullptr != m_subtitleGeneral)
    {
        m_subtitleGeneral->updateLocationData(loactionData);
    }
    // _m_locationCtrl->updateLocation(stationName);
}
void VideoController::onPressSpotInfo(const TIS_Info::RemoteMessage &msg)
{
    std::unordered_map<std::string, std::string> result;
    double press = 0;
    double spot = 0;
    if (_Kits::RemoteParser::parsePressSpotInfo(msg, press, spot))
    {
        TIS_Info::PressAndSpot pressSpotInfo;
        if (8000 != press)
        {
            pressSpotInfo.md_press0 = press;
        }
        if (8000 != spot)
        {
            pressSpotInfo.md_spot0x = spot;
        }
        if (nullptr != m_subtitleGeneral)
        {
            m_subtitleGeneral->updatePressAndSpot(pressSpotInfo);
        }
    }
}
void VideoController::onVolElecInfo(const TIS_Info::RemoteMessage &msg)
{
    std::unordered_map<std::string, std::string> result;
    double voltage = 0;
    double elec = 0;
    if (_Kits::RemoteParser::parseVolElecInfo(msg, voltage, elec))
    {
        TIS_Info::VoltageAndElectric voltageAndElectric;
        if (8000 != voltage)
        {
            voltageAndElectric.md_voltage0 = voltage;
        }
        if (8000 != elec)
        {
            voltageAndElectric.md_electric0 = elec;
        }
        if (nullptr != m_subtitleGeneral)
        {
            m_subtitleGeneral->updateVoltageAndElectric(voltageAndElectric);
        }
    }
}
void VideoController::onJiheInfo(const TIS_Info::RemoteMessage &msg)
{
    double zig = 0;
    double hei = 0;
    if (_Kits::RemoteParser::parseJiheInfo(msg, zig, hei))
    {
        TIS_Info::JiHeData jiheData;
        jiheData.fZig[0] = zig;
        jiheData.fHei[0] = hei;
        if (nullptr != m_subtitleGeneral)
        {
            m_subtitleGeneral->updateJiHeData(jiheData);
        }
    }
}
std::string VideoController::generateVideoName(const std::string &strStationName)
{
    std::string strVideoName = "";
    if (!strStationName.empty())
    {
        strVideoName += strStationName;
        strVideoName += "_";
        strVideoName += datetime::current_string("%Y_%m_%d_%H_%M");
    }
    else
    {
        strVideoName += datetime::current_string("%Y_%m_%d_%H_%M");
    }
    strVideoName += ".mp4";
    LogInfo("liveVideoName:{}", strVideoName);
    return strVideoName;
}
void VideoController::createVideoManage(const std::string &name)
{
    std::lock_guard<std::mutex> lock(m_createMutex);
    auto videoManageObject = m_videoManageMap.find(name);
    if (videoManageObject == m_videoManageMap.end())
    {
        m_videoManageMap.insert(std::make_pair(name, std::make_shared<VideoManage>(name)));
        m_videoManageMap[name]->start();
    }
}
std::shared_ptr<TIS_Info::ImageBuffer> VideoController::graytoRGB(std::shared_ptr<TIS_Info::ImageBuffer> imgdata)
{
    if (nullptr == imgdata || imgdata->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto img_rgb = m_ImageBufferPools->getObject(imgdata->width, imgdata->height, 3);
    // QImage rgbImage(imgdata->width, imgdata->height, QImage::Format_RGB888);
    // for (int y = 0; y < imgdata->height; ++y) 
    // {
    //     const uchar* grayLine = imgdata->data.data() + y * imgdata->width;
    //     uchar* rgbLine = rgbImage.scanLine(y);
        
    //     for (int x = 0; x < imgdata->width; ++x) {
    //         uchar gray = grayLine[x];
    //         rgbLine[x * 3 + 0] = gray;  // R
    //         rgbLine[x * 3 + 1] = gray;  // G
    //         rgbLine[x * 3 + 2] = gray;  // B
    //     }
    // }
     QImage rgbImage = QImage(imgdata->data.data(), imgdata->width, imgdata->height, QImage::Format_Grayscale8);
    // QImage rgbImage = image.convertToFormat(QImage::Format_RGB888);
    auto it = m_encoderInfoMap.find(imgdata->name);
    if (it != m_encoderInfoMap.end())
    {
        // int fontId = QFontDatabase::addApplicationFont(QString::fromStdString(it->second.subtitleInputInfo.fontfile));
        // QString fontFamily = QFontDatabase::applicationFontFamilies(fontId).first();
        QPainter painter(&rgbImage);
        QFont font(QString::fromStdString(it->second.subtitleInputInfo.fontfile), it->second.subtitleInputInfo.fontsize); // 设置字体和大小
        painter.setFont(font);
        QColor color(QString::fromStdString(it->second.subtitleInputInfo.fontcolor));
        painter.setPen(color);
        QRect textRect(it->second.subtitleInputInfo.posx,
                       it->second.subtitleInputInfo.posy,
                       rgbImage.width() - 100,
                       rgbImage.height() - 100); // 定义绘制区域
        painter.drawText(textRect, QString::fromStdString(m_subtitleText));
    }

    std::copy(rgbImage.bits(), rgbImage.bits() + rgbImage.byteCount(), img_rgb->data.begin());

    return img_rgb;
}
void VideoController::sendToQmlThread()
{
    while (m_isRunning)
    {
       auto imagebuffer =  m_imageBufferQueue.popItem();
        if (std::nullopt != imagebuffer)
        {
            if ((*imagebuffer)->pixFormat == 8)
            {
                auto resultrgb = graytoRGB(*imagebuffer);
                senderRoseekServicesendImageToQml(resultrgb);
            }
        }
    }
}

} // namespace _Controllers
