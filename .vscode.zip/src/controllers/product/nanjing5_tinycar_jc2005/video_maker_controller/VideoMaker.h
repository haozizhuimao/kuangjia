#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/third_devices/save_video_by_ffmpeg/SaveVideo.h"

#include <mutex>
#include <json/json.h>
#include <mutex>

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#include <tbb/concurrent_unordered_map.h>
#endif // emit
#endif // Q_MOC_RUN

#include "kits/camera/tools/LocationCtrl.h"
#include "kits/camera/hik/base/HikBase.h"
#include "kits/camera/usb/base/UsbCameraBase.h"

#ifndef DWORD
#define DWORD unsigned long
#endif

#ifndef BYTE
#define BYTE unsigned char
#endif

namespace _Controllers {
class VideoMaker : public ControllerBase<VideoMaker>
{
  public:
    VideoMaker();
    ~VideoMaker();
    void onStopVideoMaker();
    void onStartRecord(QString);
    void onStopRecord();

    /// @brief 单个相机录像
    /// @param camera_name 相机名
    /// @param file_name 录像名
    void onStartRecordOneCame(QString, QString);
    /// @brief 单个相机录像结束
    /// @param camera_name 相机名
    void onStopRecordOneCame(QString);
    /// @brief 录像结束，用于QML触发录像结束
    /// @param camera_name 相机名
    /// @param ischeck 录像开启或结束
    void onQmlRecordSignal(QVariant);

    /// @brief 用作初始化录像kit，由模块触发
    /// @param cameraMap(std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>> &&) 录像kit的名称列表
    /// @param cameraInfo(std::vector<TIS_Info::HikLogInfo> &&) 相机信息
    /// @return void
    /// @note 这个函数会在录像kit初始化时调用，通常在录像开始前调用一次即可
    void onInitHikSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>>,
                            std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>>);
    void onInitUsbSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::UsbCameraBase>>>,
                            std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>>);

    void onDisplayImgOption(QVariant);

    void SetExposureTimeAndGain(QVariant);
    void PTZControl(QVariant);
    void SetPTZSpeed(QVariant);

    void onGetLocation(const TIS_Info::LocationData &);
    void onTaskBegin(const TIS_Info::TaskInfo &);
    void onTaskEnd(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    // 初始化和释放
    SYNC_TASK_ADD(TIS_Info::HikManager::initVideoCtrl, VideoMaker::onInitHikSaveVideo);
    SYNC_TASK_ADD(TIS_Info::UsbCameraManager::initVideoCtrl, VideoMaker::onInitUsbSaveVideo);
    SYNC_TASK_ADD(TIS_Info::HikManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);
    SYNC_TASK_ADD(TIS_Info::UsbCameraManager::stopVideoCtrl, VideoMaker::onStopVideoMaker);

    // 数据接收
    ASYNC_TASK_ADD(TIS_Info::OldTask::sendOldTaskBegin, VideoMaker::onTaskBegin);
    ASYNC_TASK_ADD(TIS_Info::OldTask::sendOldTaskEnd, VideoMaker::onTaskEnd);
    ASYNC_TASK_ADD(TIS_Info::OldLocation::sendPositionOut, VideoMaker::onGetLocation);

    // qml行为
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetExposureTimeAndGain);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::PTZControl);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::SetPTZSpeed);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::VideoRecordButton, VideoMaker::onQmlRecordSignal);
    QML_ADD(TIS_Info::QmlCommunication::QmlActions::ParameterModification, VideoMaker::onDisplayImgOption);
    TASK_LIST_END

  private:
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueue;
    std::unordered_map<std::string, std::unique_ptr<_Kits::SaveVideoNew::SaveVideo>> _mmap_saveVideo;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForProcess;
    tbb::concurrent_unordered_map<std::string, tbb::concurrent_queue<std::shared_ptr<TIS_Info::ImageBuffer>>> _mmap_imgQueueForQml;
    std::unordered_map<std::string, bool> _mmap_isDisplay;

    std::thread _m_thread_saveVideo;
    std::atomic_bool _mb_SaveVideo;
    std::atomic_bool _mb_stop;

    std::thread _m_thread_processImage;
    std::thread _m_thread_sendToQml;

    std::thread _m_thread_sendTitle;

    QString _mqstr_SavePath; // 保存路径

    std::shared_ptr<_Kits::ObjectPool<TIS_Info::ImageBuffer>> _m_ImageBufferPools;

    // 使用自定义结构体替代concurrent_unordered_map，提高高频更新场景下的性能
    struct LocationInfo
    {
        QString station_name;
        QString pole_name;
        double mileage_adjust = 0.0;
        double speed = 0.0;
        int line_direction;
    };

    std::mutex m_mutex_title;
    LocationInfo _m_locationInfo;     // 直接存储位置信息，不再使用map
    LocationInfo _m_lastLocationInfo; // 上一次的位置信息
    std::vector<QString> m_vec_subtitle;

    std::unique_ptr<_Kits::LocationCtrl> _m_locationCtrl;

    TIS_Info::TaskInfo _m_task_info;
    std::mutex m_mutex;

    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>> m_udm_camHik;
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>> m_udm_camHikInfo;

    std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::UsbCameraBase>>> m_udm_camUsb;
    std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> m_udm_camUsbInfo;

  private:
    void saveVideoThread();
    void processImageThread();
    void sendToQmlThread();
    void sendTitleThread();
    void startAllThread();
    void stopAllThread();
    void processImgFirst(std::shared_ptr<TIS_Info::ImageBuffer> img);
    void drawFront(std::shared_ptr<TIS_Info::ImageBuffer> img);

    QVariantMap convertDataToJsonOrMap(const QVariant &);

    std::shared_ptr<TIS_Info::ImageBuffer> YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yv12);
    void handleTaskBegin(const TIS_Info::TaskInfo &task_info);
    void handleTaskEnd(const TIS_Info::TaskInfo &task_info);
    bool createDirectory(const QString &dirPath);
};
} // namespace _Controllers