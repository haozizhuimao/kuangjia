#include "VideoMaker.h"
#include "service/AppInterface.h"
#include <QVariant>
#include "kits/utility/log/CRossLogger.h"
#include <QJsonValue>
#include <opencv2/opencv.hpp>
#include <QDir>
#include "tis_global/enum_public/video_enum.h"
#include "kits/utility/serialization/serialize_jsoncpp.h"
#include "kits/camera/tools/RemoteParser.h"
#include <QVariantMap>
#include <QImage>
#include <QPainter>
#include <QFont>
#include <QJsonDocument>
#include <QJsonObject>

namespace _Controllers {
using namespace _Service;

_Controllers::VideoMaker::VideoMaker()
    : _m_ImageBufferPools(std::make_shared<_Kits::ObjectPool<TIS_Info::ImageBuffer>>()),
      _m_locationCtrl(std::make_unique<_Kits::LocationCtrl>([this](QString file_name) { this->onStartRecord(file_name); })),
      _m_task_info({}), _mb_SaveVideo(true), _mqstr_SavePath({"d:/gwkj/video_Notask"}), _m_thread_saveVideo{}, _m_thread_sendToQml{},
      _m_thread_processImage{}, _m_thread_sendTitle{}
{}

_Controllers::VideoMaker::~VideoMaker()
{
    onStopVideoMaker();
}

void VideoMaker::onStopVideoMaker()
{
    if (!_mb_SaveVideo.load(std::memory_order_acquire))
    {
        return;
    }

    _mb_SaveVideo.store(false);

    onStopRecord();
    for (auto &[name, cam] : (*m_udm_camHik))
    {
        cam->closeCamera();
    }
    for (auto &[name, cam] : (*m_udm_camUsb))
    {
        cam->closeCamera();
    }

    stopAllThread();

    _m_locationCtrl->stop();
}

// 辅助函数：创建目录
bool VideoMaker::createDirectory(const QString &dirPath)
{
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            _Kits::LogError("Failed to create directory: {}", dirPath.toStdString());
            return false;
        }
    }
    return true;
}

void _Controllers::VideoMaker::saveVideoThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueue)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> yuv420p;
            while (queue.try_pop(yuv420p))
            {
                if (!yuv420p)
                    continue;

                // 查找对应的保存器
                auto it = _mmap_saveVideo.find(name);
                if (it != _mmap_saveVideo.end())
                {
                    it->second->pushOriginalImage(yuv420p);
                }
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::onStartRecord(QString fileName)
{
    QString dirPath, filePath;
    std::vector<std::pair<QString, QString>> savePaths;

    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        // 构建完整路径
        dirPath = _mqstr_SavePath + "/" + QString::fromStdString(name);
        filePath = dirPath + "/" + fileName + ".mp4";

        // 创建目录结构
        if (!createDirectory(dirPath))
        {
            continue; // 跳过当前摄像头
        }

        // 开始录像
        saveVideo->startRecord(filePath);
        savePaths.push_back({QString::fromStdString(name), dirPath});
    }

    // 批量发送保存路径
    for (const auto &[name, path] : savePaths)
    {
        senderHikManagersendSavePathOut(name, path);
    }
    senderHikManagersendRecordState(true);
}

void _Controllers::VideoMaker::onStopRecord()
{
    for (const auto &[name, saveVideo] : _mmap_saveVideo)
    {
        saveVideo->stopRecord();
    }
    senderHikManagersendRecordState(false);
}

void VideoMaker::onInitHikSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::HikBase>>> cameraMap,
                                    std::shared_ptr<std::unordered_map<std::string, TIS_Info::HikLogInfo>> cameraInfo)
{
    m_udm_camHik = cameraMap;
    m_udm_camHikInfo = cameraInfo;

    for (const auto &[name, info] : (*m_udm_camHikInfo))
    {
        if (_mmap_saveVideo.find(info.mstr_deviceName) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[info.mstr_deviceName] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[info.mstr_deviceName]->initSaveVideo(1); // 初始化录像kit
        }

        if (_mmap_isDisplay.find(info.mstr_deviceName) == _mmap_isDisplay.end())
        {
            _mmap_isDisplay[info.mstr_deviceName] = true;
        }
    }

    for (const auto &[name, cam] : (*m_udm_camHik))
    {
        cam->setSendImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) { processImgFirst(img); });
    }

    startAllThread();

    _Kits::LogInfo("VideoMaker Hik Part initialized successfully.");
}

void VideoMaker::onInitUsbSaveVideo(std::shared_ptr<std::unordered_map<std::string, std::unique_ptr<_Kits::UsbCameraBase>>> cameraMap,
                                    std::shared_ptr<std::unordered_map<std::string, TIS_Info::CameraInfo>> cameraInfo)
{
    m_udm_camUsb = cameraMap;
    m_udm_camUsbInfo = cameraInfo;

    for (const auto &[cameraId, info] : (*m_udm_camUsbInfo))
    {
        if (_mmap_saveVideo.find(info.m_deviceName) == _mmap_saveVideo.end())
        {
            _mmap_saveVideo[info.m_deviceName] = std::make_unique<_Kits::SaveVideoNew::SaveVideo>();
            _mmap_saveVideo[info.m_deviceName]->initSaveVideo(1); // 初始化录像kit
        }

        if (_mmap_isDisplay.find(info.m_deviceName) == _mmap_isDisplay.end())
        {
            _mmap_isDisplay[info.m_deviceName] = true;
        }
    }

    for (const auto &[name, cam] : (*m_udm_camUsb))
    {
        cam->setImageCallback([this](std::shared_ptr<TIS_Info::ImageBuffer> img) { processImgFirst(img); });
    }

    startAllThread();

    _Kits::LogInfo("VideoMaker initialized successfully.");
}

void VideoMaker::processImgFirst(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    if (!img)
        return;

    static uint32_t count = 0;

    if (count++ % 500 == 0)
        _Kits::LogInfo("Receive image:{}", img->name);

    _mmap_imgQueueForProcess[img->name].push(img);
}

void _Controllers::VideoMaker::processImageThread()
{
    static int i = 0;

    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForProcess)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img)
                    continue;

                /* 处理图像 */
                drawFront(img);

                /* 发送图像 */
                if (_mmap_isDisplay[name])
                {
                    _mmap_imgQueueForQml[name].push(img);
                }

                _mmap_imgQueue[name].push(img);
            }
        }

        // 添加适当的休眠以避免忙等待
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::sendToQmlThread()
{
    while (_mb_SaveVideo.load())
    {
        // 无锁遍历所有队列
        for (auto &kv : _mmap_imgQueueForQml)
        {
            const std::string &name = kv.first;
            auto &queue = kv.second;

            // 无锁处理队列中的所有图像
            std::shared_ptr<TIS_Info::ImageBuffer> img;
            while (queue.try_pop(img))
            {
                if (!img || queue.unsafe_size() > 5)
                    continue;

                if (img->pixFormat == (int)TIS_Info::AVPixelFormat::AV_PIX_FMT_YUV420P)
                {
                    img = YUV420ptoRGB(img);
                }

                if (img->camera_type == (int)TIS_Info::CameraType::CameraType_HIK)
                {
                    senderHikManagersendImageToQml(img);
                }
                else if (img->camera_type == (int)TIS_Info::CameraType::CameraType_USB)
                {
                    senderUsbCameraManagersendImageToQml(img);
                }
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    }
}

void _Controllers::VideoMaker::SetExposureTimeAndGain(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD exposureTime = static_cast<DWORD>(dataMap.value("exposure").toUInt());
    BYTE gainValue = static_cast<BYTE>(dataMap.value("gain").toUInt());
    QString type = dataMap.value("type").toString();

    if (type == "setExposureAndGain")
    {
        auto it = m_udm_camHik->find(cameraName);
        if (it != m_udm_camHik->end())
        {
            it->second->onSetExposureTimeAndGain(exposureTime, gainValue);
        }
    }
}

void _Controllers::VideoMaker::PTZControl(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    QString dir = dataMap.value("dir").toString();
    QString command = dataMap.value("command").toString();
    QString type = dataMap.value("type").toString();
    if (type == "PTZControl")
    {
        auto it = m_udm_camHik->find(cameraName);
        if (it != m_udm_camHik->end())
        {
            it->second->onPTZControl(dir, command);
        }
    }
}

void _Controllers::VideoMaker::SetPTZSpeed(QVariant data)
{
    auto dataMap = convertDataToJsonOrMap(data);

    std::string cameraName = dataMap.value("camera_name").toString().toStdString();
    DWORD speed = static_cast<DWORD>(dataMap.value("speed").toUInt());
    QString type = dataMap.value("type").toString();
    if (type == "SetPTZSpeed")
    {
        auto it = m_udm_camHik->find(cameraName);
        if (it != m_udm_camHik->end())
        {
            it->second->onSetPTZSpeed(speed);
        }
    }
}

QVariantMap _Controllers::VideoMaker::convertDataToJsonOrMap(const QVariant &data)
{
    // 前端发来的是 JSON 字符串
    if (!data.canConvert<QString>())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: data is not a string");
        return {};
    }

    QString json = data.toString();
    QJsonDocument doc = QJsonDocument::fromJson(json.toUtf8());
    if (!doc.isObject())
    {
        _Kits::LogWarn("convertDataToJsonOrMap: invalid JSON object");
        return {};
    }

    return doc.object().toVariantMap();
}

void _Controllers::VideoMaker::sendTitleThread()
{
    std::vector<QString> subtitles;
    subtitles.reserve(16);

    std::vector<QString> empty_subtitle = {""};

    while (_mb_SaveVideo.load())
    {
        if (_m_task_info.nTaskstate == TIS_Info::TASK_STOPPED || _m_task_info.nTaskstate == TIS_Info::TASK_NONE)
        {
            for (const auto &name_cam : (*m_udm_camHik))
            {
                name_cam.second->onWriteSubTitle(empty_subtitle);
            }
            m_vec_subtitle = empty_subtitle;
        }
        else if (_m_task_info.nTaskstate == TIS_Info::TASK_RUNNING || _m_task_info.nTaskstate == TIS_Info::TASK_START)
        {
            // 直接访问结构体字段，避免map查找开销
            {
                std::lock_guard<std::mutex> lock(m_mutex_title);
                _m_lastLocationInfo = _m_locationInfo;
            }

            if (!_m_lastLocationInfo.station_name.isEmpty())
            {
                subtitles.push_back("站区名:" + _m_lastLocationInfo.station_name);
            }

            if (!_m_lastLocationInfo.pole_name.isEmpty())
            {
                subtitles.push_back("杆号名:" + _m_lastLocationInfo.pole_name);
            }

            subtitles.push_back("公里标:" + QString::number(_m_lastLocationInfo.mileage_adjust / 1000 / 1000, 'f', 3));
            subtitles.push_back("速度:" + QString::number(_m_lastLocationInfo.speed, 'f', 3));
            subtitles.push_back("上下行:" + QString::number(_m_lastLocationInfo.line_direction));

            for (const auto &name_cam : (*m_udm_camHik))
            {
                name_cam.second->onWriteSubTitle(subtitles);
            }

            m_vec_subtitle = subtitles;
            subtitles.clear();
            std::this_thread::sleep_for(std::chrono::milliseconds(50)); // 发送一次标题
        }
    }
}

void _Controllers::VideoMaker::onQmlRecordSignal(QVariant data)
{
    QVariantMap map = convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    bool isCheck = map.value("isCheck").toBool();

    if (isCheck)
    {
        onStartRecordOneCame(camera_name, "");
    }
    else
    {
        onStopRecordOneCame(camera_name);
    }
}

void VideoMaker::onStartRecordOneCame(QString camera_name, QString file_name)
{
    if (_m_task_info.nTaskstate == TIS_Info::TASK_RUNNING || _m_task_info.nTaskstate == TIS_Info::TASK_START)
    {
        return;
    }

    QString dirPath = _mqstr_SavePath + "/" + camera_name;
    QString filePath = dirPath + "/" + file_name + ".mp4";

    // 创建目录结构
    QDir dir;
    if (!dir.exists(dirPath))
    {
        if (!dir.mkpath(dirPath))
        {
            qWarning() << "Failed to create directory:" << dirPath;
            _Kits::LogError("[HikCamera::onStartRecordOneCame] 创建文件夹失败，录像失败");
            return;
        }
    }

    _mmap_saveVideo[camera_name.toStdString()]->startRecord(filePath);
}

void VideoMaker::onStopRecordOneCame(QString camera_name)
{
    if (_m_task_info.nTaskstate == TIS_Info::TASK_RUNNING || _m_task_info.nTaskstate == TIS_Info::TASK_START)
    {
        return;
    }

    _mmap_saveVideo[camera_name.toStdString()]->stopRecord();
}

void _Controllers::VideoMaker::onDisplayImgOption(QVariant data)
{
    QVariantMap map = convertDataToJsonOrMap(data);
    QString camera_name = map.value("camera_name").toString();
    bool isDisplay = map.value("isDisplay").toBool();

    _mmap_isDisplay[camera_name.toStdString()] = isDisplay;
}

void _Controllers::VideoMaker::onGetLocation(const TIS_Info::LocationData &location_data)
{
    // 任务非启动状态时直接返回
    if (_m_task_info.nTaskstate != TIS_Info::TASK_START)
    {
        return;
    }

    {
        std::lock_guard<std::mutex> lock(m_mutex_title);
        // 直接更新结构体字段，避免map操作开销
        _m_locationInfo.station_name = location_data.station_name;
        _m_locationInfo.pole_name = location_data.pole_name;
        _m_locationInfo.mileage_adjust = location_data.mileage_adjust;
        _m_locationInfo.speed = location_data.speed; // 每2ms更新一次速度
        _m_locationInfo.line_direction = location_data.line_direction;
    }

    _m_locationCtrl->updateLocation(_m_locationInfo.station_name);
}

void _Controllers::VideoMaker::onTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    handleTaskBegin(task_info);
}

void _Controllers::VideoMaker::onTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    handleTaskEnd(task_info);
}

std::shared_ptr<TIS_Info::ImageBuffer> VideoMaker::YUV420ptoRGB(std::shared_ptr<TIS_Info::ImageBuffer> img_yuv420p)
{
    if (!img_yuv420p || img_yuv420p->data.empty())
    {
        _Kits::LogError("[VideoMaker::YUV420ptoRGB] null or empty buffer");
        return nullptr;
    }

    auto &w = img_yuv420p->width;
    auto &h = img_yuv420p->height;

    std::shared_ptr<TIS_Info::ImageBuffer> img_rgb = _m_ImageBufferPools->getObject(w, h, 3); // RGB24

    cv::Mat yuv_mat(h * 3 / 2, w, CV_8UC1, img_yuv420p->data.data());
    cv::Mat rgb_mat(h, w, CV_8UC3, img_rgb->data.data());
    cv::cvtColor(yuv_mat, rgb_mat, cv::COLOR_YUV420p2RGB);

    // 补元数据
    img_rgb->width = w;
    img_rgb->height = h;
    img_rgb->timestamp = img_yuv420p->timestamp;
    img_rgb->pixFormat = static_cast<int>(TIS_Info::AVPixelFormat::AV_PIX_FMT_RGB24);
    img_rgb->name = img_yuv420p->name;
    img_rgb->addr = img_yuv420p->addr;
    img_rgb->camera_type = img_yuv420p->camera_type;

    return img_rgb;
}

void _Controllers::VideoMaker::handleTaskBegin(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskBegin: Task start");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;
    _m_locationCtrl->updateLocation("");
    // 更新保存路径
    if (!task_info.strTaskSavePath.isEmpty())
    {
        _mqstr_SavePath = task_info.strTaskSavePath;
        createDirectory(_mqstr_SavePath);
    }
}

void _Controllers::VideoMaker::handleTaskEnd(const TIS_Info::TaskInfo &task_info)
{
    _Kits::LogInfo("VideoMaker::handleTaskEnd: Task end");

    std::lock_guard<std::mutex> lock(m_mutex);
    _m_task_info = task_info;

    // 停止所有录像
    onStopRecord();
}

void VideoMaker::startAllThread()
{
    if (!_m_thread_processImage.joinable())
    {
        _m_thread_processImage = std::thread(&VideoMaker::processImageThread, this);
    }
    if (!_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo = std::thread(&VideoMaker::saveVideoThread, this);
    }
    if (!_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml = std::thread(&VideoMaker::sendToQmlThread, this);
    }
    if (!_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle = std::thread(&VideoMaker::sendTitleThread, this);
    }
}

void VideoMaker::stopAllThread()
{
    if (_m_thread_saveVideo.joinable())
    {
        _m_thread_saveVideo.join();
    }
    if (_m_thread_processImage.joinable())
    {
        _m_thread_processImage.join();
    }
    if (_m_thread_sendToQml.joinable())
    {
        _m_thread_sendToQml.join();
    }
    if (_m_thread_sendTitle.joinable())
    {
        _m_thread_sendTitle.join();
    }
}

void VideoMaker::drawFront(std::shared_ptr<TIS_Info::ImageBuffer> img)
{
    auto subtitle = m_vec_subtitle;

    if (img->camera_type == (int)TIS_Info::CameraType::CameraType_USB && !subtitle.empty())
    {
        // 创建QImage对象（直接引用原始数据，不进行复制）
        QImage qimg(img->data.data(), img->width, img->height, QImage::Format_RGB888);

        // 创建QPainter并设置字体和颜色
        QPainter painter(&qimg);
        QFont font = painter.font();
        font.setPointSize(16); // 设置字体大小
        font.setBold(true);    // 字体加粗
        painter.setFont(font);

        // 设置文本颜色为白色，背景为半透明黑色
        painter.setPen(QColor(255, 255, 255));

        // 将向量中的所有字符串连接成一个字符串，用换行符分隔
        QString combinedSubtitle;
        for (const auto &line : subtitle)
        {
            if (!combinedSubtitle.isEmpty())
                combinedSubtitle += "\n";
            combinedSubtitle += line;
        }

        // 计算所需的高度（每行大约30像素）
        int subtitleHeight = 30 * subtitle.size();
        painter.fillRect(10, 10, qimg.width() - 20, subtitleHeight, QColor(0, 0, 0, 128));

        // 在图像左上角绘制字幕
        painter.drawText(QRect(10, 10, qimg.width() - 20, subtitleHeight), Qt::AlignLeft | Qt::AlignTop, combinedSubtitle);
    }
}
} // namespace _Controllers