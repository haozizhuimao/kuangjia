#include "RadarController.h"
#include "service/AppFramework.h"
#include "tis_global/Field.h"
#include <qimage.h>
#include <qvariant.h>
#include <sys/stat.h>
#include <QDir>
#include "kits/third_devices/radar_kit/base/DeviceData.hpp"

#include "tis_global/EnumPublic.h"
#include "service/AppInterface.h"

namespace _Controllers
{
    using namespace _Kits;

    /**
     * @file RadarController.cpp
     * @brief 雷达控制器实现文件
     *
     * 该文件实现了RadarController类的所有方法，包括构造函数、析构函数、数据处理线程、
     * 数据分析方法以及数据存储和展示相关功能。
     */

    /**
     * @brief 发送雷达设备状态到QML界面
     * @param data 状态信息字符串
     */
    void RadarController::sendState(QString data)
    {
        QString str_state = "";
        for (const auto &[index, device] : (*m_devDealMap))
        {
            if (device != nullptr)
            {
                auto state = device->GetDeviceState();
                str_state += QString("雷达设备%1状态: %2\n").arg(index).arg(state);
            }
        }

        _Service::senderRadarServicesendStateToQml(str_state);
    }

    void RadarController::onStopCtrl()
    {
        m_stop.store(true);
        if (m_dealSurfaceDataThread.joinable())
        {
            m_dealSurfaceDataThread.join();
        }

        if (m_dealNormalDataThread.joinable())
        {
            m_dealNormalDataThread.join();
        }
        if (m_dealOverrunDataThread.joinable())
        {
            m_dealOverrunDataThread.join();
        }

        if (nullptr != m_pcdWriter)
        {
            m_pcdWriter->finish();
        }
    }

    void RadarController::combineRadarData()
    {

        // --------------------test--------------------
        TIS_Info::DeviceSurfaceData device_data;
        device_data.mus_index = 0;
        device_data.mvec_data_surface.reserve(2000);
        std::generate_n(std::back_inserter(device_data.mvec_data_surface), 2000, [y = 1100.123131]() mutable {
            return TIS_Info::DeviceSingleData{static_cast<float>(1000.21231231), static_cast<float>(++y * 1.1)};
        });
        m_devDataMap[0] = std::move(device_data);

        TIS_Info::DeviceSurfaceData device_data1;
        device_data1.mus_index = 1;
        device_data1.mvec_data_surface.reserve(2000);
        std::generate_n(std::back_inserter(device_data1.mvec_data_surface), 2000, [x = 1100.123131]() mutable {
            return TIS_Info::DeviceSingleData{static_cast<float>(++x * 1.1), static_cast<float>(1000.21231231)};
        });
        m_devDataMap[1] = std::move(device_data1);
        // --------------------test--------------------

        // 基本上现在可以预见到的最大点云大小, 1024是为了符合内存存储，减少内存碎片
        auto allData = m_devAllDataPool->getObject(constexpr(1024 * 10));
        int nAll_Size = 0;
        if (!m_devDataMap.empty())
        {
            for (const auto &[index, data] : m_devDataMap)
            {
                nAll_Size += data.mvec_data_surface.size();
            }

            if (nAll_Size != allData->mvec_data_surface.size()) // 防止越界
            {
                allData->mvec_data_surface.resize(nAll_Size);
            }

            auto all_it = allData->mvec_data_surface.begin();
            {
                std::lock_guard<std::mutex> lock(m_mutex_devDataMap);
                for (const auto &[index, data] : m_devDataMap)
                {
                    if (!data.mvec_data_surface.empty())
                    {
                        try
                        {
                            all_it = std::copy(data.mvec_data_surface.begin(), data.mvec_data_surface.end(), all_it);
                        }
                        catch (std::exception &e)
                        {
                            qDebug() << "数据异常" << e.what();
                            _Kits::LogError("[RadarController::combineRadarData]雷达接收到的数据异常, 设备索引: %d", index);
                            continue;
                        }
                    }
                }
            }

            allData->mstr_createtime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");

            m_deviceSurfaceDataQueue.push(allData);
        }
    }

    void RadarController::startRadarRecord(
        std::string configPath, std::shared_ptr<std::unordered_map<unsigned short, std::unique_ptr<_Kits::DeviceDeal>>> deviceDealMap)
    {
        if (deviceDealMap != nullptr)
        {
            m_devDealMap = deviceDealMap;
        }

        m_devAllDataPool = std::make_shared<_Kits::ObjectPool<TIS_Info::DeviceSurfaceData>>(16);
        m_devSingleDataPool = std::make_shared<_Kits::ObjectPool<TIS_Info::DeviceSurfaceData>>(16);

        initRadarDev();
        readRadarConfig(configPath);

        _Kits::thread_pool::runEvery("restartRadar", uint64_t(1000 * 60), [this]() { this->restartRadar(); });  // 一分钟重启一次
        _Kits::thread_pool::runEvery("combineRadarData", uint64_t(10), [this]() { this->combineRadarData(); }); // 10ms合成一次完整帧

        m_dealNormalDataThread = std::thread(&RadarController::deviceDataNormal, this);
        m_dealOverrunDataThread = std::thread(&RadarController::deviceDataOverrun, this);
        m_dealSurfaceDataThread = std::thread(&RadarController::dealSurfaceDataThread, this);

        QString log = "RadarController::startRadarRecord(), 雷达记录开始";
        _Service::senderRadarServiceoverinfoSendQml(log);
    }

    void RadarController::restartRadar()
    {
        for (const auto &[index, device] : (*m_devDealMap))
        {
            if (device != nullptr)
            {
                if (!device->GetDeviceState())
                {
                    device->StartDetect();
                }
            }
        }
    }

    void RadarController::initRadarDev()
    {
        for (const auto &[index, device] : (*m_devDealMap))
        {
            if (device == nullptr)
            {
                continue;
            }

            device->setDataGetCallback([this, index](unsigned short device_index, TIS_Info::DeviceSurfaceData &&data) {
                auto dev_it = m_devDealMap->find(device_index);
                if (dev_it != m_devDealMap->end())
                {
                    std::lock_guard<std::mutex> lock(m_mutex_devDataMap);
                    m_devDataMap[index] = std::move(data);
                }
            });
        }
    }

    void RadarController::readRadarConfig(const std::string &configPath)
    {
        try
        {
            auto radar_config = YAML::LoadFile(configPath);
            for (const auto &overinfo : radar_config["overrun_info"])
            {
                TIS_Info::OverrunInfo overrun_info;

                overrun_info.line_info = {overinfo["line_start"].as<uint16_t>(), overinfo["line_end"].as<uint16_t>()};

                for (const auto &point_info : overinfo["point_info"])
                {
                    overrun_info.point_info.push_back({point_info["x"].as<float>(), point_info["y"].as<float>()});
                }

                m_overrunInfovec.push_back(overrun_info);
            }

            m_skew_info.distance = radar_config["skew_info"]["distance"].as<float>();
            m_skew_info.angle_1 =
                radar_config["skew_info"]["angle_1"].as<float>(); // 筛选【angle_1，angle_2】的点，判断坐标系扶正的点云数据
            m_skew_info.angle_2 = radar_config["skew_info"]["angle_2"].as<float>();
        }
        catch (const YAML::Exception &e)
        {
            std::throw_with_nested(std::runtime_error("Error loading config file: " + configPath));
        }
    }

    /**
     * @brief 接收任务信息
     * @param taskInfo 任务信息结构体
     *
     * 保存任务信息并重置线路索引。
     */
    void RadarController::recvTaskInfo(const TIS_Info::TaskInfo &taskInfo)
    {
        if (taskInfo.nTaskstate == TIS_Info::TaskState::TASK_RUNNING || taskInfo.nTaskstate == TIS_Info::TaskState::TASK_START)
        {
            {
                std::lock_guard<std::mutex> lock(m_mutex_task);
                m_taskInfo = taskInfo;
            }

            std::string log = "RadarController::recvTaskInfo(), 收到任务, id:" + std::to_string(taskInfo.nTaskID) +
                              ", filepath:" + taskInfo.strTaskSavePath.toStdString();
            _Kits::LogInfo("{}", log);
            _Service::senderRadarServiceoverinfoSendQml(QString::fromStdString(log));
            m_str_now_location.clear();
        }
        else
        {
            std::lock_guard<std::mutex> lock(m_mutex_task);
            m_taskInfo.clear();
            stopSavePcd();
        }
    }

    /**
     * @brief 发送超限配置到QML界面
     * @param data 点云数据向量
     *
     * 将超限配置点云数据转换为QML可识别的格式并发送。
     */
    void RadarController::sendOverConfig(std::vector<TIS_Info::DeviceSingleData> data)
    {
        QVariantList innerList;
        for (const auto &s : data)
        {
            QVariantMap map;
            map["x"] = s.mf_x;
            map["y"] = s.mf_y;

            innerList << map;
        }

        _Service::senderRadarServiceoverConfigSend(QVariant::fromValue(innerList));
    }

    /**
     * @brief 表面数据处理线程
     *
     * 持续从设备表面数据队列中获取数据，并调用表面数据分析方法进行处理。
     */
    void RadarController::dealSurfaceDataThread()
    {
        while (!m_stop.load())
        {
            std::shared_ptr<TIS_Info::DeviceSurfaceData> data;
            if (m_deviceSurfaceDataQueue.try_pop(data))
            {
                if (m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_NONE || m_taskInfo.nTaskstate == TIS_Info::TaskState::TASK_STOPPED)
                {
                    continue;
                }

                surfaceDataAnalysis(data);
            }
            else
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
            }
        }
    }

    /**
     * @brief 表面数据分析
     * @param obj_all 表面数据对象
     *
     * 分析雷达表面数据，提取有效点云，并进行设备偏移判断和校正。
     */
    void RadarController::surfaceDataAnalysis(std::shared_ptr<TIS_Info::DeviceSurfaceData> obj_all)
    {
        bool isChangeDevsData = false;
        float angle_offset = 0.0f;
        float origin_angle = 0.0f;

        if (nullptr == m_radarRecordSql)
        {
            m_radarRecordSql = std::make_unique<_Kits::RadarRecord>();
        }

        auto location_data = m_locationData;
        if (location_data.station_name.isEmpty())
        {
            return;
        }

        // auto obj_one = m_devSingleDataPool->getObject(600);
        // for (auto &point : obj_all->mvec_data_surface)
        // {
        //     if (m_skew_info.angle_1 == 0 && m_skew_info.angle_2 == 0)
        //     {
        //         break; // 如果角度筛选为0，直接跳过
        //     }
        //     // 以坐标原点为基准计算角度，知道点所处位置，进而筛选
        //     float angle_actual = atan2(point.mf_y, point.mf_x) * 180 / M_PI; // 计算实际角度
        //     angle_actual = fmod(angle_actual + 360.0f, 360.0f);              // 统一到0，360 范围
        //     if (m_skew_info.angle_1 < m_skew_info.angle_2)                   // 普通区间
        //     {
        //         if (angle_actual > m_skew_info.angle_1 && angle_actual < m_skew_info.angle_2)
        //         {
        //             obj_one->mvec_data_surface.push_back(point);
        //         }
        //     }
        //     else // 跨0 °区间
        //     {
        //         if (angle_actual > m_skew_info.angle_1 || angle_actual < m_skew_info.angle_2)
        //         {
        //             obj_one->mvec_data_surface.push_back(point);
        //         }
        //     }
        // }

        // 判断设备偏移回正
        // if (obj_one->mvec_data_surface.size() > 2) // 逻辑感觉上有问题，需要修改
        // {
        //     if (m_skew_info.distance != 0)
        //     {
        //         float height = m_skew_info.distance;
        //         // zzh，认为distence应该单独从配置中获取
        //         auto paralle_points = mmap_device_deal[obj_one->mus_index]->GetParallelData(obj_one->mvec_data_surface,
        //                                                                                     height); // 依据height选取雷达返回铁轨的坐标
        //         angle_offset = mmap_device_deal[obj_one->mus_index]->IsDeviceSkew(paralle_points, origin_angle);
        //         if (abs(angle_offset) > 10 && paralle_points.size() > 0) // 判断雷达返回 平行部分的数据不为空
        //         {
        //             isChangeDevsData = true;
        //             mmap_device_deal[obj_one->mus_index]->SkewDeviceData(obj_all->mvec_data_surface, angle_offset);
        //         }
        //     }
        // }

        obj_all->mstr_location_time = location_data.created_time;

        m_queueDeviceDataNormal.push(obj_all);
        m_queueDeviceDataOverrun.push(obj_all);
        sendDataToQml(obj_all);
    }

    /**
     * @brief 发送数据到QML界面
     * @param surfaceData 表面数据对象
     *
     * 周期性地将雷达表面数据转换为QML可识别的格式并发送到界面进行展示。
     */
    void RadarController::sendDataToQml(std::shared_ptr<TIS_Info::DeviceSurfaceData> surfaceData)
    {
        static uint32_t showCount = 0;
        if (0 != ++showCount % 5) // 每5帧数据才发送一次，避免界面刷新过于频繁
        {
            return;
        }

        auto points = std::make_shared<std::vector<TIS_Info::DeviceSingleData>>();
        points->insert(points->end(), surfaceData->mvec_data_surface.begin(), surfaceData->mvec_data_surface.end());

        std::vector<TIS_Info::DeviceSingleData> vec_data;
        vec_data.assign(points->begin(), points->end());

        mvec_datatoQml.push_back(vec_data);

        if (mvec_datatoQml.size() >= 5) // 累积5组数据后一次性发送
        {
            QVariantList outerList;
            for (const auto &inner : mvec_datatoQml)
            {
                QVariantList innerList;
                for (const auto &s : inner)
                {
                    QVariantMap map;
                    map["x"] = s.mf_x;
                    map["y"] = s.mf_y;
                    innerList << map;
                }
                outerList << innerList;
            }

            _Service::senderRadarServiceshowPointData(QVariant::fromValue(outerList));
            mvec_datatoQml.clear(); // 发送完成后清空缓冲区
        }
    }

    /**
     * @brief 超限数据处理线程
     *
     * 持续从超限数据队列中获取数据，进行超限检测，并记录超限信息。
     */
    void RadarController::deviceDataOverrun()
    {
        while (!m_stop.load())
        {
            if (m_taskInfo.nTaskID == -1) // 如果没有任务，则等待
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                continue;
            }

            std::shared_ptr<TIS_Info::DeviceSurfaceData> data;

            if (m_queueDeviceDataOverrun.try_pop(data))
            {
                if (data == nullptr || data->mvec_data_surface.empty())
                {
                    continue;
                }

                // // 根据线路ID查找对应的超限配置 ，如果没有找到，就使用默认配置
                // // 这个后面需要修改
                // int index = m_iIndex;

                // if (index >= m_overrunInfovec.size())
                // {
                //     index = m_overrunInfovec.size() - 1;
                // }

                // // 如果线路索引发生变化，发送新的超限配置到界面
                // if (index != m_iIndex)
                // {
                //     sendOverConfig(m_overrunInfovec[index].point_info);
                //     m_iIndex = index;
                // }

                // 进行超限检测
                if (nullptr == m_radarOverrun)
                {
                    m_radarOverrun = std::make_unique<_Kits::RadarOverrun>();
                }

                auto it_over = m_overrunInfovec.begin(); // 后面还需要调整

                auto vec_over_data = m_radarOverrun->isOverrun(data, it_over->point_info);

                // 处理超限结果
                for (auto &vec_one : vec_over_data)
                {
                    if (vec_one.empty())
                    {
                        continue;
                    }

                    auto direction = GetDirection(vec_one.back()->mus_angle_start);

                    QDateTime createTime = QDateTime::fromString(vec_one.front()->mstr_createtime, "yyyy-MM-dd HH:mm:ss.zzz");
                    QDateTime updateTime = QDateTime::fromString(vec_one.back()->mstr_updatetime, "yyyy-MM-dd HH:mm:ss.zzz");
                    int duration_ms = createTime.msecsTo(updateTime);

                    QString logInfo = QString("超限在%1区域发生, 发生时间%2, 结束时间%3, 耗时%4ms")
                                          .arg(direction)
                                          .arg(vec_one.front()->mstr_createtime)
                                          .arg(vec_one.back()->mstr_updatetime)
                                          .arg(duration_ms);

                    // 记录超限信息到数据库
                    if (nullptr == m_radarRecordSql)
                    {
                        m_radarRecordSql = std::make_unique<_Kits::RadarRecord>();
                    }
                    m_radarRecordSql->OnRecordOverrun(vec_one,
                                                      vec_one.front()->mstr_createtime,
                                                      vec_one.back()->mstr_updatetime,
                                                      vec_one.front()->mstr_location_time,
                                                      vec_one.back()->mstr_location_time,
                                                      duration_ms,
                                                      direction,
                                                      m_taskInfo.nTaskID,
                                                      vec_one.back()->mi_zSize);

                    // 发送超限信息到界面
                    _Service::senderRadarServiceoverinfoSendQml(logInfo);
                }
            }
            else
            {
                // 队列为空时休眠，避免忙等待
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
    }

    /**
     * @brief 正常数据处理线程
     *
     * 持续从正常数据队列中获取数据，并将其记录到数据库。
     */
    void RadarController::deviceDataNormal()
    {
        while (!m_stop.load())
        {
            if (m_taskInfo.nTaskID == -1)
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                continue;
            }

            std::shared_ptr<TIS_Info::DeviceSurfaceData> data;

            // 使用非阻塞方式从队列取数据
            if (m_queueDeviceDataNormal.try_pop(data))
            {
                if (data && !data->mvec_data_surface.empty())
                {
                    if (nullptr == m_radarRecordSql)
                    {
                        m_radarRecordSql = std::make_unique<_Kits::RadarRecord>();
                    }
                    // 记录雷达数据到数据库
                    // m_radarRecordSql->OnRecordRadar(data, data->mstr_createtime, data->mstr_createtime, m_taskInfo.nTaskID, 0);

                    if (nullptr == m_pcdWriter)
                    {
                        m_pcdWriter = std::make_unique<_Kits::PCDWriter>();
                    }
                    m_pcdWriter->addFrame(data->mvec_data_surface, data->mstr_createtime);
                }
            }
            else
            {
                // 队列为空时休眠，避免忙等待
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            }
        }
    }

    /**
     * @brief 根据角度获取方位信息
     * @param angle_deg 角度值（度）
     * @return 方位字符串（如"右"、"右上"等）
     */
    QString RadarController::GetDirection(float angle_deg)
    {
        angle_deg = std::fmod(angle_deg + 360.0, 360.0); // 确保 0-360° 范围

        // 根据角度划分方向
        if (angle_deg <= 15 || angle_deg > 345)
        {
            return "右";
        }
        else if (angle_deg <= 75)
        {
            return "右上";
        }
        else if (angle_deg <= 105)
        {
            return "上";
        }
        else if (angle_deg <= 165)
        {
            return "左上";
        }
        else if (angle_deg <= 195)
        {
            return "左";
        }
        else if (angle_deg <= 255)
        {
            return "左下";
        }
        else if (angle_deg <= 295)
        {
            return "下";
        }
        else
        {
            return "右下";
        }
    }

    /**
     * @brief 接收位置信息
     * @param var 位置信息变体
     *
     * 根据接收到的位置信息更新当前位置，并相应地管理PCD文件的保存。
     */
    void RadarController::recvLocationInfo(const TIS_Info::LocationData &data)
    {

        m_locationData = data;
        // auto station = data.station_name;

        if (m_locationData.station_name != m_str_now_location)
        {

            if (m_locationData.station_name.isEmpty())
            {
                m_str_now_location.clear();
                stopSavePcd();
            }
            else if (m_locationData.station_name != m_str_now_location)
            {
                QString filename;

                if (m_str_now_location.isEmpty())
                {
                    filename = m_locationData.station_name + QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss");
                }
                else
                {
                    filename = m_str_now_location + "____" + m_locationData.station_name +
                               QDateTime::currentDateTime().toString("yyyy-MM-dd-hh-mm-ss");
                }

                QString dirPath = m_taskInfo.strTaskSavePath + "/radar_data";
                QString filePath = dirPath + "/" + filename + ".mp4";

                // 创建目录结构
                QDir dir;
                if (!dir.exists(dirPath))
                {
                    if (!dir.mkpath(dirPath))
                    {
                        qWarning() << "Failed to create directory:" << dirPath;
                        _Kits::LogError("[HikCamera::onStartRecordOneCame] 创建文件夹失败，录像失败");
                        return;
                    }
                }

                m_str_now_location = m_locationData.station_name;
                startSavePcd(filename, dirPath);
            }
        }
    }

    /**
     * @brief 停止保存PCD文件
     *
     * 完成当前PCD文件的写入并关闭文件。
     */
    void RadarController::stopSavePcd()
    {
        if (nullptr != m_pcdWriter)
        {
            m_pcdWriter->finish();
        }
    }

    /**
     * @brief 开始保存PCD文件
     * @param fileName 文件名
     *
     * 创建新的PCD文件并开始写入雷达点云数据。
     */
    void RadarController::startSavePcd(const QString fileName, const QString filePath)
    {
        if (nullptr != m_pcdWriter)
        {
            if (filePath.isEmpty() && m_taskInfo.strTaskSavePath.isEmpty())
            {
                return;
            }

            QString fullFilePath;

            if (!filePath.isEmpty())
            {
                // 如果提供了filePath，优先使用filePath作为目录路径
                fullFilePath = filePath + "/" + fileName + ".pcd";
            }
            else
            {
                // 否则使用任务保存路径
                fullFilePath = m_taskInfo.strTaskSavePath + "/" + fileName + ".pcd";
            }

            m_pcdWriter->start(fullFilePath);
        }
    }
} // namespace _Controllers