#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"

#include "kits/product_kits/radar/pcd_writer/PCDWriter.h"
#include "kits/product_kits/radar/data_process/RadarHistory.h"
#include "kits/product_kits/radar/data_process/RadarRecord.h"
#include "kits/product_kits/radar/data_process/RadarOverrun.h"

#include "kits/third_devices/radar_kit/base/DeviceDeal.h"

#include "kits/utility/object_pool/ObjectPool.h"

#ifndef Q_MOC_RUN
#ifdef emit
#undef emit
#include <tbb/concurrent_queue.h>
#define emit
#else
#include <tbb/concurrent_queue.h>
#endif // emit
#endif // Q_MOC_RUN

namespace _Controllers {

class RadarRecord;
class RadarOverrun;
class PCDWriter;

/**
 * @class RadarController
 * @brief 雷达控制器类，负责处理雷达数据的接收、分析、存储和展示
 *
 * 该类继承自ControllerBase，实现了雷达数据的处理流程，包括数据接收、表面分析、
 * 超限检测、数据存储和界面展示等功能。
 */
class RadarController : public ControllerBase<RadarController>
{
  public:
    // 任务接口方法
    void sendState(QString); // 发送状态信息

    void recvTaskInfo(const TIS_Info::TaskInfo &);         // 接收任务信息
    void recvLocationInfo(const TIS_Info::LocationData &); // 接收位置信息

    /**
     * @brief 可以说是RadarController的构造函数
     * @param configPath 配置文件路径
     * @param deviceDealMap 设备处理映射
     *
     * 停止所有线程，等待线程结束，并确保PCD文件写入器正确关闭。
     */
    void startRadarRecord(
        std::string configPath,
        std::shared_ptr<std::unordered_map<unsigned short, std::unique_ptr<_Kits::DeviceDeal>>> deviceDealMap); // 开始雷达记录

    /**
     * @brief 可以说是RadarController的析构函数
     *
     * 停止所有线程，等待线程结束，并确保PCD文件写入器正确关闭。
     */
    void onStopCtrl();

    // 任务列表定义
    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::RadarService::sendStateToQml, RadarController::sendState);

    // 开始结束
    SYNC_TASK_ADD(TIS_Info::RadarService::stopCtrl, RadarController::onStopCtrl);
    SYNC_TASK_ADD(TIS_Info::RadarService::startSingal, RadarController::startRadarRecord);

    // 接收其他信息
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskBegin, RadarController::recvTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::TaskService::taskEnd, RadarController::recvTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::LocationService::LocationRadio, RadarController::recvLocationInfo);

    ASYNC_TASK_ADD(TIS_Info::OldTask::sendOldTaskBegin, RadarController::recvTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::OldTask::sendOldTaskEnd, RadarController::recvTaskInfo);
    ASYNC_TASK_ADD(TIS_Info::OldLocation::sendPositionOut, RadarController::recvLocationInfo);

    TASK_LIST_END

  private:
    // 数据处理方法
    void dealSurfaceDataThread();                                                       // 表面数据处理线程
    void surfaceDataAnalysis(std::shared_ptr<TIS_Info::DeviceSurfaceData> surfaceData); // 表面数据分析
    void sendDataToQml(std::shared_ptr<TIS_Info::DeviceSurfaceData> surfaceData);       // 发送数据到QML界面
    void deviceDataNormal();                                                            // 处理正常数据的线程
    void deviceDataOverrun();                                                           // 处理超限数据的线程
    void sendOverConfig(std::vector<TIS_Info::DeviceSingleData>);                       // 发送超限配置
    QString GetDirection(float angle_deg);                                              // 获取方位信息
    void stopSavePcd();                                                                 // 停止保存pcd文件
    void startSavePcd(const QString fileName, const QString filePath = "");             // 开始保存pcd文件

    void restartRadar();
    void combineRadarData();
    void initRadarDev();
    void readRadarConfig(const std::string &configPath);

  private:
    // 设备处理映射
    std::shared_ptr<std::unordered_map<unsigned short, std::unique_ptr<_Kits::DeviceDeal>>> m_devDealMap;
    std::unordered_map<unsigned short, TIS_Info::DeviceSurfaceData> m_devDataMap;
    std::mutex m_mutex_devDataMap;

    // 对象池
    std::shared_ptr<_Kits::ObjectPool<TIS_Info::DeviceSurfaceData>> m_devAllDataPool;
    std::shared_ptr<_Kits::ObjectPool<TIS_Info::DeviceSurfaceData>> m_devSingleDataPool;

    // 数据存储
    std::vector<std::vector<TIS_Info::DeviceSingleData>> mvec_datatoQml;                              // 待发送到QML的数据
    std::unordered_map<std::string, std::string> m_over_cloudId_map;                                  // 超限点云id映射表
    std::unordered_map<std::string, std::vector<TIS_Info::DeviceSingleData>> m_over_cloudId_data_map; // 超限点云数据映射表

    // 数据队列
    tbb::concurrent_queue<std::shared_ptr<TIS_Info::DeviceSurfaceData>> m_deviceSurfaceDataQueue; // 设备表面数据队列
    tbb::concurrent_queue<std::shared_ptr<TIS_Info::DeviceSurfaceData>> m_queueDeviceDataNormal;  // 正常数据队列
    tbb::concurrent_queue<std::shared_ptr<TIS_Info::DeviceSurfaceData>> m_queueDeviceDataOverrun; // 超限数据队列

    // 任务和配置信息
    std::mutex m_mutex_task;                             // 任务信息互斥锁
    TIS_Info::TaskInfo m_taskInfo;                       // 任务信息
    std::vector<TIS_Info::OverrunInfo> m_overrunInfovec; // 超限信息向量
    int m_iIndex = -1;                                   // 上一次超限信息的index位置
    TIS_Info::SkewInfo m_skew_info;                      // 偏移信息

    // 线程控制
    std::atomic_bool m_stop = false;     // 停止标志
    std::thread m_dealNormalDataThread;  // 正常数据处理线程
    std::thread m_dealOverrunDataThread; // 超限数据处理线程
    std::thread m_dealSurfaceDataThread; // 表面数据处理线程

    // 功能组件指针
    std::unique_ptr<_Kits::RadarRecord> m_radarRecordSql; // 雷达记录数据库指针
    std::unique_ptr<_Kits::RadarOverrun> m_radarOverrun;  // 超限检测指针
    std::unique_ptr<_Kits::PCDWriter> m_pcdWriter;        // PCD文件写入器指针
    std::unique_ptr<_Kits::RadarHistory> m_radarHistory;  // 雷达历史数据指针

    // 位置信息
    QString m_str_now_location = "";       // 当前地点信息
    TIS_Info::LocationData m_locationData; // 位置信息
};
} // namespace _Controllers