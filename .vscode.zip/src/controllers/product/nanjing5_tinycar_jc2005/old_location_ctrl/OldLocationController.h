#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include "kits/communication/asio/udp_client/UdpClient.h"

#include <string>
#include <memory>

namespace _Controllers {
class OldLocationController : public ControllerBase<OldLocationController>
{
  private:
    struct SLocationData;

  public:
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::OldLocation::initController, OldLocationController::initController);
    SYNC_TASK_ADD(TIS_Info::OldLocation::stopController, OldLocationController::stopController);
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, OldLocationController::getUdpClient);
    TASK_LIST_END

    void initController(const std::string &uid);
    void stopController();
    void getUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);

  private:
    std::string m_uid;
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    TIS_Info::LocationData m_locationData;

  private:
    void processLocation(std::vector<uint8_t> &&data);

    /// <summary>
    /// 发送速度数据包结构，和C++对应一致
    /// </summary>
    struct SLocationData
    {
        char strStation[64] = {0};
        char strPole[64] = {0};
        float fKilo = 0.0f;
        float fSpeed = 0.0f;

        /// <summary>
        /// 运行方向(-1：方向未知 0：后退 1：前进)
        /// </summary>
        int iDir = 0;
    };
};
} // namespace _Controllers
