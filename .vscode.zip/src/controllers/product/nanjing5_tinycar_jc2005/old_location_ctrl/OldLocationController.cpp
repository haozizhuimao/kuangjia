﻿#include "OldLocationController.h"
#include "tis_global/EnumPublic.h"
#include "service/AppInterface.h"
#include "kits/product_kits/task_helper/TaskSql.h"

namespace _Controllers
{
    void OldLocationController::initController(const std::string &uid)
    {
        m_uid = uid;

        auto udp = _Service::receiverUdpCentergetUdpClient<std::shared_ptr<_Kits::UdpClient>>(uid);

        if (udp == nullptr)
        {
            return;
        }

        m_udpClient = udp;
        m_udpClient.lock()->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) { if (!data) { return; } processLocation(std::vector<uint8_t>(data->begin(), data->end())); });
    }

    void OldLocationController::stopController()
    {
    }

    void OldLocationController::getUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &udpMap)
    {
        auto udp_it = udpMap.find(m_uid);
        if (udp_it == udpMap.end())
        {
            return;
        }

        m_udpClient = udp_it->second;
        m_udpClient.lock()->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) { if (!data) { return; } processLocation(std::vector<uint8_t>(data->begin(), data->end())); });
    }

    void OldLocationController::processLocation(std::vector<uint8_t> &&data)
    {
        static const size_t data_size = sizeof(SLocationData);
        if (data.size() != data_size)
        {
            return;
        }

        // 直接将字节数组转换为SLocationData结构体引用，避免内存拷贝
        // const SLocationData &locationDataRef = *reinterpret_cast<const SLocationData *>(data.data());

        size_t offset = 0;
        SLocationData locationDataRef;
        // 解析 strStation
        memcpy(&locationDataRef.strStation, data.data() + offset, sizeof(locationDataRef.strStation));
        offset += sizeof(locationDataRef.strStation);
        locationDataRef.strStation[sizeof(locationDataRef.strStation) - 1] = '\0';

        // 解析 strPole
        memcpy(locationDataRef.strPole, data.data() + offset, sizeof(locationDataRef.strPole));
        offset += sizeof(locationDataRef.strPole);
        locationDataRef.strPole[sizeof(locationDataRef.strPole) - 1] = '\0';

        // 解析 fKilo
        memcpy(&locationDataRef.fKilo, data.data() + offset, sizeof(locationDataRef.fKilo));
        offset += sizeof(locationDataRef.fKilo);

        // 解析 fSpeed
        memcpy(&locationDataRef.fSpeed, data.data() + offset, sizeof(locationDataRef.fSpeed));
        offset += sizeof(locationDataRef.fSpeed);

        // 解析 iDir
        memcpy(&locationDataRef.iDir, data.data() + offset, sizeof(locationDataRef.iDir));

        m_locationData.station_name = QString::fromLocal8Bit(locationDataRef.strStation);

        m_locationData.pole_name = locationDataRef.strPole;
        m_locationData.mileage_adjust = locationDataRef.fKilo * 1000 * 1000;
        m_locationData.speed = locationDataRef.fSpeed;
        m_locationData.line_direction = locationDataRef.iDir;

        _Service::senderOldLocationsendPositionOut(m_locationData);
    }

} // namespace _Controllers
