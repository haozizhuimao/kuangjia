#pragma once

#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include "tis_global/Struct.h"
#include "kits/communication/asio/udp_client/UdpClient.h"

#include <string>
#include <memory>

namespace _Controllers {
class OldTaskController : public ControllerBase<OldTaskController>
{
  private:
    struct sTaskData;

  public:
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::OldTask::initController, OldTaskController::initController);
    SYNC_TASK_ADD(TIS_Info::OldTask::stopController, OldTaskController::stopController);
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, OldTaskController::getUdpClient);
    TASK_LIST_END

    void initController(const std::string &uid);
    void stopController();
    void getUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);

    void sendOldTaskBegin(const TIS_Info::TaskInfo &taskInfo);
    void sendOldTaskEnd(const TIS_Info::TaskInfo &taskInfo);

  private:
    std::string m_uid;
    std::weak_ptr<_Kits::UdpClient> m_udpClient;
    TIS_Info::TaskInfo m_taskInfo;

  private:
    int saveTaskToPg(TIS_Info::TaskInfo &taskInfo);
    void processTask(std::vector<uint8_t> &&data);

    struct sTaskData
    {
        /// <summary>
        /// 任务状态：0停止，1开始
        /// </summary>
        int state = 0;
        /// <summary>
        /// 任务名
        /// </summary>
        char taskName[64] = {0};
        /// <summary>
        /// 数据库名
        /// </summary>
        char dbName[64] = {0};
        /// <summary>
        /// 检测数据存放的根路径，例如：d://gwkj//20250904//taskName
        /// </summary>
        char taskFilePath[256] = {0};
    };
};
} // namespace _Controllers
