﻿#include "OldTaskController.h"
#include "tis_global/EnumPublic.h"
#include "service/AppInterface.h"
#include "kits/product_kits/task_helper/TaskSql.h"

namespace _Controllers
{
    void OldTaskController::initController(const std::string &uid)
    {
        m_uid = uid;
        auto udp = _Service::receiverUdpCentergetUdpClient<std::shared_ptr<_Kits::UdpClient>>(uid);

        if (udp == nullptr)
        {
            return;
        }

        m_udpClient = udp;
        m_udpClient.lock()->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) { if (!data) { return; } processTask(std::vector<uint8_t>(data->begin(), data->end())); });
    }

    void OldTaskController::stopController()
    {
    }

    void OldTaskController::getUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &udpMap)
    {
        auto udp_it = udpMap.find(m_uid);
        if (udp_it == udpMap.end())
        {
            return;
        }

        m_udpClient = udp_it->second;
        m_udpClient.lock()->subscribe([this](_Kits::UdpClient::SharedDataBuffer data) { if (!data) { return; } processTask(std::vector<uint8_t>(data->begin(), data->end())); });
    }

    void OldTaskController::sendOldTaskBegin(const TIS_Info::TaskInfo &taskInfo)
    {
        _Service::senderOldTasksendOldTaskBegin(taskInfo);
    }

    void OldTaskController::sendOldTaskEnd(const TIS_Info::TaskInfo &taskInfo)
    {
        _Service::senderOldTasksendOldTaskEnd(taskInfo);
    }

    int OldTaskController::saveTaskToPg(TIS_Info::TaskInfo &taskInfo)
    {
        auto task_id = _Kits::TaskSql::insertTaskToDB(QDateTime::currentDateTime(), taskInfo);
        return task_id;
    }

    void OldTaskController::processTask(std::vector<uint8_t> &&data)
    {
        static const size_t data_size = sizeof(sTaskData);
        if (data.size() != data_size)
        {
            return;
        }
        // 直接将字节数组转换为sTaskData结构体引用，避免内存拷贝
        // const sTaskData &taskDataRef = *reinterpret_cast<const sTaskData *>(data.data());
        size_t offset = 0;
        sTaskData taskDataRef;
        static int state = -1;
        memcpy(&taskDataRef.state, data.data() + offset, sizeof(taskDataRef.state));
        offset += sizeof(taskDataRef.state);

        std::memcpy(taskDataRef.taskName, data.data() + offset, sizeof(taskDataRef.taskName));
        offset += sizeof(taskDataRef.taskName);

        std::memcpy(taskDataRef.dbName, data.data() + offset, sizeof(taskDataRef.dbName));
        offset += sizeof(taskDataRef.dbName);

        std::memcpy(taskDataRef.taskFilePath, data.data() + offset, sizeof(taskDataRef.taskFilePath));

        // 确保字符串正确终止
        taskDataRef.taskName[sizeof(taskDataRef.taskName) - 1] = '\0';
        taskDataRef.dbName[sizeof(taskDataRef.dbName) - 1] = '\0';
        taskDataRef.taskFilePath[sizeof(taskDataRef.taskFilePath) - 1] = '\0';

        if (taskDataRef.state == state)
        {
            return;
        }
        state = taskDataRef.state;

        // 停止
        if (taskDataRef.state == 0)
        {
            m_taskInfo.nTaskstate = TIS_Info::TaskState::TASK_STOPPED;
            sendOldTaskEnd(m_taskInfo);
        }
        // 开始
        else if (taskDataRef.state == 1)
        {

            m_taskInfo.nTaskstate = TIS_Info::TaskState::TASK_START;
            m_taskInfo.strTaskName = QString::fromLocal8Bit(taskDataRef.taskName);
            m_taskInfo.strTaskSavePath = QString::fromLocal8Bit(taskDataRef.taskFilePath);
            m_taskInfo.nTaskID = saveTaskToPg(m_taskInfo);

            m_taskInfo.strCreateTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
            m_taskInfo.strSubWayNum = "none";
            m_taskInfo.strLineName = "none";
            m_taskInfo.strStartStation = "none";
            m_taskInfo.strEndStation = "none";
            m_taskInfo.strStartPole = "none";
            m_taskInfo.dKilometer = 0.0;
            m_taskInfo.nLineDirection = 0;
            m_taskInfo.nDirection = 0;
            m_taskInfo.timestamp = QDateTime::currentMSecsSinceEpoch();
            m_taskInfo.taskType = 0;

            if (m_taskInfo.nTaskID == -1)
            {
                taskDataRef.state = 0;
                return;
            }

            sendOldTaskBegin(m_taskInfo);
        }
    }

} // namespace _Controllers
