#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
//#include "tis_global/Function.h"
#include <string>
#include "tis_global/Struct.h"
namespace _Controllers {
class QmlRadarData : public ControllerBase<QmlRadarData>
{
  public:
    void onResourceInfo(TIS_Info::QmlCommunication::ForQmlSignals, const QVariant &);
    void sendStateToQml(QString);
    void overinfoSendQml(QString);
    void overRunConfigSend(QVariant);
    void sendPointDataToQml(QVariant);

    void getlocation(const TIS_Info::LocationData &);
    void getTask(const TIS_Info::TaskInfo &);

    TASK_LIST_BEGIN
    ASYNC_TASK_ADD(TIS_Info::HardwareManager::resourceInfo, QmlRadarData::onResourceInfo);
    ASYNC_TASK_ADD(TIS_Info::RadarService::sendStateToQml, QmlRadarData::sendStateToQml);
    ASYNC_TASK_ADD(TIS_Info::RadarService::overinfoSendQml, QmlRadarData::overinfoSendQml);
    ASYNC_TASK_ADD(TIS_Info::RadarService::overConfigSend, QmlRadarData::overRunConfigSend);
    ASYNC_TASK_ADD(TIS_Info::RadarService::showPointData, QmlRadarData::sendPointDataToQml);
    TASK_LIST_END
};
} // namespace _Controllers
