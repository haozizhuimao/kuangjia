#include "QmlRadarData.h"
#include "service/AppInterface.h"
namespace _Controllers
{
    void QmlRadarData::onResourceInfo(TIS_Info::QmlCommunication::ForQmlSignals action, const QVariant &value)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(action, value);
    }
    void QmlRadarData::sendStateToQml(QString state)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::radar_device_state,
                                                      QVariant::fromValue(state));
    }
    void QmlRadarData::overinfoSendQml(QString data)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::radar_overrun_info,
                                                      QVariant::fromValue(data));
    }
    void QmlRadarData::overRunConfigSend(QVariant data)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::radar_overrun_config, data);
    }
    void QmlRadarData::sendPointDataToQml(QVariant data)
    {
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::radar_page, data);
    }

    void QmlRadarData::getlocation(const TIS_Info::LocationData &data)
    {
        QVariantMap map;
        map.insert("stationName", data.station_name);
        map.insert("poleName", data.pole_name);
        map.insert("speed", data.speed);
        map.insert("kiloMeter", data.mileage_adjust);
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvlocation_page,
                                                      QVariant::fromValue(map));
    }

    void QmlRadarData::getTask(const TIS_Info::TaskInfo &data)
    {
        if (data.strTaskName.isEmpty())
        {
            return;
        }

        QString taskName = data.strTaskName;
        _Service::receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::taskname_recv,
                                                      QVariant::fromValue(taskName));
    }

} // namespace _Controllers