#include "RadarPageController.h"
namespace _Controllers
{
    void RadarPageController::onTaskIdChoosed(QVariant)
    {
        return;
    }

} // namespace _Controllers