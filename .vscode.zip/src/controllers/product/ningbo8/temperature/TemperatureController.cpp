#include "TemperatureController.h"
#include "kits/utility/log/CRossLogger.h"
#include "service/AppFramework.h"
#include "kits/common/utils/TimeToString.h"
#include "kits/product_kits/histroy_uniqueidrecv/HistoryUniqueIDRecviever.h"
#include <QPainter>
// using namespace _Controllers;
// using namespace _Kits;
// using namespace _Service;
// using namespace _Modules;

#include <iostream>
namespace _Controllers {
using namespace _Kits;
using namespace _Service;
void TemperatureController::recvIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer)
{
    m_IRImageQueue.pushItemNoBlocking(std::move(IRimagebuffer));
}
void TemperatureController::recvTempRect(const int startx, const int starty, const int endx, const int endy, const int w, const int h)
{
    m_rawRect.startx = startx;
    m_rawRect.starty = starty;
    m_rawRect.endx = endx;
    m_rawRect.endy = endy;
    m_normalwidth = w;
    m_normalheight = h;
}
void TemperatureController::init(const QVariant &data)
{
    if (nullptr == m_infraredGeneral)
    {
        m_infraredGeneral = std::make_unique<_Kits::InfraredGeneral>();
    }
    auto configpath = data.toMap().value("configpath").toByteArray().toStdString();
    auto config = YAML::LoadFile(configpath);

    m_strSavePicRoot = config["rootpath"].as<std::string>();

    auto irconfig = config["irdata"];
    float fAlarmTemp1 = irconfig["alarmtemp1"].as<double>();
    float fAlarmTemp2 = irconfig["alarmtemp2"].as<double>();
    float fAlarmTemp3 = irconfig["alarmtemp3"].as<double>();

    m_infraredGeneral->updataAlarmTemp(fAlarmTemp1, fAlarmTemp2, fAlarmTemp3);

    m_fmaxTemperature_calibration = irconfig["maxtemperatrue"].as<double>();
    m_favgTemperature_coefficient = irconfig["avgtemperatrue_coeff"].as<double>();
    m_iAlarmTimeInterval = irconfig["limittime"].as<uint32_t>();
    m_getTemperatrueType = irconfig["irtype"].as<uint32_t>();
    m_savepicflag = irconfig["savepicflag"].as<uint32_t>();
    m_startFalg.store(true);
    m_IRImageThread = std::thread(&TemperatureController::handleIRImageThread, this);
}
void TemperatureController::notifyTaskfunc(const QVariant &data)
{
    auto taskinfomap = data.toMap();
    auto taskname = taskinfomap.value("taskname").toByteArray().toStdString();

    auto taskstate = taskinfomap.value("taskstate").toInt();
    if (0 == taskstate)
    {
        // m_iSaveImgCount = 0;
        createSaveDiretory(taskname);
        // m_taskFlag.store(true);
    }
    else if (1 == taskstate)
    {
        m_iSaveImgCount = 0;
        m_taskFlag.store(false);
    }
}
void TemperatureController::stop()
{
    exitthread();
}
void TemperatureController::sendDisplayLog(const QString &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::displaylog_send, QVariant::fromValue(data));
}
void TemperatureController::handleIRImageThread()
{
    std::shared_ptr<TIS_Info::IRImageBuffer> IRimagebuffer = nullptr;
    while (m_startFalg.load())
    {
        {
            IRimagebuffer = m_IRImageQueue.popItem();
        }
        if (nullptr == IRimagebuffer)
        {
            break;
        }

        dealSendToQmlData(IRimagebuffer, m_rawRect);
        QPoint tempPoint;
        if (0 != updateTempValue(IRimagebuffer, tempPoint))
        {
            continue;
        }

        sendMaxTempToQml(QVariant::fromValue(m_maxtemp.load()));

        dealIRImageData(IRimagebuffer, tempPoint);
    }
}

int TemperatureController::updateTempValue(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, QPoint &maxTempPoint)
{
    if (nullptr == IRimagebuffer)
    {
        return 1;
    }

    if (1 == m_getTemperatrueType)
    {
        IRRuleRect normalRect;
        InfraredGeneral::normalizeRuleRect(
            m_rawRect, IRimagebuffer->width, IRimagebuffer->height, m_normalwidth, m_normalheight, normalRect);
        float maxTemp = 0.0;
        float minTemp = 0.0;
        IRPoint maxTempIRPoint;
        InfraredGeneral::analysisHotPicData(
            IRimagebuffer->tempdata.data(), normalRect, IRimagebuffer->width, minTemp, maxTemp, maxTempIRPoint);
        m_mintemp.store(minTemp);
        m_maxtemp.store(maxTemp);
        maxTempPoint.setX(maxTempIRPoint.x);
        maxTempPoint.setY(maxTempIRPoint.y);
    }
    else
    {
        m_maxtemp.store(IRimagebuffer->maxtemp);
        m_mintemp.store(IRimagebuffer->mintemp);
        maxTempPoint.setX(IRimagebuffer->maxpointx * IRimagebuffer->width);
        maxTempPoint.setY(IRimagebuffer->maxpointy * IRimagebuffer->height);
    }

    auto maxTemp = m_favgTemperature_coefficient * m_maxtemp.load() + m_fmaxTemperature_calibration;
    m_maxtemp.store(maxTemp);

    return 0;
}
void TemperatureController::dealSendToQmlData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, _Kits::IRRuleRect &rawRect)
{
    if (nullptr == IRimagebuffer)
    {
        LogError("IRImageBuffer is null");
        return;
    }

    if (0 == m_normalheight || 0 == m_normalwidth)
    {
        return;
    }

    QByteArray byteArray(reinterpret_cast<const char *>(IRimagebuffer->data.data()), IRimagebuffer->iamgesize);
    QImage image = QImage::fromData(byteArray, "JPG");

    int offsetx = rawRect.startx * IRimagebuffer->width / m_normalwidth;
    int offsety = rawRect.starty * IRimagebuffer->height / m_normalheight;
    int endoffsetx = rawRect.endx * IRimagebuffer->width / m_normalwidth;
    int endoffsety = rawRect.endy * IRimagebuffer->height / m_normalheight;

    QPainter painter(&image);
    QPoint topleft(offsetx, IRimagebuffer->height - endoffsety);
    QPoint bottomRight(endoffsetx, IRimagebuffer->height - offsety);
    QRect rect(topleft, bottomRight);
    painter.setPen(Qt::green);
    painter.setBrush(Qt::NoBrush); // 不填充
    painter.drawRect(rect);        // 绘制矩形

    QVariantMap imgMap;
    imgMap["img"] = image.convertToFormat(QImage::Format_BGR888);
    imgMap["camera_name"] = QString::fromStdString("");

    sendImage(QVariant::fromValue(imgMap));
}
void TemperatureController::dealIRImageData(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer, const QPoint &maxTempPoint)
{
    if (!m_taskFlag.load())
    {
        return;
    }

    bool bLimitByTime = true;
    auto now = std::chrono::high_resolution_clock::now();
    auto durationtime = std::chrono::duration_cast<std::chrono::seconds>(now - m_saveImageTime);

    if (m_saveImageTime != std::chrono::steady_clock::time_point(std::chrono::seconds(0)) && durationtime.count() < m_iAlarmTimeInterval)
    {
        bLimitByTime = false;
    }

    int alarmLevel = m_infraredGeneral->isAlarm(m_maxtemp.load());
    std::string picname = "";
    if (alarmLevel > 0)
    {
        if (bLimitByTime)
        {
            m_saveImageTime = now;
            if (alarmLevel <= m_savepicflag)
            {
                picname = generatePictureName();
                saveIRImage(IRimagebuffer, picname, maxTempPoint);
            }
        }
        QString strShowMaxTemp = "最高温度:" + QString::number(m_maxtemp.load()) + "警告等级:" + QString::number(alarmLevel);
        sendDisplayLog(strShowMaxTemp);
    }
    if (!bLimitByTime)
    {
        alarmLevel = 0;
    }

    float avgtemp = (m_mintemp + m_maxtemp) / 2;
    dealIRAlarmData(alarmLevel, m_mintemp.load(), m_maxtemp.load(), avgtemp, picname);
}

void TemperatureController::saveIRImage(std::shared_ptr<TIS_Info::IRImageBuffer> &IRimagebuffer,
                                        const std::string &picname,
                                        const QPoint &maxTempPoint)
{
    if (nullptr == IRimagebuffer)
    {
        return;
    }

    QByteArray byteArray(reinterpret_cast<const char *>(IRimagebuffer->data.data()), IRimagebuffer->iamgesize);
    QImage image = QImage::fromData(byteArray, "JPG");
    QPainter paintermax(&image);

    QPoint topleft = maxTempPoint - QPoint(20, 20);
    QPoint bottomRight = maxTempPoint + QPoint(20, 20);
    QRect rect(topleft, bottomRight);

    paintermax.setPen(Qt::black);
    paintermax.setBrush(Qt::NoBrush); // 不填充
    paintermax.drawRect(rect);        // 绘制矩形
    paintermax.setFont(QFont("Arial", 10));
    paintermax.drawText(maxTempPoint.x(), maxTempPoint.y() + 15, QString::number(m_maxtemp.load()));

    image.save((QString::fromLocal8Bit(picname.data())));
}
void TemperatureController::createSaveDiretory(const std::string &taskName)
{
    LogInfo("ArcDataDeal::startTask:{}", taskName);
    QString strPath = QString::fromStdString(m_strSavePicRoot);
    // std::filesystem::path path(strPath.toStdWString());
    std::filesystem::path path(strPath.toStdWString());
    path.append(TimeToString::getYearMonthDayStr());
    path.append(taskName);
    path.append(L"红外超限");

    m_taskSvaePath = path.string();

    if (!std::filesystem::exists(path))
    {
        if (std::filesystem::create_directories(path))
        {
            m_iSaveImgCount = 0;
            LogInfo("Directories created successfully:{}", path.string());
        }
        else
        {
            LogError("Failed to create directories:{}", path.string());
        }
    }
    LogInfo("start success:{}", m_taskSvaePath);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));
    m_taskFlag.store(true);
}
std::string TemperatureController::generatePictureName()
{
    std::string strPicName = std::to_string(m_iSaveImgCount++) + "_" + TimeToString::getHourMinSecStr() + "_" + std::to_string(0) + "_" +
                             std::to_string(0) + ".jpg";

    std::string picname = m_taskSvaePath + "\\" + strPicName;
    return picname;
}
void TemperatureController::dealIRAlarmData(int level, float mintemp, float maxtemp, float avgtemp, const std::string &picname)
{
    size_t last_backslash = picname.find_last_of('\\');
    size_t second_last_backslash = std::string::npos;
    if (last_backslash != std::string::npos && last_backslash > 0)
    {
        second_last_backslash = picname.find_last_of('\\', last_backslash - 1);
    }
    std::string irPicpath = picname;
    if (second_last_backslash != std::string::npos)
    {
        irPicpath = picname.substr(second_last_backslash);
    }

    long long lFileTime = 0;
    double dtimeStamp = 0;
    HistoryUniqueIDRecviever::Instance().getFileTimeAndTimeStamp(lFileTime, dtimeStamp);
    QVariantMap irDatamap;
    irDatamap.insert("irlevel", level);
    irDatamap.insert("mintemperature", mintemp);
    irDatamap.insert("maxtemperature", maxtemp);

    irDatamap.insert("lltimestamp", lFileTime);
    irDatamap.insert("dtimestamp", dtimeStamp);
    irDatamap.insert("avgtemperature", avgtemp);
    QByteArray picpath = QByteArray::fromRawData(irPicpath.data(), irPicpath.size());
    irDatamap.insert("picpath", QByteArray(picpath.constData(), picpath.size()));
    invokeHistroyProgramCommwriteIRData_V(QVariant::fromValue(irDatamap));

    if (level > 0)
    {
        QVariantMap IRamifDatamap;
        IRamifDatamap.insert("amiflevel", level);
        IRamifDatamap.insert("amiftype", 1);
        IRamifDatamap.insert("lltimestamp", lFileTime);
        IRamifDatamap.insert("dtimestamp", dtimeStamp);

        invokeHistroyProgramCommsendAmifData_V(QVariant::fromValue(IRamifDatamap));
    }
}
void TemperatureController::sendImage(const QVariant &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::egvvideo_page, data);
}
void TemperatureController::sendMaxTempToQml(const QVariant &data)
{
    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::maxtemp_recv, data);
}
void TemperatureController::exitthread()
{
    m_startFalg.store(false);
    recvIRImageData(nullptr);
    if (m_IRImageThread.joinable())
    {
        m_IRImageThread.join();
    }
}
} // namespace _Controllers