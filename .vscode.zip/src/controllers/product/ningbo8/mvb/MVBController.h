#pragma once
#include "kits/primary/controller_base/ControllerBase.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "kits/communication/asio/tcp_client/TcpClient.h"
//#include "tis_global/Function.h"
#include <memory>
#include <qcontainerfwd.h>
#include <unordered_map>
#include <vector>
#include <yaml-cpp/yaml.h>

namespace _Controllers {
class MVBController : public ControllerBase<MVBController>
{
  public:
    explicit MVBController();
    ~MVBController() noexcept;
    void setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &);
    TASK_LIST_BEGIN
    SYNC_TASK_ADD(TIS_Info::UdpCenter::dispatchClient, MVBController::setUdpClient);
    SYNC_TASK_ADD(TIS_Info::MVBDataSwitch::switchConfigData, MVBController::setConfigSwitch);
    TASK_LIST_END

  private:
    void onUdpDataReceived(const std::vector<uint8_t> &&data);
    void setConfigSwitch(const TIS_Info::MvbAmifSwitch &,
                         const TIS_Info::MvbAsatSwitch &,
                         const TIS_Info::TrdpConfig &,
                         const TIS_Info::MvbPublic &);

  private:
    void heartFunc();
    void sendAliveData();
    // 解析公共数据
    void parseCommonData(const std::vector<uint8_t> &, QVariantMap &);
    // 解析trdp协议头
    void parseTrdpHeader(const std::vector<uint8_t> &, TIS_Info::TrdpHeader &);
    // 界面展示接收数据
    void displayRecvPortData(QVariantMap &);
    // 界面展示心跳数据
    void displayHeartData();
    // 解析心跳数据
    void parseHeartData(const std::vector<uint8_t> &, QVariantMap &);
    int getConfVersion(const std::string &);

    const std::string m_udpName = "mvb";
    const std::string m_mvbHeartName = "mvb_heart";
    std::atomic_bool m_bHolder = true;
    std::weak_ptr<_Kits::UdpClient> m_udpAtcClient;
    std::weak_ptr<_Kits::UdpClient> m_udpHeartClient;
    std::vector<uint8_t> m_recvData;
    int m_headLength = 0;
    TIS_Info::TrdpConfig m_trdpConfig;

    std::vector<uint8_t> m_heartData;

    std::thread m_thHeart;
    uint16_t m_aliveId = 0; // 使用无符号自增id，数值轮转类型安全

    uint16_t m_version = 0;
};
} // namespace _Controllers
