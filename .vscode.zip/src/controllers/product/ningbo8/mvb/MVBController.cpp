﻿#include "MVBController.h"
#include "kits/third_devices/duagon/mvb_tools/ByteArrayTools.h"
#include "kits/utility/log/CRossLogger.h"
#include "kits/communication/asio/udp_client/UdpClient.h"
#include "service/AppInterface.h"
#include <QObject>
#include <qcontainerfwd.h>
#include <QVariantMap>
#include <QDateTime>
#include <regex>

namespace _Controllers {
using namespace _Kits;
using namespace _Service;
MVBController::MVBController()
{
    m_headLength = sizeof(TIS_Info::TrdpHeader);
    m_recvData.resize(m_headLength + 200, 0);
    m_heartData.resize(m_headLength + 32, 0);
    m_thHeart = std::thread(&MVBController::heartFunc, this); // 初始化完成后再启动线程，访问安全
}
MVBController::~MVBController() noexcept
{
    m_bHolder.store(false);
    if (m_thHeart.joinable())
        m_thHeart.join();
}

void MVBController::setUdpClient(const std::unordered_map<std::string, std::shared_ptr<_Kits::UdpClient>> &clients)
{
    // mvb atc数据接收
    auto atcClient = clients.find(m_udpName);
    if (atcClient == clients.end())
    {
        LogError("can not find udp client.name = {}", m_udpName);
        return;
    }
    auto udpClient = atcClient->second;
    m_udpAtcClient = udpClient;
    udpClient->subscribe([this](_Kits::UdpClient::SharedDataBuffer datas) { if (!datas) { return; } onUdpDataReceived(std::vector<uint8_t>(datas->begin(), datas->end())); });

    auto heartClient = clients.find(m_mvbHeartName);
    if (heartClient == clients.end())
    {
        LogError("can not find udp client.name = {}", m_mvbHeartName);
        return;
    }
    auto mvbudpHeartClient = heartClient->second;
    m_udpHeartClient = mvbudpHeartClient;
}

void MVBController::parseCommonData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 25);
    uint8_t stationData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 64);
    std::bitset<8> stationBit(stationData);
    // 报站数据有效
    outputData["stationVaild"] = static_cast<bool>(stationBit[0]);
    // 列车车次号
    outputData["uiTrainNumber"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 65);
    // 站点信息-下一站
    outputData["uiNextStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 67);
    // 站点信息-当前站
    outputData["uiCurrentStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 68);
    // 站点信息-终点站
    outputData["uiEndStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 69);
    // 站点信息-起始站
    outputData["uiStartStation"] = ByteArrayTools::readFromVectorBE<uint8_t>(data, 70);
    uint8_t modeData = ByteArrayTools::readFromVectorBE<uint8_t>(data, 71);
    std::bitset<8> bit(modeData);
    // 列车在下行线
    outputData["down"] = static_cast<bool>(bit[7]);
    // 列车在上行线
    outputData["up"] = static_cast<bool>(bit[6]);
}

void MVBController::displayRecvPortData(QVariantMap &portData)
{
    // 给页面传递数据展示
    QVariantMap mapData;

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    portData["recvTime"] = timeFmt;

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(portData));
}

void MVBController::setConfigSwitch(const TIS_Info::MvbAmifSwitch &amif,
                                    const TIS_Info::MvbAsatSwitch &asat,
                                    const TIS_Info::TrdpConfig &trdpConfig,
                                    const TIS_Info::MvbPublic &mvbConf)
{
    m_trdpConfig = trdpConfig;
    m_version = getConfVersion(mvbConf.version);
}

void MVBController::onUdpDataReceived(const std::vector<uint8_t> &&data)
{
    if (data.size() < m_headLength)
    {
        return;
    }
    //  解析trdp头
    TIS_Info::TrdpHeader header;
    parseTrdpHeader(data, header);
    // 解析数据内容
    QVariantMap dataMap;
    std::vector<uint8_t> commonData(data.begin() + m_headLength, data.end());
    parseCommonData(commonData, dataMap);
    // LogDebug("recv udp all data,header.headerFcs={}, comId={},stationVaild={},up={},down={},size={},data={}",
    //          header.headerFcs,
    //          header.comId,
    //          dataMap["stationVaild"].toInt(),
    //          dataMap["up"].toBool(),
    //          dataMap["down"].toBool(),
    //          data.size(),
    //          ByteArrayTools::hexString(data.data(), data.size()));
    dataMap["dataSource"] = "ningbo8_atc_data";
    // 上行用41100站台数据，下行用46100站台数据
    if ((dataMap["up"].toBool() && header.comId == m_trdpConfig.commonComID) ||
        (dataMap["down"].toBool() && header.comId == m_trdpConfig.tcmsComID))
    {
        displayRecvPortData(dataMap);
        // LogDebug("recv udp comId={},stationVaild={},data={}",
        //          header.comId,
        //          dataMap["stationVaild"].toInt(),
        //          ByteArrayTools::hexString(commonData.data(), commonData.size()));
        if (auto strongPtr = m_udpAtcClient.lock())
        {
            strongPtr->post("mvb_atc", std::move(commonData));
        }
    }
}

void MVBController::parseTrdpHeader(const std::vector<uint8_t> &data, TIS_Info::TrdpHeader &header)
{
    if (data.size() == 0)
    {
        return;
    }
    header.sequenceCounter = ByteArrayTools::readFromVectorBE<uint32_t>(data, 0);
    header.protocolVersion = ByteArrayTools::readFromVectorBE<uint16_t>(data, 4);
    header.msgType = ByteArrayTools::readFromVectorBE<uint16_t>(data, 6);
    header.comId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 8);
    header.etbTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 12);
    header.opTrnTopoCnt = ByteArrayTools::readFromVectorBE<uint32_t>(data, 16);
    header.datasetLength = ByteArrayTools::readFromVectorBE<uint32_t>(data, 20);
    header.reserved01 = ByteArrayTools::readFromVectorBE<uint32_t>(data, 24);
    header.replyComId = ByteArrayTools::readFromVectorBE<uint32_t>(data, 28);
    header.replyIpAddress = ByteArrayTools::readFromVectorBE<uint32_t>(data, 32);
    header.headerFcs = ByteArrayTools::readFromVectorBE<uint32_t>(data, 36);
}

void MVBController::heartFunc()
{
    std::chrono::steady_clock::time_point nextClock = std::chrono::steady_clock::now(); // 下次执行时刻
    std::chrono::milliseconds interval = std::chrono::milliseconds(500);
    while (m_bHolder)
    {
        auto tagTime = std::chrono::steady_clock::now();
        std::chrono::duration<double> sec = tagTime.time_since_epoch();
        auto h = std::chrono::duration_cast<std::chrono::hours>(sec);
        auto m = std::chrono::duration_cast<std::chrono::minutes>(sec) - h;
        auto s = std::chrono::duration_cast<std::chrono::seconds>(sec) - h - m;
        auto us = std::chrono::duration_cast<std::chrono::microseconds>(sec - h - m - s);

        // 计算下次唤醒时间
        auto nextWakeTime = std::chrono::steady_clock::time_point::max();
        auto now = std::chrono::steady_clock::now();
        if (now >= nextClock)
        {
            nextClock = now + interval;
            sendAliveData();
        }
        nextWakeTime = std::min(nextWakeTime, nextClock);
        auto sendTime = std::chrono::steady_clock::now();
        LogDebug("sendAliveData time={}", std::chrono::duration<double, std::milli>(sendTime - tagTime).count());
        // 等待到下次执行时间
        if (nextWakeTime != std::chrono::steady_clock::time_point::max())
        {
            std::this_thread::sleep_until(nextWakeTime);
        }
        else
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        auto sleepTime = std::chrono::steady_clock::now();
        LogDebug("sleep time={},total time={},steady_clock={}:{}:{}.{}",
                 std::chrono::duration<double, std::milli>(sleepTime - sendTime).count(),
                 std::chrono::duration<double, std::milli>(sleepTime - tagTime).count(),
                 h.count(),
                 m.count(),
                 s.count(),
                 us.count());
    }
}

void MVBController::parseHeartData(const std::vector<uint8_t> &data, QVariantMap &outputData)
{
    if (data.size() == 0)
    {
        return;
    }
    // CCU生命信号
    outputData["tcmsAlive"] = ByteArrayTools::readFromVectorBE<uint16_t>(data, 0);
    // 受电弓
    std::bitset<8> b2Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 2));
    // 受电弓姿态异常告警
    outputData["strAttitudeAlarm"] = static_cast<bool>(b2Bit[0]);
    // 受电弓碳滑板异常告警
    outputData["strCarbonStripAlarm"] = static_cast<bool>(b2Bit[1]);
    // 受电弓弓头异常告警
    outputData["strBowheadAlarm"] = static_cast<bool>(b2Bit[2]);
    // 受电弓羊角异常告警
    outputData["yangjiaoAlarm"] = static_cast<bool>(b2Bit[4]);
    // 受电弓检测到异物告警
    outputData["foreignAlarm"] = static_cast<bool>(b2Bit[5]);
    // 受电弓导流线异常故障
    outputData["diversionLieAlarm"] = static_cast<bool>(b2Bit[7]);

    std::bitset<8> b3Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 3));
    // 燃弧严重告警
    outputData["arcAlaLevel1"] = static_cast<bool>(b3Bit[0]);
    // 燃弧中等告警
    outputData["arcAlaLevel2"] = static_cast<bool>(b3Bit[1]);
    // 燃弧轻微告警
    outputData["arcAlaLevel3"] = static_cast<bool>(b3Bit[2]);
    // 磨耗轻微告警
    outputData["abrAlaLevel3"] = static_cast<bool>(b3Bit[4]);
    // 磨耗中等告警
    outputData["abrAlaLevel2"] = static_cast<bool>(b3Bit[5]);
    // 磨耗严重告警
    outputData["abrAlaLevel1"] = static_cast<bool>(b3Bit[6]);

    std::bitset<8> b4Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 4));
    // 温度轻微告警
    outputData["tmpAlaLevel3"] = static_cast<bool>(b4Bit[0]);
    // 温度中等告警
    outputData["tmpAlaLevel2"] = static_cast<bool>(b4Bit[1]);
    // 温度严重告警
    outputData["tmpAlaLevel1"] = static_cast<bool>(b4Bit[2]);

    std::bitset<8> b5Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 5));
    // 接触网硬点轻微告警
    outputData["hardPotAlaLevel3"] = static_cast<bool>(b5Bit[0]);
    // 接触网硬点中等告警
    outputData["hardPotAlaLevel2"] = static_cast<bool>(b5Bit[1]);
    // 接触网硬点严重告警
    outputData["hardPotAlaLevel1"] = static_cast<bool>(b5Bit[2]);
    // 弓网接触力轻微告警
    outputData["contactForcAlaLevel3"] = static_cast<bool>(b5Bit[4]);
    // 弓网接触力中等告警
    outputData["contactForcAlaLevel2"] = static_cast<bool>(b5Bit[5]);
    // 弓网接触力严重告警
    outputData["contactForcAlaLevel1"] = static_cast<bool>(b5Bit[6]);

    std::bitset<8> b6Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 6));
    // 拉出值超限轻微告警
    outputData["zigzagAlaLevel3"] = static_cast<bool>(b6Bit[0]);
    // 拉出值超限中等告警
    outputData["zigzagAlaLevel2"] = static_cast<bool>(b6Bit[1]);
    // 拉出值超限严重告警
    outputData["zigzagAlaLevel1"] = static_cast<bool>(b6Bit[2]);
    // 回流轨水平间距轻微告警
    outputData["hspaceAlaLevel3"] = static_cast<bool>(b6Bit[4]);
    // 回流轨水平间距中等告警
    outputData["hspaceAlaLevel2"] = static_cast<bool>(b6Bit[5]);
    // 回流轨水平间距严重告警
    outputData["hspaceAlaLevel1"] = static_cast<bool>(b6Bit[6]);

    std::bitset<8> b7Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 7));
    // 导高值超限轻微告警
    outputData["wireHeiAlaLevel3"] = static_cast<bool>(b7Bit[0]);
    // 导高值超限中等告警
    outputData["wireHeiAlaLevel2"] = static_cast<bool>(b7Bit[1]);
    // 导高值超限严重告警
    outputData["wireHeiAlaLevel1"] = static_cast<bool>(b7Bit[2]);
    // 回流轨垂直高度轻微告警
    outputData["retRailSpaceAlaLevel3"] = static_cast<bool>(b7Bit[4]);
    // 回流轨垂直高度中等告警
    outputData["retRailSpaceAlaLevel2"] = static_cast<bool>(b7Bit[5]);
    // 回流轨垂直高度严重告警
    outputData["retRailSpaceAlaLevel1"] = static_cast<bool>(b7Bit[6]);

    std::bitset<8> b8Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 8));
    // 回流轨硬点轻微告警
    outputData["retRailHardPotAlaLevel3"] = static_cast<bool>(b8Bit[0]);
    // 回流轨硬点中等告警
    outputData["retRailHardPotAlaLevel2"] = static_cast<bool>(b8Bit[1]);
    // 回流轨硬点严重告警
    outputData["retRailHardPotAlaLevel1"] = static_cast<bool>(b8Bit[2]);

    std::bitset<8> b10Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 10));
    // 温度检测模块故障
    outputData["tmpModFault"] = static_cast<bool>(b10Bit[0]);
    // 弓网视频模块故障
    outputData["videoFault"] = static_cast<bool>(b10Bit[1]);
    // 燃弧模块故障
    outputData["arcModFault"] = static_cast<bool>(b10Bit[2]);
    // 硬点模块故障
    outputData["hardPotModFault"] = static_cast<bool>(b10Bit[3]);
    // 压力模块故障
    outputData["pressureModFault"] = static_cast<bool>(b10Bit[4]);
    // 接触网几何、磨耗检测模块故障
    outputData["geoAbrModFault"] = static_cast<bool>(b10Bit[5]);
    // 巡检录像模块故障
    outputData["insVideoModFault"] = static_cast<bool>(b10Bit[6]);
    // 巡检抓拍模块故障
    outputData["insSnapModFault"] = static_cast<bool>(b10Bit[7]);

    std::bitset<8> b11Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 11));
    // 硬盘故障
    outputData["nvrDskFault"] = static_cast<bool>(b11Bit[0]);
    // 接触网巡检拍照模块故障
    outputData["xunjianPhotoModFault"] = static_cast<bool>(b11Bit[1]);
    // 回流轨几何参数检测模块故障
    outputData["retRailGeoModFault"] = static_cast<bool>(b11Bit[2]);
    // 回流轨视频模块故障
    outputData["retRailCameraFault"] = static_cast<bool>(b11Bit[3]);
    // 回流轨硬点检测模块故障
    outputData["retRailHardPotModFault"] = static_cast<bool>(b11Bit[4]);
    // MP1车压力硬点采集主机
    outputData["mp1HardPotHost"] = static_cast<bool>(b11Bit[7]);

    std::bitset<8> b12Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 12));
    // MP1车温度检测模块状态
    outputData["mp1TmpModStatus"] = static_cast<bool>(b12Bit[0]);
    // 高清模块状态（远端弓网视频）
    outputData["hdVideoModStatus"] = static_cast<bool>(b12Bit[1]);
    // MP1车燃弧模块状态
    outputData["mp1ArcModStatus"] = static_cast<bool>(b12Bit[2]);
    // MP1车硬点模块状态
    outputData["mp1HardPotModStatus"] = static_cast<bool>(b12Bit[3]);
    // MP1车压力模块状态
    outputData["mp1PressureModStatus"] = static_cast<bool>(b12Bit[4]);
    // MP1车接触网几何、磨耗检测模块
    outputData["mp1GeoAbrModStatus"] = static_cast<bool>(b12Bit[5]);
    // MP1车车底补偿模块状态0
    outputData["mp1UnderbodyModStatus"] = static_cast<bool>(b12Bit[6]);
    // 通信模块故障
    outputData["netModFault"] = static_cast<bool>(b12Bit[7]);

    std::bitset<8> b13Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 13));
    // 硬盘故障(仅宁波6有)
    outputData["dskFault6"] = static_cast<bool>(b13Bit[0]);
    // MP1车接触网巡检拍照模块0
    outputData["mp1InsSnapMod0"] = static_cast<bool>(b13Bit[1]);
    // MP1车回流轨几何参数检测模块0
    outputData["mp1RetRailGeoMod0"] = static_cast<bool>(b13Bit[2]);
    // MP1车回流轨与回流器视频监控模块0
    outputData["mp1RetRailCameraMod0"] = static_cast<bool>(b13Bit[3]);
    // MP1车回流轨硬点模块状态
    outputData["mp1RetRailHardPotMod"] = static_cast<bool>(b13Bit[4]);
    // MP1车接触网巡检拍照模块1
    outputData["mp1XunjianPhotoMod1"] = static_cast<bool>(b13Bit[5]);
    // MP1车接触网巡检触发模块0
    outputData["mp1XunjianTriggerMod0"] = static_cast<bool>(b13Bit[6]);
    // MP1车接触网巡检拍照模块2
    outputData["mp1XunjianPhotoMod2"] = static_cast<bool>(b13Bit[7]);

    std::bitset<8> b14Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 14));
    // Mp1接触网巡检拍照模块3
    outputData["mp1XunjianCamera3Fault"] = static_cast<bool>(b14Bit[0]);
    // Mp1接触网巡检触发模块1
    outputData["mp1XunjianTrigger1Fault"] = static_cast<bool>(b14Bit[1]);
    // Mp1接触网连续视频模块0
    outputData["mp1Video0Fault"] = static_cast<bool>(b14Bit[2]);
    // Mp1接触网连续视频模块1
    outputData["mp1Video1Fault"] = static_cast<bool>(b14Bit[3]);
    // 弓网视频监控1（近端）
    outputData["camera1Fault"] = static_cast<bool>(b14Bit[4]);
    // Mp1车体振动补偿检测模块1
    outputData["mp1Compensation1Fault"] = static_cast<bool>(b14Bit[5]);
    // Mp1回流轨几何参数检测模块1
    outputData["mp1GeoMod1Fault"] = static_cast<bool>(b14Bit[6]);
    // Mp1回流轨与回流器视频监控模块1
    outputData["mp1Camera1Fault"] = static_cast<bool>(b14Bit[7]);

    std::bitset<8> b25Bit(ByteArrayTools::readFromVectorBE<uint8_t>(data, 25));
    // 响应休眠指令
    outputData["responseSleepCmd"] = static_cast<bool>(b25Bit[3]);
    // 自检结果
    outputData["chkRes"] = static_cast<bool>(b25Bit[4]);
    // 自检完成
    outputData["chkComplete"] = static_cast<bool>(b25Bit[5]);
    // 自检中断
    outputData["chkBreakoff"] = static_cast<bool>(b25Bit[6]);
    // 上电自检中
    outputData["chking"] = static_cast<bool>(b25Bit[7]);
    // 软件版本
    outputData["version"] = QString("0x%1").arg(ByteArrayTools::readFromVectorBE<uint16_t>(data, 30), 2, 16, QChar('0')).toUpper();
}

void MVBController::displayHeartData()
{
    // 转发数据到界面
    QVariantMap heartData;
    std::vector<uint8_t> data(m_heartData.begin() + m_headLength, m_heartData.end());
    parseHeartData(data, heartData);

    QDateTime time = QDateTime::currentDateTime();
    QString timeFmt = time.toString("yyyy-MM-dd HH:mm:ss.zzz");
    heartData["sendTime"] = timeFmt;
    heartData["dataSource"] = "ningbo8_heart";

    receiverQmlPrivateEnginecallFromCpp(TIS_Info::QmlCommunication::ForQmlSignals::display_mvb_data, QVariant::fromValue(heartData));
}

void MVBController::sendAliveData()
{
    if (auto strongPtr = m_udpHeartClient.lock())
    {
        ++m_aliveId; // 心跳id自增

        TIS_Info::TrdpHeader header;
        header.comId = m_trdpConfig.heartComID; // 4X150
        header.sequenceCounter = m_aliveId;
        header.datasetLength = 32;
        header.protocolVersion = 0x0100;
        header.msgType = 0x5064;
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, m_aliveId, 0);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.protocolVersion, 4);
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, header.msgType, 6);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.comId, 8);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.etbTopoCnt, 12);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.opTrnTopoCnt, 16);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.datasetLength, 20);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.reserved01, 24);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyComId, 28);
        ByteArrayTools::writeToVectorBE<uint32_t>(m_heartData, header.replyIpAddress, 32);

        // 生成校验码
        header.headerFcs = ByteArrayTools::getTrdpHeaderChecksum(m_heartData, 36);
        // LogInfo("sheader.headerFcs={}", header.headerFcs);
        //  协议里面定义的是大端，但是四方是按小端来的
        ByteArrayTools::writeToVectorLE<uint32_t>(m_heartData, header.headerFcs, 36);

        // 应用数据
        // TCMS生命信号异常
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_aliveId, m_headLength + 0);
        // 自检结果
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 25, 4, true);
        // 自检完成
        ByteArrayTools::setBitInVectorLSB(m_heartData, m_headLength + 25, 5, true);
        // 软件版本
        ByteArrayTools::writeToVectorBE<uint16_t>(m_heartData, m_version, m_headLength + 30);
        auto headvector = m_heartData;
        auto time = std::chrono::steady_clock::now();
        strongPtr->post("mvb_heart", std::move(headvector));
        std::vector<uint8_t> processData(m_heartData.begin() + m_headLength, m_heartData.end());
        LogDebug("time={},send comID={},size={},data={}",
                 std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - time).count(),
                 header.comId,
                 processData.size(),
                 ByteArrayTools::hexString(processData.data(), processData.size()));

        displayHeartData();
    }
}
int MVBController::getConfVersion(const std::string &versionStr)
{
    if (versionStr.empty())
    {
        return 0;
    }

    int majorVersion = 0;
    int minorVersion = 0;
    int patchVersion = 0;

    std::smatch m;
    static const std::regex whole(R"(\b(\d+)\.(\d+)\.(\d+)\b)");
    if (!std::regex_search(versionStr, m, whole))
    {
        return 0;
    }
    majorVersion = std::stoi(m[1]);
    minorVersion = std::stoi(m[2]);
    patchVersion = std::stoi(m[3]);
    return (majorVersion << 8) | (minorVersion << 4) | (patchVersion & 0x0F);
}

} // namespace _Controllers

