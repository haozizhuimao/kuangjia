
add_custom_target(copy_config_file ALL
    COMMAND ${CMAKE_COMMAND} -E copy
        "${CMAKE_SOURCE_DIR}/.version"
        "${CMAKE_RUNTIME_OUTPUT_DIRECTORY}"
)

add_subdirectory(kits)
add_subdirectory(modules)
add_subdirectory(controllers)
add_subdirectory(service)
