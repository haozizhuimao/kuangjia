# doc 目录说明

`doc/` 用来放项目专题文档和历史资料。

## 当前基线文档

- [架构说明](architecture.md)
- [构建与运行](build-run.md)
- [版本矩阵](version-matrix.md)
- [配置约定](config-conventions.md)

## 历史资料

本目录里还保留了一些已有资料，例如：

- `RESTful API文档.md`
- `conan2部署流程.docx`
- `JCWLib开发库使用说明(v0.02).pdf`
- `mvb配置说明.docx`
- `PostgreSQL安装教程2025.2.10.pdf`
- `VsCode + Qt6.8.1安装.pdf`

## 维护约定

- 以后只维护中文版本
- 专题文档放在这里
- 目录级说明放在各自目录根 README
