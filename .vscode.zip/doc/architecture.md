# 架构说明

## 文档目标

这份文档描述仓库当前已经存在的结构和装配方式，帮助开发同事快速定位代码，不描述尚未完成的理想态。

## 启动链路

当前主启动入口如下：

1. `src/main.cpp`
2. `service/AppFramework.h`
3. `service/AppFrameworkImpl.cpp` 或 `service/AppFrameworkServiceImpl.cpp`
4. `SystemConfigGuard` 加载 `.version` 与 `config/config.yaml`
5. `AppFramework*::createModules()` 根据主配置遍历模块
6. `ControllerRegister` / `ModuleRegister` 完成控制器与模块桥接

几个关键事实：

- `.version` 同时参与构建期和运行期。
- 运行期配置入口当前是 `config/config.yaml`。
- 控制台模式与 Qt 模式共用同一套模块创建流程，但事件循环不同。

## 分层结构

### `src/kits`

基础能力层，偏“可复用工具箱”，当前可见的代表性子域包括：

- `primary/`：模块基类、工厂、线程池、I/O 管理、dump
- `utility/`：日志、时间、配置、字符串、序列化、Excel
- `communication/`：远程通信、TCP/UDP、Kafka 等
- `database/`：PostgreSQL / SQLite 抽象与实现
- `common/`：相机、视频、算法、MVB、雷达、RFID、红外等通用业务能力
- `ui/`：QML 引擎与配置操作

`src/kits/CMakeLists.txt` 当前像一个手工/半自动维护的开关文件，只编入部分基础 kit。

### `src/modules`

业务模块层，负责把 kit 组合成可启动的服务能力。当前数量较多，典型模块包括：

- `database_manager`
- `location_service`
- `task_service`
- `hik_manager`
- `video_encoder`
- `remote_access`
- `histroy_program_comm`

模块通常由主配置中的节点名触发创建，并由 `ModuleBase` 读取 `config_path` 指向的 YAML。

### `src/controllers`

控制器与场景编排层，主要有三种形态：

- 通用控制器，例如 `task_controller`、`qml`、`remote_access`
- 产品控制器，位于 `product/*`
- 开发/测试控制器，位于 `unit_test/*`

这一层承担“把模块能力注册成具体流程”的职责，因此同一模块可以被多个产品版本复用。

### `src/service`

应用壳层，负责：

- 选择 Console / Qt 入口
- 初始化配置、日志、线程和事件循环
- 按主配置创建并启动模块

### `src/tis_global`

全局共享类型层，集中放枚举和结构体定义，例如相机、定位、任务、温湿度等公共数据结构。

## 版本装配机制

### 构建期

构建期由以下链路完成版本选择：

1. 根目录 `.version` 提供 `CURRENT_VERSION`
2. 根 `CMakeLists.txt` 包含 `tis_cmake/version_build/version_build.cmake`
3. `src/CMakeLists.txt` 根据 `CURRENT_VERSION` 继续包含 `tis_cmake/version_build/<CURRENT_VERSION>.cmake`
4. 版本文件向 `MODS_CONFIGS` 与 `CTLS_CONFIGS` 填入模块和控制器
5. `src/modules/CMakeLists.txt` 与 `src/controllers/CMakeLists.txt` 根据这两个列表装配目标

### UI 资源期

如果 `BUILD_UI_TYPE` 为 `QT5` 或 `QT6`，还会继续包含：

- `tis_cmake/qml_build/<CURRENT_VERSION>.cmake`

当前仓库中已存在的 QML 构建清单只有：

- `0_FULL_VERSION`
- `CHONGQING27`
- `NINGBO8_CONTINUOUS_VIDEO`
- `SHENZHEN16`

这意味着不是每个 UI 版本都已经在仓库内补齐 QML 资源清单。

### 运行期

运行期会读取 `.version`，并把版本值转成小写保存；但当前配置主入口并不会自动切换到 `config/<version>/config.yaml`。现状是：

- `SystemConfig` 当前直接读取 `config/config.yaml`
- `ModuleBase` 当前把 `config_path` 解析到 `config/` 根目录下
- 仓库同时保留了大量 `config/<scene>/config.yaml`
- 许多模块/控制器代码仍保留 `configVersionPath()` 风格的旧引用

因此，代码装配与运行配置正处于迁移中的混合状态。

## UI 模式差异

### `CONSOLE`

- 使用 `tis_cmake/root_cmake/root_console.cmake`
- 目标为普通控制台程序
- `service/AppFrameworkServiceImpl.cpp` 会分配控制台并等待用户输入 `Q`

### `QT5`

- 使用 `tis_cmake/root_cmake/root_qt5.cmake`
- 依赖固定 Qt5 路径配置
- 通过兼容封装添加 QML 模块

### `QT6`

- 使用 `tis_cmake/root_cmake/root_qt6.cmake`
- 依赖 `Qt6 6.8`
- 使用 `qt_add_qml_module` 管理 QML 资源

## 配置加载现状

当前至少存在两套并存的配置使用习惯：

### 现行主路径

- `config/config.yaml` 是启动时一定会读的主配置
- 主配置中的模块节点通过 `config_path` 指向二级 YAML
- `ModuleBase` 以 `config/` 作为根目录解析该路径

### 历史/迁移中路径

- 各产品目录下存在 `config/<scene>/config.yaml`
- 许多模块和控制器仍引用 `configVersionPath()` 风格接口
- 代码中存在 `UIEngine`、`QmlPrivateEngine`、`Dispatch6017`、`Device6017Manager` 等新旧命名并存

如果你在排查产品配置问题，必须同时核对代码调用链和 `config/` 目录，不要只看 `.version`。

## 当前命名债与入口漂移

仓库中已经能观察到以下历史债：

- `roseek` 与 `rossek` 并存
- `histroy` 与 `history` 并存
- `version_build` 里仍有 `connectivity_service`、`rfid_recv_service`、`pressure_spot_service`、`udp6017_manager`、`mvb_msg_forward` 等与现有 `src/modules/` 不一致的名字
- `ROSEEK_VIDEO` 版本文件指向 `product/ningbo8_roseek_video`，但当前控制器目录并不在该路径

这些内容应视为“当前现状”，不是可直接依赖的规范。

## 推荐定位顺序

遇到一个版本时，建议按这个顺序定位：

1. 看 `.version`
2. 看 `tis_cmake/version_build/<CURRENT_VERSION>.cmake`
3. 看对应控制器目录或通用控制器目录
4. 看主配置 `config/config.yaml`
5. 再看具体模块或产品配置目录

## 相关文档

- [构建与运行](build-run.md)
- [版本矩阵](version-matrix.md)
- [配置约定](config-conventions.md)
