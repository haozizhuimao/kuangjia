# 配置约定

## 文档目标

这份文档只记录仓库当前可以确认的配置组织方式，帮助开发同事理解 `config/` 目录的结构与现状。

## 当前可见的配置根

仓库里至少有两类配置资源：

### 1. 根配置

- `config/config.yaml`

这是当前启动时会被直接读取的主配置入口。`SystemConfig` 会从当前工作目录下读取这个文件。

### 2. 场景配置目录

例如：

- `config/chongqing27`
- `config/jc24-18hefeiS1`
- `config/ningbo8_continuous_video`
- `config/ningbo8_low`
- `config/shenzhen8_video`
- `config/taiyuans1`
- `config/wulumuqi2`

这些目录通常包含：

- 一个产品级 `config.yaml`
- 若干模块子目录
- 各模块自己的 YAML / INI / CSV / SQL 等文件

## 当前主加载链路

根据 `src/kits/utility/system_config/system_config_impl.cpp` 和 `src/kits/primary/module_base/ModuleBase.cpp`，当前主路径是：

1. 工作目录下读取 `config/config.yaml`
2. 按主配置中的模块名寻找节点
3. 读取该节点里的 `config_path`
4. 以 `config/` 为根目录拼接二级配置文件路径

这意味着当前可直接确认的事实是：

- 主程序并不是自动从 `config/<version>/config.yaml` 起步
- 二级配置默认仍以根 `config/` 为解析根目录

## 迁移中的旧路径痕迹

仓库里仍然能看到大量旧式路径引用，例如：

- `configVersionPath()`
- `QmlPrivateEngine` 与 `UIEngine` 并存
- `Dispatch6017` 与 `Device6017Manager` 并存
- 场景目录自己的 `config.yaml`

因此，当前配置体系不能简单理解成“单一规范已完成”。

## `config_path` 约定

从现有 YAML 注释和代码看，`config_path` 有这些共同点：

- 常以 `/` 开头
- 路径分隔使用 `/`
- 注释中明确提到路径不建议包含空格和中文
- 用于指向模块自己的二级配置文件

示例：

```yaml
TcpClientCenter:
  config_path: '/tcp_client_center/client_init.yaml'

HikManager:
  config_path: '/camera_config/hik/camera_info.yaml'

AlgorithmService:
  config_path: '/algorithm_service/algorithm.yaml'
```

## 当前已存在的特殊值

根配置中并不是所有 `config_path` 都指向一个真实 YAML 文件。现有仓库已经出现了这些特殊情况：

- 空字符串：`''`
- 字符串占位：`"default"`
- 字符串占位：`'null'`

例如：

- `MVBCommunication`
- `DwcDataDispatch`
- `HttpClientStore`
- `VideoSaver`

这说明不同模块对 `config_path` 的解释并不完全一致，排查问题时需要回到具体模块实现。

## 常见目录模式

### 通用目录

根 `config/` 下可以看到的常见模块目录包括：

- `camera_config/`
- `database_manager/`
- `controller_manager/`
- `udp_center/`
- `tcp_client_center/`
- `tcp_server_center/`
- `rfid_config/`
- `hik_manager/`
- `simulation_service/`

### 产品目录

产品目录通常按“场景 -> 模块子目录”的方式组织，例如：

```text
config/jc24-18hefeiS1/
|-- config.yaml
|-- camera_config/
|-- jihe_config/
|-- qml_config/
|-- tcp_client_center/
|-- temperature_humidity_config/
`-- ...
```

## 典型示例

### 示例 1：根配置

`config/config.yaml` 当前包含：

- `app`
- `log`
- 多个模块节点
- 每个模块通过 `config_path` 或内嵌字段提供自己的配置入口

### 示例 2：产品配置目录

`config/jc24-18hefeiS1/config.yaml` 当前可见：

- `QmlPrivateEngine`
- `DatabaseManager`
- `LocationService`
- `TaskService`
- `UdpCenter`
- `HikManager`
- `Dispatch6017`
- `Sensor6051DataOut`

这说明产品目录里的节点名和根配置里的节点名并不总是完全一致。

### 示例 3：视频编码配置

`config/ningbo8_continuous_video/video_encoder_config/video_encoder.yaml` 当前采用列表形式，包含：

- `title`
- `width`
- `height`
- `fps`
- `avcodeid`
- `codecname`
- `subtitleinfo`

## 当前容易踩坑的点

### 1. 误以为 `.version` 会自动切运行配置

当前可确认的代码路径并不支持这个结论。

### 2. 根配置与产品配置混淆

仓库同时存在：

- `config/config.yaml`
- `config/<scene>/config.yaml`

二者在当前代码中的使用范围并不完全统一。

### 3. 节点命名不统一

现有例子包括：

- `UIEngine` vs `QmlPrivateEngine`
- `Device6017Manager` vs `Dispatch6017`
- `Sensor6051Manager` vs `Sensor6051DataOut`

### 4. 路径存在历史拼写

例如：

- `histroy_program_comm`
- `roseek_service`
- `rossek_service`

### 5. 配置文件格式不止 YAML

仓库中同时存在：

- `.yaml`
- `.ini`
- `.json`
- `.csv`
- `.sql`
- `.db`

## 维护建议

在当前状态下，修改配置时建议遵循：

1. 先确认代码实际读的是根配置还是场景配置
2. 再确认模块实现是否仍引用旧路径接口
3. 最后再调整 `config_path` 或具体配置文件内容

如果没有做过调用链确认，不建议仅凭目录名推断配置一定会生效。

## 相关文档

- [架构说明](architecture.md)
- [构建与运行](build-run.md)
- [版本矩阵](version-matrix.md)
