# 构建与运行

## 当前推荐路径

当前仓库推荐的基线路径是：

- 平台：Windows
- 编译器：MSVC
- 生成器：Ninja
- 依赖管理：Conan2
- UI：按需显式选择 `QT6`、`QT5` 或 `CONSOLE`

Linux 相关脚本仍然存在，但还没有与 Windows Conan2 主路径统一。

## 构建前准备

### 必备工具

- Visual Studio / MSVC 工具链
- `cl.exe`
- `ninja`
- `conan`
- CMake 3.23+

### Qt 条件

- `QT6` 模式需要 Qt 6.8 组件
- `QT5` 模式需要 Qt 5.15 组件，并依赖 `tis_cmake/root_cmake/root_qt5.cmake` 中固定的 Qt5 路径
- `CONSOLE` 模式不依赖 Qt UI 资源

### Conan profile 现状

仓库内可见的 Windows profile：

- `conan2/profiles/windows-debug`
- `conan2/profiles/windows-release`

两者都固定为：

- `compiler=msvc`
- `compiler.cppstd=20`
- `compiler.version=194`
- `tools.cmake.cmaketoolchain:generator="Ninja"`

Linux profile 文件当前存在但为空：

- `conan2/profiles/linux-debug`
- `conan2/profiles/linux-release`

## Windows Conan2 构建流程

### 方案 A：直接运行仓库脚本

`conan_install.ps1` 会同时准备 Windows Debug 与 Release 依赖，适合首次搭环境。

```powershell
powershell -ExecutionPolicy Bypass -File .\conan_install.ps1
```

### 方案 B：只生成一个工具链

如果你只需要 Debug，可以直接执行：

```powershell
conan install . `
  --output-folder=conan2/x64-windows-debug `
  --profile:host=conan2/profiles/windows-debug `
  --profile:build=conan2/profiles/windows-debug `
  --build=missing `
  --deployer=full_deploy
```

Release 类似，只需把输出目录和 profile 切到 `windows-release`。

## CMake 配置示例

### Qt6 Debug

```powershell
cmake -S . -B build/windows-debug `
  -G Ninja `
  -DCMAKE_BUILD_TYPE=Debug `
  -DBUILD_UI_TYPE=QT6 `
  -DCMAKE_TOOLCHAIN_FILE=conan2/x64-windows-debug/conan_toolchain.cmake

cmake --build build/windows-debug
```

### Console Debug

```powershell
cmake -S . -B build/console-debug `
  -G Ninja `
  -DCMAKE_BUILD_TYPE=Debug `
  -DBUILD_UI_TYPE=CONSOLE `
  "-DCMAKE_TOOLCHAIN_FILE=conan2/x64-windows-debug/conan_toolchain.cmake"

cmake --build build/console-debug
```

### Duagon MVB 板块单目标验证

```powershell
cmake --build build/console-debug --target duagon_vendor_sdk
cmake --build build/console-debug --target kit_mvb_communication
```

### Qt5 Debug

```powershell
cmake -S . -B build/qt5-debug `
  -G Ninja `
  -DCMAKE_BUILD_TYPE=Debug `
  -DBUILD_UI_TYPE=QT5 `
  -DCMAKE_TOOLCHAIN_FILE=conan2/x64-windows-debug/conan_toolchain.cmake

cmake --build build/qt5-debug
```

## 输出目录

根据 `tis_cmake/platform/platform.cmake`，当前输出规则是：

- 可执行文件：`<repo>/<arch>-<os>-<buildtype>`
- 静态/动态库：`<repo>/libs`

例如 Windows Debug 默认输出到：

- `x64-windows-debug`

注意：这和 `build/<name>` 这种 CMake 构建目录不是同一个位置。

## 运行注意事项

### 当前工作目录很重要

当前代码通过 `std::filesystem::current_path()` 读取：

- `config/config.yaml`
- `.version`

因此运行时请确保当前工作目录能够访问这两个路径。最稳妥的做法是：

- 让 IDE 的 working directory 指向仓库根目录
- 或者手工保证运行目录下有对应的 `config/` 与 `.version`

### Qt 版本与 QML 清单

Qt 模式下，配置阶段会尝试包含：

- `tis_cmake/qml_build/<CURRENT_VERSION>.cmake`

当前仓库内只有以下版本可直接找到该文件：

- `0_FULL_VERSION`
- `CHONGQING27`
- `NINGBO8_CONTINUOUS_VIDEO`
- `SHENZHEN16`

如果你切到其他 UI 版本但没有对应 QML 清单，配置阶段可能直接失败。

### Release 部署行为

Windows 下：

- Conan deploy 目录中的 DLL 会在构建后被复制到运行目录
- Release 还会额外嵌入管理员权限 manifest
- `tools/tis_daemon.exe` 与 `tools/tis_daemon_start.bat` 会被复制到运行目录

## Linux 现状

仓库保留了：

- `build.sh`
- `build_test.sh`

但它们当前仍然指向 vcpkg 路径，并不等于 Windows Conan2 主路径的镜像实现。现阶段更合适的结论是：

- Linux 路线仍在历史/待统一状态
- 不建议把这两个脚本当作当前文档基线

## 常见失败点

### 1. 忘记传 `BUILD_UI_TYPE`

根 `CMakeLists.txt` 没有为 `BUILD_UI_TYPE` 提供默认值，必须显式设置。

### 2. QML 清单缺失

切到 Qt 版本但 `tis_cmake/qml_build/<CURRENT_VERSION>.cmake` 不存在。

### 3. Qt 环境不完整

尤其是 `QT5` 模式，当前脚本里使用的是固定路径。

### 4. 工作目录错误

程序能编出来，但运行时找不到：

- `config/config.yaml`
- `.version`

### 5. 版本文件引用漂移

部分 `version_build` 条目仍指向当前仓库中不存在的模块或控制器，例如：

- `connectivity_service`
- `rfid_recv_service`
- `pressure_spot_service`
- `udp6017_manager`
- `mvb_msg_forward`
- `product/ningbo8_roseek_video`

## 推荐实践

- 优先从 `0_FULL_VERSION` 或已有 QML 清单的版本开始排障
- 改 `.version` 后重新配置 CMake，不要只增量编译
- UI 相关问题先同时核对 `version_build` 和 `qml_build`
- 运行问题先核对 working directory 与 `config/config.yaml`

## 相关文档

- [架构说明](architecture.md)
- [版本矩阵](version-matrix.md)
- [配置约定](config-conventions.md)
