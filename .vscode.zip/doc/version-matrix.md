# 版本矩阵

## 文档目标

这份文档记录仓库当前可见的 `CURRENT_VERSION` 标识，以及它们在源码中的主要入口位置。这里的“入口”优先指：

- `tis_cmake/version_build/<CURRENT_VERSION>.cmake`
- 对应的控制器入口目录或通用控制器组合

当前默认版本是：

```ini
CURRENT_VERSION=0_FULL_VERSION
```

## 全量版本列表

说明：

- “控制器入口”来自 `CTLS_CONFIGS`
- “QML 清单”表示仓库内是否存在 `tis_cmake/qml_build/<CURRENT_VERSION>.cmake`
- `TIANJING5_TEMPERATURE` 当前版本文件里没有声明模块和控制器

| CURRENT_VERSION | 控制器入口 | QML 清单 |
| --- | --- | --- |
| `0_DEV_HZK_VERSION` | `unit_test/hzk_ctls` | No |
| `0_DEV_HZY_VERSION` | `unit_test/hzy_ctls` | No |
| `0_DEV_LC_VERSION` | `unit_test/lc_ctls` | No |
| `0_DEV_YH_VERSION` | `product/shenzhen8_video` | No |
| `0_DEV_YJY_VERSION` | `product/tianjin5_3d_camera` | No |
| `0_DEV_ZDT_VERSION` | `unit_test/zdt_ctls` | No |
| `0_DEV_ZJY_VERSION` | `unit_test/zjy_ctls` | No |
| `0_DEV_ZZH_VERSION` | `unit_test/zzh_ctrls` | No |
| `0_FULL_VERSION` | `task_controller`, `jihe_yanyan`, `location_engineering`, `qml`, `remote_access`, `rfid`, `sensor6051`, `device6017`, `simulation` | Yes |
| `CHANGCHUN3` | `product/changchun3` | No |
| `changchun3_J4045` | `product/changchun3_J4045` | No |
| `CHANGCHUN3rfid` | `product/changchun3rfid` | No |
| `CHONGQING_RING` | `product/chongqing_ring` | No |
| `CHONGQING27` | `task_controller`, `jihe_yanyan`, `location_engineering`, `qml`, `remote_access`, `rfid_kpcid`, `sensor6051`, `device6017`, `roseek_arc`, `infrared_temperature`, `baian_presssure` | Yes |
| `CONFIGEDITOR` | `product/configeditor` | No |
| `GUIYANGS1` | `product/guiyang_s1` | No |
| `JC22-12_SHANGHAI4C` | `product/jc22-12_shanghai4c` | No |
| `JC24_09guiyangS1` | `product/JC24_09guiyangS1` | No |
| `JC2405HANGDE` | `product/hangde_jc2405` | No |
| `JC24-18HEFEIS1` | `product/jc24-18_hefeiS1` | No |
| `JC2501XUEGUI` | `product/jc2501xuegui` | No |
| `JIYANG` | `product/jiyang` | No |
| `NANJING5_TINYCAR_JC2005` | `product/nanjing5_tinycar_jc2005` | No |
| `NINGBO8_CONTINUOUS_VIDEO` | `product/ningbo8_continuous_video` | Yes |
| `NINGBO8_IR` | `product/ningbo8` | No |
| `NINGBO8_LOW` | `product/ningbo8_low` | No |
| `NINGXIANG` | `product/ningxiang` | No |
| `ROSEEK_VIDEO` | `product/ningbo8_roseek_video`（版本文件声明值，当前目录缺失） | No |
| `SHANGHAI4C` | `product/shanghai_4c` | No |
| `SHANGHAI4C_TEMP` | `product/shanghai_4ctemp` | No |
| `SHENZHEN16` | `task_controller`, `jihe_yanyan`, `location_engineering`, `qml`, `remote_access`, `rfid`, `sensor6051`, `device6017`, `simulation` | Yes |
| `SHENZHEN8_VIDEO` | `roseek_video_service` | No |
| `SHENZHENG16_LINE2` | `product/shenzheng16_line2` | No |
| `SUZHOU1` | `product/taiyuan_s1` | No |
| `TAIYUANS1` | `product/taiyuan_s1` | No |
| `TIANJING5_TEMPERATURE` | `(未声明)` | No |
| `TIANJINZ4XIANJIE` | `product/tianjin_z4_xianjie` | No |
| `TIEJIANUZBEKISTAN` | `product/tiejian_uzbekistan` | No |
| `WULUMUQI2` | `product/wulumuqi2` | No |
| `zhengzhou3_jy` | `product/zhengzhou3_jy` | No |

## 代表版本示例

### `0_FULL_VERSION`

源码入口：

- 版本文件：`tis_cmake/version_build/0_FULL_VERSION.cmake`
- QML 清单：`tis_cmake/qml_build/0_FULL_VERSION.cmake`
- 控制器来源：
  - `src/controllers/task_controller`
  - `src/controllers/jihe_yanyan`
  - `src/controllers/location_engineering`
  - `src/controllers/qml`
  - `src/controllers/remote_access`
  - `src/controllers/rfid`
  - `src/controllers/sensor6051`
  - `src/controllers/device6017`
  - `src/controllers/simulation`

模块列表：

- `ui_engine`
- `database_manager`
- `location_service`
- `task_service`
- `rfid_service`
- `jihe_service`
- `hardware_manager`
- `udp_center`
- `device6017_manager`
- `remote_access`
- `sensor6051_manager`
- `tcp_client_center`
- `yanyan_data_collect`
- `simulation_service`

配置观察：

- 当前运行主入口会读取 `config/config.yaml`
- `0_FULL_VERSION` 是最适合作为通用 smoke build 的起点

### `JC24-18HEFEIS1`

源码入口：

- 版本文件：`tis_cmake/version_build/JC24-18HEFEIS1.cmake`
- 控制器目录：`src/controllers/product/jc24-18_hefeiS1`
- 典型配置目录：`config/jc24-18hefeiS1`

模块列表：

- `ui_engine`
- `database_manager`
- `location_service`
- `task_service`
- `rfid_service`
- `jihe_service`
- `arc_service`
- `hardware_manager`
- `udp_center`
- `udp6017_manager`
- `hik_manager`
- `sensor6051_manager`
- `tcp_client_center`
- `yanyan_data_collect`
- `serial_port_center`
- `temperature_humidity_service`

需要特别注意：

- 版本文件里写的是 `udp6017_manager`
- 当前 `src/modules/` 里可见的是 `device6017_manager`
- 这说明该版本存在模块命名漂移，文档应以现状记录，而不是假设它已经统一

目录示例：

- `config/jc24-18hefeiS1/config.yaml`
- `config/jc24-18hefeiS1/camera_config/hik/camera_info.yaml`
- `config/jc24-18hefeiS1/tcp_client_center/client_init.yaml`
- `config/jc24-18hefeiS1/temperature_humidity_config/temperature_humidity_config.yaml`

### `NINGBO8_CONTINUOUS_VIDEO`

源码入口：

- 版本文件：`tis_cmake/version_build/NINGBO8_CONTINUOUS_VIDEO.cmake`
- QML 清单：`tis_cmake/qml_build/NINGBO8_CONTINUOUS_VIDEO.cmake`
- 控制器目录：`src/controllers/product/ningbo8_continuous_video`
- 典型配置目录：`config/ningbo8_continuous_video`

模块列表：

- `histroy_program_comm`
- `tcp_client_center`
- `simple_mysql_writer`
- `algorithm_service`
- `video_encoder`
- `ui_engine`
- `puller_center`

目录示例：

- `config/ningbo8_continuous_video/algorithm_service/algorithm.yaml`
- `config/ningbo8_continuous_video/histroy_program_comm/communication.yaml`
- `config/ningbo8_continuous_video/puller_center/puller_config.yaml`
- `config/ningbo8_continuous_video/video_encoder_config/video_encoder.yaml`

这个版本比较适合拿来观察“历史通信 + 算法 + 视频编码”这一条线的装配方式。

## 当前可见的矩阵漂移

从 `version_build` 和现有目录对照，当前至少能观察到这些问题：

- `0_DEV_ZDT_VERSION` 仍引用 `connectivity_service`、`rfid_recv_service`、`pressure_spot_service`
- `CHANGCHUN3`、`JC24-18HEFEIS1`、`JC24_09guiyangS1`、`JC22-12_SHANGHAI4C` 仍引用 `udp6017_manager`
- `JC2405HANGDE`、`TAIYUANS1`、`TIANJINZ4XIANJIE` 仍引用 `connectivity_service`
- `SHENZHENG16_LINE2` 仍引用 `mvb_msg_forward`
- `ROSEEK_VIDEO` 当前控制器入口与仓库目录不一致

这些问题会直接影响“按版本切换后是否能顺利配置/构建”的预期。

## 使用建议

- 新同事优先从 `0_FULL_VERSION`、`CHONGQING27`、`NINGBO8_CONTINUOUS_VIDEO` 这些已有 QML 清单或公共控制器清晰的版本入手
- 切换产品版本前，先核对 `version_build`、控制器目录、QML 清单和配置目录四件事
- 看到 `CURRENT_VERSION` 名字时，不要默认它和 `config/<scene>` 完全一一对应

## 相关文档

- [架构说明](architecture.md)
- [构建与运行](build-run.md)
- [配置约定](config-conventions.md)
